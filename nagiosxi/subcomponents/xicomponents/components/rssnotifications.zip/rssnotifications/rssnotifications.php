<?php
// RSS NOTIFICATIONS API
//
// Copyright (c) 2010 Nagios Enterprises, LLC.  All rights reserved.
//  
// $Id: receiver.php 4 2010-04-07 15:49:08Z mmestnik $

require_once(dirname(__FILE__).'/../componenthelper.inc.php');

// initialization stuff
pre_init();

// start session
init_session();

// grab GET or POST variables 
grab_request_vars();

// check prereqs
check_prereqs();


show_feed();


////////////////////////////////////////////////////////////////////////
//  FEED
////////////////////////////////////////////////////////////////////////

function show_feed(){

	$user=grab_request_var("user");
	$key=grab_request_var("key");

	// make sure we have what we need
	if($user=="" || $key==""){
		echo "NO USERNAME OR KEY";
		exit;
		}
		
	// get user id
	$userid=get_user_id($user);
	
	//echo "USERNAME=$user\n";
	//echo "USERID=$userid\n";

	// verify key
	$rssnotifications_key=get_user_meta($userid,'rssnotifications_key');
	//echo "SAVED KEY=$rssnotifications_key\n";
	if($userid==null || $key!=$rssnotifications_key || $rssnotifications_key==null){
		echo "BAD USERNAME OR KEY";
		exit;
		}
		
	//echo "LOOKS OKAY...";
	
	$rssnotifications_raw=get_user_meta($userid,'rssnotifications');
	//echo "RAW\n";
	//print_r($rssnotifications_raw);
	
	$rssnotifications=unserialize($rssnotifications_raw);
	//echo "ARRAY\n";
	//print_r($rssnotifications);
	
	//echo "ARRAY COUNT:=".count($rssnotifications["items"])."\n";
	
	// star the feed
	header("Content-Type: application/xml; charset=ISO-8859-1");
	echo "<?xml version=\"1.0\"?>";
?>
<rss version="2.0">
  <channel>
    <title>Nagios XI Notifications</title>
    <link><?php echo get_base_url();?></link>
    <description>RSS feed of the most recent host and service notifications for <?php echo $user;?></description>
<?php

	$base_url=get_base_url();
	$url=$base_url."/?xiwindow=".$base_url."/includes/components/xicore/status.php";

	$x=0;
	foreach($rssnotifications["items"] as $item){
	
		$url2="";
	
		//print_r($item);
	
		$x++;
				
		// service notification
		if($item["notification-type"]=="service"){
			$title=rssnotifications_component_get_service_subject($userid);
			$desc=rssnotifications_component_get_service_description($userid);
			$url2=urlencode("?show=servicedetail&host=".$item["host"]."&service=".$item["service"]);
			}
		// host notification
		else{
			$title=rssnotifications_component_get_host_subject($userid);
			$desc=rssnotifications_component_get_host_description($userid);
			$url2=urlencode("?show=hostdetail&host=".$item["host"]);
			}
			
		// process variables
		$title=process_notification_text($title,$item);
		$desc=process_notification_text($desc,$item);
		

		echo "<item>\n";
		echo "<title>".htmlentities($title)."</title>\n";
		echo "<link>".$url.$url2."</link>\n";
		echo "<description>".htmlentities($desc)."</description>\n";
		echo "</item>\n";
		}
?>
  </channel>
</rss>

<?php
	}


?>