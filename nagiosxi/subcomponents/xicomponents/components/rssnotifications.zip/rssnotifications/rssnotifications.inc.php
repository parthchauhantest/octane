<?php
// RSS NOTIFICATIONS COMPONENT
//
// Copyright (c) 2010 Nagios Enterprises, LLC.  All rights reserved.
//  
// $Id: isms.inc.php 4 2010-04-07 15:49:08Z mmestnik $

require_once(dirname(__FILE__).'/../componenthelper.inc.php');

$rssnotifications_component_name="rssnotifications";

// run the initialization function
rssnotifications_component_init();

////////////////////////////////////////////////////////////////////////
// COMPONENT INIT FUNCTIONS
////////////////////////////////////////////////////////////////////////

function rssnotifications_component_init(){
	global $rssnotifications_component_name;

	
	$args=array(

		// need a name
		COMPONENT_NAME => $rssnotifications_component_name,
		
		// informative information
		COMPONENT_VERSION => "1.2",
		//COMPONENT_DATE => "11-27-2009",
		COMPONENT_AUTHOR => "Nagios Enterprises, LLC",
		COMPONENT_DESCRIPTION => gettext("Provides notifications via RSS feeds."),
		COMPONENT_TITLE => "RSS Notifications",
		//COMPONENT_COPYRIGHT => "Copyright (c) 2009 Nagios Enterprises",
		//COMPONENT_HOMEPAGE => "http://www.nagios.com",

		// configuration function (optional)
		COMPONENT_CONFIGFUNCTION => "rssnotifications_component_config_func",
		);
		
	register_component($rssnotifications_component_name,$args);
	
		
	// register as a new notification method
	$args=array(
		NOTIFICATIONMETHOD_FUNCTION => 'rssnotifications_component_notificationmethod_func',
		);
	register_notificationmethod('rssnotifications',$args);
	
	// register to add a new tab to the notification menus
	register_callback(CALLBACK_USER_NOTIFICATION_METHODS_TABS_INIT,'rssnotifications_component_methods_addtab');
	register_callback(CALLBACK_USER_NOTIFICATION_MESSAGES_TABS_INIT,'rssnotifications_component_messages_addtab');
	}
	
	

///////////////////////////////////////////////////////////////////////////////////////////
// MENU FUNCTIONS
///////////////////////////////////////////////////////////////////////////////////////////

function rssnotifications_component_messages_addtab($cbtype,&$cbdata){

	// bail if this component has been disabled by the admin
	$settings_raw=get_option("rssnotifications_component_options");
	if($settings_raw=="")
		$settings=array();
	else
		$settings=unserialize($settings_raw);
	$rssnotificationsenabled=grab_array_var($settings,"enabled",0);
	if($rssnotificationsenabled!=1)
		return;

	$newtab=array(
		"id" => "rssnotifications",
		"title" => "RSS",
		);

	// add new tab
	$cbdata["tabs"][]=$newtab;	
	}


function rssnotifications_component_methods_addtab($cbtype,&$cbdata){

	// bail if this component has been disabled by the admin
	$settings_raw=get_option("rssnotifications_component_options");
	if($settings_raw=="")
		$settings=array();
	else
		$settings=unserialize($settings_raw);
	$rssnotificationsenabled=grab_array_var($settings,"enabled",0);
	if($rssnotificationsenabled!=1)
		return;

	$newtab=array(
		"id" => "rssnotifications",
		"title" => "RSS",
		);

	// add new tab
	$cbdata["tabs"][]=$newtab;	
	}

///////////////////////////////////////////////////////////////////////////////////////////
// NOTIFICATION METHOD FUNCTIONS
///////////////////////////////////////////////////////////////////////////////////////////

function rssnotifications_component_notificationmethod_func($mode="",$inargs,&$outargs,&$result){
	global $rssnotifications_component_name;

	// initialize return values
	$result=0;
	$outargs=array();
	$output='';
	
	// bail if this component has been disabled by the admin
	$settings_raw=get_option("rssnotifications_component_options");
	if($settings_raw=="")
		$settings=array();
	else
		$settings=unserialize($settings_raw);
	$rssnotificationsenabled=grab_array_var($settings,"enabled",0);
	if($rssnotificationsenabled!=1)
		return $output;
	
	// generate unique key if they don't have one	
	$rssnotifications_key=get_user_meta(0,'rssnotifications_key');
	if($rssnotifications_key==null || $rssnotifications_key==""){
		$rssnotifications_key=random_string(16);
		set_user_meta(0,'rssnotifications_key',$rssnotifications_key);
		}

	// generate notifications array if they don't have one
	$rssnotifications_raw=get_user_meta(0,'rssnotifications');
	if($rssnotifications_raw==""){
		$rssnotifications=array(
			"updated" => 0,
			"items" => array(),
			);
		set_user_meta(0,'rssnotifications',serialize($rssnotifications));
		}
		
	switch($mode){
	
		case NOTIFICATIONMETHOD_MODE_GETCONFIGOPTIONS:
		
			// defaults 
			$rssnotifications_enabled=get_user_meta(0,'rssnotifications_enabled');
				
			// get values from form submission
			$rssnotifications_enabled=grab_request_var("rssnotifications_enabled",$rssnotifications_enabled);
			
			$rssnotifications_enabled=checkbox_binary($rssnotifications_enabled);			
			
			
			$component_url=get_component_url_base($rssnotifications_component_name);
			$urlopts="user=".get_user_attr(0,"username")."&key=".$rssnotifications_key;

			$output="
			<table>
			<tr>
			<td valign='top'>
			<input type='checkbox' class='checkbox' name='rssnotifications_enabled' ".is_checked($rssnotifications_enabled,1)." /><br class='nobr' />
			</td>
			<td><img src='".$component_url."/images/rss-20x20.png'>
			<b>".gettext("RSS Notifications")."</b><br>
			<br>".gettext("Access your notifications via an RSS feed.")."  
			<a style='color:#4D89F9;' href='".$component_url."/rssnotifications.php?".$urlopts."' target='_blank'>".gettext("View your personal feed")."</a>.<br><br>
			</td>
			</tr>
			</table>
			";
			break;
			
		case NOTIFICATIONMETHOD_MODE_SETCONFIGOPTIONS:
		
			$rssnotifications_enabled=grab_array_var($inargs,"rssnotifications_enabled",0);
			$rssnotifications_enabled=checkbox_binary($rssnotifications_enabled);


			// check for errors
			$errors=0;
			$errmsg=array();
			if($rssnotifications_enabled==1){
				}
		
			// handle errors
			if($errors>0){
				$outargs[NOTIFICATIONMETHOD_ERROR_MESSAGES]=$errmsg;
				$result=1;
				}
				
			// save values
			set_user_meta(0,'rssnotifications_enabled',$rssnotifications_enabled);

			
			break;
			
		case NOTIFICATIONMETHOD_MODE_GETMESSAGEFORMAT:
		
			// defaults/saved values
			$rssnotifications_host_subject=rssnotifications_component_get_host_subject(0);
			$rssnotifications_service_subject=rssnotifications_component_get_service_subject(0);
			$rssnotifications_host_description=rssnotifications_component_get_host_description(0);
			$rssnotifications_service_description=rssnotifications_component_get_service_description(0);
			
			// newly submitted values
			$rssnotifications_host_subject=grab_array_var($inargs,"rssnotifications_host_subject",$rssnotifications_host_subject);
			$rssnotifications_service_subject=grab_array_var($inargs,"rssnotifications_service_subject",$rssnotifications_service_subject);
			$rssnotifications_host_description=grab_array_var($inargs,"rssnotifications_host_description",$rssnotifications_host_description);
			$rssnotifications_service_description=grab_array_var($inargs,"rssnotifications_service_description",$rssnotifications_service_description);
			
			$component_url=get_component_url_base($rssnotifications_component_name);
		

			// warn user about notifications being disabled
			if(get_user_meta(0,'rssnotifications_enabled')==0){
				$msg="<div>".gettext("Note: You currently have RSS notifications disabled.")."
				<a href='notifymethods.php#tab-custom-rssnotifications'>".gettext("Change settings")."</a>.</div>";
				$output.=get_message_text(true,false,$msg);
				}

			$output.='

	<img src="'.$component_url.'/images/rss-20x20.png">

	<div class="sectionTitle">'.gettext('RSS Feed Settings').'</div>
	
	<p>'.gettext('Specify the format of the RSS feed listings.').'</p>
	
	<table>

	<tr>
	<td valign="top">
	<label>'.gettext('Host Alert Title').':</label><br class="nobr" />
	</td>
	<td>
	<input type="textbox" name="rssnotifications_host_subject" value="'.htmlentities($rssnotifications_host_subject).'" size="65"><br class="nobr" />
	</td>
	</tr>
	
	<tr>
	<td valign="top">
	<label>'.gettext('Host Alert Description').':</label><br class="nobr" />
	</td>
	<td>
<textarea name="rssnotifications_host_description" rows="4" cols="64">'.htmlentities($rssnotifications_host_description).'
</textarea>
	<br class="nobr" />
	</td>
	</tr>

	<tr>
	<td valign="top">
	<label>'.gettext('Service Alert Title').':</label><br class="nobr" />
	</td>
	<td>
	<input type="textbox" name="rssnotifications_service_subject" value="'.htmlentities($rssnotifications_service_subject).'" size="65"><br class="nobr" />
	</td>
	</tr>
	
	<tr>
	<td valign="top">
	<label>'.gettext('Service Alert Description').':</label><br class="nobr" />
	</td>
	<td>
<textarea name="rssnotifications_service_description" rows="4" cols="65">'.htmlentities($rssnotifications_service_description).'
</textarea>
	<br class="nobr" />
	</td>
	</tr>

	</table>
			';
		
			break;
			
		case NOTIFICATIONMETHOD_MODE_SETMESSAGEFORMAT:
		
			// newly submitted values
			$rssnotifications_host_subject=grab_array_var($inargs,"rssnotifications_host_subject","");
			$rssnotifications_service_subject=grab_array_var($inargs,"rssnotifications_service_subject","");
			$rssnotifications_host_description=grab_array_var($inargs,"rssnotifications_host_description","");
			$rssnotifications_service_description=grab_array_var($inargs,"rssnotifications_service_description","");
			
			// save options
			set_user_meta(0,"rssnotifications_host_subject",$rssnotifications_host_subject);
			set_user_meta(0,"rssnotifications_service_subject",$rssnotifications_service_subject);
			set_user_meta(0,"rssnotifications_host_description",$rssnotifications_host_description);
			set_user_meta(0,"rssnotifications_service_description",$rssnotifications_service_description);

		
			break;
			
		default:
			$output="";
			break;
		}

	return $output;
	}
	
	
function rssnotifications_component_get_host_subject($user_id){
	$txt=get_user_meta(0,'rssnotifications_host_subject');
	if($txt=="")
		$txt="%type% Host Alert For %host%";
	return $txt;
	}

function rssnotifications_component_get_service_subject($user_id){
	$txt=get_user_meta(0,'rssnotifications_service_subject');
	if($txt=="")
		$txt="%type% Alert For Service %service% On Host %host%";
	return $txt;
	}

function rssnotifications_component_get_host_description($user_id){
	$txt=get_user_meta(0,'rssnotifications_host_description');
	if($txt=="")
		$txt="Host: %host%\nState: %hoststate%\nAddress: %hostaddress%\nInfo: %hostoutput%\nDate/Time: %datetime%\nNagios URL: %xiserverurl%";
	return $txt;
	}

function rssnotifications_component_get_service_description($user_id){
	$txt=get_user_meta(0,'rssnotifications_service_description');
	if($txt=="")
		$txt="Service: %service%\nHost: %hostalias%\nAddress: %hostaddress%\nState: %servicestate%\nInfo:
%serviceoutput%\nDate/Time: %datetime%\nNagios URL: %xiserverurl%";
	return $txt;
	}


///////////////////////////////////////////////////////////////////////////////////////////
//CONFIG FUNCTIONS
///////////////////////////////////////////////////////////////////////////////////////////

function rssnotifications_component_config_func($mode="",$inargs,&$outargs,&$result){
	global $rssnotifications_component_name;
	
	// initialize return code and output
	$result=0;
	$output="";
	
	
	switch($mode){
		case COMPONENT_CONFIGMODE_GETSETTINGSHTML:
		
			$settings_raw=get_option("rssnotifications_component_options");
			if($settings_raw==""){
				$settings=array(
					//"enabled"=>1,
					);
				}
			else
				$settings=unserialize($settings_raw);
				
			// initial values
			$enabled=grab_array_var($settings,"enabled","");
			
			// values passed to us
			$enabled=checkbox_binary(grab_array_var($inargs,"enabled",$enabled));

			
			$component_url=get_component_url_base($rssnotifications_component_name);

			$output='
			
			<img src="'.$component_url.'/images/rss-40x40.png">
			
	<div class="sectionTitle">'.gettext('Integration Settings').'</div>
	
	<table>

	<tr>
	<td valign="top">
	<label for="enabled">'.gettext('Enable Integration').':</label><br class="nobr" />
	</td>
	<td>
	<input type="checkbox" class="checkbox" id="enabled" name="enabled" '.is_checked($enabled,1).'>
<br class="nobr" />
	'.gettext('Enables integration of RSS notifications.').'
	</td>
	</tr>

	</table>

			';
			break;
			
		case COMPONENT_CONFIGMODE_SAVESETTINGS:
		
			// get variables
			$enabled=checkbox_binary(grab_array_var($inargs,"enabled",""));
			
			// validate variables
			$errors=0;
			$errmsg=array();
			if($enabled==1){
				}
			
			// handle errors
			if($errors>0){
				$outargs[COMPONENT_ERROR_MESSAGES]=$errmsg;
				$result=1;
				return '';
				}
			
			// save settings
			$settings=array(
				"enabled" => $enabled,
				);
			set_option("rssnotifications_component_options",serialize($settings));
			
		
			// info messages
			$okmsg=array();
			$okmsg[]="RSS notification settings updated.";
			$outargs[COMPONENT_INFO_MESSAGES]=$okmsg;
			
			break;
		
		default:
			break;
			
		}
		
	return $output;
	}


////////////////////////////////////////////////////////////////////////
// EVENT HANDLER AND NOTIFICATION FUNCTIONS
////////////////////////////////////////////////////////////////////////


register_callback(CALLBACK_EVENT_PROCESSED,'rssnotifications_component_eventhandler');

function rssnotifications_component_eventhandler($cbtype,$args){

	//echo "RSSNOTIFICATIONS EVENTHANDLER...\n";

	$settings_raw=get_option("rssnotifications_component_options");
	if($settings_raw=="")
		$settings=array();
	else
		$settings=unserialize($settings_raw);
				
	// bail out of component is not enabled
	$enabled=grab_array_var($settings,"enabled","");
	if($enabled!=1)
		return;

	switch($args["event_type"]){
		case EVENTTYPE_NOTIFICATION:
			rssnotifications_component_handle_notification_event($args);
			break;
		default:
			break;
		}
	}
	
function rssnotifications_component_handle_notification_event($args){

	//echo "RSSNOTIFICATION!\n";

	$meta=grab_array_var($args,"event_meta",array());
	
	// find the XI user
	$contact=grab_array_var($meta,"contact");
	$user_id=get_user_id($contact);
	if($user_id<=0)
		return;

	rssnotifications_component_store_notification($user_id,$meta);
	}
	

////////////////////////////////////////////////////////////////////////
// RSS FUNCTIONS
////////////////////////////////////////////////////////////////////////

function rssnotifications_component_store_notification($user_id,$meta){

	echo "RSSNOTIFICATION FOR USERID=$user_id\n";
	print_r($meta);

	// load feed items
	$rssnotifications_raw=get_user_meta($user_id,'rssnotifications');
	if($rssnotifications_raw=="")
		$rssnotifications=array(
			"updated" => 0,
			"items" => array(),
			);
	else
		$rssnotifications=unserialize($rssnotifications_raw);
		
	// update time
	$rssnotifications["updated"]=time();
	
	// get rid of old items
	if(count($rssnotifications["items"])>29)
		array_shift($rssnotifications["items"]);
	
	// add new items to array
	$rssnotifications["items"][]=$meta;
	
	// save items
	set_user_meta($user_id,'rssnotifications',serialize($rssnotifications));

	return 0;
	}



?>