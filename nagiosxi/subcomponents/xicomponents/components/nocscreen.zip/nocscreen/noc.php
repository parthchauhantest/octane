<?php  //noc.php 
//
// Nagios XI Operations Center Component
//
// Copyright (c) 2011 Nagios Enterprises, LLC.  All rights reserved.
//  
// 

require_once(dirname(__FILE__).'/../../common.inc.php');

// initialization stuff
pre_init();
// start session
init_session();
// grab GET or POST variables 
grab_request_vars();
// check prereqs
check_prereqs();
// check authentication
check_authentication(false);
?>
<!DOCTYPE html>
		<html>
			<!-- Produced by Nagios XI.  Copyyright (c) 2008-2009 Nagios Enterprises, LLC (www.nagios.com). All Rights Reserved. -->
			<!-- Powered by the Nagios Synthesis Framework -->

		<head>
		<title>Nagios XI - Operations Center</title>
		<meta http-equiv='Content-Type' content='text/html; charset=UTF-8' />
		
<?php		do_page_head_links();  ?>
		<style type='text/css'>

#content {width:95%;}
#topbar {width: 965px; height:65px;}
#leftside {margin-left:10px; margin-bottom:o; width:450px; float:left;}
#rightside {width:500px; float:right;}
table {margin:10px;}
.strong {font-weight:bold;}
#theheader {margin: 3px 10px 3px 10px;}
#lastUpdate {color:grey; font-size 7pt;}
#servicetable {width:100%;}
#hosttable {width:100%;}
div.duration {width:125px;}


		</style>
		<script type="text/javascript">
		//dashboard refresh time 
		MULTIPLIER = 30; //allow for user defined option in future versions 
		$(document).ready(function() {							
				//ajax refresh
				noc_load_content(); 
			}); 
			//content reloader 
			function noc_load_content() 
			{			
				$('#content').load('nocscreenapi.php', function() {
					var d = new Date(); 
					$('#lastUpdate').empty();
					$('#lastUpdate').append(('Last Update: '+ d.toString() ));       	
			   });
			   //summary bar
			   $('#rightside').load('nocscreenapi.php?summary=true'); 
				//alert(contents);                  
				setTimeout(noc_load_content,(MULTIPLIER*1000));  //have this multiplier as a config option
			}
	
		</script>
		</head>
		<body>
		<div id='topbar'>
		  <div id='leftside'>
			<h4  id='theheader'><img src='/nagiosxi/images/nagiosxi-logo-small.png' height='42' width='100' alt='Nagios XI' /><?php echo gettext("Operations Center"); ?></h4>
			<div id='lastUpdate'></div>
		  </div> <!-- end leftside -->	
		  <div id='rightside'></div>
			
		</div>	
		<div id='content'></div>

		

	</body>
	</html>