<?php
// Metrics
//
// Copyright (c) 2011 Nagios Enterprises, LLC.  All rights reserved.
//  
// $Id: eventlog.php 359 2010-10-31 17:08:47Z egalstad $

require_once(dirname(__FILE__).'/../../common.inc.php');

include_once(dirname(__FILE__).'/dashlet.inc.php');

// initialization stuff
pre_init();

// start session
init_session();

// grab GET or POST variables 
grab_request_vars();

// check prereqs
check_prereqs();

// check authentication
check_authentication(false);


route_request();

function route_request(){
	global $request;
			
	$mode=grab_request_var("mode");
	switch($mode){
		case "chart":
			get_chart();
			break;
		default:
			display_metrics();
			break;
		}
	}

function display_metrics(){
	global $lstr;
	
	$showperfgraphs=0;
	$sortorder="desc";
	$metric="disk";
	$maxitems=20;
	$type="";
	$tab="";
	
	// use saved values
	$prefs_raw=get_user_meta(0,"metrics_prefs");
	if(have_value($prefs_raw)){
		$prefs=unserialize($prefs_raw);

		$showperfgraphs=grab_array_var($prefs,"showperfgraphs");
		$sortorder=grab_array_var($prefs,"sortorder");
		$metric=grab_array_var($prefs,"metric");
		$maxitems=grab_array_var($prefs,"maxitems");
		$type=grab_array_var($prefs,"type");
		$tab=grab_array_var($prefs,"tab");
		}
	
	// grab request vars
	$type=grab_request_var("type",$type);
	$host=grab_request_var("host","");
	$hostgroup=grab_request_var("hostgroup","");
	$servicegroup=grab_request_var("servicegroup","");
	$maxitems=grab_request_var("maxitems",$maxitems);
	$metric=grab_request_var("metric",$metric);
	$sortorder=grab_request_var("sortorder",$sortorder);
	$showperfgraphs=grab_request_var("showperfgraphs",$showperfgraphs);
	$tab=grab_request_var("tab",$tab);
	
	// save values
	$prefs=array(
		"showperfgraphs" => $showperfgraphs,
		"sortorder" => $sortorder,
		"metric" => $metric,
		"maxitems" => $maxitems,
		"type" => $type,
		"tab" => $tab,
		);
	set_user_meta(0,"metrics_prefs",serialize($prefs),false);
	

	// makes sure user has appropriate license level
	licensed_feature_check();

	// start the HTML page
	do_page_start(array("page_title"=>"Metrics"),true);
	
?>
	<h1><?php echo gettext("Metrics"); ?></h1>
	
	<form action="" method="get" id="metricsForm">
	<input type="hidden" name="tab" value="<?php echo htmlentities($tab);?>" id="metricsFormtabname">
	
	<label><?php echo gettext("Limit To"); ?>:</label>
	<select name="hostgroup" id="hostgroupList">
	<option value=""><?php echo gettext("Hostgroup"); ?>:</option>
<?php
	$args=array('orderby' => 'hostgroup_name:a');
    $xml=get_xml_hostgroup_objects($args);
	if($xml){
		foreach($xml->hostgroup as $hg){
			$name=strval($hg->hostgroup_name);
			echo "<option value='".$name."' ".is_selected($hostgroup,$name).">$name</option>\n";
			}
		}
?>
	</select>
	<select name="servicegroup" id="servicegroupList">
	<option value=""><?php echo gettext("Servicegroup"); ?>:</option>
<?php
	$args=array('orderby' => 'servicegroup_name:a');
    $xml=get_xml_servicegroup_objects($args);
	if($xml){
		foreach($xml->servicegroup as $sg){
			$name=strval($sg->servicegroup_name);
			echo "<option value='".$name."' ".is_selected($servicegroup,$name).">$name</option>\n";
			}
		}
?>
	</select>
	<?php echo gettext("Metric"); ?>
	<select name="metric" id="metricList">
<?php
	$metrics=get_metric_names();
	foreach($metrics as $mn => $md){
		$name=$mn;
		echo "<option value='".$name."' ".is_selected($metric,$name).">$md</option>\n";
		}
?>
	</select>
	<!--
	Graphs
	<select name="showperfgraphs" id="metricList">
	<option value="0" <?php echo is_selected($showperfgraphs,0);?>>No</option>
	<option value="1" <?php echo is_selected($showperfgraphs,1);?>>Yes</option>
	</select>
	//-->
	<?php echo gettext("Show"); ?>
	<select name="sortorder" id="sortorderList">
<?php
	$sortorders=array(
		"desc" => "Top",
		"asc" => "Bottom",
		);
	foreach($sortorders as $sn => $sd){
		$name=$sn;
		echo "<option value='".$name."' ".is_selected($sortorder,$name).">$sd</option>\n";
		}
?>
	</select>
	<input type="text" name="maxitems" value="<?php echo htmlentities($maxitems);?>" size="2">
	<input type="submit" class="submitbutton" name="goButton" value="<?php echo $lstr['UpdateButton'];?>" id="goButton">
	</form>
	
	<script type="text/javascript">
	$(document).ready(function(){
		$('#servicegroupList').change(function() {
			$('#hostgroupList').val('');
			});
		$('#hostgroupList').change(function() {
			$('#servicegroupList').val('');
			});
		});
	</script>
	

	<script type="text/javascript">
	$(function() {
		// initialize tabs
		//$("#tabs").tabs();
		$("#tabs").tabs({
			select: function(event, ui) { 
				var selected=$("#tabs").tabs('option','selected');
				if(selected==0)
					tabname="tab-graphs";
				else if(selected==1)
					tabname="tab-gauges";
				else
					tabname="tab-summary";
				$("#metricsFormtabname").val(tabname);
				}
			});
		// switch to the tab specified in the URL
		$("#tabs").tabs('select', '#<?php echo htmlentities($tab);?>');
		});
	</script>

	
	<div id="tabs">
	<ul>
		<li><a href="#tab-summary"><?php echo gettext("Summary"); ?></a></li>
		<li><a href="#tab-graphs"><?php echo gettext("Graphs"); ?></a></li>
		<li><a href="#tab-gauges"><?php echo gettext("Gauges"); ?></a></li>
	</ul>

	<div id="tab-summary">
	
	
<?php
	$dargs=array(
		DASHLET_ARGS => array(
			"type" => $type,
			"host" => $host,
			"hostgroup" => $hostgroup,
			"servicegroup" => $servicegroup,
			"maxitems" => $maxitems,
			"metric" => $metric,
			"sortorder" => $sortorder,
			"showperfgraphs" => $showperfgraphs,
			),
		);
	/*
	echo "ARGS GOING IN=";
	print_r($dargs);
	echo "<BR>";
	*/
	display_dashlet("metrics","",$dargs,DASHLET_MODE_OUTBOARD);
?>


	</div>
	
<?php

	// get service metrics
	$args=array(
		"type" => $type,
		"host" => $host,
		"hostgroup" => $hostgroup,
		"servicegroup" => $servicegroup,
		"maxitems" => $maxitems,
		"metric" => $metric,
		"sortorder" => $sortorder,
		);
	$metricdata=get_service_metrics($args);

?>
	
	<div id="tab-graphs">
<?php
	foreach($metricdata as $id => $arr){
	
		$hostname=$arr["host_name"];
		$servicename=$arr["service_name"];

		if(perfdata_chart_exists($hostname,$servicename)==true){
			$img=perfdata_get_graph_image_url($hostname,$servicename);
			$oid=get_service_id($hostname,$servicename);
			$perfurl=get_base_url()."perfgraphs/?host=".urlencode($hostname)."&service=".urlencode($servicename)."&service_id=".$oid."&mode=2";
			echo '<div style="margin-bottom: 25px;">';
			echo '<a href="'.$perfurl.'" target="_blank"><img src="'.$img.'"></a>';
			echo '</div>';
			}
		
		}
?>	
	</div>
	
	<div id="tab-gauges">


<?php


	foreach($metricdata as $id => $arr){
	
		$hostname=$arr["host_name"];
		$servicename=$arr["service_name"];

?>
		<div style="margin: 0 25px 25px 0; float: left;">
<?php

		$dargs=array(
			DASHLET_ARGS => array(
				"host" => $hostname,
				"service" => $servicename,
				"metric" => $metric,
				"percent" => $arr["sortval"],
				"current" => $arr["current"],
				"uom" => $arr["uom"],
				"warn" => $arr["warn"],
				"crit" => $arr["crit"],
				"min" => $arr["min"],
				"max" => $arr["max"],
				"plugin_output" => $arr["output"],
				),
			);
		display_dashlet("metricsguage","",$dargs,DASHLET_MODE_OUTBOARD);		

?>
		</div>
<?php

		}

?>
	

	</div>
	
	</div>


<?php		
	
	// closes the HTML page
	do_page_end(true);
	}
	
	
///////////////////////////////////////////////////////////////////
// CHART FUNCTIONS
///////////////////////////////////////////////////////////////////

function get_chart(){

	require_once ('../jpgraph/src/jpgraph.php');
	require_once ('../jpgraph/src/jpgraph_odo.php');
	
	
	$width=grab_request_var("width",160);
	$height=grab_request_var("height",80);
	$percent=grab_request_var("percent",0);
	$current=grab_request_var("current",0);
	$warn=grab_request_var("warn",0);
	$crit=grab_request_var("crit",0);
	$min=grab_request_var("min",0);
	$max=grab_request_var("max",0);
	$minscale=grab_request_var("minscale",0);
	$maxscale=grab_request_var("maxscale",100);

	$colors=array('#1E90FF','#2E8B57','#ADFF2F','#DC143C','#BA55D3');
		

	// create canvas
	$canvas = new OdoGraph($width,$height);
		
	// Create the odometer
	$odo = new Odometer();

	// set needle
	$odo->needle->Set($percent);
	$odo->needle->SetStyle(NEEDLE_STYLE_STRAIGHT);
	$odo->needle->SetShadow();
	
	//$odo->scale->Set($minscale,$maxscale);
	
	$crit_start=0;
	$crit_end=100;
	$warn_start=0;
	$warn_end=0;
	if($crit>0 && $max>0){
		$crit_start=($crit/($max-$min))*100;
		$odo->AddIndication($crit_start,$crit_end,"red");
		}
	if($warn>0 && $max>0 && $crit_start>0){
		$warn_start=($warn/($max-$min))*100;
		$odo->AddIndication($warn_start,$crit_start,"yellow");
		}
	
	
	// canvas colors
	$canvas->SetMargin(0,0,0,0);
	$canvas->SetMarginColor("white");
	$canvas->SetColor("white");

	// odo colors
	$odo->SetColor("white");

	// add odometer to canvas
	$canvas->Add($odo);
	
	$canvas->Stroke();
	}
