<?php
// iSMS COMPONENT
//
// Copyright (c) 2010 Nagios Enterprises, LLC.  All rights reserved.
//  
// $Id: isms.inc.php 912 2012-11-08 16:33:53Z swilkerson $

require_once(dirname(__FILE__).'/../componenthelper.inc.php');


// run the initialization function
isms_component_init();

////////////////////////////////////////////////////////////////////////
// COMPONENT INIT FUNCTIONS
////////////////////////////////////////////////////////////////////////

function isms_component_init(){

	$component_name="isms";
	
	$args=array(

		// need a name
		COMPONENT_NAME => $component_name,
		
		// informative information
		COMPONENT_VERSION => "1.2",
		//COMPONENT_DATE => "11-27-2009",
		COMPONENT_AUTHOR => "Nagios Enterprises, LLC",
		COMPONENT_DESCRIPTION => gettext("Provides integration with the Mutli-Tech iSMS.")."
		<strong>Requires</strong> Multi-Tech iSMS modem <a href='http://assets.nagios.com/downloads/nagiosxi/docs/MultiTech_iSMS_Integration_With_XI.pdf' target='_blank' title='Documentation' >
		setup</a>.",
		COMPONENT_TITLE => "Multi-Tech iSMS Integration",
		//COMPONENT_COPYRIGHT => "Copyright (c) 2009 Nagios Enterprises",
		//COMPONENT_HOMEPAGE => "http://www.nagios.com",

		// configuration function (optional)
		COMPONENT_CONFIGFUNCTION => "isms_component_config_func",
		);
		
	register_component($component_name,$args);
	
		
	// register as a new notification method
	$args=array(
		NOTIFICATIONMETHOD_FUNCTION => 'isms_component_notificationmethod_func',
		);
	register_notificationmethod('isms',$args);
	
	// register to add a new tab to the notification menus
	register_callback(CALLBACK_USER_NOTIFICATION_METHODS_TABS_INIT,'isms_component_methods_addtab');
	register_callback(CALLBACK_USER_NOTIFICATION_MESSAGES_TABS_INIT,'isms_component_messages_addtab');	
	}
	


///////////////////////////////////////////////////////////////////////////////////////////
// TAB FUNCTIONS
///////////////////////////////////////////////////////////////////////////////////////////

function isms_component_messages_addtab($cbtype,&$cbdata){

	// bail if this component has been disabled by the admin
	$settings_raw=get_option("isms_component_options");
	if($settings_raw=="")
		$settings=array();
	else
		$settings=unserialize($settings_raw);
	$enabled=grab_array_var($settings,"enabled",0);
	if($enabled!=1)
		return;

	$newtab=array(
		"id" => "isms",
		"title" => "SMS",
		);

	// add new tab
	$cbdata["tabs"][]=$newtab;	
	}


function isms_component_methods_addtab($cbtype,&$cbdata){

	// bail if this component has been disabled by the admin
	$settings_raw=get_option("isms_component_options");
	if($settings_raw=="")
		$settings=array();
	else
		$settings=unserialize($settings_raw);
	$enabled=grab_array_var($settings,"enabled",0);
	if($enabled!=1)
		return;

	$newtab=array(
		"id" => "isms",
		"title" => "SMS",
		);

	// add new tab
	$cbdata["tabs"][]=$newtab;	
	}

	
///////////////////////////////////////////////////////////////////////////////////////////
// NOTIFICATION METHOD FUNCTIONS
///////////////////////////////////////////////////////////////////////////////////////////

function isms_component_notificationmethod_func($mode="",$inargs,&$outargs,&$result){

	$component_name="isms";

	// initialize return values
	$result=0;
	$outargs=array();
	$output='';
	
	// bail if this component has been disabled by the admin
	$settings_raw=get_option("isms_component_options");
	if($settings_raw=="")
		$settings=array();
	else
		$settings=unserialize($settings_raw);
	$isms_enabled=grab_array_var($settings,"enabled",0);
	if($isms_enabled!=1)
		return $output;

	switch($mode){
	
		case NOTIFICATIONMETHOD_MODE_GETCONFIGOPTIONS:
		
			// defaults
			$isms_notifications_enabled=get_user_meta(0,'isms_notifications_enabled');
			$isms_mobile_number=get_user_meta(0,'isms_mobile_number');
			if($isms_mobile_number=="")
				$isms_mobile_number=get_user_meta(0,'mobile_number');
				
			// get values from form submission
			$isms_notifications_enabled=grab_request_var("isms_notifications_enabled",$isms_notifications_enabled);
			$isms_mobile_number=grab_request_var("isms_mobile_number",$isms_mobile_number);
			
			$isms_notifications_enabled=checkbox_binary($isms_notifications_enabled);			
			
			$component_url=get_component_url_base($component_name);

			$output="
			
			<img src='".$component_url."/images/multitech.png' alt='Multi-Tech iSMS' title='Multi-Tech iSMS'><br clear='all'><br clear='all'>
			
			<table>
			<tr>
			<td valign='top'>
			<input type='checkbox' class='checkbox' name='isms_notifications_enabled' ".is_checked($isms_notifications_enabled,1)."><br class='nobr' />
			</td>
			<td>
			<b>SMS Text Message</b><br class='nobr' />".gettext("Receive out-of-band SMS alerts via the")." <a href='http://www.multitech.com/en_US/PRODUCTS/Families/MultiModemiSMS/' target='_top'>Multi-Tech iSMS</a>.<br>
			
			<table>
				<tr>
				<td><label>".gettext("Mobile Number").":</label></td>
				<td><input type='text' size='15' name='isms_mobile_number'value='".$isms_mobile_number."' class='textfield' /></td>
				</tr>

			</table>
			</td>
			</tr>
			<tr>
			<td valign='top'>
			<input type='checkbox' class='checkbox' name='isms_send_test' ><br class='nobr' />
			</td>
			<td>
			".gettext("Send a test SMS message to the number specified above.")."
			</td>
			</tr>
			</table>
			";
			break;
			
		case NOTIFICATIONMETHOD_MODE_SETCONFIGOPTIONS:
		
			$isms_notifications_enabled=grab_array_var($inargs,"isms_notifications_enabled",0);
			$isms_notifications_enabled=checkbox_binary($isms_notifications_enabled);
			$isms_mobile_number=grab_array_var($inargs,"isms_mobile_number","");

			// check for errors
			$errors=0;
			$errmsg=array();
			$okmsg=array();
			if($isms_notifications_enabled==1){
				if($isms_mobile_number==""){
					$errmsg[$errors++]=gettext("Mobile phone number for SMS alerts is blank.");
					}
				}
		
			// handle errors
			if($errors>0){
				$outargs[NOTIFICATIONMETHOD_ERROR_MESSAGES]=$errmsg;
				$result=1;
				}
				
			// save values
			set_user_meta(0,'isms_notifications_enabled',$isms_notifications_enabled);
			set_user_meta(0,'isms_mobile_number',$isms_mobile_number);
			
			// send a test message	
			$testnumber=grab_array_var($inargs,"isms_send_test","");
			$smsoutput=array();
			$smsresult=-1;
			if($testnumber!="" && $errors==0){
				//echo "SENDING TEST...";
				$args=array(
					"number" => $isms_mobile_number,
					"message" => "This is a test SMS message from Nagios XI\n".get_option('url'),
					);
				$smsresult=isms_component_send_sms($args,$smsoutput);
				
				// handle errors
				if($smsresult==1){
					$errmsg[$errors++]=gettext("An error occurred sending the test SMS message.");
					$outargs[NOTIFICATIONMETHOD_ERROR_MESSAGES]=$errmsg;
					$result=1;
					//echo "<BR>ERRORS<BR><BR>";
					//print_r($errmsg);
					return '';
					}
					
				// success message
				$okmsg=array();
				if($smsresult==0){
					$okmsg[]=gettext("Test SMS message sent to ").$isms_mobile_number.gettext(" successfully.");
					$outargs[NOTIFICATIONMETHOD_INFO_MESSAGES]=$okmsg;
					}					
				}
		
			/*
			echo "<BR>INARGS<BR><BR>";
			print_r($inargs);
			echo "<BR>INFO<BR><BR>";
			print_r($okmsg);
			exit();
			*/

			break;
			
		case NOTIFICATIONMETHOD_MODE_GETMESSAGEFORMAT:
		

			// defaults/saved values
			$isms_notifications_host_message=isms_component_get_host_message(0);
			$isms_notifications_service_message=isms_component_get_service_message(0);
			
			// newly submitted values
			$isms_notifications_host_message=grab_array_var($inargs,"isms_notifications_host_message",$isms_notifications_host_message);
			$isms_notifications_service_message=grab_array_var($inargs,"isms_notifications_service_message",$isms_notifications_service_message);
			
			$component_url=get_component_url_base($component_name);
		

			// warn user about notifications being disabled
			if(get_user_meta(0,'isms_notifications_enabled')==0){
				$msg="<div>".gettext("Note: You currently have SMS notifications disabled.")."  <a href='notifymethods.php#tab-custom-isms'>".gettext("Change settings")."</a>.</div>";
				$output.=get_message_text(true,false,$msg);
				}
				
			$output.="<img src='".$component_url."/images/multitech.png' alt='Multi-Tech iSMS' title='Multi-Tech iSMS'>";


			$output.='


	<div class="sectionTitle">'.gettext('SMS Message Settings').'</div>
	
	<p>'.gettext('Specify the format of the SMS messages you want to receive.').'</p>
	
	<p><b>'.gettext('NOTE').':</b> '.gettext('The maximum length of SMS text messages is 160 characters.  Messages longer than this limit will be trimmed.').'</p>
	
	<table>

	<tr>
	<td valign="top">
	<label>'.gettext('Host Alert Message').':</label><br class="nobr" />
	</td>
	<td>
<textarea name="isms_notifications_host_message" rows="4" cols="64">'.htmlentities($isms_notifications_host_message).'
</textarea>
	<br class="nobr" />
	</td>
	</tr>

	<tr>
	<td valign="top">
	<label>'.gettext('Service Alert Message').':</label><br class="nobr" />
	</td>
	<td>
<textarea name="isms_notifications_service_message" rows="4" cols="65">'.htmlentities($isms_notifications_service_message).'
</textarea>
	<br class="nobr" />
	</td>
	</tr>

	</table>
			';
		
			break;
			
		case NOTIFICATIONMETHOD_MODE_SETMESSAGEFORMAT:
		
			// newly submitted values
			$isms_notifications_host_message=grab_array_var($inargs,"isms_notifications_host_message","");
			$isms_notifications_service_message=grab_array_var($inargs,"isms_notifications_service_message","");
			
			// save options
			set_user_meta(0,"isms_notifications_host_message",$isms_notifications_host_message);
			set_user_meta(0,"isms_notifications_service_message",$isms_notifications_service_message);

		
			break;
			

		default:
			$output="";
			break;
		}

	return $output;
	}



///////////////////////////////////////////////////////////////////////////////////////////
//CONFIG FUNCTIONS
///////////////////////////////////////////////////////////////////////////////////////////

function isms_component_config_func($mode="",$inargs,&$outargs,&$result){

	// initialize return code and output
	$result=0;
	$output="";
	
	$component_name="isms";
	
	switch($mode){
		case COMPONENT_CONFIGMODE_GETSETTINGSHTML:
		
			$settings_raw=get_option("isms_component_options");
			if($settings_raw=="")
				$settings=array();
			else
				$settings=unserialize($settings_raw);
				
			// initial values
			$address=grab_array_var($settings,"address","");
			$http_port=grab_array_var($settings,"http_port","81");
			$username=grab_array_var($settings,"username","admin");
			$password=grab_array_var($settings,"password","");
			$enabled=grab_array_var($settings,"enabled","");
			$authorized_responders=grab_array_var($settings,"authorized_responders","");
			
			//echo "ACI1: $autocreateissues<BR>";
			
			// values passed to us
			$address=grab_array_var($inargs,"address",$address);
			$http_port=grab_array_var($inargs,"http_port",$http_port);
			$username=grab_array_var($inargs,"username",$username);
			$password=grab_array_var($inargs,"password",$password);
			$enabled=checkbox_binary(grab_array_var($inargs,"enabled",$enabled));
			$authorized_responders=grab_array_var($inargs,"authorized_responders",$authorized_responders);

			//echo "ACI2: $autocreateissues<BR>";
			
			//$autocreateissues=checkbox_binary($autocreateissues);

			//echo "ACI3: $autocreateissues<BR>";
			
			//print_r($inargs);
			
			$component_url=get_component_url_base($component_name);

			$output='
			
			<a href="http://www.multitech.com" target="_blank"><img src="'.$component_url.'/images/multitech.png"></a>
			
	<div class="sectionTitle">'.gettext('Integration Settings').'</div>
	
	<table>

	<tr>
	<td valign="top">
	<label for="enabled">'.gettext('Enable Integration').':</label><br class="nobr" />
	</td>
	<td>
	<input type="checkbox" class="checkbox" id="enabled" name="enabled" '.is_checked($enabled,1).'>
<br class="nobr" />
	'.gettext('Enables integration between Nagios XI and a Multi-Tech iSMS GSM modem.').'
	<strong>'.gettext('Requires').'</strong> 
	'.gettext('Multi-Tech iSMS modem').' <a href="http://assets.nagios.com/downloads/nagiosxi/docs/MultiTech_iSMS_Integration_With_XI.pdf" target="_blank" title="Documentation">'.gettext('setup').'</a>.
	</td>
	</tr>

	</table>

	<div class="sectionTitle">'.gettext('Sender Settings').'</div>
	
	<p>'.gettext('These settings relate to sending SMS alerts from Nagios XI through the iSMS Send API.').'</p>
	
	<table>

	<tr>
	<td valign="top">
	<label>'.gettext('IP Address').':</label><br class="nobr" />
	</td>
	<td>
<input type="text" size="40" name="address" id="address" value="'.$address.'" class="textfield" /><br class="nobr" />
	'.gettext('The IP address of the iSMS.').'<br><br>
	</td>
	</tr>

	<tr>
	<td valign="top">
	<label>'.gettext('HTTP Port:').'</label><br class="nobr" />
	</td>
	<td>
<input type="text" size="4" name="http_port" id="http_port" value="'.$http_port.'" class="textfield" /><br class="nobr" />
	'.gettext('The HTTP port used to access the iSMS Send API').'.<br><br>
	</td>
	</tr>

	<tr>
	<td valign="top">
	<label>'.gettext('Username').':</label><br class="nobr" />
	</td>
	<td>
<input type="text" size="20" name="username" id="username" value="'.$username.'" class="textfield" /><br class="nobr" />
	'.gettext('The username used to authenticate to the iSMS.').'<br><br>
	</td>
	</tr>

	<tr>
	<td valign="top">
	<label>'.gettext('Password:').'</label><br class="nobr" />
	</td>
	<td>
<input type="password" size="20" name="password" id="password" value="'.$password.'" class="textfield" /><br class="nobr" />
	'.gettext('The password used to authenticate to the iSMS.').'
	</td>
	</tr>
	
	</table>

	';
	
	$receive_url=get_component_url_base($component_name,false)."/receiver.php";
	/*
	$output.='
	
	<div class="sectionTitle">Receiver Settings</div>
	
	<p>These settings relate to processing SMS text messages received from the iSMS Receive API.</p>
	
	<table>

	<tr>
	<td valign="top">
	<label>Receive API Page:</label><br class="nobr" />
	</td>
	<td>
<input type="textfield" size="60" name="receive_url" id="receive_url" value="'.$receive_url.'" class="textfield" readonly /><br class="nobr" />
	Use this URL when configuring the iSMS Receive API page.  Read-Only.<br><br>
	</td>
	</tr>

	<tr>
	<td valign="top">
	<label>Authorized Responders:</label><br class="nobr" />
	</td>
	<td>
<textarea name="authorized_responders" cols="20" rows="5">
'.$authorized_responders.'
</textarea>
	<br class="nobr" />
	Phone numbers of cellphones that are authorized to acknowledge problems, disable notifications, and submit other commands.<br>Enter one phone number per line in international format (e.g. +16515555555).
	</td>
	</tr>

	</table>
';
*/
	$output.='
	<div class="sectionTitle">'.gettext('Test Message').'</div>
	
	<table>

	<tr>
	<td valign="top">
	<label>'.gettext('Phone Number').':</label><br class="nobr" />
	</td>
	<td>
<input type="text" size="20" name="testnumber" id="testnumber" value="" class="textfield" /><br class="nobr" />
	'.gettext('Enter a mobile phone number to send a test SMS message to.  This is used for testing the Nagios XI and Multi-Tech iSMS integration.').'
	</td>
	</tr>

	</table>

	<br>
	<p style="font-size: 7pt;">
	'.gettext('Multi-Tech and the Multi-Tech logo are trademarks or registered trademarks of').' <a href="http://www.multitech.com" target="_blank">Multi-Tech Systems, Inc.</a>
	</p>
			';
			break;
			
		case COMPONENT_CONFIGMODE_SAVESETTINGS:
		
			// get variables
			$address=grab_array_var($inargs,"address","");
			$http_port=grab_array_var($inargs,"http_port","");
			$username=grab_array_var($inargs,"username","");
			$password=grab_array_var($inargs,"password","");
			$enabled=checkbox_binary(grab_array_var($inargs,"enabled",""));
			$authorized_responders=grab_array_var($inargs,"authorized_responders","");
			
			// validate variables
			$errors=0;
			$errmsg=array();
			if($enabled==1){
				if(have_value($address)==false){
					$errmsg[$errors++]="No address specified.";
					}
				if(have_value($http_port)==false){
					$errmsg[$errors++]="No HTTP port specified.";
					}
				if(have_value($username)==false){
					$errmsg[$errors++]="No username specified.";
					}
				if(have_value($password)==false){
					$errmsg[$errors++]="No password specified.";
					}
				}
			
			// handle errors
			if($errors>0){
				$outargs[COMPONENT_ERROR_MESSAGES]=$errmsg;
				$result=1;
				return '';
				}
			
			// save settings
			$settings=array(
				"address" => $address,
				"http_port" => $http_port,
				"username" => $username,
				"password" => $password,
				"enabled" => $enabled,
				"authorized_responders" => $authorized_responders,
				);
			set_option("isms_component_options",serialize($settings));
			
			// send a test message
			$testnumber=grab_array_var($inargs,"testnumber","");
			$smsoutput=array();
			$smsresult=-1;
			if($testnumber!=""){
				$args=array(
					"number" => $testnumber,
					"message" => "Test Multi-Tech iSMS message from Nagios XI\n".get_option('url'),
					);
				$smsresult=isms_component_send_sms($args,$smsoutput);
				
				// handle errors
				if($smsresult==1){
					$errmsg[$errors++]="An error occurred sending the test SMS message.";
					$outargs[COMPONENT_ERROR_MESSAGES]=$errmsg;
					$result=1;
					return '';
					}
				}
		
			// info messages
			$okmsg=array();
			$okmsg[]=gettext("Multi-Tech iSMS settings updated.");
			if($smsresult==0){
				$okmsg[]=gettext("Test SMS message sent to ").$testnumber.gettext(" successfully.");
				}
			if($smsresult>=0){
				//$okmsg[]=serialize($smsoutput);
				}
			$outargs[COMPONENT_INFO_MESSAGES]=$okmsg;
			
			break;
		
		default:
			break;
			
		}
		
	return $output;
	}
	
function isms_component_get_host_message($user_id){
	$txt=get_user_meta($user_id,'isms_notifications_host_message');
	if($txt=="")
		$txt="%host% %type% (%hoststate%) %hostoutput% Addr: %hostaddress%  Time: %datetime% Nagios URL: %xiserverurl%";
	return $txt;
	}

function isms_component_get_service_message($user_id){
	$txt=get_user_meta($user_id,'isms_notifications_service_message');
	if($txt=="")
		$txt="%host% / %service% %type% (%servicestate%) %serviceoutput% Time: %datetime% Nagios URL: %xiserverurl%";
	return $txt;
	}


////////////////////////////////////////////////////////////////////////
// EVENT HANDLER AND NOTIFICATION FUNCTIONS
////////////////////////////////////////////////////////////////////////

register_callback(CALLBACK_EVENT_PROCESSED,'isms_component_eventhandler');
//isms_component_eventhandler_register_callbacks();

function isms_component_eventhandler_register_callbacks(){

	$settings_raw=get_option("isms_component_options");
	if($settings_raw=="")
		$settings=array();
	else
		$settings=unserialize($settings_raw);
				
	// bail out of component is not enabled
	$enabled=grab_array_var($settings,"enabled","");
	if($enabled!=1)
		return;

	register_callback(CALLBACK_EVENT_PROCESSED,'isms_component_eventhandler');
	}

function isms_component_eventhandler($cbtype,$args){

	$settings_raw=get_option("isms_component_options");
	if($settings_raw=="")
		$settings=array();
	else
		$settings=unserialize($settings_raw);
				
	// bail out of component is not enabled
	$enabled=grab_array_var($settings,"enabled","");
	if($enabled!=1)
		return;

	switch($args["event_type"]){
		case EVENTTYPE_NOTIFICATION:
			isms_component_handle_notification_event($args);
			break;
		default:
			break;
		}
	}
	
function isms_component_handle_notification_event($args){

	$meta=$args["event_meta"];
	$contact=$meta["contact"];
	$nt=$meta["notification-type"];
	
	// find the XI user
	$user_id=get_user_id($contact);
	if($user_id<=0)
		return;
		
	echo "==== iSMS Notification Handler ====\n";
		
	// bail if user has notifications disabled completely
	$notifications_enabled=get_user_meta($user_id,'enable_notifications');
	if($notifications_enabled!=1){
		echo "ERROR: User has (global) notifications disabled!\n";
		return;
		}
		
	// set user id session variable - used later in date/time, preference, etc. functions
	if(!defined("NAGIOSXI_USER_ID"))
		define("NAGIOSXI_USER_ID",$user_id);

	echo " iSMS: CONTACT=$contact, USERID=$user_id\n";
		
	// get settings
	$isms_notifications_enabled=get_user_meta($user_id,"isms_notifications_enabled");
	$isms_mobile_number=get_user_meta($user_id,'isms_mobile_number');
	
	// not enabled for this user
	if($isms_notifications_enabled!=1){
		echo " iSMS: User has SMS notifications disabled\n";
		return 1;
		}
	
	// don't have a mobile number
	if($isms_mobile_number==""){
		echo "iSMS: User does not have a mobile number specified\n";
		return 1;
		}
		
	// get the SMS message
	if($meta["notification-type"]=="service"){
		$message=isms_component_get_service_message($user_id);
		}
	else{
		$message=isms_component_get_host_message($user_id);
		}
		
	echo " iSMS: RAW MESSAGE='".$message."'\n";
		
	// process notification text (replace variables)
	$message=process_notification_text($message,$meta);
	
	// trim the message
	$message=substr($message,0,159);

	echo " iSMS: SMS MESSAGE='".$message."'\n";
	
	$args=array(
		"number" => $isms_mobile_number,
		"message" => $message,
		);
	//echo "iSMS: SMS ARGS:\n";
	//print_r($args);
	//echo "\n";
	
	// send the SMS message
	$outargs=array();
	$smsresult=isms_component_send_sms($args,$outargs);

	
	echo "SMS RESULT=$smsresult\n";
	//echo "SMS OUTARGS:\n";
	//print_r($outargs);
	//echo "\n";

	return 0;
	}
	

////////////////////////////////////////////////////////////////////////
// ISMS NOTIFICATION FUNCTIONS
////////////////////////////////////////////////////////////////////////

function isms_component_send_sms($args,&$outargs){

	$number=grab_array_var($args,"number");
	$message=grab_array_var($args,"message");
	
	// bail if empty number or message
	if($number=="" || $message=="")
		return 1;

	// load settings
	$settings_raw=get_option("isms_component_options");
	if($settings_raw=="")
		$settings=array();
	else
		$settings=unserialize($settings_raw);
				
	$address=grab_array_var($settings,"address");
	$http_port=grab_array_var($settings,"http_port");
	$username=grab_array_var($settings,"username");
	$password=grab_array_var($settings,"password");

	// bail out if we don't have the required info
	if($address=="" || $http_port=="" || $username=="" || $password=="")
		return 1;

	// construct the URL for the send API
	$url="http://".$address.":".$http_port."/sendmsg?user=".$username."&passwd=".$password."&cat=1&to=\"".urlencode($number)."\"&text=".rawurlencode($message);
	
	// send the request
	$urloutput=load_url($url,array('method'=>'get','return_info'=>false));
	
	// check output for indication of success
	$res=strpos($urloutput,"ID:");
	if($res===FALSE)
		return 1;
	
	$outargs=array();
	$outargs["url"]=$url;
	$outargs["result"]=$urloutput;

	return 0;
	}



?>