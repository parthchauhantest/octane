<?php
//
// Copyright (c) 2008-2009 Nagios Enterprises, LLC.  All rights reserved.
//
// $Id: globalconfig.php 319 2010-09-24 19:18:25Z egalstad $

require_once(dirname(__FILE__).'/../componenthelper.inc.php');

// initialization stuff
pre_init();

// start session
init_session();

// grab GET or POST variables 
grab_request_vars();

// check prereqs
check_prereqs();

// check authentication
check_authentication(false);

// only admins can access this page
if(is_admin()==false){
	echo $lstr['NotAuthorizedErrorText'];
	exit();
	}

// route request
route_request();


function route_request(){
	global $request;

	if(isset($request['update']))
		do_update_options();
	else
		show_options();
	exit;
	}
	
	
function show_options($error=false,$msg=""){
	global $request;
	global $lstr;
	
	//proxy options
	$use_proxy = grab_request_var("use_proxy",get_option('use_proxy')); //checkbox
	$proxy_address = grab_request_var("proxy_address",get_option('proxy_address')); 
	$proxy_port = grab_request_var("proxy_port",get_option('proxy_port'));
	$proxy_auth = grab_request_var("proxy_auth",get_option('proxy_auth'));
    $proxy_tunnel = grab_request_var("proxy_tunnel",get_option('proxy_tunnel',1));
	
	do_page_start("Proxy Configuration",true);
?>
	
	<h1><?php echo gettext("Proxy Configuration"); ?></h1>
	
<?php
	display_message($error,false,$msg);
?>

	<form id="manageOptionsForm" method="post" action="<?php echo htmlentities($_SERVER['PHP_SELF']);?>">
	
	<input type="hidden" name="options" value="1">
	<?php echo get_nagios_session_protector();?>
	<input type="hidden" name="update" value="1">
	
	<div class="sectionTitle"><?php echo gettext("Proxy Settings"); ?></div>

	<table class="manageOptionsTable">
	
	<tr>
		<td><label for="autoUpdateCheckBox"><?php echo gettext("Enable Proxy For Update Checks"); ?>:</label></td>
		<td>
			<input type="checkbox" class="checkbox" id="use_proxy" name="use_proxy" <?php echo is_checked($use_proxy,1);?>>
			<br class="nobr" />
		</td>
	</tr>

	<tr>
	<td><label for="proxy_address"><?php echo gettext("Proxy Address"); ?>: </label><br class="nobr" /></td>
	<td>
		<input type="text" size="45" name="proxy_address" id="proxy_address" value="<?php echo encode_form_val($proxy_address);?>" class="textfield" />
		<br class="nobr" />
	</td>
	</tr>
	
	<tr>
		<td><label for="adminNameBox"><?php echo gettext("Proxy Port"); ?>:</label><br class="nobr" /></td>
		<td>
			<input type="text" size="30" name="proxy_port" id="proxy_port" value="<?php echo encode_form_val($proxy_port);?>" class="textfield" />
			<br class="nobr" />
		</td>
	</tr>
	
	<tr>
	<td><label for="proxy_auth"><?php echo gettext("Proxy Auth"); ?>: &nbsp; <em><?php echo gettext("username:password"); ?></em> &nbsp; </label><br class="nobr" /></td>
	<td>
		<input type="text" size="30" name="proxy_auth" id="proxy_auth" value="<?php echo encode_form_val($proxy_auth);?>" class="textfield" />
		<br class="nobr" />
	</td>
	</tr>
    
    <tr>
	<td><label for="proxy_tunnel"><?php echo gettext("Use HTTP Tunnel"); ?>:</label><br class="nobr" /></td>
	<td>
		<input type="checkbox" class="checkbox" id="proxy_tunnel" name="proxy_tunnel" <?php echo is_checked($proxy_tunnel,1);?>>
		<br class="nobr" />
	</td>
	</tr>
	</table> <!-- end proxy options table -->

	<div id="formButtons">
	<input type="submit" class="submitbutton" name="updateButton" value="<?php echo $lstr['UpdateSettingsButton'];?>" id="updateButton">
	<input type="submit" class="submitbutton" name="cancelButton" value="<?php echo $lstr['CancelButton'];?>" id="cancelButton">
	</div>
	
	<!--</fieldset>-->
	</form>

<?php

	do_page_end(true);
	exit();
	}


function do_update_options()
{
	global $request;
	global $lstr;
	
	// user pressed the cancel button
	if(isset($request["cancelButton"]))
		header("Location: /nagiosxi/admin/main.php");
		
	// check session
	check_nagios_session_protector();
	
	$errmsg=array();
	$errors=0;
	
	//proxy address
	$use_proxy = grab_request_var('use_proxy','');
	if(have_value($use_proxy)==true)
		$use_proxy=1;
	else
		$use_proxy=0;
	$proxy_address = grab_request_var('proxy_address','');
	$proxy_port = grab_request_var('proxy_port','');
	$proxy_auth = grab_request_var('proxy_auth','');
    $proxy_tunnel = grab_request_var('proxy_tunnel','');
	if(have_value($proxy_tunnel)==true)
		$proxy_tunnel=1;
	else
		$proxy_tunnel=0;
		
	// handle errors
	if($errors>0)
		show_options(true,$errmsg);
		
	// update options	
	set_option('use_proxy',$use_proxy); 
	set_option('proxy_address',$proxy_address);
	set_option('proxy_port',$proxy_port);
	set_option('proxy_auth',$proxy_auth);
    set_option('proxy_tunnel',$proxy_tunnel); 
		
	// success!
	show_options(false,"Proxy settings updated successfully!");
}
		
		

	

?>