<?php
// Actions Component
//
// Copyright (c) 2011 Nagios Enterprises, LLC.  All rights reserved.
//  
// $Id: actions.inc.php 250 2011-01-30 16:57:02Z egalstad $

require_once(dirname(__FILE__).'/../componenthelper.inc.php');


// respect the name
$actions_component_name="actions";

// run the initialization function
actions_component_init();

////////////////////////////////////////////////////////////////////////
// COMPONENT INIT FUNCTIONS
////////////////////////////////////////////////////////////////////////

function actions_component_init(){
	global $actions_component_name;
	
	$versionok=actions_component_checkversion();
	
	$desc="";
	if(!$versionok)
		$desc="<br><b>Error: This component requires Nagios XI 2009R1.8 or later.</b>";

	$args=array(

		// need a name
		COMPONENT_NAME => $actions_component_name,
		
		// informative information
		COMPONENT_AUTHOR => "Nagios Enterprises, LLC",
		COMPONENT_DESCRIPTION => "Adds custom actions to hosts and services. ".$desc,
		COMPONENT_TITLE => "Actions",
        COMPONENT_VERSION => '1.4', 
		// configuration function (optional)
		COMPONENT_CONFIGFUNCTION => "actions_component_config_func",
		);
		
	register_component($actions_component_name,$args);
	
	if($versionok){
		// configure action callbacks
		register_callback(CALLBACK_HOST_DETAIL_ACTION_LINK,'actions_component_host_detail_action');
		register_callback(CALLBACK_SERVICE_DETAIL_ACTION_LINK,'actions_component_service_detail_action');
		}
	}
	

	
///////////////////////////////////////////////////////////////////////////////////////////
// VERSION CHECK FUNCTIONS
///////////////////////////////////////////////////////////////////////////////////////////

function actions_component_checkversion(){

	if(!function_exists('get_product_release'))
		return false;
	if(get_product_release()<207)
		return false;

	return true;
	}
	

///////////////////////////////////////////////////////////////////////////////////////////
// CONFIG FUNCTIONS
///////////////////////////////////////////////////////////////////////////////////////////

function actions_component_config_func($mode="",$inargs,&$outargs,&$result){

	// initialize return code and output
	$result=0;
	$output="";
	
	$component_name="actions";
	
	switch($mode){
		case COMPONENT_CONFIGMODE_GETSETTINGSHTML:
		
			// default settings
			$settings_default=array(
				"enabled" => 1,
				"actions" => array(
					),
				);
			$settings_default["actions"][]=array(
				"enabled" => 0,
				"type" => "host",
				"action_type" => "url",
				"target" => "_blank",
				"host" => "/.*/",
				"service" => "",
				"hostgroup" => "",
				"servicegroup" => "",
				"code" => "",
				"url" => "http://www.google.com/search?q=%host%",
				"text" => "Search for host on Google",
				);
			$settings_default["actions"][]=array(
				"enabled" => 0,
				"type" => "service",
				"action_type" => "url",
				"target" => "_blank",
				"host" => "/.*/",
				"service" => "/.*/",
				"hostgroup" => "",
				"servicegroup" => "",
				"code" => "",
				"url" => "http://www.google.com/search?q=%host%+%service%",
				"text" => "Search for service on Google",
				);

			// saved settings
			$settings_raw=get_option("actions_component_options");
			if($settings_raw!=""){
				$settings_default=unserialize($settings_raw);
				}
		
			// settings passed to us
			$settings=grab_array_var($inargs,"settings",$settings_default);
						
			
				
			// checkboxes
			$enabled=checkbox_binary(grab_array_var($settings,"enabled",""));
			foreach($settings["actions"] as $x => $sa){
				$settings["actions"][$x]["enabled"]=checkbox_binary(grab_array_var($sa,"enabled",""));
				}

			// trim empty lines
			foreach($settings["actions"] as $x => $sa){
				if($sa["host"]==""  && $sa["service"]=="" && $sa["url"]=="")
					unset($settings["actions"][$x]);
				}
			// renumber items
			$settings_new=array();
			$y=0;
			foreach($settings["actions"] as $x => $sa){
				$settings_new[$y++]=$sa;
				}
			$settings["actions"]=$settings_new;
			
			
			// get hostgroups
			$hostgroups=array();
			$args=array(
				"orderby" => "hostgroup_name:a",
				);
			$xml=get_xml_hostgroup_objects($args);
			if($xml){
				foreach($xml->hostgroup as $hg){
					$hgname=strval($hg->hostgroup_name);
					$hgalias=strval($hg->alias);
					$hostgroups[$hgname]=array(
						"name" => $hgname,
						"alias" => $hgalias,
						);
					}
				}
				
			// get servicegroups
			$servicegroups=array();
			$args=array(
				"orderby" => "servicegroup_name:a",
				);
			$xml=get_xml_servicegroup_objects($args);
			if($xml){
				foreach($xml->servicegroup as $sg){
					$sgname=strval($sg->servicegroup_name);
					$sgalias=strval($sg->alias);
					$servicegroups[$sgname]=array(
						"name" => $sgname,
						"alias" => $sgalias,
						);
					}
				}
				

				
			$component_url=get_component_url_base($component_name);

			$output='
			
	<div class="sectionTitle">Action Settings</div>
	
	<table>

	<tr>
	<td valign="top">
	<label for="enabled">Enable Component:</label><br class="nobr" />
	</td>
	<td>
	<input type="checkbox" class="checkbox" id="enabled" name="settings[enabled]" '.is_checked($enabled,1).'>
<br class="nobr" />
	Enables custom actions in Nagios XI.<br><br>
	</td>
	</tr>

	</table>
	';
	
	/*
	$r=is_host_member_of_hostgroup("api.nagios.com","test-hg1");
	$output.="api.nagios.com => test-hg1 = ".serialize($r)."<BR>";
	$r=is_host_member_of_hostgroup("www.nagios.com","test-hg1");
	$output.="www..nagios.com => test-hg1 = ".serialize($r)."<BR>";
	
	$r=is_service_member_of_servicegroup("localhost","Current Load","test-sg2");
	$output.="localhost / Current Load => test-sg2 = ".serialize($r)."<BR>";
	$r=is_service_member_of_hostgroup("www.nagios.com","PING","test-sg2");
	$output.="www.nagios.com / PING => test-sg2 = ".serialize($r)."<BR>";
	
	$r=is_host_member_of_servicegroup("localhost","test-sg2");
	$output.="localhost => test-sg2 = ".serialize($r)."<BR>";
	$r=is_host_member_of_servicegroup("www.nagios.com","test-sg2");
	$output.="www.nagios.com => test-sg2 = ".serialize($r)."<BR>";

	$r=is_service_member_of_hostgroup("localhost","Current Load","test-hg1");
	$output.="localhost / Current Load => test-hg1 = ".serialize($r)."<BR>";
	$r=is_service_member_of_hostgroup("www.nagios.com","PING","test-hg1");
	$output.="www.nagios.com / PING => test-hg1 = ".serialize($r)."<BR>";
*/

	$output.='

	<div class="sectionTitle">Actions</div>
	
	<p>
	<strong>Notes</strong>:
	</p>
	<ul>
	<li>The <i>Host</i> and <i>Service</i> fields are regular expression patterns passed to preg_match().  A link will only be displayed for hosts and services that match the expressions specified.</li>
	<li>The <i>URL/Command</i> field can contain macros that are substituted for each host and service.</li>
	<li>The <i>Code</i> field can contain optional PHP code to be evaluated.</li>
	<li>The <i>URL/Command</i>, <i>Code</i>, and <i>Action Text</i> fields can contain variables.</li>
	</ul>
	
	<table class="standardtable">
	
	<tr><th>Enabled</th><th>Match Criteria</th><th>Action</th><th>Code</th></tr>

';

	/* add an empty row at the end... */
	$settings["actions"][]=array(
		"enabled" => 0,
		"type" => "any",
		"host" => "",
		"service" => "",
		"hostgroup" => "",
		"servicegroup" => "",
		"action_type" => "url",
		"url" => "",
		"target" => "_blank",
		"text" => "",
		"code" => "",
		);

	foreach($settings["actions"] as $x => $sa){
		$output.='<tr>';
		$output.='<td><input type="checkbox" name="settings[actions]['.$x.'][enabled]" '.is_checked($sa["enabled"],1).'></td>';	

		$output.='<td>';
		$output.='<table>';
		$output.='<tr><td><label>Object Type:</label></td><td><select name="settings[actions]['.$x.'][type]"><option value="any" '.is_selected($sa["type"],"any").'>Any</option><option value="host" '.is_selected($sa["type"],"host").'>Host</option><option value="service" '.is_selected($sa["type"],"service").'>Service</option></select></td></tr>';
		$output.='<tr><td><label>Host:</label></td><td><input type="text" name="settings[actions]['.$x.'][host]" size="10" value="'.htmlentities($sa["host"]).'"></td></tr>';
		$output.='<tr><td><label>Service:</label></td><td><input type="text" name="settings[actions]['.$x.'][service]" size="10" value="'.htmlentities($sa["service"]).'"></td></tr>';
		$output.='<tr><td><label>Hostgroup:</label></td><td><select name="settings[actions]['.$x.'][hostgroup]"><option value="" '.is_selected($sa["hostgroup"],"").'></option>';
		foreach($hostgroups as $hg){
			$output.='<option value="'.htmlentities($hg["name"]).'" '.is_selected($settings["actions"][$x]["hostgroup"],$hg["name"]).'>'.htmlentities($hg["name"]).'</option>';
			}
		$output.='</td></tr>';
		$output.='<tr><td><label>Servicegroup:</label></td><td><select name="settings[actions]['.$x.'][servicegroup]"><option value="" '.is_selected($sa["servicegroup"],"").'></option>';
		foreach($servicegroups as $sg){
			$output.='<option value="'.htmlentities($sg["name"]).'" '.is_selected($settings["actions"][$x]["servicegroup"],$sg["name"]).'>'.htmlentities($sg["name"]).'</option>';
			}
		$output.='</td></tr>';


		$output.='</table>';
		$output.='</td>';
		
		$output.='<td>';
		$output.='<table>';
		$output.='<tr><td><label>Action Type:</label></td><td><select name="settings[actions]['.$x.'][action_type]"><option value="url" '.is_selected($sa["action_type"],"url").'>URL</option><option value="command" '.is_selected($sa["action_type"],"command").'>Command</option></select></td></tr>';
		$output.='<tr><td><label>URL / Command:</label></td><td><input type="text" name="settings[actions]['.$x.'][url]" value="'.htmlentities($sa["url"]).'" size="40"></td></tr>';
		$output.='<tr><td><label>Action Text:</label></td><td><input type="text" name="settings[actions]['.$x.'][text]" value="'.htmlentities($sa["text"]).'" size="40"></td></tr>';
		$output.='</table>';
		$output.='</td>';
		
		if($sa["code"]==""){
			$sa["code"]="/*if((%objecttype%=='host' && '%hoststateid%'!='0') || (%objecttype%=='service' && '%servicestateid%'!='0')){\$img='/nagiosxi/images/schedulecheck.png';\$showlink=true;} else{\$showlink=false;}*/";
			}
		
		$output.='<td><textarea name="settings[actions]['.$x.'][code]" rows="5" cols="20">'.htmlentities($sa["code"]).'</textarea></td>';

		$output.='<input type="hidden" name="settings[actions]['.$x.'][target]" value="_blank">';
		//$output.='<select name="settings[actions]['.$x.'][target]"><option value="_blank" '.is_selected($sa["target"],"_blank").'>New Window</option><option value="_self" '.is_selected($sa["target"],"_self").'>Same Window</option></select></td>';
		
		$output.='</tr>';
		}

	// add some blank rows for new additions
	/*
	$total_actions=count($settings["actions"]);
	for($x=$total_actions;$x<($total_actions+3);$x++){
		$output.='<tr>';
		$output.='<td><input type="checkbox" name="settings[actions]['.$x.'][enabled]"></td>';
		$output.='<td><select name="settings[actions]['.$x.'][type]"><option value="host">Host</option><option value="service">Service</option></select></td>';
		$output.='<td><input type="text" name="settings[actions]['.$x.'][host]" size="6"></td>';
		$output.='<td><input type="text" name="settings[actions]['.$x.'][service]" size="10"></td>';
		$output.='<td><textarea name="settings[actions]['.$x.'][code]" rows="3" cols="20"></textarea></td>';
		$output.='<td><input type="text" name="settings[actions]['.$x.'][url]"></td>';
		$output.='<td><select name="settings[actions]['.$x.'][target]"><option value="_blank">New Window</option><option value="_self">Same Window</option></select></td>';
		$output.='<td><input type="text" name="settings[actions]['.$x.'][text]"></td>';
		$output.='</tr>';
		}
	*/
	
$output.='
	</table>

	';
			break;
			
		case COMPONENT_CONFIGMODE_SAVESETTINGS:
		
			// get variables
			$settings=grab_array_var($inargs,"settings",array("settings"=>array()));

			// fix checkboxes
			$settings["enabled"]=checkbox_binary(grab_array_var($settings,"enabled",""));
			foreach($settings["actions"] as $x => $sa){
				$settings["actions"][$x]["enabled"]=checkbox_binary(grab_array_var($sa,"enabled",""));
				}
			$enabled=grab_array_var($settings,"enabled");	
			// trim empty lines
			foreach($settings["actions"] as $x => $sa){
				if($sa["host"]==""  && $sa["service"]=="" && $sa["url"]=="")
					unset($settings["actions"][$x]);
				}
			// renumber items
			$settings_new=array();
			$y=0;
			foreach($settings["actions"] as $x => $sa){
				// add a uid
				$sa["uid"]=random_string(6);
				$settings_new[$y++]=$sa;
				}
			$settings["actions"]=$settings_new;
				
				
			//print_r($settings);
			//exit();
			
			// validate variables
			$errors=0;
			$errmsg=array();
			if($enabled==1){
			
				foreach($settings["actions"] as $x => $sa){
					if($sa["enabled"]==1){
						if($sa["url"]=="")
							$errmsg[$errors++]="No URL specified on line ".($x+1);
						if(have_value($sa["text"])==false)
							$errmsg[$errors++]="No action text specified on line ".($x+1);
						}
					}

				}
			
			// handle errors
			if($errors>0){
				$outargs[COMPONENT_ERROR_MESSAGES]=$errmsg;
				$result=1;
				return '';
				}
			
			// save settings
			set_option("actions_component_options",serialize($settings));
						
			break;
		
		default:
			break;
			
		}
		
	return $output;
	}

	
///////////////////////////////////////////////////////////////////////////////////////////
// ACTION FUNCTIONS
///////////////////////////////////////////////////////////////////////////////////////////

function actions_component_host_detail_action($cbtype,&$cbargs){

	// get our settings
	$settings_raw=get_option("actions_component_options");
	if($settings_raw==""){
		$settings=array(
			"enabled" => 0,
			);
		}
	else
		$settings=unserialize($settings_raw);	

	// initial values
	$enabled=grab_array_var($settings,"enabled");
	
	//print_r($settings);
	
	// bail out if we're not enabled...
	if($enabled!=1){
		return;
		}
		
		
	// add an action link...

	$hostname=grab_array_var($cbargs,"hostname");
	$host_id=grab_array_var($cbargs,"host_id");
	$hoststatus_xml=grab_array_var($cbargs,"hoststatus_xml");
	
	// get variables
	$objectvars=actions_component_get_host_vars($hostname,$host_id,$hoststatus_xml);
	//print_r($objectvars);
		
	$component_url=get_component_url_base("actions");
	$img=$component_url."/images/action.png";

	// find matching actions
	foreach($settings["actions"] as $x => $sa){
		if($sa["enabled"]!=1)
			continue;
		// must be host type
		if($sa["type"]!="host" && $sa["type"]!="any")
			continue;
		// must match host name
		if($sa["host"]!="" && preg_match($sa["host"],$hostname)==0)
			continue;
		// must match hostgroup if specified
		if($sa["hostgroup"]!="" && is_host_member_of_hostgroup($hostname,$sa["hostgroup"])==false)
			continue;
		// must match servicegroup if specified
		if($sa["servicegroup"]!="" && is_host_member_of_servicegroup($hostname,$sa["servicegroup"])==false)
			continue;	
			
		// good to go...
		
		// URL
		if($sa["action_type"]=="url"){
		
			$url=$sa["url"];
			$target=$sa["target"];
			$hrefopts="";
			
			// process vars in url
			foreach($objectvars as $var => $val){
				$tvar="%".$var."%";
				$url=str_replace($tvar,urlencode($val),$url);
				}
			}
			
		// COMMAND
		else{
	
			$url=$component_url."/runcmd.php?action=".urlencode($x)."&uid=".urlencode($sa["uid"])."&host=".urlencode($hostname);
			$target="_blank";
			$hrefopts="";
			}

		// action text
		$text=$sa["text"];
			
		// get optional code to run
		$code=$sa["code"];
		
		// process vars in text, and php code
		foreach($objectvars as $var => $val){
			$tvar="%".$var."%";
			$text=str_replace($tvar,$val,$text);
			$code=str_replace($tvar,$val,$code);
			}
				
		$showlink=true;
			
		// execute PHP code
		if($code!=""){
			eval($code);
			}
		// code indicated we shouldn't show this link
		if($showlink==false)	
			return;
		
		$cbargs["actions"][]='<li><div class="commandimage"><a href="'.$url.'" target="'.$target.'" '.$hrefopts.'><img src="'.$img.'" alt="'.htmlentities($text).'" title="'.htmlentities($text).'"></a></div><div class="commandtext"><a href="'.$url.'" target="'.$target.'" '.$hrefopts.'>'.htmlentities($text).'</a></div></li>';
		}
		
	}

function actions_component_service_detail_action($cbtype,&$cbargs){

	// get our settings
	$settings_raw=get_option("actions_component_options");
	if($settings_raw==""){
		$settings=array(
			"enabled" => 0,
			);
		}
	else
		$settings=unserialize($settings_raw);	

	// initial values
	$enabled=grab_array_var($settings,"enabled");
	
	//print_r($settings);
	
	// bail out if we're not enabled...
	if($enabled!=1){
		return;
		}
		
		
	// add an action link...

	$hostname=grab_array_var($cbargs,"hostname");
	$servicename=grab_array_var($cbargs,"servicename");
	$service_id=grab_array_var($cbargs,"service_id");
	$servicestatus_xml=grab_array_var($cbargs,"servicestatus_xml");

	// get variables
	$objectvars=actions_component_get_service_vars($hostname,$servicename,$service_id,$servicestatus_xml);
	//print_r($objectvars);
		
	$component_url=get_component_url_base("actions");
	$img=$component_url."/images/action.png";

	// find matching actions
	foreach($settings["actions"] as $x => $sa){
		if($sa["enabled"]!=1)
			continue;
		// must be service type
		if($sa["type"]!="service" && $sa["type"]!="any")
			continue;
		// must match host name
		if($sa["host"]!="" && preg_match($sa["host"],$hostname)==0)
			continue;
		// must match service name
		if($sa["service"]!="" && preg_match($sa["service"],$servicename)==0)
			continue;
		// must match hostgroup if specified
		if($sa["hostgroup"]!="" && is_service_member_of_hostgroup($hostname,$servicename,$sa["hostgroup"])==false)
			continue;
		// must match servicegroup if specified
		if($sa["servicegroup"]!="" && is_service_member_of_servicegroup($hostname,$servicename,$sa["servicegroup"])==false)
			continue;	
			
		// good to go...
		
		// URL
		if($sa["action_type"]=="url"){
		
			$url=$sa["url"];
			$target=$sa["target"];
			$hrefopts="";
			
			// process vars in url
			foreach($objectvars as $var => $val){
				$tvar="%".$var."%";
				$url=str_replace($tvar,urlencode($val),$url);
				}
			}
			
		// COMMAND
		else{
	
			$url=$component_url."/runcmd.php?action=".urlencode($x)."&uid=".urlencode($sa["uid"])."&host=".urlencode($hostname)."&service=".urlencode($servicename);
			$target="_blank";
			$hrefopts="";
			}

		// action text
		$text=$sa["text"];
			
		// get optional code to run
		$code=$sa["code"];
		
			
		// process vars in text, and php code
		foreach($objectvars as $var => $val){
			$tvar="%".$var."%";
			$text=str_replace($tvar,$val,$text);
			$code=str_replace($tvar,$val,$code);
			}
				
		$showlink=true;
			
		// execute PHP code
		if($code!=""){
			eval($code);
			}
		// code indicated we shouldn't show this link
		if($showlink==false)	
			return;
		
		$cbargs["actions"][]='<li><div class="commandimage"><a href="'.$url.'" target="'.$target.'" '.$hrefopts.'><img src="'.$img.'" alt="'.htmlentities($text).'" title="'.htmlentities($text).'"></a></div><div class="commandtext"><a href="'.$url.'" target="'.$target.'" '.$hrefopts.'>'.htmlentities($text).'</a></div></li>';
		}
		
	}

	
	
function actions_component_get_host_vars($hostname,$host_id=-1,$hoststatus_xml=null){

	$hostaddress=$hostname;

	$objectvars=array();
	
	// find the host's address (and possibly id)
	$args=array(
		"cmd" => "gethosts",
		);
	if($host_id==-1)
		$args["name"]=$hostname;
	else
		$args["host_id"]=$host_id;

	$xml=get_xml_host_objects($args);
	if($xml){
		$hostaddress=strval($xml->host->address);
		}
		
	// fetch host status if needed
	if($hoststatus_xml==null){
		$args=array(
			"cmd" => "gethoststatus",
			"name" => $hostname,
			);
		$hoststatus_xml=get_xml_host_status($args);
		}
		
	// variables
	$objectvars=array(
		"objecttype"=>"host",
		"host"=>$hostname,
		"hostname"=>$hostname,
		"hostaddress"=>$hostaddress,
		"hostid"=>strval($hoststatus_xml->hoststatus->host_id),
		"hostdisplayname"=>strval($hoststatus_xml->hoststatus->display_name),
		"hostalias"=>strval($hoststatus_xml->hoststatus->alias),
		"hoststateid"=>intval($hoststatus_xml->hoststatus->current_state),
		"hoststatetype"=>strval($hoststatus_xml->hoststatus->state_type),
		"hoststatustext"=>strval($hoststatus_xml->hoststatus->status_text),
		"hoststatustextlong"=>strval($hoststatus_xml->hoststatus->status_text_long),
		"hostperfdata"=>strval($hoststatus_xml->hoststatus->performance_data),
		"hostchecktype"=>strval($hoststatus_xml->hoststatus->check_type),
		"hostactivechecks"=>strval($hoststatus_xml->hoststatus->active_checks_enabled),
		"hostpassivechecks"=>strval($hoststatus_xml->hoststatus->passive_checks_enabled),
		"hostnotifications"=>strval($hoststatus_xml->hoststatus->notifications_enabled),
		"hostacknowledged"=>strval($hoststatus_xml->hoststatus->problem_acknowledged),
		"hosteventhandler"=>strval($hoststatus_xml->hoststatus->event_handler_enabled),
		"hostflapdetection"=>strval($hoststatus_xml->hoststatus->flap_detection_enabled),
		"hostisflapping"=>strval($hoststatus_xml->hoststatus->is_flapping),
		"hostpercentstatechange"=>strval($hoststatus_xml->hoststatus->percent_state_change),
		"hostdowntime"=>strval($hoststatus_xml->hoststatus->scheduled_downtime_depth),
		"hostlatency"=>strval($hoststatus_xml->hoststatus->latency),
		"hostexectime"=>strval($hoststatus_xml->hoststatus->execution_time),
		"hostlastcheck"=>strval($hoststatus_xml->hoststatus->last_check),
		"hostnextcheck"=>strval($hoststatus_xml->hoststatus->next_check),
		"hosthasbeenchecked"=>strval($hoststatus_xml->hoststatus->has_been_checked),
		"hostshouldbescheduled"=>strval($hoststatus_xml->hoststatus->should_be_scheduled),
		"hostcurrentattempt"=>strval($hoststatus_xml->hoststatus->current_check_attempt),
		"hostmaxattempts"=>strval($hoststatus_xml->hoststatus->max_check_attempts),
		);

	return $objectvars;
	}
	
function actions_component_get_service_vars($hostname,$servicename,$service_id,$servicestatus_xml){

	$objectvars=array();
	
	$hostaddress=$hostname;
    
    if($servicestatus_xml==null){
            $args=array(
                "cmd" => "getservicestatus",
                "host_name" => $hostname,
                "service_description" => $servicename,
                "combinedhost" => 1,
                
                );
            $servicestatus_xml=get_xml_service_status($args);
            }
    
	// find the host's address
	$args=array(
		"cmd" => "gethosts",
		"host_id" => intval($servicestatus_xml->servicestatus->host_id),
		);
	$xml=get_xml_host_objects($args);
	if($xml){
		$hostaddress=strval($xml->host->address);
		}
		
	// variables
	$objectvars=array(
		"objecttype"=>"service",
		"service"=>$servicename,
		"servicename"=>$servicename,
		"serviceid"=>strval($servicestatus_xml->servicestatus->service_id),
		"servicedisplayname"=>strval($servicestatus_xml->servicestatus->display_name),
		"servicestateid"=>intval($servicestatus_xml->servicestatus->current_state),
		"servicestatetype"=>strval($servicestatus_xml->servicestatus->state_type),
		"servicestatustext"=>strval($servicestatus_xml->servicestatus->status_text),
		"servicestatustextlong"=>strval($servicestatus_xml->servicestatus->status_text_long),
		"serviceperfdata"=>strval($servicestatus_xml->servicestatus->performance_data),
		"hostchecktype"=>strval($servicestatus_xml->servicestatus->check_type),
		"serviceactivechecks"=>strval($servicestatus_xml->servicestatus->active_checks_enabled),
		"servicepassivechecks"=>strval($servicestatus_xml->servicestatus->passive_checks_enabled),
		"servicenotifications"=>strval($servicestatus_xml->servicestatus->notifications_enabled),
		"serviceacknowledged"=>strval($servicestatus_xml->servicestatus->problem_acknowledged),
		"serviceeventhandler"=>strval($servicestatus_xml->servicestatus->event_handler_enabled),
		"serviceflapdetection"=>strval($servicestatus_xml->servicestatus->flap_detection_enabled),
		"serviceisflapping"=>strval($servicestatus_xml->servicestatus->is_flapping),
		"servicepercentstatechange"=>strval($servicestatus_xml->servicestatus->percent_state_change),
		"servicedowntime"=>strval($servicestatus_xml->servicestatus->scheduled_downtime_depth),
		"servicelatency"=>strval($servicestatus_xml->servicestatus->latency),
		"serviceexectime"=>strval($servicestatus_xml->servicestatus->execution_time),
		"servicelastcheck"=>strval($servicestatus_xml->servicestatus->last_check),
		"servicenextcheck"=>strval($servicestatus_xml->servicestatus->next_check),
		"servicehasbeenchecked"=>strval($servicestatus_xml->servicestatus->has_been_checked),
		"serviceshouldbescheduled"=>strval($servicestatus_xml->servicestatus->should_be_scheduled),
		"servicecurrentattempt"=>strval($servicestatus_xml->servicestatus->current_check_attempt),
		"servicemaxattempts"=>strval($servicestatus_xml->servicestatus->max_check_attempts),

		
		"host"=>$hostname,
		"hostname"=>$hostname,
		"hostaddress"=>$hostaddress,
		"hostid"=>strval($servicestatus_xml->servicestatus->host_id),
		"hostdisplayname"=>strval($servicestatus_xml->servicestatus->host_display_name),
		//"hostalias"=>strval($servicestatus_xml->servicestatus->host_alias),
		"hoststateid"=>intval($servicestatus_xml->servicestatus->host_current_state),
		"hoststatetype"=>strval($servicestatus_xml->servicestatus->host_state_type),
		"hoststatustext"=>strval($servicestatus_xml->servicestatus->host_status_text),
		"hoststatustextlong"=>strval($servicestatus_xml->servicestatus->host_status_text_long),
		"hostperfdata"=>strval($servicestatus_xml->servicestatus->host_performance_data),
		"hostchecktype"=>strval($servicestatus_xml->servicestatus->host_check_type),
		"hostactivechecks"=>strval($servicestatus_xml->servicestatus->host_active_checks_enabled),
		"hostpassivechecks"=>strval($servicestatus_xml->servicestatus->host_passive_checks_enabled),
		"hostnotifications"=>strval($servicestatus_xml->servicestatus->host_notifications_enabled),
		"hostacknowledged"=>strval($servicestatus_xml->servicestatus->host_problem_acknowledged),
		"hosteventhandler"=>strval($servicestatus_xml->servicestatus->host_event_handler_enabled),
		"hostflapdetection"=>strval($servicestatus_xml->servicestatus->host_flap_detection_enabled),
		"hostisflapping"=>strval($servicestatus_xml->servicestatus->host_is_flapping),
		"hostpercentstatechange"=>strval($servicestatus_xml->servicestatus->host_percent_state_change),
		"hostdowntime"=>strval($servicestatus_xml->servicestatus->host_scheduled_downtime_depth),
		"hostlatency"=>strval($servicestatus_xml->servicestatus->host_latency),
		"hostexectime"=>strval($servicestatus_xml->servicestatus->host_execution_time),
		"hostlastcheck"=>strval($servicestatus_xml->servicestatus->host_last_check),
		"hostnextcheck"=>strval($servicestatus_xml->servicestatus->host_next_check),
		"hosthasbeenchecked"=>strval($servicestatus_xml->servicestatus->host_has_been_checked),
		"hostshouldbescheduled"=>strval($servicestatus_xml->servicestatus->host_should_be_scheduled),
		"hostcurrentattempt"=>strval($servicestatus_xml->servicestatus->host_current_check_attempt),
		"hostmaxattempts"=>strval($servicestatus_xml->servicestatus->host_max_check_attempts),
		);
	
	return $objectvars;
	}

?>