<?php
// Lates Alerts
//
// Copyright (c) 2011 Nagios Enterprises, LLC.  All rights reserved.
//  
// $Id: eventlog.php 359 2010-10-31 17:08:47Z egalstad $

require_once(dirname(__FILE__).'/../../common.inc.php');

include_once(dirname(__FILE__).'/dashlet.inc.php');

// initialization stuff
pre_init();

// start session
init_session();

// grab GET or POST variables 
grab_request_vars();

// check prereqs
check_prereqs();

// check authentication
check_authentication(false);


route_request();

function route_request(){
	global $request;
			
	$mode=grab_request_var("mode");
	switch($mode){
		case "getdata":
			minemap_get_data();
			break;
		default:
			display_alerts();
			break;
		}
	}

function display_alerts(){
	global $lstr;

	$type=grab_request_var("type","");
	$host=grab_request_var("host","");
	$hostgroup=grab_request_var("hostgroup","");
	$servicegroup=grab_request_var("servicegroup","");
	$maxitems=grab_request_var("maxitems",20);

	// makes sure user has appropriate license level
	licensed_feature_check();

	// start the HTML page
	do_page_start(array("page_title"=>"Latest Alerts"),true);
	
?>
	<h1><?php echo gettext("Latest Alerts"); ?></h1>
	
	<form action="" method="get">
	<label><?php echo gettext("Limit To"); ?>:</label>
	<select name="hostgroup" id="hostgroupList">
	<option value=""><?php echo gettext("Hostgroup"); ?>:</option>
<?php
	$args=array('orderby' => 'hostgroup_name:a');
    $xml=get_xml_hostgroup_objects($args);
	if($xml){
		foreach($xml->hostgroup as $hg){
			$name=strval($hg->hostgroup_name);
			echo "<option value='".$name."' ".is_selected($hostgroup,$name).">$name</option>\n";
			}
		}
?>
	</select>
	<select name="servicegroup" id="servicegroupList">
	<option value=""><?php echo gettext("Servicegroup"); ?>:</option>
<?php
	$args=array('orderby' => 'servicegroup_name:a'); 
    $xml=get_xml_servicegroup_objects($args);
	if($xml){
		foreach($xml->servicegroup as $sg){
			$name=strval($sg->servicegroup_name);
			echo "<option value='".$name."' ".is_selected($servicegroup,$name).">$name</option>\n";
			}
		}
?>
	</select>
	<?php echo gettext("Max Items"); ?>
	<input type="text" name="maxitems" value="<?php echo htmlentities($maxitems);?>" size="2">
	<input type="submit" class="submitbutton" name="goButton" value="<?php echo $lstr['UpdateButton'];?>" id="goButton">
	</form>
	
	<script type="text/javascript">
	$(document).ready(function(){
		$('#servicegroupList').change(function() {
			$('#hostgroupList').val('');
			});
		$('#hostgroupList').change(function() {
			$('#servicegroupList').val('');
			});
		});
	</script>
	
	
<?php
	$dargs=array(
		DASHLET_ARGS => array(
			"type" => $type,
			"host" => $host,
			"hostgroup" => $hostgroup,
			"servicegroup" => $servicegroup,
			"maxitems" => $maxitems,
			),
		);
	/*
	echo "ARGS GOING IN=";
	print_r($dargs);
	echo "<BR>";
	*/
	display_dashlet("latestalerts","",$dargs,DASHLET_MODE_OUTBOARD);
?>

<?php		
	
	// closes the HTML page
	do_page_end(true);
	}
	