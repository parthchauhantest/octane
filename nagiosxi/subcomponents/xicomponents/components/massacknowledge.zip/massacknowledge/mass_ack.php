<?php  //mass_ack.php 
//
// Mass Acknowledge
//
// Copyright (c) 2011 Nagios Enterprises, LLC.  All rights reserved.
//  
// 

require_once(dirname(__FILE__).'/../../common.inc.php');
//require_once(dirname(__FILE__).'/../../../backend/includes/common.inc.php');

// initialization stuff
pre_init();
// start session
init_session();
// grab GET or POST variables 
grab_request_vars();
// check prereqs
check_prereqs();
// check authentication
check_authentication(false);

$title = "Nagios XI - Mass Acknowledgement";
?>
<?php 
do_page_start(array("page_title"=>$title),true);
?>
        
        <style type='text/css'>
		td {vertical-align:center; }
		.alignleft {text-align:left; }
		.aligncenter {text-align:center; }
		.plugin_output {width: 300px; overflow:hidden;word-wrap:break-word;}
		#massack_wrapper {margin: 10px auto; width: 1000px;}
		#checkAllButton,#submit {margin-top: 3px; }
		#submit {margin-left: 500px; }
		div.errorMessage,div.actionMessage { width: 400px; padding: 10px; }
		.stickyhead{width:70px;}
		.notifyhead{width:70px;}
		.persisthead{width:90px;}
		.centertd {text-align:center;}
		</style>
		<script type="text/javascript">
			$(document).ready(function() {
				$('tr:even').addClass('even'); 	
			}); 
			
			var allChecked = false;
			var allCheckedSticky = false;
			var allCheckedNotify = false;
			var allCheckedPersist = false;
			
			function checkAll(host)
			{
				if(host == 'all' && allChecked==false) {
					$('.hostcheck:checkbox').each(function() {
						this.checked = 'checked'; 
					}); 
					$('.servicecheck:checkbox').each(function() {
						this.checked = 'checked'; 
					});
					
					$('#checkAllButton').val('Uncheck All Items'); 
					allChecked = true;
					
				}
				else if(host == 'all' && allChecked==true) {
					$('.hostcheck:checkbox').each(function() {
						this.checked = ''; 
					}); 
					$('.servicecheck:checkbox').each(function() {
						this.checked = ''; 
					}); 					
					$('#checkAllButton').val('Check All Items'); 
					allChecked = false;
				}
				else  {				
					$('input.'+host).each(function() {
						if(this.checked == '')
                            this.checked = 'checked'; 
                        else
                            this.checked = ''; 
					}); 
				}	
			}//end checkAll
			
			function checkAllSticky() {
				if(allCheckedSticky==false) {
					$('input.sticky').each(function() {
						this.checked='checked'; 
					}); 	
					allCheckedSticky = true;
				}	
				else {
					$('input.sticky').each(function() {
						this.checked=''; 
					}); 
					allCheckedSticky = false;					
				}	
			}
			
			
			function checkAllNotify() {
				if(allCheckedNotify==false) {
					$('input.notify').each(function() {
						this.checked='checked'; 
					}); 	
					allCheckedNotify = true;
				}	
				else {
					$('input.notify').each(function() {
						this.checked=''; 
					}); 
					allCheckedNotify = false;					
				}				
			
			}
			
			function checkAllPersist() {
				if(allCheckedPersist==false) {
					$('input.persist').each(function() {
						this.checked='checked'; 
					}); 	
					allCheckedPersist = true;
				}	
				else {
					$('input.persist').each(function() {
						this.checked=''; 
					}); 
					allCheckedPersist = false;					
				}				
			
			}
            
			function checkAlldt() {
				if(allCheckedPersist==false) {
					$('input.dt').each(function() {
						this.checked='checked'; 
					}); 	
					allCheckedPersist = true;
				}	
				else {
					$('input.dt').each(function() {
						this.checked=''; 
					}); 
					allCheckedPersist = false;					
				}				
			
			}
			
			function checkTime()
			{
				if($('#massack_type').val() =='acknowledgment' || $('#massack_type').val()=='both') { 
					$('#time').attr('disabled') == true; 
					$('.sticky').show(); 
					$('.notify').show();
					$('.persist').show();
					
				}
				else { 
					$('#time').removeAttr('disabled'); 
					$('.sticky').hide(); 
					$('.notify').hide();
					$('.persist').hide();
				} 
			}
			
		</script>
<?php //////////////////////////////////////MAIN//////////////////////////////

$submitted = grab_request_var('submitted',false); 
$feedback = ''; 
//display output from command submissions 
if($submitted)
{
	$exec_errors = 0; 
	$error_string = ''; 
	$feedback = massacknowledge_core_commands(); 
}
//create array of hosts that have unhandled services problems
$massack_hosts = massacknowledge_get_hosts(); 
//fetch all service problems
$problem_services = massacknowledge_get_unhandled_service_problems();

//sort the hostnames alphabetically
sort($massack_hosts); 

// get downtimes
$downtimes = massacknowledge_get_downtimes();

//build the html content 
$html = massacknowledge_build_html($massack_hosts, $problem_services,$feedback);
$html .= massacknowledge_build_downtime_html($downtimes);

print $html; 


/////////////////FUNCTIONS/////////////////////////////////

function massacknowledge_build_html($hosts, $problem_services,$feedback)
{
	if (is_readonly_user(0)){
        $html=gettext("You are not authorized for this component");
        return $html;
    }
        
    $html = "
		<div id='massack_wrapper'>
		<h3>".gettext('Mass Acknowledgments and Downtime Scheduling')."</h3>
		{$feedback}
		<div id='massack_info'>
			<a href='".htmlentities($_SERVER['PHP_SELF'])."' title='Update List' />".gettext("Update List")."</a><br />
			<p>".gettext("Use this tool to schedule downtime or to acknowledge large groups of unhandled problems. 
				For scheduled downtime, specify the length of downtime in minutes to schedule 'flexible' downtime. 
				Commands may take a few moments to take effect on status details.")."</p>
            <p>".gettext("Please note that you may only submit characters that are from your locale. 
                In other words, if your locale is set to en_US, you may not submit Japanese characters for submission, 
                you must first change your locale to ja_JP and then submit your message.")."</p>
		</div>		
		<div id='massack'>
			<form id='form_massack' action='".htmlentities($_SERVER['PHP_SELF'])."' method='post'>
			<input type='hidden' id='submitted' name='submitted' value='true' />
			<label for='massack_type'>".gettext('Command Type')."</label>
			<select onchange='checkTime()' name='type' id='massack_type'>
				<option value='ack'>".gettext("Acknowledgement")."</option>
				<option value='dt'>".gettext("Schedule Downtime")."</option>
				<option value='both'>".gettext("Acknowledge and Schedule Downtime")."</option>
				<option value='sc'>".gettext("Schedule Immediate Check<")."/option>
			</select> &nbsp;
			<label for='time'>".gettext("Time(mn)")."</label>
			<input type='text' id='time' name='time' value='120' disabled='disabled' size='4' /><br />
			<label for='massack_comment'>".gettext("Comment")."</label>
			<input type='text' id='massack_comment' name='comment' value='".gettext("Problem is acknowledged")."' size='50' /><br />
			<input type='button' id='checkAllButton' onclick='checkAll(\"all\")' title='Check All Hosts and Services' value='".gettext("Check All Items'")." />
			<input type='submit' id='submit' value='".gettext("Submit Commands")."' />
			<br /><br />
			<table class='standardtable servicestatustable' id='massack_table'>
				<tr><th>".gettext("Host Name")."</th>
					<th>".gettext("Unhandled Service Problems")."</th>
					<th>".gettext("Service Status")."</th>
					<th class='stickyhead centertd'>".gettext("Sticky")." <input type='checkbox' onchange='checkAllSticky()' /></th>
					<th class='notifyhead centertd'>".gettext("Notify")." <input type='checkbox' onchange='checkAllNotify()' /></th>
					<th class='persisthead centertd'>".gettext("Persistent")." <input type='checkbox' onchange='checkAllPersist()' /></th>
				</tr>";
	
	$hostcount = 0; 	
	foreach($hosts as $host)
	{
		//skip hosts that have no problems or problem services 
		if($host['problem']==false && !isset($problem_services[$host['host_name']]) ) continue; 
		//html variables 
 		$host_checkbox = ($host['problem'] == true) ? "<input type='checkbox' class='hostcheck' name='hosts[]' value='{$host['host_name']}' />" : ''; 
		$checkAll = (isset($problem_services[$host['host_name']])) ? "<a href='javascript:checkAll(\"host{$hostcount}\");'>".gettext("Check All For This Host") : '&nbsp;'; 
		$host_class = host_class($host['host_state']); 
		
		$html .="<tr>
			<td class='{$host_class}'>{$host_checkbox} {$host['host_name']} </td>
			<td class='aligncenter'> {$checkAll} </td>
			<td> &nbsp; </td>"; 
		if($host_checkbox !='') 
			$html.="
			<td class='centertd'><input type='checkbox' class='sticky' name='sticky[{$host['host_name']}]' value='2' /></td>
			<td class='centertd'><input type='checkbox' class='notify' name='notify[{$host['host_name']}]' value='1' /></td>
			<td class='centertd'><input type='checkbox' class='persist' name='persist[{$host['host_name']}]' value='1' /></td>
			</tr>";
		else
			$html .="<td></td><td></td><td></td></tr>"; 
		
		if(isset($problem_services[$host['host_name']]) )
		{
			foreach($problem_services[$host['host_name']] as $service)
			{
				$html.="<tr><td> &nbsp; </td>
				<td class='alignleft ".service_class($service['current_state'])."'>
					<input class='host{$hostcount} servicecheck' type='checkbox' name='services[]' value='{$host['host_name']}::{$service['service_description']}' />
					{$service['service_description']}</td>
					<td><div class='plugin_output'>{$service['plugin_output']}</div></td>
					<td class='centertd'><input type='checkbox' class='sticky' name='sticky[{$host['host_name']}::{$service['service_description']}]' value='2' /></td>
					<td class='centertd'><input type='checkbox' class='notify' name='notify[{$host['host_name']}::{$service['service_description']}]' value='1' /></td>
					<td class='centertd'><input type='checkbox' class='persist' name='persist[{$host['host_name']}::{$service['service_description']}]' value='1' /></td>
					
					</tr>"; 
			}
			$hostcount++; 
		}
		
	}
	$html .="</table></form>";	
	$html .="</div></div>";
	
	return $html; 
}

function massacknowledge_build_downtime_html($downtimes)
{
	if (is_readonly_user(0)){
        $html=gettext("You are not authorized for this component");
        return $html;
    }
        
    $html = "
		<div id='downtime_wrapper'>
		<h3>".gettext('Mass Remove Downtime')."</h3>
		<div id='downtime_info'>
			<a href='".htmlentities($_SERVER['PHP_SELF'])."' title='Update List' />".gettext("Update List")."</a><br />
			<p>".gettext("Use this tool to remove scheduled downtimes.  Commands may take a few moments to take effect on status details.")."</p>  
		</div>		
		<div id='massdt'>
			<form id='form_massack' action='".htmlentities($_SERVER['PHP_SELF'])."' method='post'>
			<input type='hidden' name='submitted' value='true' />
            <input type='hidden' name='type' value='removedt' />
			<input type='button' onclick='checkAlldt()' title='Check All Downtime' value='".gettext("Check All'")." />
			<input type='submit' value='".gettext("Remove Downtimes")."' />
			<br /><br />
			<table class='standardtable servicestatustable' id='massdt_table'>
				<tr><th>".gettext("Host Name")."</th>
					<th>".gettext("Service Description")."</th>
					<th>".gettext("Start Time")."</th>
					<th>".gettext("End Time")."</th>
				</tr>";
    
    $hostcount = 0;
	foreach($downtimes as $host)
	{
        
        foreach($host as $downtime)
        {
		//html variables  
		$downtime_value=($downtime['service_description']=="") ? "h" : "s"; 
		$html .="<tr><td><a href='javascript:checkAll(\"dt{$hostcount}\");'>{$downtime['host_name']}</a></td>
			<td> <input type='checkbox' class='dt dt{$hostcount}' name='downtime[]' value='$downtime_value-{$downtime['downtime_id']}' />{$downtime['service_description']} </td>
			<td> {$downtime['scheduled_start_time']} </td>
            <td> {$downtime['scheduled_end_time']} </td> 
		</tr>"; 
		
        }
        $hostcount++;
    }
	$html .="</table><br /><br /><input type='button' onclick='checkAlldt()' title='Check All Downtime' value='".gettext("Check All'")." />
			<input type='submit' value='".gettext("Remove Downtimes")."' /></form>";	
	$html .="</div></div></body></html>";
	
    if (count($downtimes)==0)
        $html="";
	return $html; 
}

function massacknowledge_get_hosts()
{
	$backendargs["cmd"]="gethoststatus";
	$backendargs["brevity"]=1;
	$xml=get_xml_host_status($backendargs);
	$hosts = array(); 
	if($xml)
	{
		foreach($xml->hoststatus as $x)
		{
			$name = "$x->name"; 
			$state = "$x->current_state"; 
			$problem = true;
			if("$x->current_state" == 0 || "$x->scheduled_downtime_depth" > 0 ||
			   "$x->problem_acknowledged" > 0 || "$x->has_been_checked" ==0)
			   //problem diverted 
				$problem = false;
				
			$hosts[$name] = array('host_state' => $state, 'host_name' => $name, 'problem' =>$problem) ; 
		}
	}
	else echo "can't find host xml!"; 
	return $hosts; 
}


function massacknowledge_get_unhandled_service_problems()
{	
//	global $massack_hosts; 	
	$backendargs["cmd"]="getservicestatus";
	$backendargs["combinedhost"]=1;
	$xml=get_xml_service_status($backendargs);	
	$problem_services = array(); 
	
	if($xml)
	{
		foreach($xml->servicestatus as $x)
		{
			//filter unhandled services 
			if(intval($x->current_state)==0) continue;
			if(intval($x->has_been_checked)==0) continue;
			if(intval($x->scheduled_downtime_depth) > 0) continue;
			if(intval($x->problem_acknowledged) > 0) continue;

			$host_state=intval($x->host_current_state);			
			$service = array( 'host_name' => "$x->host_name",
								'service_description' => "$x->name",
							//	'host_state'		=> $host_state,
								'current_state'	=> "$x->current_state",
								'plugin_output' =>  "$x->status_text");
								
			//$massack_hosts["$x->host_name"] = "$x->host_name"; 					
			$problem_services["$x->host_name"][] = $service;											
		}
		
	return $problem_services; 	
	}//end if
} //end function 


function massacknowledge_core_commands()
{
	global $exec_errors; 
	global $error_string; 
	
	//print_r($_POST); 
	
	$hosts = grab_request_var('hosts',array()); 
	$services = grab_request_var('services',array()); 
	$sticky = grab_request_var('sticky',array()); 
	$notify = grab_request_var('notify',array());
	$persist = grab_request_var('persist',array());
	$message = grab_request_var('comment',''); 
	$mode = grab_request_var('type','both'); 
	$time = grab_request_var('time',0); 
	$message = grab_request_var('comment',''); 	
	$username = get_user_attr($_SESSION['user_id'],'name'); 
	$username = $username == '' ? $_SESSION['username'] : $username;  //default to session username 
		
	//bail if missing required values 
	if(count($hosts) == 0 && count($services)==0 && $mode != "removedt") 
		return feedback_message('You must specify at least one service',true);  
	if($message =='' && $mode != "removedt") 
		return feedback_message('You must specify a comment',true);
		
	//make sure script is executable 	
	//if(!is_executable(dirname(__FILE__).'/ack_Host.sh')) exec('chmod +x ack_Host.sh'); 
    if ($mode != "removedt"){
        //loop through any host specific commands	
        foreach($hosts as $host) {
            $stick = grab_array_var($sticky,$host,1);
            $notif = grab_array_var($notify,$host,0);
            $persistent = grab_array_var($persist,$host,0);
            massacknowledge_exec_script($host,$username,$message,$service=false,$mode,$time,$stick,$notif,$persistent);		
        }	
        //loop through service specific commands 
        foreach($services as $service) {	
            $stick = grab_array_var($sticky,$service,1);
            $notif = grab_array_var($notify,$service,0);
            $persistent = grab_array_var($persist,$service,0);
            $vals = explode('::',$service);
            massacknowledge_exec_script($vals[0],$username,$message,$vals[1],$mode,$time,$stick,$notif,$persistent);
        }	
    
    }
    else { // it is a downtime removal
        $downtimes = grab_request_var('downtime',array()); 
        foreach($downtimes as $id) {
            massacknowledge_del_downtime_exec_script($id);	
            
        }
    }
	//return feedback for front-end 
	if($exec_errors ==0) 
		return feedback_message(gettext('Commands processed successfully! Your command submissions may take a few moments to update in the display.'));
	else
		return feedback_message("$exec_errors ".gettext("errors were encountered while processing these commands")." <br />$error_string",true);
}

function massacknowledge_del_downtime_exec_script($id)
{
    global $cfg; 
	global $exec_errors; 
	global $error_string;
	
    //split to determine host or service
    $splitid=explode("-", $id);
    //security measures 
    $dt_id=escapeshellcmd($splitid[1]);
    
    if ($splitid[0]=="h")
        $dtCommand = "DEL_HOST_DOWNTIME";
    else
        $dtCommand = "DEL_SVC_DOWNTIME";
    
	$pipe = $cfg['component_info']['nagioscore']['cmd_file']; 
	$now = time(); 
    
    
    $dtString = "/bin/echo '[$now] $dtCommand;$dt_id\n' > $pipe";
    
    $bool = exec($dtString); 

	//handle errors 
	if($bool > 0) 
	{
		$exec_errors++; 
		//$error_string .=$output.'<br />'; 
	}	
    
    
}

function massacknowledge_exec_script($host,$username,$message,$service=false,$mode='both',$time,$sticky,$notify,$persistent)
{
	global $cfg; 
	global $exec_errors; 
	global $error_string;
    
    // Set our locale for PHP
    // If we don't do this, escapeshellcmd will remove all unicode.
    $locale = grab_array_var($_SESSION, 'language', 'en_US');


    /* The following is a quick fix to solve the issue of the locale
     * being set to en_EN, which doesn't actually exist. We are temporarily
     * setting it to en_US while we look into whether or not a massive
     * change from en_EN would break anything else.
     *
     * TPS ticket id = 951, XI bug id = 452
     */
    if($locale == 'en_EN') {
        $locale = 'en_US';
    }


    if(FALSE == setlocale(LC_CTYPE, "UTF8", $locale)) {
        return FALSE;
    }

	//security measures 
    // Using escapeshellcmd because escapeshellarg will add quotes, which
    // will break the Nagios command pipe
	$host = escapeshellcmd($host);
	$username = escapeshellcmd($username);
    
	$message = escapeshellcmd($message);
    if(empty($message)) {
        $exec_errors++;
        $error_string .= gettext('Message after escaping the shell args was blank. Make sure your locale is set properly.');
    }
    
	$service = ($service) ? escapeshellcmd($service) : false; 
	$mode = escapeshellcmd($mode);
	$time = escapeshellcmd($time); 
	$sticky = escapeshellcmd($sticky);
	$notify = escapeshellcmd($notify);
	$persistent = escapeshellcmd($persistent);

	$seconds = ($time *60);  
	$pipe = $cfg['component_info']['nagioscore']['cmd_file']; 
	$now = time(); 
	$dtEnd = $now + $seconds; 
	
	if($service)
	{
		$ackCommand = 'ACKNOWLEDGE_SVC_PROBLEM';
		$dtCommand =  'SCHEDULE_SVC_DOWNTIME'; 
		$scCommand = 'SCHEDULE_FORCED_SVC_CHECK'; 
		$ackString = "/bin/echo \"[$now] $ackCommand;$host;$service;$sticky;$notify;$persistent;$username;$message\" > $pipe";
		$dtString = "/bin/echo \"[$now] $dtCommand;$host;$service;$now;$dtEnd;1;0;$seconds;$username;$message\" > $pipe";
		$scString = "/bin/echo \"[$now] $scCommand;$host;$service;$now\" > $pipe"; 
	}
	else
	{
		$ackCommand = 'ACKNOWLEDGE_HOST_PROBLEM'; 
		$dtCommand = 'SCHEDULE_HOST_DOWNTIME'; 
		$scCommand = 'SCHEDULE_FORCED_HOST_CHECK'; 
		$ackString = "/bin/echo \"[$now] $ackCommand;$host;$sticky;$notify;$persistent;$username;$message\" > $pipe";
		$dtString = "/bin/echo \"[$now] $dtCommand;$host;$now;$dtEnd;1;0;$seconds;$username;$message\" > $pipe";
		$scString = "/bin/echo \"[$now] $scCommand;$host;$now\" > $pipe"; 
	}
	
    $output = array();
    
	switch($mode)
	{
		case 'ack':
            exec($ackString, $output, $returncode);   
            break;
		case 'dt':
            exec($dtString, $output, $returncode); 
            break;
		case 'sc':
            exec($scString, $output, $returncode); 
            break; 
		case 'both':		
            exec($ackString, $output, $returncode);   
		case 'dt':
            exec($dtString, $output, $returncode); 
            break; 
	}
	//$cmdString = "[$now] ACKNOWLEDGE_SVC_PROBLEM;$host;$service;1;1;1;$username;$message!!";
	//exec[1305905288] ACKNOWLEDGE_SVC_PROBLEM;192.168.5.64;_testservice_3;1;1;1;nagiosadmin;all is well!!
	//[1305905288] SCHEDULE_HOST_SVC_DOWNTIME;192.168.5.64;1305905288;1305905468;0;0;0;nagiosadmin;all is well!!
	//SCHEDULE_SVC_DOWNTIME;$host_name;$service_description;$time;$end_time;1;0;$duration;$user;$msg
	//debug 
	//echo "bool is: $bool.  Output is: $output <br /> Argstring is $argstring"; 
	
	//handle errors 
	if($bool > 0) 
	{
		$exec_errors++; 
		//$error_string .=$output.'<br />'; 
	}	
}

function feedback_message($msg,$error=false)
{
	$class = ($error) ? 'errorMessage' : 'actionMessage'; 
	$html = "<div class='{$class}'>
				{$msg}
			</div>"; 
	return $html; 
}

function host_class($code)
{
	switch($code) 
	{
		case 0:   	return "hostup";
		case 1:		return 'hostdown';
		default:	return 'hostunreachable';
	}
}

function service_class($code)
{
	switch($code) 
	{
		case 0:		return "serviceok";
		case 1:		return 'servicewarning';
		case 2:		return 'servicecritical';
		default:	return 'serviceunknown';
	}
}

function massacknowledge_get_downtimes()
{
	$backendargs=array();
	$backendargs["cmd"]="getscheduleddowntime";
    
    $xml=get_backend_xml_data($backendargs);
	$downtimes = array(); 
	if($xml)
	{
		foreach($xml->scheduleddowntime as $x)
		{
            $downtime_id = "$x->internal_id";
			$host_name = "$x->host_name"; 
			$service_description = "$x->service_description"; 
            $scheduled_start_time = "$x->scheduled_start_time";
            $scheduled_end_time = "$x->scheduled_end_time";
            $duration = "$x->duration";
				
			$downtimes[$host_name][] = array('downtime_id' => $downtime_id, 'host_name' => $host_name, 'service_description' => $service_description, 'scheduled_start_time' => $scheduled_start_time, 'scheduled_end_time' =>$scheduled_end_time, 'duration' => $duration) ; 
		}
	}
	else echo "can't find host xml!"; 
	return $downtimes; 
}













?>
