<?php 
// MASS ACKNOWLEDGE COMPONENT
//
// Copyright (c) 2010 Nagios Enterprises, LLC.  All rights reserved.
//  
// $Id: massacknowledge.inc.php 115 2010-08-16 16:15:26Z mguthrie $

//include the helper file
require_once(dirname(__FILE__).'/../componenthelper.inc.php');

// respect the name
$massacknowledge_component_name="massacknowledge";

// run the initialization function
massacknowledge_component_init();

////////////////////////////////////////////////////////////////////////
// COMPONENT INIT FUNCTIONS
////////////////////////////////////////////////////////////////////////

function massacknowledge_component_init(){
	global $massacknowledge_component_name;
	
	//boolean to check for latest version
	$versionok=massacknowledge_component_checkversion();
	
	//component description
	$desc=gettext("This component allows administrators to submit mass acknowledgements or downtime for 
			a list of problem hosts and services. ");
	
	if(!$versionok)
		$desc="<b>".gettext("Error: This component requires Nagios XI 2009R1.2B or later.")."</b>";
	
	//all components require a few arguments to be initialized correctly.  
	$args=array(

		// need a name
		COMPONENT_NAME => $massacknowledge_component_name,
		COMPONENT_VERSION => '2.0', 
		COMPONENT_DATE => '02/18/2013',

		// informative information
		COMPONENT_AUTHOR => "Mike Guthrie. Nagios Enterprises, LLC",
		COMPONENT_DESCRIPTION => $desc,
		COMPONENT_TITLE => "Mass Acknowledge",

		// configuration function (optional)
		//COMPONENT_CONFIGFUNCTION => "massacknowledge_component_config_func",
		);
	
	//register this component with XI 
	register_component($massacknowledge_component_name,$args);
	
	// register the addmenu function
	if($versionok)
		register_callback(CALLBACK_MENUS_INITIALIZED,'massacknowledge_component_addmenu');
	}
	



///////////////////////////////////////////////////////////////////////////////////////////
// MISC FUNCTIONS
///////////////////////////////////////////////////////////////////////////////////////////

function massacknowledge_component_checkversion(){

	if(!function_exists('get_product_release'))
		return false;
	//requires greater than 2009R1.2
	if(get_product_release()<114)
		return false;

	return true;
	}
	
function massacknowledge_component_addmenu($arg=null){
	global $massacknowledge_component_name;
	//retrieve the URL for this component
	$urlbase=get_component_url_base($massacknowledge_component_name);
	//figure out where I'm going on the menu	
	$mi=find_menu_item(MENU_HOME,"menu-home-acknowledgements","id");
	if($mi==null) //bail if I didn't find the above menu item 
		return;
		
	$order=grab_array_var($mi,"order","");  //extract this variable from the $mi array 
	if($order=="")
		return;
		
	$neworder=$order+0.1; //determine my menu order 

	//add this to the main home menu 
	add_menu_item(MENU_HOME,array(
		"type" => "link",
		"title" => gettext("Mass Acknowledge"),
		"id" => "menu-home-massacknowledge",
		"order" => $neworder,
		"opts" => array(
			//this is the page the menu will actually point to.
			//all of my actual component workings will happen on this script
			"href" => $urlbase."/mass_ack.php",      
			)
		));

	}


?>