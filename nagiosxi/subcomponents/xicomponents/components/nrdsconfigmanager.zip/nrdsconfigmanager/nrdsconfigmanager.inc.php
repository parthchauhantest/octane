<?php 
// NRDS Config Manager
// Written by: Scott Wilkerson (nagios@nagios.org)
// Copyright (c) 2010 Nagios Enterprises, LLC.  All rights reserved.
//  
// 

//include the helper file
require_once(dirname(__FILE__).'/../componenthelper.inc.php');

// respect the name
$nrdsconfigmanager_component_name="nrdsconfigmanager";

// run the initialization function
nrdsconfigmanager_component_init();

////////////////////////////////////////////////////////////////////////
// COMPONENT INIT FUNCTIONS
////////////////////////////////////////////////////////////////////////

function nrdsconfigmanager_component_init(){
	global $nrdsconfigmanager_component_name;
	
	//boolean to check for latest version
	$versionok=nrdsconfigmanager_component_checkversion();
	
	//component description
	$desc="This component allows administrators to manage their NRDS config files to be distributed to remote clients. ";
	if (!file_exists(dirname(__FILE__)."/installed.nrds")) {
        $desc.=" <br><b>IMPORTANT: Run the following as root to install.</b><br/><pre>
cd ".dirname(__FILE__)." 
chmod +x install.sh
./install.sh
</pre>";
    }
	if(!$versionok)
		$desc="<b>Error: This component requires Nagios XI 2009R1.2B or later.</b>";
	
	//all components require a few arguments to be initialized correctly.  
	$args=array(

		// need a name
		COMPONENT_NAME => $nrdsconfigmanager_component_name,
		COMPONENT_VERSION => '1.4', 
		COMPONENT_DATE => '02/27/2012',

		// informative information
		COMPONENT_AUTHOR => "Scott Wilkerson. Nagios Enterprises, LLC",
		COMPONENT_DESCRIPTION => $desc,
		COMPONENT_TITLE => "NRDS Config Manager",

		// configuration function (optional)
		//COMPONENT_CONFIGFUNCTION => "nrdsconfigmanager_component_config_func",
		);
	
	//register this component with XI 
	register_component($nrdsconfigmanager_component_name,$args);
	
	// register the addmenu function
	if($versionok)
		register_callback(CALLBACK_MENUS_INITIALIZED,'nrdsconfigmanager_component_addmenu');
	}
	



///////////////////////////////////////////////////////////////////////////////////////////
// MISC FUNCTIONS
///////////////////////////////////////////////////////////////////////////////////////////

function nrdsconfigmanager_component_checkversion(){

	if(!function_exists('get_product_release'))
		return false;
	//requires greater than 2009R1.2
	if(get_product_release()<114)
		return false;

	return true;
	}
	
function nrdsconfigmanager_component_addmenu($arg=null){
	global $nrdsconfigmanager_component_name;
	//retrieve the URL for this component
	$urlbase=get_component_url_base($nrdsconfigmanager_component_name);
	//figure out where I'm going on the menu	
	$mi=find_menu_item(MENU_ADMIN,"menu-admin-missingobjects","id");
	if($mi==null) //bail if I didn't find the above menu item 
		return;
		
	$order=grab_array_var($mi,"order","");  //extract this variable from the $mi array 
	if($order=="")
		return;
		
	$neworder=$order-0.1; //determine my menu order 

	//add this to the main home menu 
	add_menu_item(MENU_ADMIN,array(
		"type" => "link",
		"title" => "NRDS Config Manager",
		"id" => "menu-admin-nrdsconfigmanager",
		"order" => $neworder,
		"opts" => array(
			//this is the page the menu will actually point to.
			//all of my actual component workings will happen on this script
			"href" => $urlbase."/nrdsconfigmanager.php",      
			)
		));

	}


?>
