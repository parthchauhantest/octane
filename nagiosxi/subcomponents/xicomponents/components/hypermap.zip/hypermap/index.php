<?php
// EVENT LOG REPORTS
//
// Copyright (c) 2008-2009 Nagios Enterprises, LLC.  All rights reserved.
//  
// $Id: eventlog.php 359 2010-10-31 17:08:47Z egalstad $

require_once(dirname(__FILE__).'/../../common.inc.php');

include_once(dirname(__FILE__).'/ajax.inc.php');

// initialization stuff
pre_init();

// start session
init_session();

// grab GET or POST variables 
grab_request_vars();

// check prereqs
check_prereqs();

// check authentication
check_authentication(false);


route_request();

function route_request(){
	global $request;
	
	// only certain people can see this
	if(is_authorized_for_all_objects()==false){
		echo gettext("You are not authorized to view all hosts and services.");
		exit();
		}
		
	$mode=grab_request_var("mode");
	switch($mode){
		case "getdata":
			hypermap_get_data();
			break;
		default:
			display_hypermap();
			break;
		}
	}

function display_hypermap(){

	$type=grab_request_var("type","");
	$refresh=grab_request_var("refresh",60);

	// makes sure user has appropriate license level
	licensed_feature_check();

	// start the HTML page
	do_page_start(array("page_title"=>"Hypermap"),true);
	
?>
	<h1>Hypermap</h1>
	
<?php
	$dargs=array(
		DASHLET_ARGS => array(
			"type" => $type,
			"refresh" => $refresh,
			),
		);
	/*
	echo "ARGS GOING IN=";
	print_r($dargs);
	echo "<BR>";
	*/
	display_dashlet("hypermap","",$dargs,DASHLET_MODE_OUTBOARD);
?>

<?php		
	
	// closes the HTML page
	do_page_end(true);
	}
	