<?php 
// Nagios IM COMPONENT
//
// Copyright (c) 2010 Nagios Enterprises, LLC.  All rights reserved.
//  
// $Id: nagiosim.inc.php 115 2010-08-16 16:15:26Z mguthrie $

//include the helper file
require_once(dirname(__FILE__).'/../componenthelper.inc.php');

// respect the name
$nagiosim_component_name="nagiosim";

// run the initialization function
nagiosim_component_init();

////////////////////////////////////////////////////////////////////////
// COMPONENT INIT FUNCTIONS
////////////////////////////////////////////////////////////////////////

function nagiosim_component_init(){
	global $nagiosim_component_name;
	
	//boolean to check for latest version
	$versionok=nagiosim_component_checkversion();
	
	//component description
	$desc=gettext("This component integrates Nagios Incident Manager with Nagios XI events.");
	
	if(!$versionok)
		$desc="<b>".gettext("Error: This component requires Nagios XI 2011R3.2 or later.")."</b>";
	
	//allow for future version updates 
	$im_current_version=101;
	
	//all components require a few arguments to be initialized correctly.  
	$args=array(

		// need a name
		COMPONENT_NAME => $nagiosim_component_name,
		COMPONENT_VERSION => '1.6', 
		COMPONENT_DATE => '05/22/2013',

		// informative information
		COMPONENT_AUTHOR => "Mike Guthrie. Nagios Enterprises, LLC",
		COMPONENT_DESCRIPTION => $desc,
		COMPONENT_TITLE => "Nagios IM",

		// configuration function (optional)
		COMPONENT_CONFIGFUNCTION => "nagiosim_component_config_func",
		);
	
	//register this component with XI 
	register_component($nagiosim_component_name,$args);
	
	nagiosim_db_init($im_current_version); 
	
	// register the addmenu function
	if($versionok) {
		register_callback(CALLBACK_MENUS_INITIALIZED,'nagiosim_component_addmenu');
		//add a new function into the global event handler
		//this callback saves the incident to xi_incidents table
		register_callback(CALLBACK_EVENT_PROCESSED,'nagiosim_component_callback_incident'); 
		//this callback cleans/sends incidents every minute
		register_callback(CALLBACK_SUBSYS_CLEANER,'nagiosim_component_flush_incidents');		
	}	
}
	

///////////////////////////////////////////////////////////////////////////////////////////
// COMPONENT REGISTRATION FUNCTIONS
///////////////////////////////////////////////////////////////////////////////////////////

function nagiosim_component_checkversion(){

	if(!function_exists('get_product_release'))
		return false;
	//requires greater than 2009R1.2
	if(get_product_release()<215)
		return false;

	return true;
	}
	
	
/**
*	DEBUGGING FUNCTION: only add to menu for dev testing, otherwise don't have a menu item.
*/	
function nagiosim_component_addmenu($arg=null){

	//production setting
	return; 

	global $nagiosim_component_name;
	//retrieve the URL for this component
	$urlbase=get_component_url_base($nagiosim_component_name);
	//figure out where I'm going on the menu	
	$mi=find_menu_item(MENU_HOME,"menu-home-acknowledgements","id");
	if($mi==null) //bail if I didn't find the above menu item 
		return;
		
	$order=grab_array_var($mi,"order","");  //extract this variable from the $mi array 
	if($order=="")
		return;
		
	$neworder=$order+0.5; //determine my menu order 

	//add this to the main home menu 
	add_menu_item(MENU_HOME,array(
		"type" => "link",
		"title" => gettext("Nagios IM"),
		"id" => "menu-home-nagiosim",
		"order" => $neworder,
		"opts" => array(
			//this is the page the menu will actually point to.
			//all of my actual component workings will happen on this script
			"href" => $urlbase."/nagiosim.php",      
			)
		));
}


/**
*	manages component configuration for Admin->Manage Components page for this component
*/ 	
function nagiosim_component_config_func($mode="",$inargs,&$outargs,&$result)
{
	// initialize return code and output
	$result=0;
	$output="";
		
	switch($mode)
	{
		case COMPONENT_CONFIGMODE_GETSETTINGSHTML:
		
			// initial values
			$meta = is_null(get_option('im_component_options')) ? array() : unserialize(get_option("im_component_options"));
			$im_send = grab_array_var($meta,'im_send',false); 
			$url =  grab_array_var($meta,'url','');
			$api_key =  grab_array_var($meta,'api_key','');
			$threshold = grab_array_var($meta,'threshold',10);
			$max_age = grab_array_var($meta,'max_age',1);
			$users =  grab_array_var($meta,'users','');
			$teams =  grab_array_var($meta,'teams','');
			$type =  grab_array_var($meta,'type','');
			$message =  grab_array_var($meta,'message','');
			$title =  grab_array_var($meta,'title','');
			$proxy =  grab_array_var($meta,'proxy','');
			$hostgroups = grab_array_var($meta,'hostgroups',array()); 
			$servicegroups = grab_array_var($meta,'servicegroups',array()); 
			$resolve_incidents = grab_array_var($meta,'resolve_incidents',false);
            $auto_resolve_status = grab_array_var($meta,'auto_resolve_status','Resolved');
			
			//IM callback registration flag
			$cb_registered = grab_array_var($meta,'callback_registered',false);
			$cb_msg = "<span style='color:green;'>".gettext("Callback registered with Nagios IM")."</span>\n";
			if(!$cb_registered)
				$cb_registered = nagiosim_component_create_remote_callback($url,$api_key,$proxy,$cb_msg);  
			
			//select list options
			$hostgroup_opts = nagiosim_get_tbl_opts('hostgroup',$hostgroups); 
			$servicegroup_opts = nagiosim_get_tbl_opts('servicegroup',$servicegroups);
			
			//type,host,service,event_time,status,output
			if($title=='')
				$title = '%host% : %service% %status%'; 
			if($message=='')	
				$message = "****Nagios XI Incident*****\n
Type:%type%
Time:%event_time%
Host:%host%
Service: %service%
Status: %status%
Output: %output%

Nagios URL: <a href='%xiserverurl%' target='_blank'>Nagios XI</a>
Status URL: <a href='%xiserverurl%?xiwindow=%xiserverurl%includes/components/xicore/status.php?&show=%type%detail&host=%host%&service=%service%' target='_blank'>View Details</a>
"; 

			//build html for IM options 
			$output='			
			<div class="sectionTitle">'.gettext('Nagios Incident Manager Settings').'</div>
			<br />	
			<table class="standardtable">
			<tr><td><label>'.gettext('Enable Nagios IM Sender').'</label></td>
				<td><input type="checkbox" name="im_send" id="im_send" '.is_checked($im_send).' /> 
				'.gettext('Enable the Nagios IM event handler.').'</td>
			</tr>				
			<tr>
				<td valign="top"><label>*'.gettext('Nagios Incident Manager Public URL:').' </label><br class="nobr" /></td>
				<td>
					<input type="text" size="45" name="url" id="url" value="'.htmlentities($url).'" class="textfield" />
					<br class="nobr" />http://&lt;serveraddress&gt;/nagiosim<br /><br />
				</td>
			</tr>
			<tr>
				<td valign="top"><label>*'.gettext('User API Key').'</label><br class="nobr" /></td>
				<td>
					<input type="text" size="45" name="api_key" id="api_key" value="'.$api_key.'" class="textfield" />
					<br class="nobr" />'.gettext("The API key unique to each user in Nagios IM. This can be found from the Admin->Edit User page in the Incident Manager interface. It is recommended to create a 'Nagios XI' user in the incident manager as a best practice for permissions.").'<br /><br />
				</td>
			</tr>
			<tr> 
				<td valign="top"><label>'.gettext('Auto Resolve Incidents').'</label><br class="nobr" /></td>
				<td>
					<input type="checkbox" name="resolve_incidents" id="resolve_incidents" '.is_checked($resolve_incidents).' /> with <select name="auto_resolve_status"><option value="Resolved" '.is_selected($auto_resolve_status,"Resolved").'>Resolved</option><option value="Closed" '.is_selected($auto_resolve_status,"Closed").'>Closed</option></select>
					<br class="nobr" />'.gettext('Automatically mark incidents as resolved in Nagios IM upon host or service recovery.').'<br /><br />
				</td>
			</tr>			
			<tr> 
				<td valign="top"><label>*'.gettext('Incident Type').'</label><br class="nobr" /></td>
				<td>
					<input type="text" name="type" id="type" value="'.$type.'" class="textfield" />
					<br class="nobr" />'.gettext('An Incident Type').' <strong>'.gettext('Alias').'</strong> '.gettext('defined in the Administration->Manage Incident Types page of Nagios IM.').'<br /><br />
				</td>
			</tr>			
			<tr><td valign="top"><label>Callback Registration Status</label></td>
				<td>'.$cb_msg.' '.gettext('Callback registration allows Nagios IM to submit comments and acknowledgments back to Nagios XI for related incidents.').'</td>
				<input type="hidden" name="callback_registered" value="'.$cb_registered.'" />
			</tr>			
			<tr>
				<td valign="top"><label>*'.gettext('Max Age').'</label><br class="nobr" /></td>
				<td>
					<input type="text" size="4" name="max_age" id="max_age" value="'.$max_age.'" class="textfield" />days
					<br class="nobr" />'.gettext('The amount of time in days Nagios XI will store an incident. If an incident is stored in Nagios XI a new incident will not be created in Nagios IM. This is used to prevent multiple incidents from being created by a single host or service experiencing frequent problems.').'<br /><br />
				</td>
			</tr>			
			<tr>
				<td valign="top"><label>'.gettext('Forwarding Threshold (optional)').'</label><br class="nobr" /></td>
				<td>
					<input type="text" size="4" name="threshold" id="threshold" value="'.$threshold.'" class="textfield" />mn
					<br class="nobr" />'.gettext('The amount of time in minutes Nagios XI will wait before forwarding a hard state change as an incident. If a threshold is used, the event will only be forwarded if the host or service remains ina problem state after the threshold has been exceeded. Enter 0 if to bypass the use of a threshold.').
					'<br /><br />
				</td>
			</tr>	
			
			<tr> 
				<td valign="top"><label>*'.gettext('Incident Title').'</label><br class="nobr" /></td>
				<td>
					<input type="text" size="60" name="title" id="title" value="'.htmlentities($title).'" class="textfield" />
					<br class="nobr" />'.gettext('The title format to be used for new incidents.').'<br /><br />
				</td>
			</tr>
			<tr><td><label>*'.gettext('Incident Message').'</label></td>
				<td><textarea name="message" id="message" rows="5" cols="50">'.htmlentities($message).'</textarea></td>
			</tr>			
			<tr> 
				<td valign="top"><label>'.gettext('IM Users').': (optional)</label><br class="nobr" /></td>
				<td>
					<textarea cols="45" rows="2" name="users" id="users">'.$users.'</textarea>
					<br class="nobr" />'.gettext('A comma delineated list of Nagios IM usernames to automatically assign incidents to.').'<br /><br />
				</td>
			</tr>
			<tr>
				<td valign="top"><label>'.gettext('IM Teams (optional)').'</label><br class="nobr" /></td>
				<td>
					<textarea cols="45" rows="2" name="teams" id="teams">'.$teams.'</textarea>
					<br class="nobr" />'.gettext('A comma delineated list of Nagios IM teams to automatically assign incidents to.').'<br /><br />
				</td>
			</tr>
			<tr><td><label>'.gettext('Use Proxy (optional)').'</label></td>
				<td><input type="checkbox" name="proxy" id="proxy" '.is_checked($proxy).' /> 
				(**'.gettext('experimental').') <strong>'.gettext('Requires the proxy component.').'</strong> '.gettext('Utilize a proxy if the 
				proxy component is installed and enabled.').'</td>
			</tr>
			</table>
			<br />
			<table class="standardtable">
			<tr><td colspan="2"><strong>'.gettext('Filtering').':</strong> '
			.gettext('If hostgroups').' <strong>'.gettext('OR').'</strong> '.gettext('servicegroups are selected, Nagios XI will only forward events for selected groups.').'</td></tr>
			<tr><td><label>'.gettext('Hostgroups (optional)').'</label></td>
				<td><select name="hostgroups[]" id="hostgroups" multiple="multiple" size="4" style="min-width:300px;">
						'.$hostgroup_opts.'
					</select><br />
				'.gettext('(optional) By default this component will forward all hard state changes. Select hostgroups to forward results only for the selected groups.').'</td>
			</tr>
			<tr><td><label>'.gettext('Servicegroups (optional)').'</label></td>
				<td><select name="servicegroups[]" id="servicegroups" multiple="multiple" size="4" style="min-width:300px;">
						'.$servicegroup_opts.'
					</select><br />
				'.gettext('(optional) By default this component will forward all hard state changes. Select servicegroups to forward results only for the selected groups.').'</td>
			</tr>
			
			'; 

			$output .="</table>"; 
						
		break;
		
		//save 	
		case COMPONENT_CONFIGMODE_SAVESETTINGS:
			
			// get variables
			$im_send = grab_array_var($inargs,'im_send',false);
			$url =  grab_array_var($inargs,'url','');
			$api_key =  grab_array_var($inargs,'api_key','');
			$threshold = grab_array_var($inargs,'threshold',0); 
			$max_age = grab_array_var($inargs,'max_age',1);
			$users =  grab_array_var($inargs,'users','');
			$teams =  grab_array_var($inargs,'teams','');
			$type =  grab_array_var($inargs,'type','');
			$message =  grab_array_var($inargs,'message','');
			$title =  grab_array_var($inargs,'title','');
			$proxy =  grab_array_var($inargs,'proxy','');
			$resolve_incidents =  grab_array_var($inargs,'resolve_incidents',false);
			$hostgroups = grab_array_var($inargs,'hostgroups',array()); 
			$servicegroups = grab_array_var($inargs,'servicegroups',array()); 
			$cb_registered = grab_array_var($inargs,'callback_registered',false);
            $auto_resolve_status = grab_array_var($inargs,'auto_resolve_status','Resolved');
            
            //get current meta info
            $meta = is_null(get_option('im_component_options')) ? array() : unserialize(get_option("im_component_options"));
            $metaurl =  grab_array_var($meta,'url','');
			$metaapi_key =  grab_array_var($meta,'api_key','');
			
			// validate variables
			$errmsg=array();
			
			if($url=='')
				$errmsg[] = gettext("Please enter the full URL of the Nagios IM server"); 
			if($api_key=='')
				$errmsg[] = gettext("Please enter an api_key for the Nagios IM server"); 
            
            // make blank 0
            if($threshold=='')
                $threshold=0;
            
			// handle errors
			if(!empty($errmsg)){
				$outargs[COMPONENT_ERROR_MESSAGES]=$errmsg;
				$result=1;
				return '';
				}
			
            // if URL or API changes create remote callback
            if ($metaurl != $url || $metaapi_key != $api_key){
                $cb_msg = "<span style='color:green;'>".gettext("Callback registered with Nagios IM")."</span>\n";
                $cb_registered = nagiosim_component_create_remote_callback($url,$api_key,$proxy,$cb_msg);
            }
            
			// save settings
			$settings = array(
				'im_send' => $im_send,
				'url' => $url,
				'max_age' => $max_age,
				'api_key' => $api_key,
				'threshold' => $threshold,
				'users' => $users,
				'teams' => $teams,
				'type' => $type,
				'message' => $message,
				'title' => $title,
				'hostgroups' => $hostgroups,
				'servicegroups' => $servicegroups,
				'proxy' => $proxy,
				'callback_registered' => $cb_registered,
				'resolve_incidents' => $resolve_incidents,
                'auto_resolve_status' => $auto_resolve_status,
					
				);
			set_option("im_component_options",serialize($settings));

		break;
			
		default:
		break;
			
	}//end switch 
		
	return $output;
} //end nagiosim_component_config_func	
	
	
/**
*	initialize xi_incidents database table if it's not there
*	@param int $im_current_version: version number of this component
*/ 		
function nagiosim_db_init($im_current_version) {
	 
	db_connect_all();  
	$sql = "SELECT COUNT(relname) FROM pg_class WHERE relname = 'xi_incidents'"; 
	$rs = exec_sql_query(DB_NAGIOSXI,$sql,true); 

	$im_component_version = is_null(get_option('im_component_version')) ? 100 : get_option('im_component_version'); 

	if($im_component_version == 100) {
		foreach($rs as $row) {
			if($row['count']==0) {
				//create sequence
				$sql="
					CREATE SEQUENCE xi_incidents_id_seq
						INCREMENT BY 1
						NO MAXVALUE
						NO MINVALUE
						CACHE 1";
				exec_sql_query(DB_NAGIOSXI,$sql,true);
				//create table 
				$sql = "
					CREATE TABLE xi_incidents (
						id integer DEFAULT nextval('xi_incidents_id_seq'::regclass) NOT NULL,
						incident_id integer DEFAULT 0,
						submitted integer DEFAULT 0,
						type varchar(16),
						host varchar(96),
						service varchar(96),
						event_time timestamp without time zone NOT NULL,
						status varchar(16),	
						output varchar(255)
					)";

					exec_sql_query(DB_NAGIOSXI,$sql,true);
					//make sure we own it 
					$sql="ALTER TABLE public.xi_incidents OWNER TO nagiosxi";	
			}//end IF xi_incidents table exists 		
		}//end foreach loop 
		
		set_option('im_component_version',$im_current_version); 
	}
}	
	
/**
*	attempts to create the appropriate callback function in Nagios Incident Manager via it's api
*	@param string $url: Nagios IM URL fetched from component settings array
*	@param string $api_key: Nagios IM user api_key from settings array
*	@param bool $proxy: enable proxy on the load_url function
*	@param string $msg: Feedback message for UI
*/ 	
function nagiosim_component_create_remote_callback($url,$api_key,$proxy,&$msg) {

	$msg = ''; 
	
	//basic requirements
	if($url=='' || $api_key=='') {
		$msg="<span style='color:red;'>".gettext("Unable to register remote callback with Nagios IM. Missing URL and/or API Key.")."</span>\n"; 
		return false; 
	}
		
	$args = array(
		'api_key' => $api_key,
		'name' => 'XI Component Callback',
		'enabled' => true,
		'request_method' => 'GET',
		'callback_url' => get_base_url().'includes/components/nagiosim/nagiosim.php?mode=update&token='.trim($api_key),
		//'extra_params' => 'mode=update&token='.trim($api_key),

		);
		
	$querystring = http_build_query($args); 
	//echo "QS: $querystring <br />"; 
	
	$full_url = $url.'/index.php/api/callbacks/add/?'.$querystring; 	
	//echo "<br />FULLURL: ".htmlentities($full_url)."<br />"; 	
	$opts=array('method' => 'post','return_info'=>true); 	
	$http_array = load_url($full_url,$opts,$proxy);	
	
	//array_dump($http_array['body']); 
	
	$xml = simplexml_load_string($http_array['body']); 
	if($xml) {
		//array_dump($xml); 
		$node = $xml->status;
		if($node['code']==200) {
			$msg = "<span style='color:green;'>".gettext("Callback registered with Nagios IM.")." </span>\n"; 
			return true; 
		}
		else {
			$msg = "<span style='color:red;'>{$xml->status} {$xml->info}.</span>\n";
			return false; 
		}
	}
	else {
		//echo "BODY: <br />".$http_array['body']; 
		$msg="<span style='color:red;'>".gettext("Unable to register remote callback with Nagios IM. API Registration failed.")."</span>\n"; 
		return false; 		
	}
}	
	
	
	
////////////////////////////////////////////////////////////	
//	CALLBACK FUNCTIONS
///////////////////////////////////////////////////////////	
/**
*	callback wrapper to handle different event types 
*	@param string $cbtype: Callback type, defined constant in XI
*	@param mixed $args: Event data array
*/ 
function nagiosim_component_callback_incident($cbtype,$args) {
		
	if($args["event_type"]==EVENTTYPE_STATECHANGE)
		nagiosim_component_handle_statechange_event($args);				
}
	

/**
*	saves hard state changes to the database to process as incidents 
*	@param mixed $args: array of event data from XI event handler
*/ 	
function nagiosim_component_handle_statechange_event($args){

	//only run if enabled 
	if(!nagiosim_component_enabled())
		return; 	

	echo "#####NAGIOS IM CALLBACK FUNCTION######\n";
	$meta=grab_array_var($args,"event_meta",array());
	$handler_type=grab_array_var($meta,"handler-type","");	
	$statetype = grab_array_var($meta,$handler_type.'statetype','SOFT'); 
	$state = grab_array_var($meta,$handler_type.'state');
		
	//add if the state change is a HARD PROBLEM state 	
	if($statetype=='HARD' && $state!='OK' && $state!='UP' ) {
		echo "Saving incident to database...\n"; 
		//grab remaining info
		$host = grab_array_var($meta,'host','_HOST_'); 
		$service = grab_array_var($meta,'service','');	
		$state = grab_array_var($meta,$handler_type.'state'); 
		$output = grab_array_var($meta,$handler_type.'output',''); 
		
		//move to incidents queue
		$sql = "INSERT INTO xi_incidents (type,host,service,event_time,status,output) 
				VALUES ( '{$handler_type}','{$host}','{$service}','{$args['event_time']}','{$state}','{$output}')";
		exec_sql_query(DB_NAGIOSXI,$sql,true); 
	}
	
	//add ability to close ticket and remove incident from XI's DB. 
	if(($state=='OK' || $state=='UP') && nagiosim_component_autoresolve_enabled() ) {
		$c=0;
		$host = grab_array_var($meta,'host','_HOST_'); 
		$service = grab_array_var($meta,'service','');	
		$output = grab_array_var($meta,$handler_type.'output',''); 
		$incidents = nagiosim_component_find_incidents($host,$service);
		foreach($incidents as $incident) {
			$bool = nagiosim_component_resolve_incident($incident['incident_id'],$output);
			$c+=intval($bool); 
		}
		
		echo "{$c} incidents resolved in Nagios IM\n"; 
	}
					
}
	
/**
*	Forwards appropriate incidents to Nagios IM and deletes any stale or forwarded incidents
*	@param string $cbtype: callback type
*	@param mixed $args: misc args array, should be empty
*	@return null
*/	
function nagiosim_component_flush_incidents($cbtype,$args) {

	//only run if enabled 
	if(!nagiosim_component_enabled())
		return; 

	echo "NAGIOS IM FLUSH INCIDENTS\n"; 

	// load settings
	$settings=unserialize(get_option("im_component_options"));
	$threshold = grab_array_var($settings,'threshold',0); //default is 10mn
	$hostgroups = grab_array_var($settings,'hostgroups',array()); 
	$servicegroups = grab_array_var($settings,'servicegroups',array()); 
	
	//get recent incidents that have not been sent 
	$sql = "SELECT * FROM xi_incidents WHERE 
			event_time < ( now() - interval '{$threshold} minutes' )
			AND submitted=0 "; 
	//echo "\n".$sql."\n"; 		
	$rs = exec_sql_query(DB_NAGIOSXI,$sql,true); 
	
	echo "COUNT:".$rs->recordCount()."\n"; 
	//process incidents
	$c=0;
	foreach($rs as $r) {
	
		$send = true; 		
		$host = grab_array_var($r,'host'); 
		$service = grab_array_var($r,'service'); 
		$id = grab_array_var($r,'id'); 
		$hostgroup_filter=false; 
		
		//check object state one more time...
		if($threshold != 0) { 
			$args = array('host_name' => $host, 'brevity' => 3 ); 
			if($service=='')  {//host type 
				$xml=get_xml_host_status($args); 	
				$node = 'hoststatus'; 
			}	
			else { //service type 
				$args['service_description'] = $service;
				$xml=get_xml_service_status($args);
				$node = 'servicestatus'; 
			}
			
			//array_dump($xml); 
			//echo "STATE {$xml->$node->current_state}<br />"; 		
			$current_state = intval($xml->$node->current_state);
			
			//cancel send if object has recovered 
			if($current_state==0) {
				$send = false; 	
				echo "Recovery: {$host} {$service}, removing incident<br />\n"; 
				nagiosim_component_remove_incident($id); 
				continue; 
			}
			
				
		} //end IF threshold 
		
		//filter by hostgroups, assume we're not in the filter 
		if(!empty($hostgroups)) {		
			$send = false; 
			foreach($hostgroups as $groupname) {
				if(is_host_member_of_hostgroup($host,$groupname)) {
					$hostgroup_filter=true; 
					$send = true; 
					break; 
				}
			}
		}//end if hostgroup filter 
		
		//filter by servicegroups?
		if(!empty($servicegroups) && $hostgroup_filter==false ) {
			if($service=='') { //this is a service 
				foreach($servicegroups as $groupname) {
					if(is_service_member_of_servicegroup($host,$service,$groupname)) {
						$send=true;
						break; 
					}
				}	
			}
			else { //this is a host 
				foreach($servicegroups as $groupname) {
					if(is_host_member_of_servicegroup($host,$groupname)) {
						$send=true;
						break; 
					}
				}
			}
		} //end if servicegroup filter 
		
		//check for an existing incident for this so we don't flood IM with duplicates...
		$max_age = grab_array_var($settings,'max_age',7); //max age of incidents in days
		if($send && $max_age > 0) {
			$sql = "SELECT COUNT(*) FROM xi_incidents WHERE submitted=1 AND host='{$host}' AND service='{$service}'"; 
			$rs = exec_sql_query(DB_NAGIOSXI,$sql,true); 
			foreach($rs as $row) {	
				//array_dump($row); 
				$count = $row['count'];
				if($count > 0) {
					$send=false;
                    nagiosim_component_remove_incident($id);
					echo "Incident exists, skipping...\n";
				}		
			}		
		}
	
		//time to send it off! 
		if($send) {
			$bool = nagiosim_component_send_incident($r,$settings); 
			if($bool) //increment for logging 
				$c++; 
            else
                break;
		}
		else {
			//remove incident from queue 
			echo "Removing incident...\n"; 
			nagiosim_component_remove_incident($id);
		}
	} //end for loop for incidents 
	
	echo "{$c} incidents sent to Nagios IM\n"; 

}	

/**
*	uses Curl to post single incident data to Nagios IM
*	@param mixed $arr: Incident data from xi_incidents table
*	@param mixed $settings: im_component_options from config array
*	return bool: success | failure to send
*/ 
function nagiosim_component_send_incident($arr,$settings) {

	echo "Nagios IM Sending Incident...\n"; 
	//array_dump($arr); 
	
	$msg_array = array(
		'host' => grab_array_var($arr,'host'),
		'service' => grab_array_var($arr,'service'),
		'type' => grab_array_var($arr,'type'),
		'event_time' => grab_array_var($arr,'event_time'),
		'status' => grab_array_var($arr,'status'),
		'output' => grab_array_var($arr,'output'),
		'xiserverurl' => get_external_url(),
	);
	
	//process title
	$title = grab_array_var($settings,'title'); 
	foreach($msg_array as $var => $val){
		$tvar="%".$var."%";
		$title=str_replace($tvar,$val,$title);
	}
	//process summary messages 
	$summary = grab_array_var($settings,'message');
	foreach($msg_array as $var => $val){
		$tvar="%".$var."%";
		$summary=str_replace($tvar,$val,$summary);
	}	

	//extract from settings the API stuff 
	$url = grab_array_var($settings,'url'); 
	$url.='/index.php/api/incidents/add/'; 
	
	$proxy=false; 
	$im_use_proxy = grab_array_var($settings,'proxy',false); 
	$xi_use_proxy = get_option('use_proxy'); 
	
	//experimental support for proxies 
	if($im_use_proxy==true && $xi_use_proxy==true)
		$proxy=true; 
	
	//process settings array into vars for the query string
	$users = explode(',',grab_array_var($settings,'users'));
	array_walk($users,'trim'); 
	$teams = explode(',',grab_array_var($settings,'teams'));
	array_walk($teams,'trim'); 
	
	$type = grab_array_var($settings,'type'); 
	$args = array( 
		'api_key' => grab_array_var($settings,'api_key'), //api_key
		'users' => $users, 
		'teams' => $teams, 
		//'priority' => '', 
		//'status'  => '',
		'type' => $type, //get this list from IM API??
		'summary' => $summary, 
		'title' => $title, 
	); 
	
	//build URL for curl request 
	$querystring = http_build_query($args); 
	$full_url = $url.'?'.$querystring; 	
	//echo "<br />FULLURL: ".htmlentities($full_url)."<br />"; 	
	$opts=array('method' => 'post','return_info'=>true); 	
	$http_array = load_url($full_url,$opts,$proxy);
	//array_dump($http_array); 
	 	
	//process XML returned from the API
	$xml = simplexml_load_string($http_array['body']); 
	if($xml) {
		//echo "RESPOSE XML"; 
		//array_dump($xml); 
		$node = $xml->incident; 
		$id =intval($node['id']); 
		$xi_id = grab_array_var($arr,'id'); 
		echo "\nIncident Added: XIID: {$xi_id}. IMID: {$id}\n";
		$sql = "UPDATE xi_incidents SET incident_id='{$id}',submitted=1 WHERE id='{$xi_id}'"; 
		//echo $sql."<br />";
		exec_sql_query(DB_NAGIOSXI,$sql,true); 
		return true; 
	}
	else {
		$code = grab_array_var($http_array['info'],'http_code',999);
		echo "Nagios IM Send ERROR: {$code}\n"; //????
		//echo "NAGIOS IM Response:{$http_array['status]); 
		return false; 
	}		
}

/**
*	Resolves an incident in Nagios IM if the host/service returns to an OK state
*	@param int $id: The nagiosim incident ID
*	@param string $output: The plugin output for the recovered object
*	@return bool: True on success | False on failure
*/ 
function nagiosim_component_resolve_incident($id,$output) {

	//only run if enabled 
	if(!nagiosim_component_enabled())
		return; 

	echo "NAGIOS IM RESOLVE INCIDENT: {$id}\n"; 

	// load settings
	$settings=unserialize(get_option("im_component_options"));
	
	//bail if this setting is disabled
	//if(grab_array_var($settings,'resolve_incidents',false)==false)
	//	return; 
		
	//extract from settings the API stuff 
	$url = grab_array_var($settings,'url'); 
	
	//handle proxy option
	$proxy=false; 
	$im_use_proxy = grab_array_var($settings,'proxy',false); 
	$xi_use_proxy = get_option('use_proxy'); 
	
	//experimental support for proxies 
	if($im_use_proxy==true && $xi_use_proxy==true)
		$proxy=true; 
		
	//add a new message to the Incident first
	$args = array( 
		'api_key' => grab_array_var($settings,'api_key'), //api_key
		'title' => gettext('Nagios RECOVERY'),
		'message' => gettext('Nagios XI has detected a recovery for this incident. The ticket will be resolved automatically. Plugin Output: '.$output),
	); 
	
	//build URL for curl request 
	$message_url = $url.'/index.php/api/incidents/'.$id.'/messages/';
	$querystring = http_build_query($args); 
	$full_url = $message_url.'?'.$querystring; 	
	echo "<br />FULLURL: ".htmlentities($full_url)."<br />"; 	
	$opts=array('method' => 'post','return_info'=>true); 	
	$http_array = load_url($full_url,$opts,$proxy);
	
	//Resolve incident
	$args = array( 
		'api_key' => grab_array_var($settings,'api_key'), //api_key
		'status' => grab_array_var($settings,'auto_resolve_status','Resolved'),
	); 
	
	//build URL for curl request 
	$edit_url=$url.'/index.php/api/incidents/'.$id.'/edit/'; 
	$querystring = http_build_query($args); 
	$full_url = $edit_url.'?'.$querystring; 	
	echo "<br />FULLURL: ".htmlentities($full_url)."<br />"; 	
	$opts=array('method' => 'post','return_info'=>true); 	
	$http_array = load_url($full_url,$opts,$proxy);
	array_dump($http_array); 
	 	
	//process XML returned from the API
	$xml = simplexml_load_string($http_array['body']); 
	if($xml) {
		echo "RESPONSE XML"; 
		array_dump($xml); 
		$node = $xml->status; 
		$code =intval($node['code']); 
		if($code==200) {
			nagiosim_component_remove_incident($id); 
			return true; 		
		}	
	}
	else {
		$code = grab_array_var($http_array['info'],'http_code',999);
		echo "Nagios IM Send ERROR: {$code}\n"; //????
		//echo "NAGIOS IM Response:{$http_array['status]);  
	}	

	return false;

}

/**
*	simple boolean checker for whether or not event handler is enabled 
*/ 
function nagiosim_component_enabled() {
	$settings = unserialize(get_option('im_component_options'));
	if($settings==false)
		return false; 
		
	$im_send = grab_array_var($settings,'im_send',false); //max age of incidents in days
	return $im_send; 
}

/**
*	simple boolean check to see if auto-resolve is enabled
*/ 
function nagiosim_component_autoresolve_enabled() {
	$settings = unserialize(get_option('im_component_options'));
	if($settings==false)
		return false; 
		
	$resolve = grab_array_var($settings,'resolve_incidents',false); //max age of incidents in days
	return $resolve; 
}

/**
*	removes item from xi_incidents table 
*	@param int $id: incident row id
*/ 
function nagiosim_component_remove_incident($id) {
	
	$sql = "DELETE FROM xi_incidents WHERE id='{$id}'";
	exec_sql_query(DB_NAGIOSXI,$sql,true); 
}

/**
*	Fetches a Nagios IM Incident(s) from XI's DB if it exists
*	@param string $host: hostname
*	@param string $service: service description
*/ 
function nagiosim_component_find_incidents($host,$service) {
	$sql = "SELECT * FROM xi_incidents WHERE submitted=1 AND host='{$host}' AND service='{$service}'";
	$rs = exec_sql_query(DB_NAGIOSXI,$sql,true);
	if($rs->recordCount() ==0)
		return false;
	$incidents = array(); 	
	foreach($rs as $row)
		$incidents[] = $row; 
	
	return $incidents; 
}

/**
*	clear stale incidents that over over a week old
*/ 
function nagiosim_component_drop_stale_incidents() {
	$settings = unserialize(get_option('im_component_options'));
	$max_age = grab_array_var($settings,'max_age',1); //max age of incidents in days
	$sql = "DELETE FROM xi_incidents WHERE timestamp event_time < ( now() - interval '{$max_age} days')";
	exec_sql_query(DB_NAGIOSXI,$sql,true); 

}


/**
*	returns a select list of nagios objects, with preselections
*	@param string $table: nagios object type
*	@param mixed $preselect: array of preselected object ID's
*	@return string $options: html option string 
*/ 
function nagiosim_get_tbl_opts($table,$preselect=array()) {
	global $myDebug;
	
	//exception for timeperiod selection
	if(!is_array($preselect))
		$preselect=array($preselect); 
		
	$query = "SELECT id,{$table}_name FROM tbl_{$table} ORDER BY {$table}_name ASC"; 
	$rs = exec_sql_query(DB_NAGIOSQL,$query,$myDebug);
	
	$options='<option value="NULL"></option>'; 
	foreach($rs as $r) {
		$name = $r[$table.'_name']; 
		$options.="<option value='{$name}' ";
		if(in_array($name,$preselect)) $options.= " selected='selected' "; 
		$options.=">".$name."</options>\n";
	}
	
	return $options; 
}
	