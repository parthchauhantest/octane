<?php  //nagiosim.php 
//
// Nagios IM integration component
//
// Copyright (c) 2011 Nagios Enterprises, LLC.  All rights reserved.
//  
// 

require_once(dirname(__FILE__).'/../../common.inc.php');

// initialization stuff
pre_init();
// start session
init_session();
// grab GET or POST variables 
grab_request_vars();
// check prereqs
check_prereqs();

/////////Bypass normal authentication//////////////
// check authentication
//check_authentication(false);

//Nagios IM Api handler for XI

//else handle any component version upates
//array_dump($_SESSION); 
 
//define('IM_DEBUG',true); 

route_request();



function route_request() {

	$mode = grab_request_var('mode','default'); 
	$token = grab_request_var('token','badtoken'); 
	//db_connect_all(); 
	
	switch($mode) {
	
		case 'update':
			$settings = unserialize(get_option('im_component_options')); 
			$xitoken = grab_array_var($settings,'api_key',''); 
			
			//echo "TOKEN: $token \n XITOKEN: $xitoken\n<br />"; 
			if($token == $xitoken )	{
				//handle authorization bypass, token is good
				//process incident update 
				handle_incident_update();
			}
			else {
				//im_log("Unauthorized access detected: ".print_r($_REQUEST,true)); 
				$msg = "Nagios IM Component - Unauthorized action. Bad Token.\n";
				send_to_audit_log($msg,AUDITLOGTYPE_SECURITY);
				die($msg); 
			}	
		break; 
		
		case 'resolve':
			$host = grab_request_var('host','');
			$service = grab_request_var('service',''); 
			$c=0;
			
			$incidents = nagiosim_component_find_incidents($host,$service);
			foreach($incidents as $incident) {
				$bool = nagiosim_component_resolve_incident($incident['incident_id']);
				$c+=intval($bool); 
			}
			
			echo "{$c} incidents resolved in Nagios IM\n"; 
			
		break; 
		
		default: //use as a debugger
			echo "<pre>\n"; 
			echo "NAGIOS IM Scratch Pad\n"; 
			nagiosim_component_flush_incidents(CALLBACK_SUBSYS_CLEANER,array());
			echo "</pre>\n"; 
		break;	
	
	}
}


function handle_incident_update() {

	$msg = "Callback 'handle_incident_update()' \n";
	im_log($msg."\n".print_r($_REQUEST,true)."\n\n"); 

	//handle post inputs
	$incident_id = grab_request_var('incident_id',false);
	$type_array = grab_request_var('incident_type',array()); 	 
	$title = grab_request_var('title','');
	$status = grab_request_var('status',false);
	$api_url = grab_request_var('api_url',false);
	$cbtype = grab_request_var('callback_type',false);
	$incident_type=grab_array_var($type_array,'title','');
	
	//preserve sanity
	if($incident_id==false || intval($incident_id)==0)
		return; 
	
	//grab incident from db if it exists
	$sql = "SELECT * FROM xi_incidents WHERE incident_id='{$incident_id}'"; 
	$rs = exec_sql_query(DB_NAGIOSXI,$sql,true); 
	im_log("SQL: {$sql}\n");
	
	//nothing to do if the incident has already been removed by a recovery
	if($rs->recordCount()==0)
		return; 
			
	foreach($rs as $row)
		$incident = $row;
		
	$host = grab_array_var($incident,'host');
	$service = grab_array_var($incident,'service',''); 
	
	//do acknowledgment stuff
	if($status=='Closed' || $status=='Resolved' || $status=='Acknowledged') {

		$cmd = get_core_acknowledgment($host,$service,$title,$status);
		exec($cmd,$output); 
		$msg = "CMD: $cmd\n OUTPUT: ".print_r($output,true)."\n";
		im_log($msg);
		
		//log command
		if(function_exists('send_to_audit_log'))
			send_to_audit_log("Nagios IM Component submitted a command to Nagios Core: ACKNOWLEDGMENT: {$host} {$service}",AUDITLOGTYPE_INFO);
		
		//only remove an incident if it's closed or resolved
		if($status != 'Acknowledged') {
			$msg ="Removing XI Incident...\n";
			im_log($msg);
			$sql = "DELETE FROM xi_incidents WHERE incident_id='{$incident_id}'";
			exec_sql_query(DB_NAGIOSXI,$sql,true); 
		}
	}
	else { //just post a comment
		//details update	
		$cmd = get_core_comment($host,$service,$title,$status);
		exec($cmd,$output); 
		$msg = "CMD: '$cmd'\n";
		im_log($msg);
		
		//log command
		if(function_exists('send_to_audit_log'))
			send_to_audit_log("Nagios IM Component submitted a command to Nagios Core: ADD COMMENT: {$host} {$service}",AUDITLOGTYPE_INFO);			
	}
}

function im_log($msg) {

	if(IM_DEBUG ==true) {
		$file = '/tmp/nagiosim_api.log'; 
		file_put_contents($file,$msg,FILE_APPEND); 
	}
}


function get_core_acknowledgment($host,$service,$title,$status) {
	global $cfg; 

	$pipe = grab_array_var($cfg['component_info']['nagioscore'],'cmd_file','/usr/local/nagios/var/rw/nagios.cmd'); 
	$now = time(); 
	$sticky = 1; 
	$notify = 1;
	$persistent=0;
	$username='Nagios IM Component'; 
	$message="Incident Update: {$title}. Status is: {$status}";

	if($service!=''){
		$ackCommand = 'ACKNOWLEDGE_SVC_PROBLEM';
		$cmdstring = "/bin/echo '[$now] $ackCommand;$host;$service;$sticky;$notify;$persistent;$username;$message' > $pipe";
	}
	else{
		$ackCommand = 'ACKNOWLEDGE_HOST_PROBLEM'; 
		$cmdstring = "/bin/echo '[$now] $ackCommand;$host;$sticky;$notify;$persistent;$username;$message' > $pipe";
	}
	
	return $cmdstring; 
}


function get_core_comment($host,$service,$title,$status) {
	global $cfg; 

	$pipe = grab_array_var($cfg['component_info']['nagioscore'],'cmd_file','/usr/local/nagios/var/rw/nagios.cmd'); 
	$now = time(); 
	$persistent=0;
	$username='Nagios IM Component'; 
	$message="Incident: {$title} updated. Status is: {$status}";

	if($service!=''){
		$ackCommand = 'ADD_SVC_COMMENT';
		$cmdstring = "/bin/echo '[$now] $ackCommand;$host;$service;$persistent;$username;$message' > $pipe";
	}
	else{
		$ackCommand = 'ADD_HOST_COMMENT'; 
		$cmdstring= "/bin/echo '[$now] $ackCommand;$host;$persistent;$username;$message' > $pipe";
	}
	
	return $cmdstring; 	
}



/**

api token is also the XI token to access this page directly

IM will send this page an incident ID, XI will find it, and acknowledge the host or service problem
if it still exists and remove the incident.  




*/

?>