<?php

$opscreen_component_xi=true;  // should opscreen use Nagios XI code?


// Nagios XI includes/prereqs
if($opscreen_component_xi==true){

	require_once(dirname(__FILE__).'/../../common.inc.php');

	// initialization stuff
	pre_init();

	// start session
	init_session();

	// grab GET or POST variables 
	grab_request_vars();

	// check prereqs
	check_prereqs();

	// check authentication
	check_authentication(false);
	
	//use variables from config.inc.php
	$host = grab_array_var($cfg['db_info']['ndoutils'],'dbserver','localhost'); 
	$user = grab_array_var($cfg['db_info']['ndoutils'],'user','ndoutils');
	$db = grab_array_var($cfg['db_info']['ndoutils'],'db','nagios');
	$pw = grab_array_var($cfg['db_info']['ndoutils'],'pwd','n@gweb');
	
	//echo "HOST $host USER $user DB $db PW $pw<br />"; 
	
	$con = mysql_connect($host, $user, $pw) or die("<h3><font color=red>Could not connect to the database!</font></h3>");
	$db = mysql_select_db($db, $con);
	
	}
?>


<?php 


?>
<div class="dash_unhandled hosts dash">
    <h2><?php echo gettext("Unhandled Hosts down"); ?></h2>
    <div class="dash_wrapper">
        <table class="dash_table">
            <?php 
            #ALL down-hosts
            //$query = "select host_name, alias, count(host_name) from host where last_hard_state = 1 and problem_has_been_acknowledged = 0 group by host_name";
			
			
			$query = "SELECT obj1.name1 AS host_name, nagios_hosts.alias, current_state, problem_has_been_acknowledged FROM nagios_hoststatus LEFT JOIN nagios_objects AS obj1 ON nagios_hoststatus.host_object_id=obj1.object_id LEFT JOIN nagios_hosts ON nagios_hoststatus.host_object_id=nagios_hosts.host_object_id WHERE problem_has_been_acknowledged='0' AND current_state!='0'";
			
			// limit what the user can see
			if($opscreen_component_xi==true){
				$args=array(
					"sql" => $query,
					"objectauthfields" => array(
						"nagios_hoststatus.host_object_id",
						),
					"objectauthperms" => P_READ,
					);
				$query=limit_sql_by_authorized_object_ids($args);
				}
			
            $result = mysql_query($query);
            $save = "";
            $output = "";
            while ($row = mysql_fetch_array($result)) {
                $output .=  "<tr class=\"critical\"><td>".$row[0]."</td><td>".$row[1]."</td></tr>";
                $save .= $row[0];
            }
            if($save){
            ?>
            <tr class="dash_table_head">
                <th><?php echo gettext("Hostname"); ?></th>
                <th><?php echo gettext("Alias"); ?></th>
            </tr>
            <?php print $output; ?>
            <?php
				}
            else{ 
                print "<tr class=\"ok\"><td>All problem hosts have been acknowledged.</td></tr>";
				}
            ?>
        </table>
    </div>
</div>
<div class="dash_tactical_overview tactical_overview hosts dash">
    <h2><?php echo gettext("Tactical overview"); ?></h2>
    <div class="dash_wrapper">
        <table class="dash_table">
            <tr class="dash_table_head">
                <th><?php echo gettext("Type"); ?></th>
                <th><?php echo gettext("Totals"); ?></th>
                <th><?php echo gettext("Percentage"); ?> %</th>
            </tr>
            <?php
            # number of hosts down
            //$query = "select count(1) as count from host where last_hard_state = 1";
			$query="SELECT count(*) as total from nagios_hoststatus WHERE current_state!=0";
			// limit what the user can see
			if($opscreen_component_xi==true){
				$args=array(
					"sql" => $query,
					"objectauthfields" => array(
						"nagios_hoststatus.host_object_id",
						),
					"objectauthperms" => P_READ,
					);
				$query=limit_sql_by_authorized_object_ids($args);
				}
				
 			//echo "HOSTSDOWNQ: $query<BR>";
            $result = mysql_query($query);
            $row = mysql_fetch_array($result);
            $hosts_down = $row[0];
			//echo "HOSTSDOWN: $hosts_down<BR>";
            
            # total number of hosts
            //$query = "select count(1) as count from host";
			$query="SELECT count(*) as total from nagios_hoststatus WHERE 1";
			// limit what the user can see
			if($opscreen_component_xi==true){
				$args=array(
					"sql" => $query,
					"objectauthfields" => array(
						"nagios_hoststatus.host_object_id",
						),
					"objectauthperms" => P_READ,
					);
				$query=limit_sql_by_authorized_object_ids($args);
				}
 			//echo "HOSTSTOTALQ: $query<BR>";
			$result = mysql_query($query);
            $row = mysql_fetch_array($result);
            $total_hosts = $row[0];
			//echo "HOSTSTOTAL: $total_hosts<BR>";
            
            $hosts_down_pct = round($hosts_down / $total_hosts * 100, 2);
            $hosts_up = $total_hosts - $hosts_down;
            $hosts_up_pct = round($hosts_up / $total_hosts * 100, 2);
            
            #### SERVICES
            #
            //$query = "select count(1) as count from service where last_hard_state = 1";
			$query="SELECT count(*) as total from nagios_servicestatus WHERE current_state!=0";
			// limit what the user can see
			if($opscreen_component_xi==true){
				$args=array(
					"sql" => $query,
					"objectauthfields" => array(
						"nagios_servicestatus.service_object_id",
						),
					"objectauthperms" => P_READ,
					);
				$query=limit_sql_by_authorized_object_ids($args);
				}
			//echo "SERVICEDOWNQ: $query<BR>";
            $result = mysql_query($query);
            $row = mysql_fetch_array($result);
            $services_down = $row[0];
			//echo "SERVICESDOWN: $services_down<BR>";
            
            # total number of hosts
            //$query = "select count(1) as count from service";
			$query="SELECT count(*) as total from nagios_servicestatus WHERE 1";
			// limit what the user can see
			if($opscreen_component_xi==true){
				$args=array(
					"sql" => $query,
					"objectauthfields" => array(
						"nagios_servicestatus.service_object_id",
						),
					"objectauthperms" => P_READ,
					);
				$query=limit_sql_by_authorized_object_ids($args);
				}
			$result = mysql_query($query);
            $row = mysql_fetch_array($result);
            $total_services = $row[0];
            
            $services_down_pct = round($services_down / $total_services * 100, 2);
            $services_up = $total_services - $services_down;
            $services_up_pct = round($services_up / $total_services * 100, 2);
            
            ?>
            <tr class="ok total_hosts_up">
                <td><?php echo gettext("Hosts up"); ?></td>
                <td><?php print $hosts_up ?>/<?php print $total_hosts ?></td>
                <td><?php print $hosts_up_pct ?></td>
            </tr>
            <tr class="critical total_hosts_down">
                <td><?php echo gettext("Hosts down"); ?></td>
                <td><?php print $hosts_down ?>/<?php print $total_hosts ?></td>
                <td><?php print $hosts_down_pct ?></td>
            </tr>
            <tr class="ok total_services_up">
                <td><?php echo gettext("Services up"); ?></td>
                <td><?php print $services_up ?>/<?php print $total_services ?></td>
                <td><?php print $services_up_pct ?></td>
            </tr>
            <tr class="critical total_services_down">
                <td><?php echo gettext("Services down"); ?></td>
                <td><?php print $services_down ?>/<?php print $total_services ?></td>
                <td><?php print $services_down_pct ?></td>
            </tr>
        </table>
    </div>
</div>
<div class="logo">
<a href="http://www.nagios.com" target="_blank"><img src="images/nagios.png" border="0" alt="Nagios" title="Nagios"></a>
<br clear="right">
<div class="logotext"><?php echo gettext("Operations Screen"); ?></div>
</div>
<div class="clear"></div>
<div class="dash_unhandled_service_problems hosts dash">
    <h2><?php echo gettext("Unhandled service problems"); ?></h2>
    <div class="dash_wrapper">
        <table class="dash_table">
            <tr class="dash_table_head">
                <th>
                    <?php echo gettext("Host"); ?>
                </th>
                <th>
                    <?php echo gettext("Service"); ?>
                </th>
                <th>
                    <?php echo gettext("Output"); ?>
                </th>
                <th>
                    <?php echo gettext("Last statechange"); ?>
                </th>
                <th>
                    <?php echo gettext("Last check"); ?>
                </th>
            </tr>
            <?php 
            #ALL critical/warning services on hosts not being down
			/*
            $query = "select service.host_name,service.service_description,service.last_hard_state,service.output, service.last_hard_state_change,service.last_check ";
            $query = $query." from service,host where ";
            $query = $query." host.host_name = service.host_name and ";
            $query = $query." service.last_hard_state in (1,2) and ";
            $query = $query." service.problem_has_been_acknowledged = 0 and host.problem_has_been_acknowledged = 0 and ";
            $query = $query." host.last_hard_state not like 1 group by service.service_description order by service.last_hard_state";
			*/
			$query="SELECT obj1.name1 AS host_name, obj1.name2 AS service_name, nagios_servicestatus.last_hard_state, nagios_servicestatus.output, nagios_servicestatus.last_hard_state_change, nagios_servicestatus.last_check, nagios_servicestatus.problem_has_been_acknowledged,
nagios_hosts.address as ha, nagios_hoststatus.problem_has_been_acknowledged AS hack, nagios_services.service_id as sid ,
nagios_servicestatus.servicestatus_id as ssid,
nagios_hosts.host_object_id AS hid
FROM nagios_servicestatus 
LEFT JOIN nagios_objects AS obj1 ON nagios_servicestatus.service_object_id=obj1.object_id 
LEFT JOIN nagios_services ON nagios_servicestatus.service_object_id=nagios_services.service_object_id 
LEFT JOIN nagios_hosts ON nagios_services.host_object_id=nagios_hosts.host_object_id
LEFT JOIN nagios_hoststatus ON nagios_hosts.host_object_id=nagios_hoststatus.host_object_id
WHERE nagios_servicestatus.problem_has_been_acknowledged='0' AND nagios_servicestatus.current_state!='0' AND nagios_hoststatus.problem_has_been_acknowledged='0' AND nagios_hoststatus.last_hard_state='0' AND nagios_hoststatus.current_state='0'

";
 			// limit what the user can see
			if($opscreen_component_xi==true){
				$args=array(
					"sql" => $query,
					"objectauthfields" => array(
						"nagios_servicestatus.service_object_id",
						),
					"objectauthperms" => P_READ,
					);
				$query=limit_sql_by_authorized_object_ids($args);
				}
			$query.=" ORDER BY obj1.name1 ASC, obj1.name2 ASC";
			$result = mysql_query($query);
            ?>
            <?php 
            while ($row = mysql_fetch_array($result)) {
                $class = "";
                if ($row[2] == 2) {
                    $class = "critical";
                } elseif ($row[2] == 1) {
                    $class = "warning";
                }
                ?>
                <tr class="<?php print $class ?>">
                    <td><?php print $row[0] ?></td>
                    <td><?php print $row[1] ?></td>
                    <td><?php print $row[3] ?></td>
                    <td class="date date_statechange"><?php echo $row[4]; /*print date("d-m-Y H:i:s", $row[4])*/ ?></td>
                    <td class="date date_lastcheck"><?php echo $row[5]; /* print date("d-m-Y H:i:s", $row[5])*/ ?></td>
                </tr>
                <?php 
            }
            ?>
        </table>
    </div>
</div>

