<?php
// TIMELINE REPORT
//
// Copyright (c) 2010-2011 Nagios Enterprises, LLC.  All rights reserved.
//  
// $Id: eventlog.php 359 2010-10-31 17:08:47Z egalstad $

require_once(dirname(__FILE__).'/../../common.inc.php');

// initialization stuff
pre_init();

// start session
init_session();

// grab GET or POST variables 
grab_request_vars();

// check prereqs
check_prereqs();

// check authentication
check_authentication(false);


route_request();

function route_request(){
	global $request;
	
	$mode=grab_request_var("mode");
	switch($mode){
		default:
			display_timeline();
			break;
		}
	}

function similetimeline_insert_includes(){

	$url=get_base_url()."includes/components/similetimeline";
?>
	<script type="text/javascript">
      Timeline_ajax_url="<?php echo $url;?>/timeline_2.3.0/timeline_ajax/simile-ajax-api.js";
      Timeline_urlPrefix='<?php echo $url;?>/timeline_2.3.0/timeline_js/';      
      Timeline_parameters='bundle=true';
   </script>
    <!-- NOTE: The local copy of timeline does not appear to show time durations properly, but the online version does -->
    <script src="<?php echo $url;?>/timeline_2.3.0/timeline_js/timeline-api.js" type="text/javascript"></script>

<?php
	}
	
function display_timeline(){
	global $request;
	global $lstr;

	register_callback(CALLBACK_PAGE_HEAD,'similetimeline_insert_includes');

	// get values passed in GET/POST request
	$reportperiod=grab_request_var("reportperiod","last24hours");
	$startdate=grab_request_var("startdate","");
	$enddate=grab_request_var("enddate","");
	$search=grab_request_var("search","");
	$host=grab_request_var("host","");
	$service=grab_request_var("service","");
	$hostgroup=grab_request_var("hostgroup","");
	$servicegroup=grab_request_var("servicegroup","");
	$datatype=grab_request_var("datatype","events");

	// fix search
	if($search==$lstr['SearchBoxText'])
		$search="";
		
	// we search for hosts, so clear host if search is present
	if($search!=""){
		$host="";
		$service="";
		}
		
	if($datatype=="nagios"){
		$reportperiod="custom";
		$startdate="1999-03-19";
		$enddate=time();
		}
	
	// determine start/end times based on period
	get_times_from_report_timeperiod($reportperiod,$starttime,$endtime,$startdate,$enddate);

	// makes sure user has appropriate license level
	licensed_feature_check();

	// start the HTML page
	do_page_start(array("page_title"=>"Event Timeline"),true);
	
?>
	<h1><?php echo gettext("Event Timeline"); ?></h1>
	
<?php
	if($service!=""){
?>
	<div class="servicestatusdetailheader">
	<div class="serviceimage">
	<!--image-->
	<?php show_object_icon($host,$service,true);?>
	</div>
	<div class="servicetitle">
	<div class="servicename"><a href="<?php echo get_service_status_detail_link($host,$service);?>"><?php echo htmlentities($service);?></a></div>
	<div class="hostname"><a href="<?php echo get_host_status_detail_link($host);?>"><?php echo htmlentities($host);?></a></div>
	</div>
	</div>
	<br clear="all">

<?php
		}
	else if($host!=""){
?>
	<div class="hoststatusdetailheader">
	<div class="hostimage">
	<!--image-->
	<?php show_object_icon($host,"",true);?>
	</div>
	<div class="hosttitle">
	<div class="hostname"><a href="<?php echo get_host_status_detail_link($host);?>"><?php echo htmlentities($host);?></a></div>
	</div>
	</div>
	<br clear="all">
<?php
		}
?>
	
	<form method="get" action="<?php echo htmlentities($_SERVER["REQUEST_URI"]);?>">
	<input type="hidden" name="host" value="<?php echo htmlentities($host);?>">
	<input type="hidden" name="service" value="<?php echo htmlentities($service);?>">
	<input type="hidden" name="hostgroup" value="<?php echo htmlentities($hostgroup);?>">
	<input type="hidden" name="servicegroup" value="<?php echo htmlentities($servicegroup);?>">
	
	<div class="reportexportlinks">
	<?php echo get_add_myreport_html("Alert Timeline",$_SERVER["REQUEST_URI"],array());?>
	</div>

	<div class="reportsearchbox">
<?php
	// search box
	$searchclass="textfield";
	if(have_value($search)==true){
		$searchstring=$search;
		$searchclass.=" newdata";
		}
	else
		$searchstring=$lstr['SearchBoxText'];
?>

	<input type="text" size="15" name="search" id="searchBox" value="<?php echo encode_form_val($searchstring);?>" class="<?php echo $searchclass;?>" />

	</div>
	
<?php
	$auto_start_date=date('m/d/Y',strtotime('yesterday'));
	$auto_end_date=date('m/d/Y');
?>
	
	<script type="text/javascript">
	$(document).ready(function(){
		$('#startdateBox').click(function(){
			$('#reportperiodDropdown').val('custom');
			if($('#startdateBox').val()=='' && $('#enddateBox').val()==''){
				$('#startdateBox').val('<?php echo $auto_start_date;?>');
				$('#enddateBox').val('<?php echo $auto_end_date;?>');
				}
			});
		$('#enddateBox').click(function(){
			$('#reportperiodDropdown').val('custom');
			if($('#startdateBox').val()=='' && $('#enddateBox').val()==''){
				$('#startdateBox').val('<?php echo $auto_start_date;?>');
				$('#enddateBox').val('<?php echo $auto_end_date;?>');
				}
			});
		
		});
	</script>

	<div class="reporttimepicker">
	<?php echo gettext("Period"); ?>&nbsp;
	<select id='reportperiodDropdown' name="reportperiod">
<?php
	$tp=get_report_timeperiod_options();
	foreach($tp as $shortname => $longname){
		echo "<option value='".$shortname."' ".is_selected($shortname,$reportperiod).">".$longname."</option>";
		}
?>
	</select>
	&nbsp;<?php echo gettext("From"); ?>&nbsp;
	<input class="textfield" type="text" id='startdateBox' name="startdate" value="<?php echo encode_form_val(get_datetime_from_timestring($startdate)); ?>" size="16" />
	<div class="reportstartdatepicker"><img src="<?php echo theme_image("calendar_small.png");?>"></div>
	&nbsp;<?php echo gettext("To"); ?>&nbsp;
	<input class="textfield" type="text" id='enddateBox' name="enddate" value="<?php echo encode_form_val(get_datetime_from_timestring($enddate)); ?>" size="16" />
	<div class="reportenddatepicker"><img src="<?php echo theme_image("calendar_small.png");?>"></div>
	&nbsp;
	<input type='submit' class='reporttimesubmitbutton' name='reporttimesubmitbutton' value='Go'>
	</div>
	</form>

	
	
	<div>
	<?php echo gettext("From"); ?>: <b><?php echo get_datetime_string($starttime,DT_SHORT_DATE_TIME,DF_AUTO,"null");?></b> <?php echo gettext("To"); ?>: <b><?php echo get_datetime_string($endtime,DT_SHORT_DATE_TIME,DF_AUTO,"null");?></b>
	</div>
	
	
<?php
	if($search!="")
		echo "<p>".gettext('Showing results for')." '<b><i>$search</i></b>'</p>";
?>


<?php
	$ajaxurl=get_base_url()."includes/components/similetimeline/getdata.php";
	$ajaxurl.="?1";
	foreach($request as $var => $val)
		$ajaxurl.="&".urlencode($var)."=".urlencode($val);
	$ajaxurl.="&type=".urlencode($datatype);
?>
	
	<script type="text/javascript">
	$(document).ready(function(){
	
		//alert("OK");
		onLoad();

		$(window).resize(function() {
			onResize();
			});
		});
	</script>

<?php
	/*
	$tz=date("T");
	echo "TIMEZONE: $tz<BR>";
	$offset=date("Z");
	echo "OFFSET2: $offset<BR>";
	$timeline_starttime=$starttime+$offset;
	*/
	
	$timeline_starttime=$starttime;

	//date_default_timezone_set("GMT");
	$startdate=date("M j Y G:i:s T",$timeline_starttime);// "Jun 28 2006 00:00:00 GMT"
	
	//echo "STARTDATE: $startdate<BR>";
?>
  
  <div id="my-timeline" style="height: 400px; border: 1px solid #aaa"><img src="<?php echo theme_image("throbber1.gif");?>"> <b><?php echo gettext("Generating data"); ?>...</b></div>
  
<?php
	$yearinterval=250;
	if($datatype=="nagios"){
		$yearinterval=100;
		}
 ?>
  
 <script type="text/javascript">
 var tl;
function onLoad() {

 var eventSource = new Timeline.DefaultEventSource();

<?php
	if($datatype=="nagios"){
?>
  var bandInfos = [
    Timeline.createBandInfo({
        eventSource:    eventSource,
        date:           "<?php echo $startdate;?>",
        width:          "80%", 
        intervalUnit:   Timeline.DateTime.DAY, 
        intervalPixels: 200
    }),
    Timeline.createBandInfo({
		showEventText:  false, // causes problems if enabled
        //trackHeight:    0.35,
        //trackGap:       0.4,
        eventSource:    eventSource,
        date:           "<?php echo $startdate;?>",
        width:          "10%", 
        intervalUnit:   Timeline.DateTime.MONTH, 
        intervalPixels: 200
    }),
    Timeline.createBandInfo({
		showEventText:  false,
        trackHeight:    0.3,
        trackGap:       0.6,
        eventSource:    eventSource,
        date:           "<?php echo $startdate;?>",
        width:          "10%", 
        intervalUnit:   Timeline.DateTime.YEAR, 
        intervalPixels: <?php echo $yearinterval;?>
    })
  ];

  bandInfos[1].syncWith = 0;
  bandInfos[1].highlight = true;
  bandInfos[2].syncWith = 1;
  bandInfos[2].highlight = true;
<?php
		}
	else{
?>
  var bandInfos = [
    Timeline.createBandInfo({
		//showEventText:  true,
        eventSource:    eventSource,
        date:           "<?php echo $startdate;?>",
        width:          "70%", 
        intervalUnit:   Timeline.DateTime.HOUR, 
        intervalPixels: 150
    }),
    Timeline.createBandInfo({
		showEventText:  false,
        trackHeight:    0.5,
        trackGap:       0.2,
        eventSource:    eventSource,
        date:           "<?php echo $startdate;?>",
        width:          "10%", 
        intervalUnit:   Timeline.DateTime.DAY, 
        intervalPixels: 200
    }),
    Timeline.createBandInfo({
		showEventText:  false, // causes problems if enabled
        trackHeight:    0.35,
        trackGap:       0.4,
        eventSource:    eventSource,
        date:           "<?php echo $startdate;?>",
        width:          "10%", 
        intervalUnit:   Timeline.DateTime.MONTH, 
        intervalPixels: 200
    }),
    Timeline.createBandInfo({
		showEventText:  false,
        trackHeight:    0.3,
        trackGap:       0.6,
        eventSource:    eventSource,
        date:           "<?php echo $startdate;?>",
        width:          "10%", 
        intervalUnit:   Timeline.DateTime.YEAR, 
        intervalPixels: <?php echo $yearinterval;?>
    })
  ];

  bandInfos[1].syncWith = 0;
  bandInfos[1].highlight = true;
  bandInfos[2].syncWith = 1;
  bandInfos[2].highlight = true;
  bandInfos[3].syncWith = 2;
  bandInfos[3].highlight = true;
<?php
	}
?>

  tl = Timeline.create(document.getElementById("my-timeline"), bandInfos);
  
  Timeline.loadJSON("<?php echo $ajaxurl;?>", function(json, url) { eventSource.loadJSON(json, url); });

}

var resizeTimerID = null;
function onResize() {
    if (resizeTimerID == null) {
        resizeTimerID = window.setTimeout(function() {
            resizeTimerID = null;
            tl.layout();
        }, 500);
    }
}
 </script>
  
<?php		
	
	// closes the HTML page
	do_page_end(true);
	}
	