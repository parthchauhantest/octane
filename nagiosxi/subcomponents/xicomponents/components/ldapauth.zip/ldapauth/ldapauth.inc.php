<?php
// LDAP Authentication Component
//
// Copyright (c) 2010 Nagios Enterprises, LLC.  All rights reserved.
//  
// $Id: ldapauth.inc.php 903 2012-10-30 21:15:05Z mguthrie $

require_once(dirname(__FILE__).'/../componenthelper.inc.php');


// respect the name
$ldapauth_component_name="ldapauth";

// run the initialization function
ldapauth_component_init();

////////////////////////////////////////////////////////////////////////
// COMPONENT INIT FUNCTIONS
////////////////////////////////////////////////////////////////////////

function ldapauth_component_init(){
	global $ldapauth_component_name;
	
	$versionok=ldapauth_component_checkversion();
	
	$desc="<strong>".gettext("Experimental")."</strong>.";
	if(!$versionok)
		$desc="<br><b>".gettext("Error: This component requires Nagios XI 2009R1.3G or later.")."</b>";

	$args=array(

		// need a name
		COMPONENT_NAME => $ldapauth_component_name,
		COMPONENT_VERSION => '0.2',
			
		// informative information
		COMPONENT_AUTHOR => "Nagios Enterprises, LLC",
		COMPONENT_DESCRIPTION => gettext("Provides LDAP authentication for Nagios XI. ").$desc,
		COMPONENT_TITLE => "LDAP Authentication",
		// configuration function (optional)
		COMPONENT_CONFIGFUNCTION => "ldapauth_component_config_func",
		);
		
	register_component($ldapauth_component_name,$args);
	
	if($versionok){
		// configure authentication callback
		register_callback(CALLBACK_PROCESS_AUTH_INFO,'ldapauth_component_check_authentication');
		}
	}
	

	
///////////////////////////////////////////////////////////////////////////////////////////
// VERSION CHECK FUNCTIONS
///////////////////////////////////////////////////////////////////////////////////////////

function ldapauth_component_checkversion(){

	if(!function_exists('get_product_release'))
		return false;
	if(get_product_release()<124)
		return false;

	return true;
	}
	

///////////////////////////////////////////////////////////////////////////////////////////
// CONFIG FUNCTIONS
///////////////////////////////////////////////////////////////////////////////////////////

function ldapauth_component_config_func($mode="",$inargs,&$outargs,&$result){

	// initialize return code and output
	$result=0;
	$output="";
	
	$component_name="ldapauth";
	
	switch($mode){
		case COMPONENT_CONFIGMODE_GETSETTINGSHTML:
		
			$settings_raw=get_option("ldapauth_component_options");
			if($settings_raw=="")
				$settings=array();
			else
				$settings=unserialize($settings_raw);
				
			// initial values
			$ldap_host=grab_array_var($settings,"ldap_host","192.168.5.4");
			$ldap_port=grab_array_var($settings,"ldap_port","389");
			$base_dn=grab_array_var($settings,"base_dn","dc=acme,dc=com");
			$user_dn=grab_array_var($settings,"user_dn","cn=[USERNAME],cn=users,dc=acme,dc=com");
			$enabled=grab_array_var($settings,"enabled","");
			
			// values passed to us
			$ldap_host=grab_array_var($inargs,"ldap_host",$ldap_host);
			$ldap_port=grab_array_var($inargs,"ldap_port",$ldap_port);
			$base_dn=grab_array_var($inargs,"base_dn",$base_dn);
			$user_dn=grab_array_var($inargs,"user_dn",$user_dn);
			$enabled=checkbox_binary(grab_array_var($inargs,"enabled",$enabled));

			$component_url=get_component_url_base($component_name);

			$output='
			
	<div class="sectionTitle">'.gettext('Authentication Settings').'</div>
	
	<table>

	<tr>
	<td valign="top">
	<label for="enabled">'.gettext('Enable LDAP Authentication').':</label><br class="nobr" />
	</td>
	<td>
	<input type="checkbox" class="checkbox" id="enabled" name="enabled" '.is_checked($enabled,1).'>
<br class="nobr" />
	'.gettext('Enables LDAP authentication for Nagios XI').'.<br><br>
	</td>
	</tr>

	<tr>
	<td valign="top">
	<label>'.gettext('LDAP Host').':</label><br class="nobr" />
	</td>
	<td>
<input type="text" size="40" name="ldap_host" id="ldap_host" value="'.htmlentities($ldap_host).'" class="textfield" /><br class="nobr" />
	'.gettext('The IP address of your LDAP host.').'<br><br>
	</td>
	</tr>

	<tr>
	<td valign="top">
	<label>'.gettext('LDAP Port').':</label><br class="nobr" />
	</td>
	<td>
<input type="text" size="3" name="ldap_port" id="ldap_port" value="'.htmlentities($ldap_port).'" class="textfield" /><br class="nobr" />
	'.gettext('The port that your LDAP host is running on.').'<br><br>
	</td>
	</tr>

	<tr>
	<td valign="top">
	<label>'.gettext('Base DN:').'</label><br class="nobr" />
	</td>
	<td>
<input type="text" size="40" name="base_dn" id="base_dn" value="'.htmlentities($base_dn).'" class="textfield" /><br class="nobr" />
	'.gettext('The base DN to use for authenticating to and/or browsing the LDAP server.').'<br><br>
	</td>
	</tr>

	<tr>
	<td valign="top">
	<label>'.gettext('User DN:').'</label><br class="nobr" />
	</td>
	<td>
<input type="text" size="50" name="user_dn" id="user_dn" value="'.htmlentities($user_dn).'" class="textfield" /><br class="nobr" />
	'.gettext('The user DN (fully distinguished name) that is used to check user authentication.  Note: <b>[USERNAME]</b> will be automatically replaced with the user\'s username when they authenticate.').'<br><br>
	</td>
	</tr>

	</table>

			';
			break;
			
		case COMPONENT_CONFIGMODE_SAVESETTINGS:
		
			// get variables
			$ldap_host=grab_array_var($inargs,"ldap_host","");
			$ldap_port=grab_array_var($inargs,"ldap_port","");
			$base_dn=grab_array_var($inargs,"base_dn","");
			$user_dn=grab_array_var($inargs,"user_dn","");
			$enabled=checkbox_binary(grab_array_var($inargs,"enabled",""));
			
			// validate variables
			$errors=0;
			$errmsg=array();
			if($enabled==1){
				if(!function_exists('ldap_bind')) {
					$errmsg[$errors++]=gettext("LDAP libraries not installed!  To install them, log into the server, and run 'yum install php-ldap'.");
					}
                if(have_value($ldap_host)==false){
					$errmsg[$errors++]=gettext("No LDAP host specified.");
					}
				if(have_value($ldap_port)==false){
					$errmsg[$errors++]=gettext("No LDAP port specified.");
					}
				if(have_value($base_dn)==false){
					$errmsg[$errors++]=gettext("No base DN specified.");
					}
				if(have_value($user_dn)==false){
					$errmsg[$errors++]=gettext("No user DN specified.");
					}
				else if(strstr($user_dn,"[USERNAME]")===FALSE){
					$errmsg[$errors++]="<b>[USERNAME]</b> pattern not found in user DN.";
					}
				}
			
			// handle errors
			if($errors>0){
				$outargs[COMPONENT_ERROR_MESSAGES]=$errmsg;
				$result=1;
				return '';
				}
			
			// save settings
			$settings=array(
				"ldap_host" => $ldap_host,
				"ldap_port" => $ldap_port,
				"base_dn" => $base_dn,
				"user_dn" => $user_dn,
				"enabled" => $enabled,
				);
			set_option("ldapauth_component_options",serialize($settings));
						
			break;
		
		default:
			break;
			
		}
		
	return $output;
	}

	
///////////////////////////////////////////////////////////////////////////////////////////
// AUTHENTICATION FUNCTIONS
///////////////////////////////////////////////////////////////////////////////////////////

function ldapauth_component_check_authentication($cbtype,&$cbargs){

	// get the credentials the user is passing to us
	$username=grab_array_var($cbargs["credentials"],"username");
	$password=grab_array_var($cbargs["credentials"],"password");
	
	// get our settings
	$settings_raw=get_option("ldapauth_component_options");
	if($settings_raw=="")
		$settings=array();
	else
		$settings=unserialize($settings_raw);	

	// initial values
	$ldap_host=grab_array_var($settings,"ldap_host");
	$ldap_port=grab_array_var($settings,"ldap_port");
	$base_dn=grab_array_var($settings,"base_dn");
	$user_dn=grab_array_var($settings,"user_dn");
	$enabled=grab_array_var($settings,"enabled");
	
	// bail out if we're not enabled...
	if($enabled!=1){
		$cbargs["debug_messages"][]="LDAP authentication not enabled - skipping.";
		return;
		}
	
	//putenv('LDAPTLS_REQCERT=never')   //allows connection to SSL LDAP server, fixes certificate issue 
	
	// connect to the LDAP server
	if(!($ds=ldap_connect($ldap_host,$ldap_port))){
	
		// return some info for debugging
		$cbargs["info_messages"][]="Unable to connect to LDAP server '".htmlentities($ldap_host)."'.";
		
		return;
		}

	ldap_set_option($ds,LDAP_OPT_PROTOCOL_VERSION,3);
		
	// construct the dn
	$dn=str_replace("[USERNAME]",$username,$user_dn);
		
	// try binding with the username and password
	if(($bind=ldap_bind($ds,$dn,$password))){
	
		// credentials were correct!
		
		// notify caller of authentication success
		$cbargs["login_ok"]=1;
		
		$cbargs["debug_messages"][]="Sucessfully authenticated against LDAP!";
		
		return;
		}
		
	// bind failed...
	$msg=ldap_error($ds);
	$cbargs["debug_messages"][]="Unable to bind to LDAP server ".$ldap_host." (port ".$ldap_port.") with DN: ".htmlentities($dn).".  Error was: ".$msg;
		
	// FUTURE TODO: fallback to searching LDAP tree via filter...
	}


?>