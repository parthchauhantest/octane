<?php
// HYPERMAP REPLAY
//
// Copyright (c) 2008-2009 Nagios Enterprises, LLC.  All rights reserved.
//  
// $Id: index.php 903 2012-10-30 21:15:05Z mguthrie $

require_once(dirname(__FILE__).'/../../common.inc.php');

include_once(dirname(__FILE__).'/ajax.inc.php');

// initialization stuff
pre_init();

// start session
init_session();

// grab GET or POST variables 
grab_request_vars();

// check prereqs
check_prereqs();

// check authentication
check_authentication(false);


route_request();

function route_request(){
	global $request;
	
	// only certain people can see this
	if(is_authorized_for_all_objects()==false){
		echo gettext("You are not authorized to view all hosts and services.");
		exit();
		}
		
	$mode=grab_request_var("mode");
	switch($mode){
		case "getdata":
			hypermap_replay_get_data();
			break;
		default:
			display_hypermap_replay();
			break;
		}
	}

function display_hypermap_replay(){

	include_once(dirname(__FILE__).'/dashlet.inc.php');

	// get values passed in GET/POST request
	$reportperiod=grab_request_var("reportperiod","last24hours");
	$startdate=grab_request_var("startdate","");
	$enddate=grab_request_var("enddate","");
	$type=grab_request_var("type","");
	$timepoints=grab_request_var("timepoints",10);
	$refresh=grab_request_var("refresh",6);

	// determine start/end times based on period
	get_times_from_report_timeperiod($reportperiod,$starttime,$endtime,$startdate,$enddate);

	// makes sure user has appropriate license level
	licensed_feature_check();

	// start the HTML page
	do_page_start(array("page_title"=>"Network Replay"),true);
	
?>
	<h1><?php echo gettext("Network Replay"); ?></h1>

<?php
	
?>
	<form method="get" action="<?php echo htmlentities($_SERVER["REQUEST_URI"]);?>">
	
	<div class="reportexportlinks">
	<?php echo get_add_myreport_html("Network Replay",$_SERVER["REQUEST_URI"],array());?>
	</div>
	
<?php
	$auto_start_date=date('m/d/Y',strtotime('yesterday'));
	$auto_end_date=date('m/d/Y');
?>
	
	<script type="text/javascript">
	$(document).ready(function(){
		$('#startdateBox').click(function(){
			$('#reportperiodDropdown').val('custom');
			if($('#startdateBox').val()=='' && $('#enddateBox').val()==''){
				$('#startdateBox').val('<?php echo $auto_start_date;?>');
				$('#enddateBox').val('<?php echo $auto_end_date;?>');
				}
			});
		$('#enddateBox').click(function(){
			$('#reportperiodDropdown').val('custom');
			if($('#startdateBox').val()=='' && $('#enddateBox').val()==''){
				$('#startdateBox').val('<?php echo $auto_start_date;?>');
				$('#enddateBox').val('<?php echo $auto_end_date;?>');
				}
			});
		
		});
	</script>

	<div class="reporttimepicker">
	<?php echo gettext("Period"); ?>&nbsp;
	<select id='reportperiodDropdown' name="reportperiod">
<?php
	$tp=get_report_timeperiod_options();
	foreach($tp as $shortname => $longname){
		echo "<option value='".$shortname."' ".is_selected($shortname,$reportperiod).">".$longname."</option>";
		}
?>
	</select>
	&nbsp;<?php echo gettext("From"); ?>&nbsp;
	<input class="textfield" type="text" id='startdateBox' name="startdate" value="<?php echo encode_form_val($startdate); ?>" size="8" />
	<div class="reportstartdatepicker"><img src="<?php echo theme_image("calendar_small.png");?>"></div>
	&nbsp;<?php echo gettext("To"); ?>&nbsp;
	<input class="textfield" type="text" id='enddateBox' name="enddate" value="<?php echo encode_form_val($enddate); ?>" size="8" />
	<div class="reportenddatepicker"><img src="<?php echo theme_image("calendar_small.png");?>"></div>
	&nbsp;
	<input type='submit' class='reporttimesubmitbutton' name='reporttimesubmitbutton' value='Go'>
	</div>
		
	</form>

<?php
	// don't dislpay this as a dashlet - just call the function directly.  we might want it as a dashlet in the future
	$args=array(
		"starttime" => $starttime,
		"endtime" => $endtime,
		"timepoints" => $timepoints,
		"refresh" => $refresh,
		);
	$output=hypermap_replay_dashlet(DASHLET_MODE_OUTBOARD,"",$args);
	echo $output;
?>
	
<?php
	/*
	$dargs=array(
		DASHLET_ARGS => array(
			"type" => $type,
			),
		);

		echo "ARGS GOING IN=";
	print_r($dargs);
	echo "<BR>";
	display_dashlet("hypermap_replay","",$dargs,DASHLET_MODE_OUTBOARD);
	*/
?>

<?php		
	
	// closes the HTML page
	do_page_end(true);
	}
	