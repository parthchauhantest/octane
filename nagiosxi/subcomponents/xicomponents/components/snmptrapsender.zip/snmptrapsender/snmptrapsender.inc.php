<?php
// SNMP TRAP SENDER COMPONENT
//
// Copyright (c) 2010 Nagios Enterprises, LLC.  All rights reserved.
//  
// $Id: snmptrapsender.inc.php 532 2012-03-02 15:40:15Z egalstad $

require_once(dirname(__FILE__).'/../componenthelper.inc.php');

// respect the name
$snmptrapsender_component_name="snmptrapsender";

// run the initialization function
snmptrapsender_component_init();

////////////////////////////////////////////////////////////////////////
// COMPONENT INIT FUNCTIONS
////////////////////////////////////////////////////////////////////////

function snmptrapsender_component_init(){
	global $snmptrapsender_component_name;
	
	$desc="";

	// check XI versiond
	$versionok=snmptrapsender_component_checkversion();
	if(!$versionok)
		$desc.="<b>Error: This component requires Nagios XI 2009R1.2B or later.</b>  ";
		
	// check required component installation
	$installok=snmptrapsender_component_checkinstallation();
	if(!$installok)
		$desc.="<b>Installation Required!</b>  You must login to the server as the root user and run the following commands to complete the installation of this component:<br>
		<i>cd /usr/local/nagiosxi/html/includes/components/".$snmptrapsender_component_name."/</i><br>
		<i>chmod +x installprereqs.sh</i><br>		
		<i>./installprereqs.sh</i><br>";
	/* ENABLING THIS CHECK BELOW BREAKS THINGS! */
	/*
	db_connect_all();
	$eventhandlersok=snmptrapsender_component_checkeventhandlers();
	if(!$eventhandlersok)
		$desc.="<br><font color='red'><b>WARNING:</b> Event handlers are currently disabled.  This will prevent the SNMP trap sender from working!</font>";
	*/
	
	$args=array(

		// need a name
		COMPONENT_NAME => $snmptrapsender_component_name,
		
		// informative information
		COMPONENT_AUTHOR => "Nagios Enterprises, LLC",
		COMPONENT_DESCRIPTION => "Allows Nagios XI to send SNMP traps to other network management systems when host and service alerts occur.  ".$desc,
		COMPONENT_TITLE => "SNMP Trap Sender",
        COMPONENT_VERSION => '1.1', 

		// configuration function (optional)
		COMPONENT_CONFIGFUNCTION => "snmptrapsender_component_config_func",
		);
		
	register_component($snmptrapsender_component_name,$args);
	

	// add a menu link
	//if($versionok)
	//	register_callback(CALLBACK_MENUS_INITIALIZED,'snmptrapsender_component_addmenu');
	}
	

///////////////////////////////////////////////////////////////////////////////////////////
//CONFIG FUNCTIONS
///////////////////////////////////////////////////////////////////////////////////////////

function snmptrapsender_component_config_func($mode="",$inargs,&$outargs,&$result){
	global $snmptrapsender_component_name;

	// initialize return code and output
	$result=0;
	$output="";
	

	switch($mode){
		case COMPONENT_CONFIGMODE_GETSETTINGSHTML:

			// defaults
			$trap_hosts=array();
			for($x=0;$x<=4;$x++){
				$trap_hosts[$x]=array(
					"address" => "",
					"community" => "public",
					);
				}

			$settings_raw=get_option("snmptrapsender_component_options");
			if($settings_raw==""){
				$settings=array(
					"enabled"=>0,
					//"trap_hosts"=>array(),
					);
				}
			else
				$settings=unserialize($settings_raw);
				
			//print_r($settings);
				
			// initial values
			$enabled=grab_array_var($settings,"enabled","");
			$trap_hosts=grab_array_var($settings,"trap_hosts",$trap_hosts);
			
			// values passed to us
			$enabled=checkbox_binary(grab_array_var($inargs,"enabled",$enabled));
			$trap_hosts=grab_array_var($inargs,"trap_hosts",$trap_hosts);
			
			$component_url=get_component_url_base($snmptrapsender_component_name);
			
			$output='';
			
			$eventhandlersok=snmptrapsender_component_checkeventhandlers();
			if(!$eventhandlersok)
				$output.="<font color='red'><b>WARNING:</b> Event handlers are currently disabled.  This will prevent the SNMP trap sender from working!</font>";


			$output.='
			
					
	<div class="sectionTitle">Integration Settings</div>
	
	<table>

	<tr>
	<td valign="top">
	<label for="enabled">Enable Integration:</label><br class="nobr" />
	</td>
	<td>
	<input type="checkbox" class="checkbox" id="enabled" name="enabled" '.is_checked($enabled,1).'>
<br class="nobr" />
	Enables SNMP trap sending functionality.
	</td>
	</tr>

	</table>

	<div class="sectionTitle">Trap Hosts</div>
	
	<p>
	Specify the addresses of the hosts that SNMP traps should be sent to.
	</p>
	
	<table class="standardtable">
	<tr><th>Host Address</th><th>SNMP Community</th></tr>
	';
	
	for($x=0;$x<=2;$x++){

		$output.='
	<tr>
	<td>
<input type="text" size="25" name="trap_hosts['.$x.'][address]" value="'.htmlentities($trap_hosts[$x]["address"]).'" class="textfield" />
	</td>
	<td>
<input type="text" size="15" name="trap_hosts['.$x.'][community]" value="'.htmlentities($trap_hosts[$x]["community"]).'" class="textfield" />
	</td>
	</tr>
		';
		}
		
	$output.='
	</table>

	
	<div class="sectionTitle">MIBs</div>
	
	<p>
	You should install the following MIBs on the trap management hosts:
	</p>
	<p>
	<a href="'.$component_url.'/mibs/NAGIOS-NOTIFY-MIB.txt">NAGIOS-NOTIFY-MIB.txt</a><br>
	<a href="'.$component_url.'/mibs/NAGIOS-ROOT-MIB.txt">NAGIOS-ROOT-MIB.txt</a><br>
	</p>
	
	<table>


	</table>
	';
		

			break;
			
		case COMPONENT_CONFIGMODE_SAVESETTINGS:
		
			// get variables
			$enabled=checkbox_binary(grab_array_var($inargs,"enabled",""));
			$trap_hosts=grab_array_var($inargs,"trap_hosts","");
			
			// validate variables
			$errors=0;
			$errmsg=array();
			if($enabled==1){
				}
			
			// handle errors
			if($errors>0){
				$outargs[COMPONENT_ERROR_MESSAGES]=$errmsg;
				$result=1;
				return '';
				}
			
			// save settings
			$settings=array(
				"enabled" => $enabled,
				"trap_hosts" => $trap_hosts,
				);
			set_option("snmptrapsender_component_options",serialize($settings));
			
		
			// info messages
			$okmsg=array();
			$okmsg[]="Settings updated.";
			$outargs[COMPONENT_INFO_MESSAGES]=$okmsg;
			
			break;
		
		default:
			break;
			
		}
		
	return $output;
	}
	

////////////////////////////////////////////////////////////////////////
// EVENT HANDLER AND NOTIFICATION FUNCTIONS
////////////////////////////////////////////////////////////////////////

register_callback(CALLBACK_EVENT_PROCESSED,'snmptrapsender_component_eventhandler');


//snmptrapsender_component_register_callbacks();

/*
function snmptrapsender_component_register_callbacks(){
	// load settings
	$settings_raw=get_option("snmptrapsender_component_options");
	if($settings_raw==""){
		//$settings=array();
		// settings have not been configured yet...
		echo "SNMP TRAP SENDER NOT CONFIGURED!\n";
		return;
		}
	else
		$settings=unserialize($settings_raw);
	
	// are we enabled?
	$enabled=grab_array_var($settings,"enabled","");
	if($enabled!=1){
		echo "SNMP TRAP SENDER NOT ENABLED! VALUE='$enabled'\n";
		return;
		}
		
	register_callback(CALLBACK_EVENT_PROCESSED,'snmptrapsender_component_eventhandler');
	}
*/

function snmptrapsender_component_eventhandler($cbtype,$args){

	echo "*** GLOBAL HANDLER (snmptrapsender)...\n";
	print_r($args);

	switch($args["event_type"]){
		case EVENTTYPE_STATECHANGE:
			snmptrapsender_component_handle_statechange_event($args);
			break;
		/*
		case EVENTTYPE_NOTIFICATION:
			snmptrapsender_component_handle_notification_event($args);
			break;
		*/
		default:
			break;
		}
	}
	
	
function snmptrapsender_component_handle_statechange_event($args){

	// the commands we run
	$service_trap_command="/usr/bin/snmptrap -v 2c -c public 192.168.5.4 '' NAGIOS-NOTIFY-MIB::nSvcEvent nSvcHostname s \"%host%\" nSvcDesc s \"%service%\" nSvcStateID i %servicestateid% nSvcOutput s \"%serviceoutput%\"";
	$host_trap_command="/usr/bin/snmptrap -v 2c -c public 192.168.5.4 '' NAGIOS-NOTIFY-MIB::nHostEvent nHostname s \"%host%\" nHostStateID i %hoststateid% nHostOutput s \"%hostoutput%\"";
	$meta=grab_array_var($args,"event_meta",array());
	$handler_type=grab_array_var($meta,"handler-type","");
	
	// load settings
	$settings_raw=get_option("snmptrapsender_component_options");
	if($settings_raw==""){
		//$settings=array();
		// settings have not been configured yet...
		echo "SNMP TRAP SENDER NOT CONFIGURED!\n";
		return;
		}
	else
		$settings=unserialize($settings_raw);
	
	// are we enabled?
	$enabled=grab_array_var($settings,"enabled","");
	if($enabled!=1){
		echo "SNMP TRAP SENDER NOT ENABLED! VALUE='$enabled'\n";
		return;
		}
	
	switch($handler_type){
		case "host":
		case "service":
			if(array_key_exists("trap_hosts",$settings)){
			
				// loop through all trap hosts
				foreach($settings["trap_hosts"] as $th){
                    echo "PROCESSING:\n";
                    print_r($th);
					// get address and community
					$address=grab_array_var($th,"address");
					$community=grab_array_var($th,"community");
					// only send to hosts that have address and community defined
					if($address!="" && $community!=""){

						if($handler_type=="service")
							$trap_command="/usr/bin/snmptrap -v 2c -c $community $address '' NAGIOS-NOTIFY-MIB::nSvcEvent nSvcHostname s \"%host%\" nSvcDesc s \"%service%\" nSvcStateID i %servicestateid% nSvcOutput s \"%serviceoutput%\"";
						else {
                            $trap_command="/usr/bin/snmptrap -v 2c -c $community $address '' NAGIOS-NOTIFY-MIB::nHostEvent nHostname s \"%host%\" nHostStateID i %hoststateid% nHostOutput s \"%hostoutput%\"";
                            }
						snmptrapsender_component_sendtrap($address,$community,$trap_command,$meta);
						}
					}
				}
			break;
		default;
			break;
		}
		
	}

	
function snmptrapsender_component_sendtrap($host,$community,$command,$meta){

	// pre-process command for variables
	$processed_command=process_notification_text($command,$meta);
	
	echo "RUNNING COMMAND: $processed_command\n";
	
	// run the command
	exec($processed_command);
	}
	
	

///////////////////////////////////////////////////////////////////////////////////////////
// MISC FUNCTIONS
///////////////////////////////////////////////////////////////////////////////////////////

function snmptrapsender_component_checkversion(){

	if(!function_exists('get_product_release'))
		return false;
	//requires greater than 2009R1.2
	if(get_product_release()<114)
		return false;

	return true;
	}
	
function snmptrapsender_component_checkinstallation(){
	global $snmptrapsender_component_name;
	
	$f="/usr/local/nagiosxi/html/includes/components/".$snmptrapsender_component_name."/installed.ok";
	
	// install file doesn't exist
	if(!file_exists($f)){
		//echo "FILE $f DOES NOT EXIST<BR>";
		return false;
		}
		
	return true;
	}
	
function snmptrapsender_component_checkeventhandlers(){

	// get process status
	$args=array(
		"cmd" => "getprogramstatus",
		);
	$xml=get_backend_xml_data($args);
	if($xml){
		$v=intval($xml->programstatus->event_handlers_enabled);
		if($v==1)
			return true; // event handlers are enabled
		}
	
	return false;
	}

?>