#!/bin/sh


componentdir=/usr/local/nagiosxi/html/includes/components/snmptrapsender

# Install required rpms
echo "Installing required components..."

# if offline then not needed
if [ ! -f $INSTALL_PATH/offline ]; then
	yum install net-snmp net-snmp-utils net-snmp-devel -y
fi
	
pushd $componentdir

# Install MIBS
echo "Installing MIBs..."
cp mibs/*.txt /usr/share/snmp/mibs/

# Write installed file/flat
touch installed.ok

popd

echo "==============="
echo "SETUP COMPLETED"
echo "==============="
