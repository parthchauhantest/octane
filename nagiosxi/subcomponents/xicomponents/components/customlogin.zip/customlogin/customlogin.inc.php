<?php
// Custom Login Component
//
// Copyright (c) 2010 Nagios Enterprises, LLC.  All rights reserved.
//  
// $Id: customlogin.inc.php 902 2012-10-26 21:25:46Z mguthrie $

require_once(dirname(__FILE__).'/../componenthelper.inc.php');


// respect the name
$customlogin_component_name="customlogin";

// run the initialization function
customlogin_component_init();

////////////////////////////////////////////////////////////////////////
// COMPONENT INIT FUNCTIONS
////////////////////////////////////////////////////////////////////////

function customlogin_component_init(){
	global $customlogin_component_name;
	
	$versionok=customlogin_component_checkversion();
	
	$desc="";
	if(!$versionok)
		$desc="<br><b>".gettext("Error: This component requires Nagios XI 2012R1.3 or later.")."</b>";

	$args=array(

		// need a name
		COMPONENT_NAME => $customlogin_component_name,
		COMPONENT_VERSION => '1.0',
		// informative information
		COMPONENT_AUTHOR => "Nagios Enterprises, LLC",
		COMPONENT_DESCRIPTION => gettext("Allows a custom login splash page to be defined. ").$desc,
		COMPONENT_TITLE => "Custom Login",
		// configuration function (optional)
		COMPONENT_CONFIGFUNCTION => "customlogin_component_config_func",
		);
		
	register_component($customlogin_component_name,$args);
	
	}
	

///////////////////////////////////////////////////////////////////////////////////////////
// MISC FUNCTIONS
///////////////////////////////////////////////////////////////////////////////////////////

function customlogin_component_checkversion(){

	if(!function_exists('get_product_release'))
		return false;
	//requires greater than 2009R1.2
	if(get_product_release()<301)
		return false;

	return true;
	}
	
////////////////////////////////////////////////////////////////////////
// CONFIG FUNCTIONS
////////////////////////////////////////////////////////////////////////

function customlogin_component_config_func($mode="",$inargs,&$outargs,&$result){

	// initialize return code and output
	$result=0;
	$output="";
	
	$component_name="customlogin";
	
	switch($mode){
		case COMPONENT_CONFIGMODE_GETSETTINGSHTML:
		
			$enabled=get_option("custom_login_splash_enabled");
			$enabled=empty($enabled) ? false: checkbox_binary($enabled,true);
			$file = get_option("custom_login_splash_include");
			$file = empty($file) ? '/usr/local/nagiosxi/html/loginsplash.inc.php' : $file; 
					
			$output='
			
	<div class="sectionTitle">'.gettext('Custom Login Settings').'</div>
	
	<table>

	<tr>
	<td valign="top">
	<label for="enabled">'.gettext('Enable Custom Login Splash').':</label><br class="nobr" />
	</td>
	<td>
	<input type="checkbox" class="checkbox" id="enabled" name="enabled" '.is_checked($enabled,true).'>
<br class="nobr" />
	'.gettext('Enables use of a custom login splash defined by the specified PHP include file.').'<br><br>
	</td>
	</tr>

	<tr>
	<td valign="top">
	<label>'.gettext('Include File').':</label><br class="nobr" />
	</td>
	<td>
<input type="text" size="40" name="file" id="file" value="'.htmlentities($file).'" class="textfield" /><br class="nobr" />
	'.gettext('The include file to be used on the login page').'<br><br>
	</td>
	</tr>

	</table>

			';
			break;
			
		case COMPONENT_CONFIGMODE_SAVESETTINGS:
		
			// get variables
			$file=grab_array_var($inargs,"file","");
			$enabled=checkbox_binary(grab_array_var($inargs,"enabled",""));
			
			// validate variables
			$errors=0;
			$errmsg=array();
			if($enabled==1){
				if(have_value($file)==false)
					$errmsg[$errors++]="No include file specified.";	
				}
			
			// handle errors
			if($errors>0){
				$outargs[COMPONENT_ERROR_MESSAGES]=$errmsg;
				$result=1;
				return '';
				}
			
			// save settings
			set_option("custom_login_splash_enabled",$enabled);
			set_option("custom_login_splash_include",$file); 
						
			break;
		
		default:
			break;
			
		}
		
	return $output;
	}


?>