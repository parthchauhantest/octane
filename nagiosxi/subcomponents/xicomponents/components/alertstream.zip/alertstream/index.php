<?php
// ALERT STREAM
//
// Copyright (c) 2010-2011 Nagios Enterprises, LLC.  All rights reserved.
//  
// $Id: index.php 901 2012-10-26 21:11:02Z mguthrie $

require_once(dirname(__FILE__).'/../../common.inc.php');

// initialization stuff
pre_init();

// start session
init_session();

// grab GET or POST variables 
grab_request_vars();

// check prereqs
check_prereqs();

// check authentication
check_authentication(false);


route_request();

function route_request(){
	global $request;
	
	$mode=grab_request_var("mode");
	switch($mode){
		default:
			display_alertstream();
			break;
		}
	}
	
function display_alertstream(){
	global $lstr;

	// get values passed in GET/POST request
	$reportperiod=grab_request_var("reportperiod","last24hours");
	//$reportperiod=grab_request_var("reportperiod","thisquarter");
	$startdate=grab_request_var("startdate","");
	$enddate=grab_request_var("enddate","");
	$search=grab_request_var("search","");
	$host=grab_request_var("host","");
	$service=grab_request_var("service","");
	$hostgroup=grab_request_var("hostgroup","");
	$servicegroup=grab_request_var("servicegroup","");
	$datatype=grab_request_var("datatype","events");
	$title=grab_request_var("title","Alert Stream");
	$ytitle=grab_request_var("ytitle","Alerts");
	
	$width=grab_request_var("width",750);
	$height=grab_request_var("height", 425);

	// fix search
	if($search==$lstr['SearchBoxText'])
		$search="";
		
	// we search for hosts, so clear host if search is present
	if($search!=""){
		$host="";
		$service="";
		}
		
	if($datatype=="nagios"){
		$reportperiod="custom";
		$startdate="1999-03-19";
		$enddate=time();
		}
	
	// determine start/end times based on period
	get_times_from_report_timeperiod($reportperiod,$starttime,$endtime,$startdate,$enddate);

	// makes sure user has appropriate license level
	licensed_feature_check();

	// start the HTML page
	do_page_start(array("page_title"=>"Alert Stream"),true);
	
?>
	<h1><?php echo gettext("Alert Stream"); ?></h1>
	
	<div class="reportexportlinks">
	<?php echo get_add_myreport_html("Alert Stream",$_SERVER["REQUEST_URI"],array());?>
	</div>

<?php
	if($service!=""){
?>
	<div class="servicestatusdetailheader">
	<div class="serviceimage">
	<!--image-->
	<?php show_object_icon($host,$service,true);?>
	</div>
	<div class="servicetitle">
	<div class="servicename"><a href="<?php echo get_service_status_detail_link($host,$service);?>"><?php echo htmlentities($service);?></a></div>
	<div class="hostname"><a href="<?php echo get_host_status_detail_link($host);?>"><?php echo htmlentities($host);?></a></div>
	</div>
	</div>
	<br clear="all">

<?php
		}
	else if($host!=""){
?>
	<div class="hoststatusdetailheader">
	<div class="hostimage">
	<!--image-->
	<?php show_object_icon($host,"",true);?>
	</div>
	<div class="hosttitle">
	<div class="hostname"><a href="<?php echo get_host_status_detail_link($host);?>"><?php echo htmlentities($host);?></a></div>
	</div>
	</div>
	<br clear="all">
<?php
		}
?>
	
	<form method="get" action="<?php echo htmlentities($_SERVER["REQUEST_URI"]);?>">
	<input type="hidden" name="host" value="<?php echo htmlentities($host);?>">
	<input type="hidden" name="service" value="<?php echo htmlentities($service);?>">
	<!--
	<input type="hidden" name="hostgroup" value="<?php echo htmlentities($hostgroup);?>">
	<input type="hidden" name="servicegroup" value="<?php echo htmlentities($servicegroup);?>">
	//-->
	
	<div class="reportsearchbox">
<?php
	// search box
	$searchclass="textfield";
	if(have_value($search)==true){
		$searchstring=$search;
		$searchclass.=" newdata";
		}
	else
		$searchstring=$lstr['SearchBoxText'];
?>

	<input type="text" size="15" name="search" id="searchBox" value="<?php echo encode_form_val($searchstring);?>" class="<?php echo $searchclass;?>" />

	</div>
	
<?php
	$auto_start_date=date('m/d/Y',strtotime('yesterday'));
	$auto_end_date=date('m/d/Y');
?>
	
	<script type="text/javascript">
	$(document).ready(function(){
		$('#startdateBox').click(function(){
			$('#reportperiodDropdown').val('custom');
			if($('#startdateBox').val()=='' && $('#enddateBox').val()==''){
				$('#startdateBox').val('<?php echo $auto_start_date;?>');
				$('#enddateBox').val('<?php echo $auto_end_date;?>');
				}
			});
		$('#enddateBox').click(function(){
			$('#reportperiodDropdown').val('custom');
			if($('#startdateBox').val()=='' && $('#enddateBox').val()==''){
				$('#startdateBox').val('<?php echo $auto_start_date;?>');
				$('#enddateBox').val('<?php echo $auto_end_date;?>');
				}
			});
		
		});
	</script>

	<div class="reporttimepicker">
	<?php echo gettext("Period"); ?>&nbsp;
	<select id='reportperiodDropdown' name="reportperiod">
<?php
	$tp=get_report_timeperiod_options();
	foreach($tp as $shortname => $longname){
		echo "<option value='".$shortname."' ".is_selected($shortname,$reportperiod).">".$longname."</option>";
		}
?>
	</select>
	&nbsp;<?php echo gettext("From"); ?>&nbsp;
	<input class="textfield" type="text" id='startdateBox' name="startdate" value="<?php echo encode_form_val(get_datetime_from_timestring($startdate)); ?>" size="16" />
	<div class="reportstartdatepicker"><img src="<?php echo theme_image("calendar_small.png");?>"></div>
	&nbsp;<?php echo gettext("To"); ?>&nbsp;
	<input class="textfield" type="text" id='enddateBox' name="enddate" value="<?php echo encode_form_val(get_datetime_from_timestring($enddate)); ?>" size="16" />
	<div class="reportenddatepicker"><img src="<?php echo theme_image("calendar_small.png");?>"></div>
	&nbsp;
	<input type='submit' class='reporttimesubmitbutton' name='reporttimesubmitbutton' value='Go'>
	</div>
	
	<div class="reportoptionpicker">
	<?php echo gettext("Limit To "); ?>
	<select name="hostgroup" id="hostgroupList">
	<option value=""><?php echo gettext("Hostgroup"); ?>:</option>
<?php
	$args=array('orderby' => 'hostgroup_name:a');
    $xml=get_xml_hostgroup_objects($args);
	if($xml){
		foreach($xml->hostgroup as $hg){
			$name=strval($hg->hostgroup_name);
			echo "<option value='".$name."' ".is_selected($hostgroup,$name).">$name</option>\n";
			}
		}
?>
	</select>
	<select name="servicegroup" id="servicegroupList">
	<option value=""><?php echo gettext("Servicegroup"); ?>:</option>
<?php
	$args=array('orderby' => 'servicegroup_name:a'); 
    $xml=get_xml_servicegroup_objects($args);
	if($xml){
		foreach($xml->servicegroup as $sg){
			$name=strval($sg->servicegroup_name);
			echo "<option value='".$name."' ".is_selected($servicegroup,$name).">$name</option>\n";
			}
		}
?>
	</select>
	</div>
		
	

	
	
	<div>
	<?php echo gettext("From"); ?>: <b><?php echo get_datetime_string($starttime,DT_SHORT_DATE_TIME,DF_AUTO,"null");?></b>
	<?php echo gettext("To"); ?>: <b><?php echo get_datetime_string($endtime,DT_SHORT_DATE_TIME,DF_AUTO,"null");?></b>
	</div>
	
	
<?php
	if($search!="")
		echo "<p>Showing results for '<b><i>$search</i></b>'</p>";
?>

	<p>
	<?php echo gettext("The alert stream provides a visual representation of host and service alerts over time."); ?>
	</p>
	<p>
	<?php echo gettext("Clicking on a host name will cause the graph to drill down to show service alerts for that particular host."); ?>
	</p>
	
<?php
	// craft the URL that the applet will use to access XML data (our streamgraph API)
	$xmlurl=get_base_url()."includes/components/alertstream/xmldata.php";
	$xmlurl.="?host=".urlencode($host);
	$xmlurl.="&hostgroup=".urlencode($hostgroup);
	$xmlurl.="&servicegroup=".urlencode($servicegroup);
	$xmlurl.="&search=".urlencode($search);
	$xmlurl.="&reportperiod=".urlencode($reportperiod);
	$xmlurl.="&startdate=".urlencode($startdate);
	$xmlurl.="&enddate=".urlencode($enddate);
	$xmlurl.="&starttime=".urlencode($starttime);
	$xmlurl.="&endtime=".urlencode($endtime);
	$xmlurl.="&title=".urlencode($title);
	$xmlurl.="&ytitle=".urlencode($ytitle);
	
	// go url
	$gourl=get_base_url()."includes/components/alertstream/go.php";
	$gourl.="?host=".urlencode($host);
	$gourl.="&hostgroup=".urlencode($hostgroup);
	$gourl.="&servicegroup=".urlencode($servicegroup);
	$gourl.="&search=".urlencode($search);
	$gourl.="&reportperiod=".urlencode($reportperiod);
	$gourl.="&startdate=".urlencode($startdate);
	$gourl.="&enddate=".urlencode($enddate);
	$gourl.="&starttime=".urlencode($starttime);
	$gourl.="&endtime=".urlencode($endtime);
	$gourl.="&title=".urlencode($title);
	$gourl.="&ytitle=".urlencode($ytitle);
?>
	
	
	<div style="width: <?php echo htmlentities($width);?>px;">
	<!-- BEGIN APPLET EMBED CODE -->

		<applet code="AlertStream.class" archive="AlertStream.jar" width="<?php echo htmlentities($width);?>" height="<?php echo htmlentities($height);?>" mayscript="true" VIEWASTEXT ID="Applet2">

		<param name="datasrc" value="<?php echo $xmlurl;?>">
		<param name="gourl" value="<?php echo $gourl;?>">
		<param name="title" value="<?php echo htmlentities($title);?>">
		<param name="ytitle" value="<?php echo htmlentities($ytitle);?>">
		<param name="starttime" value="<?php echo htmlentities($starttime);?>">
		<param name="endtime" value="<?php echo htmlentities($endtime);?>">
		<param name="host" value="<?php echo htmlentities($host);?>">

		<!-- This is the message that shows up when people don't have
			Java installed in their browser. Any HTML can go here
			(i.e. if you wanted to include an image other links, 
			or an anti-Microsoft diatribe. -->
		<?php echo gettext("To view this content, you need to install Java from"); ?> <A HREF="http://java.com">java.com</A>

		</applet>
 
	<!-- END APPLET EMBED CODE -->
	</div>
	
<?php	
	// closes the HTML page
	do_page_end(true);
	}

?>