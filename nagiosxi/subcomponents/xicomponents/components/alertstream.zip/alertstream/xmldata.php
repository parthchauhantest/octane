<?php
// ALERT CLOUD XML DATA
//
// Copyright (c) 2010-2011 Nagios Enterprises, LLC.  All rights reserved.
//  
// $Id: xmldata.php 361 2011-08-05 22:33:33Z egalstad $

require_once(dirname(__FILE__).'/../../common.inc.php');
//require_once(dirname(__FILE__).'/../../utilsx.inc.php');

// initialization stuff
pre_init();

// start session
init_session();

// grab GET or POST variables 
grab_request_vars();

// check prereqs
check_prereqs();

// check authentication
check_authentication(false);


route_request();

function route_request(){
	global $request;
	
	$mode=grab_request_var("mode");
	switch($mode){
		default:
			getxml();
			break;
		}
	}
	
function getxml(){


	// get values passed in GET/POST request
	$page=grab_request_var("page",1);
	$records=grab_request_var("records",25);
	$reportperiod=grab_request_var("reportperiod","last24hours");
	$startdate=grab_request_var("startdate","");
	$enddate=grab_request_var("enddate","");
	$starttime=grab_request_var("starttime","");
	$endtime=grab_request_var("endtime","");
	$search=grab_request_var("search","");
	$host=grab_request_var("host","");
	$service=grab_request_var("service","");
	$hostgroup=grab_request_var("hostgroup","");
	$servicegroup=grab_request_var("servicegroup","");
	$statetype=grab_request_var("statetype","");
	
	// fix search
	//if($search==$lstr['SearchBoxText'])
		//$search="";
	
	// special "all" stuff
	if($hostgroup=="all")
		$hostgroup="";
	if($servicegroup=="all")
		$servicegroup="";
	if($host=="all")
		$host="";
		

	// can do hostgroup OR servicegroup OR host
	if($host!=""){
		$servicegroup="";
		$hostgroup="";
		}
	else if($hostgroup!=""){
		$servicegroup="";
		$host="";
		}
	else if($servicegroup!=""){
		$host="";
		}

	//  limit hosts by hostgroup or host
	$host_ids=array();
	//  limit by hostgroup
	if($hostgroup!=""){
		$host_ids=get_hostgroup_member_ids($hostgroup);
		}
	//  limit by host
	//else if($host!=""){
	///	$host_ids[]=get_host_id($host);
	//	}
	//  limit service by servicegroup
	$service_ids=array();
	if($servicegroup!=""){
		$service_ids=get_servicegroup_member_ids($servicegroup);
		}
		
	$object_ids=array();
	$object_ids_str="";
	$y=0;
	foreach($host_ids as $hid){
		if($y>0)
			$object_ids_str.=",";
		$object_ids_str.=$hid;
		$y++;
		}
	foreach($service_ids as $sid){
		if($y>0)
			$object_ids_str.=",";
		$object_ids_str.=$sid;
		$y++;
		}
		
	// start/end times must be in unix timestamp format
	// if they weren't specified, default to last 24 hours
	//$endtime=grab_request_var("endtime",time());
	//$starttime=grab_request_var("starttime",$endtime-(24*60*60));
	
	// determine start/end times based on period
	if($starttime=="" || $endtime=="")
		get_times_from_report_timeperiod($reportperiod,$starttime,$endtime,$startdate,$enddate);
	
	// initialize buckets
	$buckets=array();
	$total_buckets=25;
	for($x=0;$x<($total_buckets+1);$x++)
		$buckets[$x]=array();
		
	$timediff=($endtime-$starttime);
	$bucketsize=intval(($timediff/$total_buckets));
	
	//echo "START: $starttime<BR>";
	//echo "END: $endtime<BR>";
	//echo "BUCKET_SIZE: $bucketsize<BR>";

	// adjust start time to have one more bucket
	//$starttime=$starttime-$bucketsize;
	$endtime=$endtime+$bucketsize;

	// re-calculate bucket size
	//$timediff=($endtime-$starttime);
	//$bucketsize=intval(($timediff/$total_buckets));
	
	//echo "END2: $endtime<BR>";
	//echo "BUCKET_SIZE2: $bucketsize<BR>";
	
	$args=array(
		"starttime" => $starttime,
		"endtime" => $endtime,
		);
	switch($statetype){
		case "soft":
			$args["state_type"]=0;
			break;
		case "hard":
			$args["state_type"]=1;
			break;
		default:
			break;
		}
	// object id limiters
	if($object_ids_str!="")
		$args["object_id"]="in:".$object_ids_str;
	else{
		if($host!=""){
			$args["host_name"]=$host;
			$args["objecttype_id"]=OBJECTTYPE_SERVICE;
			}
		}
	if($search)
		$args["output"]="lk:".$search;
	$xml=get_xml_statehistory($args);
	
	//header("Type: text/plain");
	
	//echo "ARGS:<BR>";
	//print_r($args);
	//$xml=null;
	/**/
	//print_r($xml);


?>

<?php

	if($xml){
		foreach($xml->stateentry as $se){
		
			$statetime=strtotime(strval($se->state_time));
			if($host!="")
				$objname=strval($se->service_description);
			else
				$objname=strval($se->host_name);
				
			// what bucket does this go into
			$bucket=floor(($statetime-$starttime)/$bucketsize);
			
			// put it in the bucket
			if(!array_key_exists($objname,$buckets[$bucket]))
				$buckets[$bucket][$objname]=0;
			$buckets[$bucket][$objname]=$buckets[$bucket][$objname]+1;
			
			//if($bucket>=3){
				//echo "BUCKET=$bucket, TIME=$statetime<BR>\n";
			//	}
			}
		}
		
	//echo "BUCKETSIZE: $bucketsize<BR>";
	//print_r($buckets);
?>
<alertdata>
<?php
	$x=0;
	foreach($buckets as $b){
		//if($x>=$total_buckets)
			//break;
		echo "   <timeslot bucket='".$x."' start='".($starttime+($x*$bucketsize))."' end='".($starttime+(($x+1)*$bucketsize))."'>\n";
		foreach($b as $objname => $total){
			echo "      <itemtotal name='".xmlentities($objname)."'>".$total."</itemtotal>\n";
			}
		echo "   </timeslot>\n";
		$x++;
		}
?>
</alertdata>
<?php

	}
?>