<?php
// Alert Stream Component
//
// Copyright (c) 2010-2011 Nagios Enterprises, LLC.  All rights reserved.
//  
// $Id: alertstream.inc.php 902 2012-10-26 21:25:46Z mguthrie $

require_once(dirname(__FILE__).'/../componenthelper.inc.php');


// respect the name
$alertstream_component_name="alertstream";

// run the initialization function
alertstream_component_init();

////////////////////////////////////////////////////////////////////////
// COMPONENT INIT FUNCTIONS
////////////////////////////////////////////////////////////////////////

function alertstream_component_init(){
	global $alertstream_component_name;
	
	$versionok=alertstream_component_checkversion();
	
	$desc="";
	if(!$versionok)
		$desc="<br><b>".gettext("Error: This component requires Nagios XI 2009R1.4B or later.")."</b>";

		
	$args=array(

		// need a name
		COMPONENT_NAME => $alertstream_component_name,
		COMPONENT_VERSION => '1.2',
		// informative information
		COMPONENT_AUTHOR => "Nagios Enterprises, LLC",
		COMPONENT_DESCRIPTION => gettext("Displays a streamgraph report of alerts. ").$desc,
		COMPONENT_TITLE => "Alert Stream",
		// configuration function (optional)
		//COMPONENT_CONFIGFUNCTION => "alertstream_component_config_func",
		);
		
	register_component($alertstream_component_name,$args);
	
	if($versionok){
		// add a menu link
		register_callback(CALLBACK_MENUS_INITIALIZED,'alertstream_component_addmenu');

		}


	}
	

///////////////////////////////////////////////////////////////////////////////////////////
// MISC FUNCTIONS
///////////////////////////////////////////////////////////////////////////////////////////

function alertstream_component_checkversion(){

	if(!function_exists('get_product_release'))
		return false;
	//requires greater than 2009R1.4B
	if(get_product_release()<126)
		return false;

	return true;
	}
	
	
function alertstream_component_addmenu($arg=null){
	global $alertstream_component_name;
	
	$mi=find_menu_item(MENU_REPORTS,"menu-reports-sectionend-visualization","id");
	if($mi==null)
		return;
		
	$order=grab_array_var($mi,"order","");
	if($order=="")
		return;
		
	$neworder=$order-.1;

	add_menu_item(MENU_REPORTS,array(
		"type" => "link",
		"title" => gettext("Alert Stream"),
		"id" => "menu-reports-alertstream",
		"order" => $neworder,
		"opts" => array(
			"href" => get_base_url().'includes/components/alertstream/',
			)
		));

	}
	
?>