<?php

require_once(dirname(__FILE__).'/../../common.inc.php');

// initialization stuff
pre_init();

// start session
init_session();

// grab GET or POST variables 
grab_request_vars();

// check prereqs
check_prereqs();

// check authentication
check_authentication(false);


route_request();

function route_request(){
	global $request;
	
	doit();
	}
	
function doit(){
	global $lstr;

	// get values passed in GET/POST request
	$reportperiod=grab_request_var("reportperiod","last24hours");
	$startdate=grab_request_var("startdate","");
	$enddate=grab_request_var("enddate","");
	$search=grab_request_var("search","");
	$host=grab_request_var("host","");
	$service=grab_request_var("service","");
	$hostgroup=grab_request_var("hostgroup","");
	$servicegroup=grab_request_var("servicegroup","");
	$datatype=grab_request_var("datatype","events");
	$title=grab_request_var("title","Alert Stream");
	$ytitle=grab_request_var("ytitle","Alerts");
	
	// craft the URL to state history
	$gourl=get_base_url()."reports/statehistory.php";
	$gourl.="?host=".urlencode($host);
	$gourl.="&service=".urlencode($service);
	$gourl.="&reportperiod=".urlencode($reportperiod);
	$gourl.="&startdate=".urlencode($startdate);
	$gourl.="&enddate=".urlencode($enddate);
	$gourl.="&starttime=".urlencode($starttime);
	$gourl.="&endtime=".urlencode($endtime);
	
	header("Location: ".$gourl);
	}

?>