<?php
// ALERT CLOUD DASHLET
//
// Copyright (c) 2010 Nagios Enterprises, LLC.  All rights reserved.
//  
// $Id: alertcloud.inc.php 3 2010-04-02 21:41:26Z egalstad $

include_once(dirname(__FILE__).'/../../dashlets/dashlethelper.inc.php');


function alertcloud_dashlet_func($mode=DASHLET_MODE_PREVIEW,$id="",$args=null){

	$output="";
	$imgbase=get_base_url()."includes/components/alertcloud/images/";

	switch($mode){
	
		case DASHLET_MODE_GETCONFIGHTML:
			$output='
			<BR CLASS="nobr" />

			<LABEL FOR="width">'.gettext('Cloud Width').'</LABEL><BR>
			<INPUT TYPE="text" NAME="width" SIZE="5" VALUE="350"><BR>
			
			<LABEL FOR="height">'.gettext('Cloud Height').'</LABEL><BR>
			<INPUT TYPE="text" NAME="height" SIZE="5" VALUE="350"><BR>

			<LABEL FOR="height">'.gettext('Touch Speed').'</LABEL><BR>
			<INPUT TYPE="text" NAME="speed" SIZE="5" VALUE="50"><BR>

			<BR CLASS="nobr" />
			';  
			break;
			break;
			
		case DASHLET_MODE_OUTBOARD:
		case DASHLET_MODE_INBOARD:

			$output="";
			
			$id="alertcloud_".random_string(6);
			
			// ajax updater args
			$ajaxargs=$args;
			// build args for javascript
			$n=0;
			$jargs="{";
			foreach($ajaxargs as $var => $val){
				if($n>0)
					$jargs.=", ";
				$jargs.="\"$var\" : \"$val\"";
				$n++;
				}
			$jargs.="}";

			$output.='
			<div class="alertcloud_dashlet" id="'.$id.'">
			
			<div class="infotable_title">Alert Cloud</div>
			'.get_throbber_html().'			
			
			</div><!--ahost_status_summary_dashlet-->

			<script type="text/javascript">
			$(document).ready(function(){

			
				get_'.$id.'_content();
					
				$("#'.$id.'").everyTime(90*1000, "timer-'.$id.'", function(i) {
					get_'.$id.'_content();
				});

				
				function get_'.$id.'_content(){
					$("#'.$id.'").each(function(){
						var optsarr = {
							"func": "get_alertcloud_dashlet_html",
							"args": '.$jargs.'
							}
						var opts=array2json(optsarr);
						get_ajax_data_innerHTML("getxicoreajax",opts,true,this);
						});
					}
					

			});
			
			$(document).ready(function(){
				var outerDash = $("#'.$id.'").parent(); //parent resizable/draggable div 
			
				var Obj = $("#alertCloudObject"); //ID of alert cloud object (needs unique ID) 

				outerDash.resize(function() {  //when outerDash is resized, pass these new values to the object attributes
					newHeight = $(this).height();				
					newWidth = $(this).width(); 
							
					//Obj.height(newHeight).width(newWidth);  //works for normal html block elements, not for object element 
				}); //end resize() binding 
			}); 
			</script>
			';
			
			break;
			
		case DASHLET_MODE_PREVIEW:
			$output="<p><img src='".$imgbase."preview.png'></p>";
			break;
		}
		
	return $output;
	}
	

?>