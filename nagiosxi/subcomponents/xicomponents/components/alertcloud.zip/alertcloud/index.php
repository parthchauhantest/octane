<?php
// ALERT CLOUD
//
// Copyright (c) 2010-2011 Nagios Enterprises, LLC.  All rights reserved.
//  
// $Id: index.php 901 2012-10-26 21:11:02Z mguthrie $

require_once(dirname(__FILE__).'/../../common.inc.php');

include_once(dirname(__FILE__).'/dashlet.inc.php');

// initialization stuff
pre_init();

// start session
init_session();

// grab GET or POST variables 
grab_request_vars();

// check prereqs
check_prereqs();

// check authentication
check_authentication(false);


route_request();

function route_request(){
	global $request;
	
	$mode=grab_request_var("mode");
	switch($mode){
		default:
			display_alertcloud();
			break;
		}
	}
	
function display_alertcloud(){

	$width=grab_request_var("width",350);
	$height=grab_request_var("height",350);
	$bgcolor=grab_request_var("bgcolor","ffff");
	$tcolor=grab_request_var("tcolor","044CC2"); //4B83DF
	$tcolor2=grab_request_var("tcolor2","0E65F6");
	$speed=grab_request_var("speed",50);
	$distr=grab_request_var("distr",1);
	$hicolor=grab_request_var("hicolor",1);
	$trans=grab_request_var("trans","true");
	$data=grab_request_var("data","alerts");

	// start the HTML page
	do_page_start(array("page_title"=>"Alert Cloud"),true);
	
?>
	<h1><?php echo gettext("Alert Cloud"); ?></h1>
	
	
	<div class="reportexportlinks">
	<?php echo get_add_myreport_html("Alert Cloud",$_SERVER["REQUEST_URI"],array());?>
	</div>

	<p>
	<?php echo gettext("The alert cloud provides a dynamic, visual representation of the state of your network.  Host names are color-coded to indicate their state, as well as the state of services associated with them."); ?>
	</p>
	
	<div style="float: right;">
	<p>
	<b><?php echo gettext("Color Legend"); ?>:</b><br>
	<p>
	<span style="color: #1F6FF6;"><b><?php echo gettext("Blue"); ?></b>
	</span> - <?php echo gettext("Host is up and all services are ok"); ?><br>
	<span style="color: #ff0099;"><b><?php echo gettext("Pink"); ?></b>
	</span> - <?php echo gettext("Host is down or unreachable"); ?><br>
	<span style="color: #EF7911;"><b><?php echo gettext("Orange"); ?></b>
	</span> -<?php echo gettext(" Host is up, but one or more services have problems"); ?>
	</p>
	</div>

<?php
	$dargs=array(
		DASHLET_ARGS => array(
			"width" => $width,
			"height" => $height,
			"bgcolor" => $bgcolor,
			"trans" => $trans,
			"tcolor" => $tcolor,
			"tcolor2" => $tcolor2,
			"hicolor" => $hicolor,
			"speed" => $speed,
			"distr" => $distr,
			"data" => $data,
			),
		);
	/*
	echo "ARGS GOING IN=";
	print_r($dargs);
	echo "<BR>";
	*/
	display_dashlet("alertcloud","",$dargs,DASHLET_MODE_OUTBOARD);
?>

	
 
<?php	
	// closes the HTML page
	do_page_end(true);
	}

?>