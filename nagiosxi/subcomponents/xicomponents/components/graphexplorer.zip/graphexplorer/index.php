<?php
// Nagios XI Graph Explorer index
//  
// Copyright (c) 2011 Nagios Enterprises, LLC.  All rights reserved.
//  
// $Id: eventlog.php 359 2010-10-31 17:08:47Z egalstad $
require_once(dirname(__FILE__).'/../../common.inc.php');
include_once(dirname(__FILE__).'/dashlet.inc.php'); 
require_once(dirname(__FILE__).'/visFunctions.inc.php');

// initialization stuff
pre_init();

// start session
init_session();

// grab GET or POST variables 
grab_request_vars();

// check prereqs
check_prereqs();

// check authentication
check_authentication(false);

?>

<!DOCTYPE html>
<html>
	<!-- Produced by Nagios XI.  Copyyright (c) 2008-2009 Nagios Enterprises, LLC (www.nagios.com). All Rights Reserved. -->
	<!-- Powered by the Nagios Synthesis Framework -->

<head>
<title>Nagios XI - Graph Explorer</title>
	<meta name="ROBOTS" content="NOINDEX, NOFOLLOW">
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<?php 
	do_page_head_links();
?>
		<script type="text/javascript" src="<?php echo get_base_url(); ?>/includes/components/highcharts/js/highcharts.js"></script>		
		<script type="text/javascript" src="<?php echo get_base_url(); ?>/includes/components/highcharts/js/themes/gray.js"></script>			
		<script type="text/javascript" src="<?php echo get_base_url(); ?>/includes/components/highcharts/js/modules/exporting.js"></script>		
<script type="text/javascript">		

<?php $rand = rand(); ?>

/////////////////js page variables ////////////////////////
var filtering = false; 
var host;
var service;
var type;
var filter; 
var start;
var end=''; 
var minus = true; 
var rand = '<?php echo $rand; ?>';
var opt='';  
var firstHost = 'localhost';
var firstService = '_HOST_';

////////////////////////////////////////////////////////////
//page load default function 

<?php  //handle default page load  
	
	//handle return requests
	$r = grab_request_var('r',false); 
	if($r) 
	{
		$arg = urldecode($r);

		$pagestart = "
			$(document).ready(function() {
				display_child_popup();
					txtHeader=get_language_string('AddToDashboardSuccessHeader');
					txtMessage=get_language_string('AddToDashboardSuccessMessage');
					content=\"<div id='child_popup_header'><b>\"+txtHeader+\"</b></div><div style='height: 100px;' id='child_popup_data'><p>\"+txtMessage+\"</p></div>\";
					
				set_child_popup_content(content);	
				$('#child_popup_layer').css('height', '120px'); //overrideing built in resizing  
				$('#visContainer{$rand}').load('{$arg}&div=visContainer{$rand}');
				 
				fade_child_popup('green',2000);
				
				"; 
				
				
		if(strpos($r,'timeline')) $pagestart .="toggle_filter('timeline');"; 
		if(strpos($r,'stack'))    $pagestart .="toggle_filter('stack');"; 
		
		$pagestart .="	});"; 
		 
	}
	else //default page load 
	{
		$pagestart = "
		$(document).ready(function() {
			setType('bar'); 
			fetch_bar(); 
			$('#showBar').parent().addClass('selectedTab'); 
			
		});";  
	
	}
	
	print $pagestart;		
?>
	
</script>
<!-- graph explorer JS functions --> 
<script type="text/javascript" src="graphexplorer.js"></script>
<style type="text/css">

h3 { margin: 5px auto; text-align: center; padding:5px; height:16px;}
ul,li { text-indent: 0px; margin: 0px; padding: 0px;  }
ul.childUl {padding-left: 5px; }
.parentLi { color: #4D89F9; list-style:none; padding-left: 0px;  width: 100%; }
.parentLi:hover {cursor: pointer; }
.parentLi:before {content: url('images/expand1.png');  display:inline;}
.childLi  { text-indent: 1px; background-color: #DEDEDE; margin: 1px; padding: 1px 1px 1px 8px; list-style: none; }
.childLi:hover {cursor: pointer; }
.childLi a {width: 100%; }
#leftContainer { clear:left; float:left; width: 20%; height: 800px; overflow: auto; margin: 5px; display:none; min-width:200px;}
#filterDiv {height: 180px; position: relative; }
#leftNav { overflow:auto;  }
#rightContainer { width: 75%; margin: 5px auto; }
.expand:before { content: url('images/collapse.png');   display:inline; }
select { width: 100px; }
#vtkNavLinks {width: 97%; border-bottom: 1px solid #AAA; clear: right; height: 26px; min-width:700px; }
.vtkNav {float:left;
         display: block;
         margin: 1px;
        border: 1px solid #AAA;
        padding: 5px;
        background: #EDEDED;
        border-top-right-radius: 5px;
        border-top-left-radius: 5px;
		height:14px;
 }

.selectedTab { border-bottom: #FFF; background: #FFF;padding-bottom: 6px; z-index: 1000;  }
p.message { text-align: center; }
#startDate, #endDate { background-color: #DEDEDE; } 
.childcontentthrobber {margin:30px auto; height:300px; text-align:center;}
</style>
		
</head>
<body>
<h3><?php echo gettext("Nagios Graph Explorer"); ?></h3>
<div  class="childpage"><!-- page-->
	<div id="header" >

<!--- CHILD HEADER START -->

<div id="child_popup_layer">
	<div id="child_popup_content">
		<div id="child_popup_close">
			<a id="close_child_popup_link" href="#">
				<img src="<?php echo get_base_url(); ?>/images/b_close.png" border="0" alt="Close" title="Close" /> Close
			</a>			
		</div>
		<div id="child_popup_container">
			</div>
	</div><!-- end child_popup_content --> 
</div><!-- end child_popup_layer --> 
</div> <!-- end header -->
<!--- CHILD HEADER END -->		
<div id="childcontentthrobber"><img src='<?php echo get_base_url(); ?>/images/throbber1.gif' /></div>



<div id='tabs'>	
  <ul id='vtkNavLinks'><!-- removed ui-helper-reset ui-helper-clearfix ui-widget-header -->
	<li class='vtkNav'><a class="tab" id='showBar' href='javascript:setType("bar"); javascript:fetch_bar(); javascript:toggle_filter();' title="Shows the top alert producers for the last 24 hours" > <?php echo gettext("Top Alerts Last 24hrs"); ?> </a></li>			
	<li class='vtkNav'><a class="tab" id='showPieHost' href='javascript:setType("pie"); javascript:fetch_pie("hosthealth"); javascript:toggle_filter();' title="Shows host health percentage as a pie graph." > <?php echo gettext("Host Health"); ?> </a></li>
	<li class='vtkNav'><a class="tab" id='showPieService' href='javascript:setType("pie"); javascript:fetch_pie("servicehealth"); javascript:toggle_filter();' title="Shows service health percentage as a pie graph." > <?php echo gettext("Service Health"); ?> </a></li>
	<li class='vtkNav'><a class="tab" id='showTimeline' href='javascript:setType("timeline"); javascript:toggle_filter("timeline");' title="Shows performance data on a scalable timeline." > <?php echo gettext("Scalable Performance Graph"); ?> </a></li>
	<li class='vtkNav'><a class="tab" id='showStack' href='javascript:setType("stack"); javascript:toggle_filter("stack");' title="Shows performance data with overlapping timeperiods for comparison." > <?php echo gettext("Time Stacked Performance Graph"); ?> </a></li> 
  </ul>
</div>


<div id="leftContainer">	

	<div id="filterDiv">
	<form id='graphFilter' method='get' action=''>	
	
	<div id='filterLabel'><?php echo gettext("Filtering Options"); ?></div>
	
	  <div id='dateFilterTimeline'>	
		<label for='timeType'><?php echo gettext("Filter By Timeperiod"); ?></label><br />
		<input type='text' name='start' id='startMinus' value='-24h' size='4'/>
		<label for="startMinus">-24h, -1d, -7d -30d</label><br />
		<strong><?php echo gettext("OR"); ?></strong><br />
		<label for="startDate"><?php echo gettext("Start/End"); ?>: YYYYMMDD</label><br />
		<input type='text' name='start' id='startDate' value='' size='6' /> To: 
		<input type='text' name='end' id='endDate' value='' size='6' /><br />
	  </div>
	  
	  <div id='dateFilterStack'>
		<label for='optSelect'><?php echo gettext("Select Time Frame"); ?></label><br />
		<select name='optSelect' id='optSelect'>
			<option value=''> &nbsp; </option>
			<option value='days'> <?php echo gettext("Last 3 Days"); ?> </option>
			<option value='weeks'> <?php echo gettext("Last 3 Weeks"); ?> </option>
			<option value='months'> <?php echo gettext("Last 3 Months"); ?> </option> 
		</select>
	  </div>
	  
	  <div id='dataFilter'>
		<label for='filterOpts'><?php echo gettext("Filter Data By Type"); ?></label><br />
		<select name="filterOpts" id="filterOpts">
			<option value=''> &nbsp; </option> 
			<!-- add additional options here where applicable -->
		</select><br /><br />
	  </div>
		<!--add option for filter -->
		<button type='button' name='filterButton' id='filterButton'><?php echo gettext("Apply Filter"); ?></button><br />
	</form>
	</div> <!-- end filterDiv -->


<div id="leftNav">
 <!-- ajax load lists for improved load time -->
	<div class="childcontentthrobber">
		<img src="/nagiosxi/images/throbber1.gif" />
	</div>	
</div> <!-- end leftNav -->	
	
</div> <!-- end leftContainer -->

<div id="rightContainer">



	<div class='dashifybutton2'>
		<a class='dashifybutton2' id='dashify2' href='#' title='Add This To A Dashboard'>
		<img src='<?php echo get_base_url(); ?>/images/dashify.png'></a>
	</div>

	<!-- attempting to pass args for dashlet creation --> 
	<form id='dashletArgs' method='post' action='dashifygraph.php'>
		<input type='hidden' id='hiddenUrl' name='url' value='' />
		<input type='hidden' id='dashletName' name='dashletName' value='' />
		<input type='hidden' id='boardName' name='boardName' value='' />
		<input type='hidden' name='divId' value='visContainer<?php echo $rand; ?>' />
		<input type='hidden' name='dashifygraph' value='true' />
	</form>
	
	<div class='viewer' id="visContainer<?php echo $rand; ?>">
		<!-- javascript magic here --> 
			<div class="childcontentthrobber" id='childcontentthrobber'>
				<img src="/nagiosxi/images/throbber1.gif" />
			</div>	
	</div>	
</div>	

	
	</body>
	</html>
	