/**
*	graph explorer include for global scope of XI. Used for status table icons
*/ 


/**
*	
*
*/ 
function graphexplorer_display_graph(host,service) {
	display_child_popup(300); 
	//prepare container for graph
	var content = "<div style='padding-top:10px; clear:both;' id='graphcontainer'><img src='/nagiosxi/images/throbber1.gif' /></div>";
	content += "<div id='scriptcontainer'></div>"; 
	
	$("#child_popup_container").height(300);
	$("#child_popup_container").width(650);
	$("#child_popup_layer").height(320);
	$("#child_popup_layer").width(680);
	$("#child_popup_layer").css('position','fixed');
	center_child_popup();
	
	set_child_popup_content(content); 

	var args ='height=250&witdh=600&type=timeline&host='+host+'&service='+service+'&div=graphcontainer'; 
	var url=base_url+'includes/components/graphexplorer/visApi.php?'+args;
	//alert(url);
	$("#scriptcontainer").load(base_url+'includes/components/graphexplorer/visApi.php?'+args,function() {

	}); 
	
	$('#close_child_popup_link').click(function() {
		set_child_popup_content(''); 
		$("#child_popup_layer").css('position','absolute');
		$("#child_popup_layer").width(300);
		$("#child_popup_container").width(300);
		center_child_popup();
	}); 

}




