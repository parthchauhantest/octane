<?php 
// Graph Explorer Component
//
// Copyright (c) 2010 Nagios Enterprises, LLC.  All rights reserved.
//  
// $Id: graphexplorer.inc.php 155 2010-11-06 02:36:00Z egalstad $

require_once(dirname(__FILE__).'/../componenthelper.inc.php');

include_once(dirname(__FILE__).'/dashlet.inc.php');

// respect the name
$graphexplorer_component_name="graphexplorer";

// run the initialization function
graphexplorer_component_init();

////////////////////////////////////////////////////////////////////////
// COMPONENT INIT FUNCTIONS
////////////////////////////////////////////////////////////////////////

function graphexplorer_component_init(){
	global $graphexplorer_component_name;
	
	$versionok=graphexplorer_component_checkversion();
	
	$desc=gettext("Nagios Graph Explorer is an interactive graphing tool for your Nagios data. Requires Nagios XI 2011R1.3 or later.
			For most reliable graphs and dashlets, use Mozilla Firefox.");
	if(!$versionok)
		$desc="<b>".gettext("Error: This component requires Nagios XI 2011R1 or later.")."</b>";
	
	$args=array(

		// need a name
		COMPONENT_NAME => $graphexplorer_component_name,
		
		// informative information
		COMPONENT_AUTHOR => "Mike Guthrie, Nagios Enterprises, LLC",
		COMPONENT_DESCRIPTION => $desc,
		COMPONENT_TITLE => "Nagios Graph Explorer",
		COMPONENT_DATE => '12/03/2012',
		COMPONENT_VERSION => '1.12',
		// configuration function (optional)
		//COMPONENT_CONFIGFUNCTION => "graphexplorer_component_config_func",
		);
		
	register_component($graphexplorer_component_name,$args);
	
	// add a menu link
	if($versionok)
		register_callback(CALLBACK_MENUS_INITIALIZED,'graphexplorer_component_addmenu');
		
	//add graph icons to status tables and add required javascript to page head	
	if(get_product_release() > 302) {
		register_callback(CALLBACK_CUSTOM_TABLE_ICONS,'graphexplorer_component_table_icon');
		register_callback(CALLBACK_PAGE_HEAD,'graphexplorer_component_js_include'); 
	}
		
		
	// register a dashlet
	$args=array();
	$args[DASHLET_NAME]="graphexplorer";
	$args[DASHLET_TITLE]="Graph Explorer";
	$args[DASHLET_FUNCTION]="graphexplorer_dashlet_func";
	$args[DASHLET_DESCRIPTION]=gettext("Displays a graph explorer dashlet.");
	$args[DASHLET_WIDTH]="500";
	$args[DASHLET_HEIGHT]="450";
	$args[DASHLET_INBOARD_CLASS]="graphexplorer_map_inboard";
	$args[DASHLET_OUTBOARD_CLASS]="graphexplorer_map_outboard";
	$args[DASHLET_CLASS]="graphexplorer_map";
	$args[DASHLET_AUTHOR]="Nagios Enterprises, LLC";
	$args[DASHLET_COPYRIGHT]="Dashlet Copyright &copy; 2011 Nagios Enterprises. All rights reserved.";
	$args[DASHLET_HOMEPAGE]="http://www.nagios.com";
	$args[DASHLET_SHOWASAVAILABLE]=false;
	register_dashlet($args[DASHLET_NAME],$args);
	}
	



///////////////////////////////////////////////////////////////////////////////////////////
// MISC FUNCTIONS
///////////////////////////////////////////////////////////////////////////////////////////

/**
*	adds a clickable graph icon into the status tables
*	@param string $cbtype: the callback name being referenced: CALLBACK_CUSTOM_TABLE_ICONS
*	@param mixed $args: the callback data array, contains all host/service data, also used to pass data back up to it
*/ 
function graphexplorer_component_table_icon($cbtype='',&$args=array()) {

	//array_dump($args); 
	$host = grab_array_var($args,'host_name',false); 
	$service  = grab_array_var($args,'service_description',''); 
	
	//bail if we're missing what we need or there's no graph available
	if(!$host ||!perfdata_chart_exists($host,$service))
		return; ;  
	
	//clean input 
	$host = urlencode(graphexplorer_doClean($host));
	$service = urlencode(graphexplorer_doClean($service)); 
	
	$service=empty($service) ? '_HOST_' : $service;  
	
	//html to be added to the status table icon
	$icondata = "<img class=''graphexplorericon' style='cursor:pointer;' src='".get_base_url()."includes/components/graphexplorer/images/timeline_icon.png' alt='' title='View Performance Graphs' onclick='graphexplorer_display_graph(\"{$host}\",\"{$service}\")' />";

	//send the html data back to the callback data array
	$args['icons'][] = $icondata; 
}

/**
*	adds required graph explorer js files to the main page head of XI
*	@param string $cbtype: This callback function is called during do_page_start() defined in pageparts.inc.php: CALLBACK_PAGE_HEAD
*	@param mixed $array: data array for callback, should be empty. 
*/ 
function graphexplorer_component_js_include($cbtype='',$args=null) {
	echo "<script type='text/javascript' src='".get_base_url()."includes/components/graphexplorer/graphexplorerinclude.js'></script>";
	echo '<script type="text/javascript" src="'.get_base_url().'/includes/components/highcharts/js/highcharts.js"></script>		
		<script type="text/javascript" src="'.get_base_url().'/includes/components/highcharts/js/themes/gray.js"></script>			
		<script type="text/javascript" src="'.get_base_url().'/includes/components/highcharts/js/modules/exporting.js"></script>'; 		
}

/**
*	make sure we will actually work and we're not REALLY old
*/ 
function graphexplorer_component_checkversion(){

	if(!function_exists('get_product_release'))
		return false;
	//requires greater than 2009R1.4B
	if(get_product_release()<200)
		return false;

	return true;
	}

/**
*	add a menu item to the graphs section
*/ 	
function graphexplorer_component_addmenu($arg=null){
	global $graphexplorer_component_name;
	
	$mi=find_menu_item(MENU_HOME,"menu-home-all-host-graphs","id");
	if($mi==null)
		return;
		
	$order=grab_array_var($mi,"order","");
	if($order=="")
		return;
		
	$neworder=$order+0.1;
	
/*	add_menu_item(MENU_HOME,array(
		"type" => "linkspacer",
		"order" => $neworder,
		));
*/
		
	$neworder=$order+0.1;
	
	add_menu_item(MENU_HOME,array(
		"type" => "link",
		"title" => gettext("Graph Explorer"),
		"id" => "menu-home-graphexplorer",
		"order" => $neworder,
		"opts" => array(
			"href" => get_base_url().'includes/components/graphexplorer/',
			//"target" => "_blank",  
			)
		));
	
	}
	
/**
*	cleans hostname and service description to so names can be matched to an rrd file
*	@param string $string: a hostname or service description to be cleaned
*	@return string $string: a processed name that will match an rrd file
*/ 	
function graphexplorer_doClean($string) {
	$string = preg_replace('/[ :\/\\\\]/', "_", $string);
	$string = urlencode($string); 
	//$string = rawurldecode($string);
	return $string;
}