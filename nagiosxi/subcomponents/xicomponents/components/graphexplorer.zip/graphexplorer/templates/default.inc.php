<?php //default.inc.php    default display for visualization tookit  

//create a jquery grab for the default html code

?>

$(document).ready(function() {
	var p = '<p>Nagios Graph Explorer</p>'; 
	$("#visContainer").append(p); 
}); 