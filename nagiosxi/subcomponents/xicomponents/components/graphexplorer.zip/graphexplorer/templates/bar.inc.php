<?php  //bargraph template 

//returns bargraph JSON/Jquery
//Expects associative array -> $args(array()) :
	//string $args['container']
	//string $args['title'] 
	//string $args['yTitle']
	//string $args['categories']
	//string  $args['names']  
	//string $args['data']  - actual field data, json_encoded array  

function fetch_bargraph($args)
{
	$height = grab_array_var($args,'height',500);

	//begin heredoc string 
	$graph=<<<GRAPH
	
		var chart1; // globally available
$(document).ready(function() {

    //reset default colors
    Highcharts.setOptions({
			    colors: ['#058DC7', '#50B432', '#ED561B', '#DDDF00', '#24CBE5', '#64E572', '#FF9655', '#FFF263', '#6AF9C4']
	});

    chart1 = new Highcharts.Chart({
         chart: {
            renderTo: '{$args['container']}',      
            defaultSeriesType: 'bar',
			height: {$height}
         },
         title: {
            text: '{$args['title']}'      
         },
		 legend: {
				enabled: false
		 },
         xAxis: {
         		categories: {$args['categories']},  //use if there are multiple perf outputs like "rta" and "pl"
              //categories: ['Apples', 'Bananas', 'Oranges']
         },
         yAxis: {
            title: {
               text: '{$args['yTitle']}'         
            }
         },
         series: 
		 [{
				name: '{$args['names']}',           
				data: {$args['data']}			 			 
		  }]  //end series           
	});  //close chart 
});
GRAPH;

	return $graph; 
}		
		
?> 		