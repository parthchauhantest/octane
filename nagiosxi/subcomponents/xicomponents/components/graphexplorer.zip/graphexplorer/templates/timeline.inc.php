<?php //timeline.inc.php        template file for highcharts timeline graph     

function fetch_timeline($args)
{
	//pass args into template 
	//return JSON code 	
	//declare JS variables and JSON object
	
	//allow for height to be passed for resizing
	$height = grab_array_var($args,'height',500); 
	
	if(isset($args['datatypes'][1])) //there is more than one set of data, create javascript filtering option  
	{
		$filterString = "$(document).ready(function() { \n 
							\t\t$('#filterOpts').empty(); \n 
							\t\t$('#filterOpts').append('<option value=\'\'> &nbsp; </option>'); \n";   
							
		foreach($args['datatypes'] as $key =>$name)
		{
 
			$filterString .= "\t\t$('#filterOpts').append('<option value=\"{$key}\">{$name}</option>'); \n";  
		}
		$filterString .= "\n  }); //end appending filterOpts select list \n"; 
	}
	else $filterString = ''; 
	
	//begin heredoc string syntax 
	$graph=<<<GRAPH
		
		var COUNT = {$args['count']}; //total rrd entries fetched 
		var UOM = '{$args['UOM']}';
		var START = {$args['start']};   //Date.UTC(2011, 1, 21) ->added below for correct datatype
		var TITLE = '{$args['title']}'; 
		var CONTAINER = '{$args['container']}'; 
		
		{$filterString} 
	
		//reset default colors 
	Highcharts.setOptions({
			    colors: ['#058DC7', '#50B432', '#ED561B', '#DDDF00', '#24CBE5', '#64E572', '#FF9655', '#FFF263', '#6AF9C4']	
	}); 
	
		//data points added below for correct datatype interpretation 				
		//use browser's timezone offset for date 		
		Highcharts.setOptions({
			global: { useUTC: false },
		});
				
			var chart;
			$(document).ready(function() {
				chart = new Highcharts.Chart({
					chart: {
						renderTo: CONTAINER,
						zoomType: 'x',
						spacingRight: 20,
						height: {$height}
					},
				    title: {
				    	//insert host/service name here 
						text: TITLE
					},
				    subtitle: {
						text: document.ontouchstart === undefined ?
							"Click and drag mouse to zoom<br>Click legend to show/hide different data sets" :     
							"Click and drag mouse to zoom<br>Click legend to show/hide different data sets"
					},
					xAxis: {
						
						type: 'datetime',
						maxZoom: {$args['increment']}*1000,  //max zoom is 5 minutes 
						title: {
							text: null
						}
					},
					yAxis: {
						title: {
							text: UOM    //unit of measurement from perf data 
						},
						//min: 0,						//minimum height for yAxis 
						startOnTick: false,
						showFirstLabel: false
					},
					tooltip: {
						shared: true					
					},
					legend: {
						enabled: true
					},
					plotOptions: {
						series: {
						   fillOpacity: 0.5
						},
						area: {
							lineWidth: 1,
							marker: {
								enabled: false,
								states: {
									hover: {
										enabled: true,
										radius: 5
									}
								}
							},
							shadow: false,
							states: {
								hover: {
									lineWidth: 1						
								}
							}
						}
					},
				
					series: [
GRAPH;
//end heredoc syntax 
		//loop for multiple data sets in perfdata 
		$series = array(); 
		for($i=0;$i<count($args['datastrings']);$i++)
		{ 
			$series[] = "
					{
						type: \"area\",
						name: \"{$args['names'][$i]}\",  //service description or host check 						     
						pointInterval: {$args['increment']}*1000, 			 //time scale, 5mn 
						pointStart: {$args['start']},    //start time  
						//performance data here 
						data: [
							
							".implode(', ',$args['datastrings'][$i])." 
						]
					}
					"; 
		} //end loop
		
		$graph.=implode(',',$series); 

		$graph .="
					]  //series data closed 					
				});				
			});"; //end graph 
		
	return $graph; 		
} //end fetch_timeline() 

?> 