<?php 
ob_start(); 

require_once(dirname(__FILE__).'/../../common.inc.php');
include_once(dirname(__FILE__).'/dashlet.inc.php'); 
require_once(dirname(__FILE__).'/visFunctions.inc.php');

// initialization stuff
pre_init();

// start session
init_session();

// grab GET or POST variables 
grab_request_vars();

// check prereqs
check_prereqs();

// check authentication
check_authentication(false);

//process variables and submit to dashboard 
$url = grab_request_var('url'); 
$divId=grab_request_var('divId'); 
$title=grab_request_var('dashletName'); 
$board=grab_request_var('boardName');  

$newurl=get_base_url().'/includes/components/graphexplorer/'.$url;

$dargs=array('url'=>$newurl, 'divId'=>$divId, ); 
		
//$args=serialize(base64_encode($dargs)); 
//add_dashlet_to_dashboard($userid=0,$boardid,$name,$title,$opts,$args)
add_dashlet_to_dashboard(0,$board,'graphexplorer',$title,null,$dargs);

$returnto = urlencode($url); 
$newurl=get_base_url().'/includes/components/graphexplorer/?r='.$returnto;  
header("Location: $newurl"); 
ob_end_flush(); 
?>