<?php
// GRAPH EXPLORER DASHLET
//
// Copyright (c) 2010 Nagios Enterprises, LLC.  All rights reserved.
//  
// $Id: dashlet.inc.php 3 2010-04-02 21:41:26Z mguthrie $

include_once(dirname(__FILE__).'/../../dashlets/dashlethelper.inc.php');


function graphexplorer_dashlet_func($mode=DASHLET_MODE_PREVIEW,$id="",$args=null){

	$imgbase=get_base_url()."includes/components/graphexplorer/images/";
	
	//$metric=grab_array_var($args,"metric","");
	$url = grab_array_var($args,'url',''); 
	$divId = grab_array_var($args,'divId','');  
	$comp_url=get_base_url().'/includes/components/graphexplorer/';
	$hc_url = get_base_url().'/includes/components/highcharts/';
	switch($mode){
	
		case DASHLET_MODE_GETCONFIGHTML:
			break;
			
		case DASHLET_MODE_OUTBOARD:
		case DASHLET_MODE_INBOARD:

			$output="";			
			$output.='
			<script type="text/javascript" src="'.$hc_url.'js/highcharts.js"></script>		
			<script type="text/javascript" src="'.$hc_url.'js/themes/gray.js"></script>			
			<script type="text/javascript" src="'.$hc_url.'js/modules/exporting.js"></script> 
					
			<div class="graphexplorer_dashlet" id="'.$divId.'">			
			</div> <!-- end  dashlet -->
			<script type="text/javascript">
			$(document).ready(function(){			
				get_'.$divId.'_content();
				
				var hc = $("#'.$divId.'").find(".highcharts-container");
				hc.unbind("resize");
				hc.children().unbind("resize"); 
			
			});
			
			function get_'.$divId.'_content()
			{
				var height = $("#'.$divId.'").parent().height(); 
				$("#'.$divId.'").load("'.$url.'&height="+height);
				$("#'.$divId.'").click(function(event) {	
					if(event.target != this)
					{
						event.stopPropagation(); //stops problems with the zoomable graph 
					}
				}); 

			}
			</script>
			';
			
			break;
			
		case DASHLET_MODE_PREVIEW:
			$output="<p><img src='".$imgbase."timeline.png'></p>";
			break;
		}
		
	return $output;
	}
	

?>