<?php //visApi.php 

ini_set('display_errors','off'); 
@require_once(dirname(__FILE__).'/../../common.inc.php');
@include_once(dirname(__FILE__).'/dashlet.inc.php'); 

// initialization stuff
pre_init();

// start session
init_session();

// grab GET or POST variables 
grab_request_vars();

// check prereqs
check_prereqs();

// check authentication
check_authentication(false);

//security fix
foreach($request as $key =>$val){
	if(is_array($val)) continue;
	$request[$key] = escapeshellcmd($val);
}


//pie graphs API
/*
* 	type=pie
*	 
*/

/*timeline graph
*	type=timeline
*	host=<hostname>
*	[service=<servicename>]
*
*/



$vtkArgs = array();  //necessary args for different functions of VTK 
include_once(dirname(__FILE__).'/dashlet.inc.php');
require_once(dirname(__FILE__).'/visFunctions.inc.php'); 

//fetch Jquery code based on request
print "<script type='text/javascript'>";
get_jquery();  
print "</script>"; 

?>