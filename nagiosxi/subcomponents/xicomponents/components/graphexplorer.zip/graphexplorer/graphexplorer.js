
var throbber = '<div class="childcontentthrobber"><img src="/nagiosxi/images/throbber1.gif" /></div>'; 

//need to load lists after initial page load to reduce page load time 
function load_list() {
	$('#leftNav').load('lists.php',function() {
		$('.childUl').hide();  //hide services 
		$('.parentLi').each(function(index) {
			$(this).click(function(event) {
				if(event.target == this)  //prevent event bubbling 
				{
					if($(this).children('.childUl').css('display')=='none')               
						$(this).children('.childUl').show();               
					else
						$(this).children('.childUl').hide(); 
					
					$(this).toggleClass('expand');  
				}
			});
		});
	});	
}

//////////////////graph fetching functions//////////////////
function setType(arg)
{
	type=arg; 
	$("#visContainer"+rand).html(throbber);
	//show_child_content_throbber();
	if(type=='timeline' || type=='stack') 
	{ 
		//$("#visContainer"+rand).empty();
		//$("#visContainer"+rand).append('<p class="message">Please select a graph to view from the list</p>'); 
		$('#leftNav').show(); 
		fetch_timeline(firstHost,firstService); 

	}
	//alert('Type is: '+type); 
}

function fetch_bar()
{
	var url = 'visApi.php?type='+type+'&div=visContainer'+rand+'&opt=topalerts';
	//alert(url); 
	$('#hiddenUrl').val(url);		
	$("#visContainer"+rand).load(url); 
}

function fetch_pie(arg)
{
	var url = 'visApi.php?type='+type+'&div=visContainer'+rand+'&opt='+arg;
	//alert(url); 	
	$('#hiddenUrl').val(url);
	//alert($('#hiddenUrl').val()); 
	$("#visContainer"+rand).load(url);
}

///////////////////////////// Timeline ////////////////////////////////////////

function fetch_timeline(inhost, inservice, f)
{
	if(f) filtering = 'true';  
	else filtering = false; //clear data type upon fresh graph loading 
	if(type=='')
	{
		alert('No Graph Type Specified');
		return false; 
	}
	host = inhost; 
	service = inservice; 
	$("#filterOpts").empty(); //clear filter options
	$("#filterOpts").append("<option value=''> &nbsp; </option>");
	if(type=='timeline')
	{
		if(filtering==false) { var url ='visApi.php?type='+type+'&host='+host+'&service='+service+'&div=visContainer'+rand;   }
		else { var url = 'visApi.php?type='+type+'&host='+host+'&service='+service+'&start='+start+'&end='+end+'&div=visContainer'+rand+'&filter='+filter; }	
	}
	if(type=='stack')
	{
		if(filtering==false) { var url ='visApi.php?type='+type+'&host='+host+'&service='+service+'&div=visContainer'+rand+'&opt='+opt;   }
		else { var url = 'visApi.php?type='+type+'&host='+host+'&service='+service+'&start='+start+'&end='+end+'&div=visContainer'+rand+'&opt='+opt+'&filter='+filter; }	
	}
	if(!url) return false; 
	//alert(url); 
	$('#hiddenUrl').val(url);
    $("#visContainer"+rand).load(url);				
	return false; 
}
 
///////////Timeline Lists //////////////////// 
$(document).ready(function() {
  //$('.childUl').hide();  //hide services 
  //bind list toggle to items 
	load_list(); 
   
   /////////////Filter Fields and Functions (Timeline)///////////////////////
   //control input for date fields, disable inactive timeperiod
   $('#startDate').click(function() {
		minus = false; 
		$('#startMinus').css('background-color', '#DEDEDE'); 
		$('#endDate').css('background-color', '#FFF');
		$('#startDate').css('background-color', '#FFF');  
   }); 
   $('#startMinus').click(function() {
		minus = true; 
		$('#startMinus').css('background-color', '#FFF'); 
		$('#startDate').css('background-color', '#DEDEDE');   
		$('#endDate').css('background-color', '#DEDEDE'); 
   }); 
   
   //bind filter button to events
   $('#filterButton').click(function() {
		//setType("timeline");
		filtering = true; 
		//retrieve values from form fields and set global vars to match
		//validate form fields		
		if($('#startMinus').val() !='' && minus == true)
		{
			start = $('#startMinus').val();
			end=''; 
		}
		else
		{
			start = $('#startDate').val();
			if(start < 20000101 || isNaN(start) || parseInt(start)!=start)   
			{
				alert('Invalid date format'); 
				return; 
			}
			end = $('#endDate').val();
		}		
		filter = $('#filterOpts').val();
		fetch_timeline(host,service,'true');  
   }); 
    
   ///////////////////Dashify Hacks//////////////////////////////
   $('#dashify2').click(function() {
		
		show_child_content_throbber();
   		var boardselect=get_ajax_data("getdashboardselectmenuhtml","");;
		//alert(boardselect); 
		var theurl="";
		var txtHeader=get_language_string("AddToDashboardHeader");
		var txtMessage=get_language_string("AddToDashboardMessage");
		var t1=get_language_string("AddToDashboardTitleBoxTitle");
		var t2=get_language_string("AddToDashboardDashboardSelectTitle");
		var txtSubmitButton=get_language_string("AddItButton");
		
		var content="<div id='popup_header'><b>"+txtHeader+"</b></div><div id='popup_data'><p>"+txtMessage+"</p></div>";
		content+="<label for='addToDashboardTitleBox'>"+t1+"</label><br class='nobr' />";
		content+="<input type='text' size='30' name='title' id='addtoDashboardTitleBox' value='My Graph' class='textfield' />";
		content+="<br class='nobr' /><label for='addToDashboardBoardSelect'>"+t2+"</label><br class='nobr' />";
		content+="<select id='addToDashboardBoardSelect'>"+boardselect+"</select><br class='nobr' />";
		content+="<div id='addToDashboardFormButtons'><button id='AddToDashButton' onclick='add_it()'>"+txtSubmitButton+"</button></div>";
		//alert(content); 
		hide_child_content_throbber();
		set_child_popup_content(content);
		display_child_popup("250px");
   
   }); 
   
   ///////////////////end dashify///////////////   
   $('#dashify2').hover(function() {
	  $("#visContainer"+rand).css('opacity', '0.5'); 
	   }, function() {
	      $("#visContainer"+rand).css('opacity', '1.0');
    }); 
	
	/////////////////stack filter select list//////////////////
	$('#optSelect').change(function() {
		//alert($('#optSelect').val()); 
		opt = $('#optSelect').val(); 
	}); 
	
	//////////////tab click bind ////////////////
	$('.tab').click(function() {
		$('.tab').parent().each(function() {
			$(this).removeClass('selectedTab'); 
		}); 
		$(this).parent().toggleClass('selectedTab');
	}); 
	
	
	
	
	
}); ////////////////////end $(document).ready() //////////////////////////

function add_it()
{
	//alert('clicked'); 
	hide_throbber(); 
	hide_child_content_throbber();

	$('#boardName').val( $('#addToDashboardBoardSelect').val() ); //assign select value to hidden input 
	$('#dashletName').val( $('#addtoDashboardTitleBox').val() ); //assign dashboard title to hidden input
	if($('#hiddenUrl').val != '' && $('#boardName').val() != '') 
	{
		$('#dashletArgs').submit(); 
	}
	else { alert($('#boardName').val() ); } 
}
		
function toggle_filter(arg) 
{	
	var leftbox=$('#leftContainer'); 
	var rt = $('#rightContainer'); 
	var dft = $('#dateFilterTimeline');
	var dfs = $('#dateFilterStack');
	var dataf = $('#dataFilter');
	if(arg=='timeline') 
	{ 
		rt.css('float','left'); 
		leftbox.show(); 
		dft.show(); 
		dataf.show();
		dfs.hide(); 
	}
	else if(arg=='stack')  
	{
		rt.css('float','left');
		leftbox.show();
		dft.hide(); 
		dataf.show();
		dfs.show(); 
		
	}
	else 
	{ 		
		leftbox.hide(); 
		rt.css('float','none');
	}
}	
