<?php  //visFunctions.inc.php 

/*function get_jquery()
*
*	main graph router function of the graph explorer
*	@return null (prints output to screen) 
*/
function get_jquery()
{
	global $vtkArgs; 
	//if there are nav requests, process and retrieve a graph
	if(process_globs())
	{	
		$graph = fetch_graph();
		print $graph; 
	}		
	//else display default 
	else include(dirname(__FILE__).'/templates/default.inc.php'); 
}

/*function process_globs() 
*	
*	checks and validates request args for valid graph retrieval
*	@global array $vtkArgs - modifies global array and sets default values 
*/
function process_globs()
{
	//grab hostname, service description, etc 
	global $vtkArgs; 
	if(isset($_REQUEST))
	{	
		if(!isset($_REQUEST['type'])) return;  //need a graph type  
		//establish necessary vars 
		$vtkArgs['host'] = grab_request_var('host',NULL); 
		$vtkArgs['service'] = grab_request_var('service','_HOST_'); 		 
		$vtkArgs['start'] = grab_request_var('start', "-24h"); 
		$vtkArgs['end'] = grab_request_var('end',''); 
		$vtkArgs['container'] = grab_request_var('div', 'visContainer'); 
		$vtkArgs['type'] = grab_request_var('type'); 
		$vtkArgs['filter'] = grab_request_var('filter',''); 
		$vtkArgs['height'] = grab_request_var('height',500); 
		return true; 
	}
	else return;  
}


/*	function fetch_graph()
*
*	request $vars are valid so far, fetch appropriate graph
*	@return string JSON object or jquery string	
*/ 
function fetch_graph()
{
	global $vtkArgs; 
	//determine graph type 
	$graph = ''; 
	switch($vtkArgs['type'])
	{
		////////////////////////////////////TIMELINE/////////////////////////////////////
		case 'timeline':
			//timeline requirements  
			if(!isset($vtkArgs['host'])) die("Host name is required for timeline graph");
			if(!isset($vtkArgs['service'])) $vtkArgs['service'] =  '_HOST_';
			require(dirname(__FILE__).'/fetch_rrd.php'); 
			require(dirname(__FILE__).'/templates/timeline.inc.php');
			
			//gather necessary data for timeline 			
			//make a get call to the fetch_rrd.php script to grab the data and do JSON encode 
			$xmlDoc = '/usr/local/nagios/share/perfdata/'.$vtkArgs['host'].'/'.$vtkArgs['service'].'.xml';		
			$xmlDat = simplexml_load_file($xmlDoc); 
			
			//retrieve rrd data
			$rrd = fetch_rrd($vtkArgs);
			//add ability to filter performance data sets
			//print_r($rrd); 
			if(isset($vtkArgs['filter'])&& $vtkArgs['filter'] !='') 
			{
				$filter = $vtkArgs['filter'];
				$vtkArgs['datastrings'][] = $rrd['sets'][$filter] ; 
			}
			else  
				$vtkArgs['datastrings'] = $rrd['sets']; 
				
			$vtkArgs['start'] = $rrd['start'].'000'; //starting timestamp for actual data grabbed, ms 			
			$vtkArgs['count'] = $rrd['count']; //data points retrieved 
			$vtkArgs['increment'] = $rrd['increment']; 
			//retrieve UOM as xml objects -> print in double quotes to display text value correctly 
			$vtkArgs['units'] = $xmlDat->xpath('/NAGIOS/DATASOURCE/UNIT');  //UOM from perfdata 
			$vtkArgs['names'] = $xmlDat->xpath('/NAGIOS/DATASOURCE/NAME');	//perfdata names (rta and pl)
			$vtkArgs['datatypes'] = $vtkArgs['names']; 
			//create label for unit of measurement
			if(isset($filter) && $filter != '')
			{
				$vtkArgs['UOM'] = $vtkArgs['units'][$filter];
				$vtkArgs['names'][0] = $vtkArgs['names'][$filter]; 
			}
			else //no filter defined
			{
				$vtkArgs['UOM']  = ''; 
				//concatenate UOM string for multiple data sets 
				for($i=0; $i<count($vtkArgs['units']); $i++) $vtkArgs['UOM'] .= $vtkArgs['units'][$i].' ';
			}
			//misc vars for timeline
			if(!isset($vtkArgs['container'])) $vtkArgs['container'] = 'visContainer'; 
			$vtkArgs['title'] = $vtkArgs['host'].' : '.$vtkArgs['service'];

			//graph graph template 
			$graph = fetch_timeline($vtkArgs); 
		break; //end timeline data 
		
		////////////////////////////////////BAR/////////////////////////////////////
		case 'bar':
		//template file
		//Expects $args(array()) :	
			//string 'title' 
			//string 'yTitle'
			//array  'names'  
			//array	 'categories'
			//array 'data'  - actual field data 
		require(dirname(__FILE__).'/templates/bar.inc.php');
		
		$subType = grab_request_var('opt'); 
		switch($subType)
		{	
			///////////////////////////////TOP ALERT PRODUCERS//////////////
			case 'topalerts':
				require_once(dirname(__FILE__).'/../../utils-reports.inc.php');
				//create args for topalert data 
				//$inargs=array(); 
				//$inargs['starttime'] = '1293840000';
				//$inargs['stoptime'] = grab_request_var('stop', ''); 
				// determine start/end times based on period
				$reportperiod = grab_request_var("reportperiod","last24hours");
				get_times_from_report_timeperiod($reportperiod,$starttime,$endtime,$startdate,$enddate);
				
				$args=array(
					"starttime" => $starttime,
					"endtime" => $endtime,
					"records" => "10:0",
					);
				$xml = get_xml_topalertproducers($args); 
				//print "//".print_r($xml); 
				$categories = array(); 
				$alerts = array();
				$names = array(); 
				
				$c = 0; 
				foreach($xml->producer as $node)
				{
					$categories[]="$node->host_name<br>$node->service_description"; 
					$alerts[]=intval("{$node->total_alerts}"); 
					$c++;
					if($c>8) break; 					
				}
				echo "//Categories count is: ".count($categories); 
				echo "//Alerts count is: ".count($alerts); 
				
				//do other stuff 
				$args['title'] = 'Top Alert Producers Last 24 Hours';
				$args['yTitle'] = '';  // '$datestart.' - '.$datestop; 
				$args['names'] = 'Alerts'; // 
				$args['categories'] = json_encode($categories); //hosts names/Service descriptions
				$args['data'] = json_encode($alerts); //alert counts 
				$args['container'] = $vtkArgs['container'];  //render to div  
				$args['height'] = $vtkArgs['height'];
				$graph = fetch_bargraph($args); 
			break; 
			//get the bar data

				
			default:	//do nothing for now 
				//fetch the template	
				echo "alert('The bar is not ready yet');"; 
				//$graph .=fetch_bargraph(vtkArgs); 
			break; 
		}
		break; 
		
		////////////////////////////////////PIE/////////////////////////////////////
		case 'pie':
		//get the pie data 
		$pieType = grab_request_var('opt');
		$args = array();
		$args['pieType'] = $pieType; 
        $args['height'] = $vtkArgs['height'];
		$args['url'] = get_base_url().'/includes/components/xicore/status.php?&show='; 
		//http://192.168.5.59/nagiosxi/includes/components/xicore/status.php?&show=hosts&hoststatustypes=2&servicestatustypes=0
		switch($pieType)
		{
			case 'hosthealth':
				$backendargs = array('brevity' => 3);
				$hostXML = get_xml_host_status($backendargs); 
				$total = intval($hostXML->recordcount);				 
				$hosts = $hostXML->hoststatus; 
				$up = 0; 
				$down = 0; 
				$unreachable = 0;
				foreach($hosts as $host) 
				{
					switch($host->current_state)
					{
						case 0: $up++; break;
						case 1: $down++; break;
						case 2: $unreachable; break;
						default: break; 
					}
				}
				print "// Total records: $total  UP: $up, DOWN $down, UR $unreachable \n";
				$up = number_format( ($up*100)/ $total, 2);
				$down = number_format( ($down*100)/ $total, 2);
				$unreachable = number_format( ($unreachable*100)/ $total, 2); 				
				$args['datastring'] = "['UP', $up], ['DOWN', $down], ['UNREACHABLE', $unreachable]"; 
				$args['title'] = 'Host Health';
				$args['subtitle'] = 'Host Health Percentage';
				$args['url'] .= 'hosts&hoststatustypes=';  
			break;
			
			case 'servicehealth':
				$backendargs = array('brevity' => 3); 
				$serviceXML = get_xml_service_status($backendargs);
				$total = intval($serviceXML->recordcount);				 
				$services = $serviceXML->servicestatus; 
				$ok = 0; 
				$warning=0; 
				$critical = 0;
				$unknown = 0;
				foreach($services as $service) 
				{
					switch($service->current_state)
					{
						case 0: $ok++; break;
						case 1: $warning++; break;
						case 2: $critical++; break;
						case 3: $unknown++; break;
						default: break; 
					}
				}
				print "// Total records: $total  OK: $ok, WARNING $warning, CRIT $critical  UK $unknown \n";
				$ok = number_format( ($ok*100)/ $total, 2);
				$warning = number_format( ($warning*100)/ $total, 2);
				$critical = number_format( ($critical*100)/ $total, 2); 
                $unknown = number_format( ($unknown*100)/ $total, 2); 
				$args['datastring'] = "['OK', $ok], ['WARNING', $warning], ['CRITICAL', $critical], ['UNKNOWN', $unknown]"; 
				$args['title'] = 'Service Health';
				$args['subtitle'] = 'Service Health Percentage';
				$args['url'] .='services&hoststatustypes=0&servicestatustypes=';
			break;
			
			default: //do nothing 
			break; 
		
		}//end $pieType switch() 

		
		$args['container'] = $vtkArgs['container']; 
		require_once(dirname(__FILE__).'/templates/pie.inc.php');
		$graph = fetch_piegraph($args); 
		break; ///////////////////////////end pie////////////////////////
		
		////////////////////////////////STACK/////////////////////////////
		//creates a stacked performance graph overlaying periods of time 
		case 'stack':

			//timeline requirements  
			if(!isset($vtkArgs['host'])) die("Host name is required for timeline graph");
			if(!isset($vtkArgs['service'])) $vtkArgs['service'] =  '_HOST_';
			require(dirname(__FILE__).'/fetch_rrd.php'); 
			require(dirname(__FILE__).'/templates/timeline.inc.php');
			
			$host = $vtkArgs['host'];
			$service = $vtkArgs['service']; 
			//determine date units (days, weeks, or months) 
			$opt = grab_request_var('opt',''); 
			
			switch($opt) //calculate starts and stops for last 3 timeperiods
			{
				case 'weeks':
				$starts =array('-7d','-14d','-21d'); 
				$stops = array('', '-7d', '-14d'); 	
				$res = 1800;  
				break; 
				
				case 'months':
				$starts =array('-30d','-60d','-90d'); 
				$stops = array('', '-30d', '-60d'); 
				$res = 900; 				
				break; 
				
				case 'days':
				default:
				//defaults to last 3 days
				$starts =array('-24h','-48h','-72h'); 
				$stops = array('', '-24h', '-48h'); 
				$res = 300; 
				$opt = 'days'; 
				break; 
			} 
			
			//array to be passed to template 
			$args=array(); 
			
			//rrd fetch the 3 sets of data 
			$rrd1 = fetch_rrd(array('host'=>$host,'service'=>$service,'start'=>$starts[0],'end'=>$stops[0],'resolution'=>$res));			
			$rrd2 = fetch_rrd(array('host'=>$host,'service'=>$service,'start'=>$starts[1],'end'=>$stops[1],'resolution'=>$res));
			$rrd3 = fetch_rrd(array('host'=>$host,'service'=>$service,'start'=>$starts[2],'end'=>$stops[2],'resolution'=>$res));
			
			//get UOM for graph from xml file 
			$xmlDoc = '/usr/local/nagios/share/perfdata/'.$host.'/'.$service.'.xml';		
			$xmlDat = simplexml_load_file($xmlDoc); 
			//retrieve UOM as xml objects -> print in double quotes to display text value correctly 
			$vtkArgs['units'] = $xmlDat->xpath('/NAGIOS/DATASOURCE/UNIT');  //UOM from perfdata 
			$args['datatypes'] = $xmlDat->xpath('/NAGIOS/DATASOURCE/NAME');	//perfdata names (rta and pl)
						
			//process and format data set for graph
			//automatically filter this graph for cleaner data 
			if(isset($vtkArgs['filter']) && $vtkArgs['filter'] !='') $filter = $vtkArgs['filter'];
			else  $filter = 0; 
			$args['datastrings'] = array(); 
			$args['datastrings'][] = $rrd1['sets'][$filter]; 
			$args['datastrings'][] = $rrd2['sets'][$filter];
			$args['datastrings'][] = $rrd3['sets'][$filter];
			
			$args['start'] = $rrd1['start'].'000'; //starting timestamp for actual data grabbed, ms 			
			$args['count'] = $rrd1['count']; //data points retrieved 
			$args['increment'] = $rrd1['increment']; 
						
			//create label for unit of measurement
			$args['UOM'] = $vtkArgs['units'][$filter];
			$names = array("{$starts[0]} -> Now","{$starts[1]} -> {$stops[1]}","{$starts[2]} -> {$stops[2]}"); 
			$args['names'] = $names;  

			//misc vars for timeline
			if(!isset($vtkArgs['container']) || $vtkArgs['container']=='') $args['container'] = 'visContainer'; 
			else $args['container'] = $vtkArgs['container']; 
			$args['title'] = $host.' : '.$service.' - Last 3 '.$opt; 
			$args['height'] = $vtkArgs['height'];

			//pass array to graph for display 
			$graph=fetch_timeline($args); 
		
		break; ////////////////////////////end stack///////////////////////
		
		default: 
			//do stuff 
			include(dirname(__FILE__).'/templates/default.inc.php');		
		break; 
		
		
	}//end switch 
	
	return $graph; //return JSON or Jquery string 
	
}//end fetch_graph() 





/*  function show_perfdata_lists() 
*
*	prints a heirachy list of all hosts/services with available performanace data (filtered per user) 
*	@return null  prints output directly to browser 
*/
function show_perfdata_lists()
{
	global $cfg; 
		
	$perfdata = $cfg['component_info']['pnp']['perfdata_dir'];
	$badchars = array(' ', '/', ':',';'); //bad meta characters for rrd files 
	$firstHost = true;	
	$dirs = scandir($perfdata); 
	
	//get perfdata directory array 
	foreach($dirs as $dir)
		if($dir[0]!='.') $hosts[] = $dir; 
		
	//get combined list from backend 
	$args = array(
		'cmd' => 'getobjects',
		'brevity' => 3, 
		'orderby' =>'name1:a,name2:a',
		'objecttype_id' => 'in:1,2', //get anything that's a host or service
		); 
		
	$objsXML = get_xml_objects($args);
	
	//begin the nested list 
	print '<ul>';

	$lasthost = ''; 
	foreach($objsXML as $obj) {
	
		$type = intval($obj->objecttype_id); 
		$content = ''; 
		$servicecontent = '';
		$host = "$obj->name1";
		$service = "$obj->name2";
		$hostdir = doClean($host); 
		
		//Do we have a new host listing?
		if($host != $lasthost) {//add a host folder
			
			if(!$firstHost) //close off the previous list if this isn't the first listing 
				$content.="\n</ul></li>\n";
				
			//add the host directory 	
			$content .= "<li class='parentLi'>{$host}\n <ul class='childUl'>\n"; 		
		}	
			
		//host object type 
		if($type==OBJECTTYPE_HOST) {
			//capture actual hostname 
			$host_rrd = $perfdata.'/'.$hostdir.'/_HOST_.rrd'; 
			if(file_exists($host_rrd)) {
				$content.="<a onclick='fetch_timeline(\"{$hostdir}\", \"_HOST_\")'><li class='childLi'>_HOST_</li></a>\n";
			}//end if _HOST_ file 	
		} //end host IF 
	
		//service object 
		if($type==OBJECTTYPE_SERVICE) {
			$full_hostdir = $perfdata.'/'.$hostdir.'/'; //full pathname 
			$servicerrd = doClean($service); //service rrdfile
			if(file_exists($full_hostdir.$servicerrd.'.rrd') ) {//got an rrd!
				$content .="<a onclick='fetch_timeline(\"{$hostdir}\", \"{$servicerrd}\")'><li class='childLi'>".htmlentities($service)."</li></a>\n";				
			}//end if rrd is found
							 
		} //end service IF 	
		
		//special case for the first listing
		if($firstHost && $host!='') {
			$firstService = $service=='' ? '_HOST_' : $servicerrd; 
			print "<script type='text/javascript'>
				firstHost='{$host}';
				firstService='{$firstService}';
			</script>\n";
			$firstHost = false;
		}	
		
		$lasthost=$host; 
		
		print $content; 
				
	}//end HOSTDIR foreach 

	//print page content 
	print "</ul>\n"; 	

}//end show_perfdata_lists() 


function debug_logger($text)
{
	$f = fopen('/tmp/debugger.log','ab'); 
	fwrite($f,$text); 
	fclose($f); 	
}

function doClean($string) {
	$string = preg_replace('/[ :\/\\\\]/', "_", $string);
	$string = rawurldecode($string);
	return $string;
}

?>