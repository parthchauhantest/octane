<?php
// USER OPTIONS FOR HOME PAGE
//
// Copyright (c) 2008-2009 Nagios Enterprises, LLC.  All rights reserved.
//  
// $Id: useropts.php 903 2012-10-30 21:15:05Z mguthrie $

require_once(dirname(__FILE__).'/../../common.inc.php');

// initialization stuff
pre_init();

// start session
init_session();

// grab GET or POST variables 
grab_request_vars();

// check prereqs
check_prereqs();

// check authentication
check_authentication(false);


route_request();

function route_request(){
	global $request;
	
	if(isset($request['update']))
		do_update_options();
	else
		show_options();
	}

function show_options($error=false,$msg=""){
	global $lstr;
	
	// get settings specified by admin
	$settings_raw=get_option("homepagemod_component_options");
	if(empty($settings_raw))
	// get our settings
	$settings_raw=get_option("homepagemod_component_options");
	if(empty($settings_raw)){
		$settings=array(
			"enabled" => 1,
			"destination_type" => "default",
			"destination_url" => "",
			"home_page_title" => "Nagios XI",
			"allow_user_override" => 1,
			);
		}
	else
		$settings=unserialize($settings_raw);	
		
	$home_page_title=grab_array_var($settings,"home_page_title","Nagios XI");
	$allow_override = grab_array_var($settings,'allow_user_override'); 

	// default settings
	$settings_default=array(
		"destination_type" => "default",
		"destination_url" => "",
		"home_page_title" => $home_page_title,
		);

	// saved settings
	$settings_raw=get_user_meta(0,"homepagemod_component_options");
	if($settings_raw!=""){
		$settings_default=unserialize($settings_raw);
		}

	// settings passed to us
	$settings=grab_request_var("settings",$settings_default);
				
	$title="Home Page Options";
	
	//let the user know if they can't override the home page
	if($allow_override!=1) {
		$error=true;
		$msg.=gettext("Home page modifications are currently disabled.");
	}
	


	// start the HTML page
	do_page_start(array("page_title"=>$title),true);
	
?>
	<h1><?php echo $title;?></h1>

<?php
	display_message($error,false,$msg);
?>

	<p>
	<?php echo gettext("You can use the settings on this page to affect/override the default home page you see when you first login."); ?>
	</p>
	
	<form id="manageOptionsForm" method="post" action="<?php echo htmlentities($_SERVER['PHP_SELF']);?>">

	<input type="hidden" name="options" value="1">
	<?php echo get_nagios_session_protector();?>
	<input type="hidden" name="update" value="1">

<?php
	echo '
	<div class="sectionTitle">'.gettext('Home Page Modification Settings').'</div>
	
	<table>

	<tr>
	<td valign="top">
	<label>'.gettext('Default Home Page Title').'</label><br>
	</td>
	<td>
	<input type="text" name="settings[home_page_title]" value="'.htmlentities($settings["home_page_title"]).'" size="30"><br>
	'.gettext('Used to override the default home page title.  Leave blank to use the default.').'<br><br>
	</td>
	</tr>
	
	<tr>
	<td valign="top">
	<label>'.gettext('Home Page Destination').'</label><br>
	</td>
	<td>
	<select name="settings[destination_type]">
	<option value="default" '.is_selected($settings["destination_type"],"default").'>'.gettext('Default Location').'</option>
	<option value="homedashboard" '.is_selected($settings["destination_type"],"homedashboard").'>'.gettext('Home Dashboard').'</option>	
	<option value="custom" '.is_selected($settings["destination_type"],"custom").'>'.gettext('Custom URL').'</option>
	</select><br>
	'.gettext('Where should the home page be directed?').'<br><br>
	</td>
	</tr>

	<tr>
	<td valign="top">
	<label>'.gettext('Custom URL').'</label><br>
	</td>
	<td>
	<input type="text" name="settings[destination_url]" value="'.htmlentities($settings["destination_url"]).'" size="50"><br>
	'.gettext('Specifies a custom URL to be shown as the default home page.').'<br><br>
	</td>
	</tr>

	</table>
	';
?>
	<div id="formButtons">
	<input type="submit" class="submitbutton" name="updateButton" value="<?php echo $lstr['UpdateSettingsButton'];?>" id="updateButton">
	<input type="submit" class="submitbutton" name="cancelButton" value="<?php echo $lstr['CancelButton'];?>" id="cancelButton">
	</div>

	</form>
<?php		
	
	// closes the HTML page
	do_page_end(true);
	}
	
	
function do_update_options(){
	global $request;
	global $lstr;
	
	// user pressed the cancel button
	if(isset($request["cancelButton"]))
		header("Location: main.php");
		
	// check session
	check_nagios_session_protector();
	
	$errmsg=array();
	$errors=0;

	// get values
	// settings passed to us
	$settings=grab_request_var("settings",array());
	

	// make sure we have requirements
	if(in_demo_mode()==true)
		$errmsg[$errors++]=$lstr['DemoModeChangeError'];
	if($settings["destination_type"]=="custom" && have_value($settings["destination_url"])==false)
		$errmsg[$errors++]=gettext("Destination URL must be specified.");

		
	// handle errors
	if($errors>0)
		show_options(true,$errmsg);
		
	// update options
	set_user_meta(0,"homepagemod_component_options",serialize($settings),false);
	set_user_meta(0,"homepagemod_component_options_configured",1,false);
			
	// success!
	show_options(false,$lstr['GlobalConfigUpdatedText']);
	}
