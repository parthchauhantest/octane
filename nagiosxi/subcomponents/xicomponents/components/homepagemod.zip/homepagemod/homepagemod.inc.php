<?php  
// Home Page Mode Component
//
// Copyright (c) 2011 Nagios Enterprises, LLC.  All rights reserved.
//  
// $Id: homepagemod.inc.php 182 2010-11-18 18:30:46Z egalstad $

require_once(dirname(__FILE__).'/../componenthelper.inc.php');


// respect the name
$homepagemod_component_name="homepagemod";

// run the initialization function
homepagemod_component_init();

////////////////////////////////////////////////////////////////////////
// COMPONENT INIT FUNCTIONS
////////////////////////////////////////////////////////////////////////

function homepagemod_component_init(){
	global $homepagemod_component_name;
	
	$versionok=homepagemod_component_checkversion();
	
	$desc="";
	if(!$versionok)
		$desc="<br><b>".gettext("Error: This component requires Nagios XI 2011R1.7 or later.")."</b>";

	$args=array(

		// need a name
		COMPONENT_NAME => $homepagemod_component_name,
		COMPONENT_VERSION => '1.0',
		// informative information
		COMPONENT_AUTHOR => "Nagios Enterprises, LLC",
		COMPONENT_DESCRIPTION => gettext("Allows admins and users to customize the home page landing screen."),
		COMPONENT_TITLE => "Home Page Modification",
		// configuration function (optional)
		COMPONENT_CONFIGFUNCTION => "homepagemod_component_config_func",
		);
		
	register_component($homepagemod_component_name,$args);
	
	if($versionok){
		// configure callback when home page is about to be displayed
		register_callback(CALLBACK_HOME_PAGE_OPTIONS,'homepagemod_options_callback');
		
		// add a menu link
		register_callback(CALLBACK_MENUS_INITIALIZED,'homepagemod_addmenu');
		}
	}
	

	
///////////////////////////////////////////////////////////////////////////////////////////
// VERSION CHECK FUNCTIONS
///////////////////////////////////////////////////////////////////////////////////////////

function homepagemod_component_checkversion(){

	if(!function_exists('get_product_release'))
		return false;
	if(get_product_release()<207)
		return false;

	return true;
	}
	

///////////////////////////////////////////////////////////////////////////////////////////
// CONFIG FUNCTIONS
///////////////////////////////////////////////////////////////////////////////////////////

function homepagemod_component_config_func($mode="",$inargs,&$outargs,&$result){

	// initialize return code and output
	$result=0;
	$output="";
	
	$component_name="homepagemod";
	
	switch($mode){
		case COMPONENT_CONFIGMODE_GETSETTINGSHTML:
		
			// default settings
			$settings_default=array(
				//"enabled" => 1,
				"destination_type" => "default",
				"destination_url" => "",
				"home_page_title" => "Nagios XI",
				"allow_user_override" => 1,
				);

			// saved settings
			//set_option("homepagemod_component_options","");  // for debugging only
			$settings_raw=get_option("homepagemod_component_options");
			if($settings_raw!=""){
				$settings_default=unserialize($settings_raw);
				}
		
			// settings passed to us
			$settings=grab_array_var($inargs,"settings",$settings_default);
						
			// fix checkboxes
			$settings["enabled"]=checkbox_binary(grab_array_var($settings,"enabled",""));
			$settings["allow_user_override"]=checkbox_binary(grab_array_var($settings,"allow_user_override",""));
			
				
			$output='
			
	<div class="sectionTitle">'.gettext('Home Page Modification Settings').'</div>
	
	<table>

	<!--
	<tr>
	<td valign="top">
	<label for="enabled">'.gettext('Enable Component:').'</label><br class="nobr" />
	</td>
	<td>
	<input type="checkbox" class="checkbox" id="enabled" name="settings[enabled]" '.is_checked($settings["enabled"],1).'>
<br class="nobr" />
	'.gettext('Enables the component.').'<br><br>
	</td>
	</tr>
	//-->
	
	<tr>
	<td valign="top">
	<label>'.gettext('Default Home Page Title').'</label><br>
	</td>
	<td>
	<input type="text" name="settings[home_page_title]" value="'.htmlentities($settings["home_page_title"]).'" size="30"><br>
	'.gettext('Used to override the default home page title.  Leave blank to use the default.').'<br><br>
	</td>
	</tr>
	
	<tr>
	<td valign="top">
	<label>'.gettext('Home Page Destination').'</label><br>
	</td>
	<td>
	<select name="settings[destination_type]">
	<option value="default" '.is_selected($settings["destination_type"],"default").'>'.gettext('Default Location').'</option>
	<option value="homedashboard" '.is_selected($settings["destination_type"],"homedashboard").'>'.gettext('Home Dashboard').'</option>
	<option value="custom" '.is_selected($settings["destination_type"],"custom").'>'.gettext('Custom URL').'</option>
	</select><br>
	'.gettext('Where should the home page be directed?').'<br><br>
	</td>
	</tr>

	<tr>
	<td valign="top">
	<label>'.gettext('Custom URL').'</label><br>
	</td>
	<td>
	<input type="text" name="settings[destination_url]" value="'.htmlentities($settings["destination_url"]).'" size="50"><br>
	'.gettext('Specifies a custom URL to be shown as the default home page.').'<br><br>
	</td>
	</tr>

	<tr>
	<td valign="top">
	<label for="enabled">'.gettext('Allow User-Override').':</label><br class="nobr" />
	</td>
	<td>
	<input type="checkbox" class="checkbox" name="settings[allow_user_override]" '.is_checked($settings["allow_user_override"],1).'>
<br class="nobr" />
	'.gettext('Allow users to override their default home page settings.').'<br><br>
	</td>
	</tr>
	
	</table>

			';
			break;
			
		case COMPONENT_CONFIGMODE_SAVESETTINGS:
		
			// get variables
			$settings=grab_array_var($inargs,"settings",array());
			
			// fix checkboxes
			$settings["enabled"]=checkbox_binary(grab_array_var($settings,"enabled",1));
			$settings["allow_user_override"]=checkbox_binary(grab_array_var($settings,"allow_user_override",""));
			
			// validate variables
			$errors=0;
			$errmsg=array();
			
			if($settings["enabled"]==1){
				if($settings["destination_type"]=="custom" && $settings["destination_url"]==""){
					$errmsg[$errors++]="Custom URL must be specified.";
					}
				}
			
			// handle errors
			if($errors>0){
				$outargs[COMPONENT_ERROR_MESSAGES]=$errmsg;
				$result=1;
				return '';
				}
			
			// save settings
			set_option("homepagemod_component_options",serialize($settings));
			set_option("homepagemod_component_options_configured",1);
						
			break;
		
		default:
			break;
			
		}
		
	return $output;
	}

	
///////////////////////////////////////////////////////////////////////////////////////////
// CALLBACK FUNCTIONS
///////////////////////////////////////////////////////////////////////////////////////////

function homepagemod_options_callback($cbtype,&$cbargs){

	// get our settings
	$settings_raw=get_option("homepagemod_component_options");
	if(empty($settings_raw)){
		$settings=array(
			"enabled" => 1,
			"destination_type" => "default",
			"destination_url" => "",
			"home_page_title" => "Nagios XI",
			"allow_user_override" => 1,
			);
		}
	else
		$settings=unserialize($settings_raw);	
		
	// initial values
	$enabled=grab_array_var($settings,"enabled");
	//$enabled=1;

	$global_configured=get_option("homepagemod_component_options_configured");
	$user_configured=get_user_meta(0,"homepagemod_component_options_configured");
	
	// bail out if we're not enabled or the component hasn't been configured...
	//|| $global_configured!=1  //if component hasn't been configured, the home page can't be changed unless its from the Manage Components page 
	if($enabled!=1 ){
		return;
		}
				
	// get defaults being passed in
	$page_title=grab_array_var($cbargs,"page_title");
	$page_url=grab_array_var($cbargs,"page_url");
	
	$redirect_url=false;
	
	
	$destination="default";
	
	
	// GLOBAL SETTINGS
	$component_page_title=grab_array_var($settings,"home_page_title","");
	$component_destination_url=grab_array_var($settings,"destination_url","");
	$allow_user_override=grab_array_var($settings,"allow_user_override",1);
	
	//if($component_page_title!="" || ($global_configured==1))
		$page_title=$component_page_title;
		
	if($settings["destination_type"]=="homedashboard")
		$destination="homedashboard";
	if($settings["destination_type"]=="custom" && $component_destination_url!=""){
		$page_url=$component_destination_url;
		$redirect_url=true;
		$destination="custom";
		}

		
	// USER SETTINGS
	if($user_configured==1 && $allow_user_override==1){
		$settings_raw=get_user_meta(0,"homepagemod_component_options");
		if($settings_raw!=""){
			$user_settings=unserialize($settings_raw);
			}
		else
			$user_settings=array();		
			
		$user_page_title=grab_array_var($user_settings,"home_page_title","");
		$user_destination_url=grab_array_var($user_settings,"destination_url","");
		
		if($user_page_title!="")
			$page_title=$user_page_title;
		
		if($user_settings["destination_type"]=="homedashboard")
			$destination="homedashboard";
		if($user_settings["destination_type"]=="custom" && $user_destination_url!=""){
			$page_url=$user_destination_url;
			$redirect_url=true;
			$destination="custom";
			}
		
		}
		
	// set options
	$cbargs["destination"]=$destination;
	$cbargs["page_title"]=$page_title;
	$cbargs["page_url"]=$page_url;
	$cbargs["redirect_url"]=$redirect_url; // tell XI whether the home page should be redirected
	}
	
function homepagemod_can_show_menu(){


	// bail if we're not enabled
	$settings=@unserialize(get_option("homepagemod_component_options"));
	//$enabled=grab_array_var($settings,"enabled",0);
	$enabled=1;
	$override=grab_array_var($settings,"allow_user_override",0);
	if($enabled==0 || $override==0){
		//print_r($settings);
		return false;
		}
	
	return true;
	}


function homepagemod_addmenu(){



	$desturl=get_component_url_base("homepagemod");
	
	$mi=find_menu_item(MENU_ACCOUNT,"menu-account-accountinfo","id");
	if($mi==null)
		return;
		
	$order=grab_array_var($mi,"order","");
	if($order=="")
		return;
		
	$neworder=$order+.01;

	add_menu_item(MENU_ACCOUNT,array(
		"type" => "link",
		"title" => gettext("Home Page Options"),
		"id" => "menu-account-homepageopts",
		"order" => $neworder,
		"opts" => array(
			"href" => $desturl.'/useropts.php',
			),
		"function" => "homepagemod_can_show_menu",
		));
			
	}

?>