<?php 
// RENAMING TOOL COMPONENT
//
// Copyright (c) 2010 Nagios Enterprises, LLC.  All rights reserved.
//  
// $Id: rename.inc.php 115 2010-08-16 16:15:26Z mguthrie $

//include the helper file
require_once(dirname(__FILE__).'/../componenthelper.inc.php');

// respect the name
$rename_component_name="rename";

// run the initialization function
rename_component_init();

////////////////////////////////////////////////////////////////////////
// COMPONENT INIT FUNCTIONS
////////////////////////////////////////////////////////////////////////

function rename_component_init(){
	global $rename_component_name;
	
	//boolean to check for latest version
	$versionok=rename_component_checkversion();
	
	//component description
	$desc=gettext("This component allows administrators to manage renaming of hosts and services in bulk.");
	
	if(!$versionok)
		$desc="<b>".gettext("Error: This component requires Nagios XI 2012R1.0 or later with Enterprise Features enabled.")."</b>";
	
	//all components require a few arguments to be initialized correctly.  
	$args=array(

		// need a name
		COMPONENT_NAME => $rename_component_name,
		COMPONENT_VERSION => '1.3', 
		COMPONENT_DATE => '02/04/2013',

		// informative information
		COMPONENT_AUTHOR => "Nagios Enterprises, LLC",
		COMPONENT_DESCRIPTION => $desc,
		COMPONENT_TITLE => "Renaming Tool",

		// configuration function (optional)
		//COMPONENT_CONFIGFUNCTION => "rename_component_config_func",
		);
	
	//register this component with XI 
	register_component($rename_component_name,$args);
	
	//only add this menu if the user is an admin
	// register the addmenu function
	if($versionok)
		register_callback(CALLBACK_MENUS_INITIALIZED,'rename_component_addmenu');
	}
	



///////////////////////////////////////////////////////////////////////////////////////////
// MISC FUNCTIONS
///////////////////////////////////////////////////////////////////////////////////////////

function rename_component_checkversion(){

	if(!function_exists('get_product_release'))
		return false;
	//needs permission fix in reconfigure_nagios.sh script in 2011R2.4
	if(get_product_release()<300) 
		return false;

	return true;
	}
	
function rename_component_addmenu($arg=null){
	global $rename_component_name;
	global $menus;
	//retrieve the URL for this component
	$urlbase=get_component_url_base($rename_component_name);
	//figure out where I'm going on the menu	
	//$mi=find_menu_item(MENU_HOME,"menu-home-acknowledgements","id");
	//if($mi==null) //bail if I didn't find the above menu item 
	//	return;
		
	//$order=grab_array_var($mi,"order","");  //extract this variable from the $mi array 
	//if($order=="")
	//	return;
		
	//$neworder=$order+0.1; //determine my menu order 
	
	//add this to the core config manager menu 
	add_menu_item(MENU_CORECONFIGMANAGER,array(
		"type" => "link",
		"title" => gettext("Renaming Tool"),
		"id" => "menu-coreconfigmanager-rename",
		"order" => 801.5,
		"opts" => array(
			"href" => $urlbase."/rename.php",
			)
		));
	//add to the new ccm if it is installed	
	add_menu_item(MENU_CCM,array(
		"type" => "link",
		"title" => gettext("Renaming Tool"),
		"id" => "menu-ccm-rename",
		"order" => 802.5,
		"opts" => array(
			"href" => $urlbase."/rename.php",
			)
		));		

		
}


?>