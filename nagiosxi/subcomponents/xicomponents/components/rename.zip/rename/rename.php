<?php  //rename.php 
//
// Renaming Tool
//
// Copyright (c) 2011 Nagios Enterprises, LLC.  All rights reserved.
//  
require_once(dirname(__FILE__).'/../../common.inc.php');

// initialization stuff
pre_init();
// start session
init_session(true);
// grab GET or POST variables 
grab_request_vars();
// check prereqs
check_prereqs();
// check authentication
check_authentication(false);
// only admins can access this page
if(is_admin()==false){
	echo $lstr['NotAuthorizedErrorText'];
	exit();
	}

?>
<!DOCTYPE html>
<html>
	<!-- Produced by Nagios XI.  Copyyright (c) 2008-2009 Nagios Enterprises, LLC (www.nagios.com). All Rights Reserved. -->
	<!-- Powered by the Nagios Synthesis Framework -->

<head>
<title>Nagios XI - Renaming Tool</title>
<meta http-equiv='Content-Type' content='text/html; charset=UTF-8' />
		
<?php		do_page_head_links();  ?>
<style type='text/css'>

#main {margin:10px; }
#listings_table {width:95%; text-align:center;margin-bottom:10px;}
input.td {width:95%;}
.container {margin:10px;}
.td_hostlist{text-align:left;}
#actionSearch{margin-bottom:10px;}
#selected{min-width:350px;}
#prompt{margin-bottom:20px;}
</style>
<script type="text/javascript">

function remove(id) {
	$('#'+id).remove();
}

$(document).ready(function() {
	$('#back').click(function() {
		var type = $('#objecttype').val(); 
		goBack(type); 
	});
	
	//bind search event to enter key 
	$('#search').keyup(function(ev) {
		if(ev.which == 13 && $('#search').val()!='') {
			var type = $('#objecttype').val();
			obj_search(type); 
		}		
	}); 
	
}); 

function goBack(type) {
	var stage = parseInt($('#stage').val()) - 2;
	//alert(stage); 
	window.location='rename.php?stage='+stage+'&objecttype='+type;  
}
	
function obj_search(type) {
	var search = $('#search').val(); 
	window.location='rename.php?stage=2&objecttype='+type+'&search='+search; 
}	

function clear_search(type) {
	window.location='rename.php?stage=2&objecttype='+type; 
}
	
</script>
</head>
<body>

<h1><?php echo gettext("Bulk Renaming Tool"); ?></h1>



<div id='main'>
		
<?php
echo enterprise_message();

print route_request(); 
print "</div> <!-- end main -->"; 
do_page_end(true); 
exit(); 




//////////////////////////////////////////FUNCTIONS////////////////////


function route_request() {
	global $escape_request_vars;
	$escape_request_vars=false; 
	
	$stage = grab_request_var('stage',1);
	$type = escape_sql_param(grab_request_var('objecttype','host'),DB_NDOUTILS); //clean variable for sql 
	
	switch($stage) {
		case 2:
			$output=rename_stage_two($type);
		break;		
		case 3:
			$output=rename_stage_three($type);
		break; 
		case 4:
			$output=rename_stage_four($type);
		break; 		
		case 1:
		default:
			$output=rename_stage_one(); 
		break; 	
	}
	
	return $output; 
}


function rename_stage_one() {

	$output = "
	<div id='rename_stage_1' class='container'>
		<div class='info'>
		".gettext("The Renaming Tool allows for host and service names to be updated in bulk, while retaining all historical
		status information and performance data.  The renaming tool updates configurations based on what is
		defined in the Core Config Manager.")."  <br /><br />
		<strong>".gettext("Note").": </strong>".
		gettext("Hosts and services that are renamed will show as <strong>Pending</strong> until the first check result is received with the new name.")." 
		
		</div> <!-- end info div -->
		<h2>".gettext("Stage 1")."</h2>
		<div id='prompt'>".gettext("What would you like to rename?")."</div>
		<div id='formdiv'>
		<form id='mainform' method='post' action='rename.php'>
			<input type='radio' id='rad1' value='host' checkec='checked' name='objecttype' /><label for='rad1'>".gettext("Hosts")."</label><br />
			<input type='radio' id='rad1' value='service'  name='objecttype' /><label for='rad2'>".gettext("Services")."</label><br /><br />
			<br />
			<input type='submit' id='submit' name='submit' value='".gettext("Next")."' />
			<input type='hidden' name='stage' id='stage' value='2' /> 
		</form>	
		</div> <!-- end formdiv -->
	</div>	
	"; 
	
	return $output; 

}


function rename_stage_two($type) {

	$Type = ucfirst($type).'s'; 
	$search = escape_sql_param(grab_request_var('search',''),DB_NDOUTILS); 
	$optionString = get_option_list($type,$search); 
	$info = ($type=='service') ? "<div id='listInfo'><strong>".gettext("Config Name")."</strong> :: <strong>".gettext("Service Description")."</strong></div>\n" : ''; 

	$output = "
	<div id='rename_stage_2' class='container'>
		<h2>".gettext("Stage 2")."</h2>
		<div id='prompt'>".gettext("Which")." {$Type} ".gettext("would you like to rename?")."</div>
		<div id='formdiv'>
		<form id='mainform' method='post' action='rename.php'>
			<label for='search'>".gettext("Search").": </label>
			<input type='text' name='search' id='search' value='{$search}' /> &nbsp; 
			<input type='button' id='actionSearch' onclick='javascript:obj_search(\"{$type}\");' value='".gettext("Search")."' />
			<input type='button' id='clearSearch' onclick='javascript:clear_search(\"{$type}\");' value='".gettext("Clear")."' /><br />
			
			{$info}
			<select name='selected[]' id='selected' multiple='multiple' size='20'>
				{$optionString}
			</select>
			<br /><br />	
			<input type='button' id='back' name='back' value='".gettext("Back")."' /> &nbsp;
			<input type='submit' id='submit' name='submit' value='".gettext("Next")."' />  
			<br />
			<input type='hidden' name='stage' id='stage' value='3' /> 
			<input type='hidden' name='objecttype' id='objecttype' value='{$type}' />
		</form>	
		</div> <!-- end formdiv -->
	</div>	
	"; 
	
	return $output; 


}

function rename_stage_three($type,$errors=array(0,''),$ids=null) {
	
	$Type = ucfirst($type).'s'; 
	if($ids===null)
		$ids = grab_request_var('selected',array());
	//fetch more info on the selected objects 
	$tr_data = get_object_details($type,$ids); 
	
	//check for errors if we're coming back from stage 4
	$feedback = '';
	if($errors[0] > 0)
		$feedback = display_message($errors[0],true,$errors[1]);
	
	$output = "
	<div id='rename_stage_3' class='container'>
		<h2>Stage 3</h2>
		<div id='prompt'>".gettext("Update Names for the Selected Objects")."</div>
		{$feedback}
		<div id='formdiv'>
		<form id='mainform' method='post' action='rename.php'>
		<table class='standardtable' id='listings_table'>
		{$tr_data}
		</table>
			<input type='button' id='back' name='back' value='".gettext("Back")."' />&nbsp; 
			<input type='submit' id='submit' name='submit' value='".gettext("Next")."' /> 
			<br /><br />
			<input type='hidden' name='stage' id='stage' value='4' /> 
			<input type='hidden' name='objecttype' id='objecttype' value='{$type}' />
		</form>	
		</div> <!-- end formdiv -->
	</div>	
	"; 
	
	return $output; 
}

/**
*	stage 4 of wizard, verifies input and returns success | fail message 
*/ 
function rename_stage_four($type) {

	$output=''; 
	$Type = ucfirst($type).'s'; 
	$rows = grab_request_var('rows',array());
	$msg = ''; 	
	$ids = array(); 
	//array_dump($rows); 
	
	//validate input 
	$errors = 0;
	$errmsg = '';
	
	if(!enterprise_features_enabled()) {
		$errors++;
		$errmsg.=gettext('This feature requires a Nagios XI Enterprise Edition license.').' <br />';
	}
	
	foreach($rows as $r) {
		if($type=='host' && (!isset($r['host_name']) || trim($r['host_name'])=='')) {
			$errors++;
			$errmsg.=gettext("Missing required Host Name for Host: ").$r['old_name']."<br />";
		}
		if($type=='service' && (!isset($r['service_description']) || trim($r['service_description'])=='') ) {
			$errors++;
			$errmsg.=gettext("Missing required Service Description for Host").": {$r['host_name']} : ".gettext("Service").": {$r['host_name']}<br />";		
		}

		$ids[] = $r['id']; //add to ids array for error handling 		
	}
	//go back if there are problems
	if($errors > 0)
		return rename_stage_three($type,array($errors,$errmsg),$ids); 
		
	unset($ids); //no longer needed 	
	
	//process input results 
	$rename_function = "process_{$type}_rename";

	foreach($rows as $r) {
        $error=$rename_function($r,$msg);
		$errors+=$error; 
	}
	
	//apply configuration if all is well 
	if($errors==0)
		submit_command(COMMAND_NAGIOSCORE_APPLYCONFIG);
		
	//build html for stage 4 
	$output = "
	<div id='rename_stage_4' class='container'>
		<h2>".gettext("Renaming Wizard Complete!")."</h2>
		<div id='prompt'>".get_message_text($errors,false,$msg)."</div>
		<div id='formdiv'>
			<a href='rename.php?stage=1' title='Run this wizard again'>".gettext("Run This This Wizard Again")."</a>		
		</div> <!-- end formdiv -->
	</div>	
	"; 
	
	return $output; 
}





///////////////////////////////END STAGES /////////////////////////////


//////////////////////////FUNCTIONS/////////////////////////////////////
/**
*	get html option list based on object type
*	@param string $type 'host' | 'service'
*	@param string $search form input search
*	@return string $output html option string
*/
function get_option_list($type,$search) {

	$output = ""; 
	if($type=='host') {
		$opts = get_all_ccm_hosts($search); 
		$name = 'host_name'; 
	}	
	else {
		$opts = get_all_ccm_services($search);
		$name = 'name';
	}	
		
	foreach($opts as $row)
		$output.="<option value='{$row['id']}'>{$row[$name]}</option>\n"; 
	
	return $output; 
}



/**
*	gets more detailed info fields for selected $ids
*	@param string $type 'host' | 'service'
*	@param mixed $ids array of selected object ids
*	@return string $rows html string of table rows
*/
function get_object_details($type,$ids) {
	$selected = implode(',',$ids); 

	if($type=='host') 
		$query="SELECT `id`,`host_name`,`alias`,`display_name` FROM tbl_host WHERE `id` IN ({$selected}) ORDER BY `host_name`";	
	else //services 
		$query="SELECT `id`,`config_name`,`service_description` 
				FROM tbl_service WHERE id IN ({$selected}) ORDER BY `service_description`"; 
	
	//echo $query."<br />"; 
	$rs = exec_sql_query(DB_NAGIOSQL,$query,true); 
	//echo "COUNT ".$rs->recordCount()."<br />"; 
	$rows = rs_to_table_row($rs,$type); 
		
	return $rows; 

} 


/**
*	Builds the html set of table rows based on result set from $rs
*	@param mixed $rs ADODB database object
*	@param string $type 'host' | 'service'
*	@return string $rows html string of table rows
*/
function rs_to_table_row($rs,$type) {
	$rows=''; 
	$count=0;
	$img = '<img border="0" title="Close" alt="Close" src="'.get_base_url().'/images/b_close.png">'; 
	if($type=='host') {
		$rows.="<tr><th>".gettext("Host Name")."</th>
					<th>".gettext("New Name")."</th>
					<th>".gettext("Alias")."</th>
					<th>".gettext("Display Name")."</th>
					<th>".gettext("Remove")."</th></tr>\n"; 
		foreach($rs as $r){
			$class = ($count++ % 2 == 1) ? 'even' : 'odd'; 
			$rows.="
			<tr class='{$class}' id='tr_{$count}'>
				<td><input type='hidden' name='rows[{$count}][id]' value='{$r['id']}' />
					<input type='hidden' name='rows[{$count}][old_name]' value='{$r['host_name']}' />
					{$r['host_name']}
				</td>
				<td>
					<input type='text' class='td' name='rows[{$count}][host_name]' value='{$r['host_name']}' />
				</td>				
				<td>
					<input type='text' class='td' name='rows[{$count}][alias]' value='{$r['alias']}' />
				</td>
				<td>
					<input type='text' class='td' name='rows[{$count}][display_name]' value='{$r['display_name']}' />
				</td>
				<td><a class='remove' href='javascript:remove(\"tr_{$count}\")'> {$img} </a></td>
			</tr>\n"; 
		}
	
	}
	else { //service
		$rows.="<tr><th>".gettext("Config Name")."</th>
				<th>".gettext("Old Service Description")."</th>
				<th>".gettext("New Service Description")."</th>
				<th>".gettext("Affected Hosts")."</th>
				<th>".gettext("Remove")."</th></tr>\n"; 
		foreach($rs as $r){
			$class = ($count++ % 2 == 1) ? 'even' : 'odd'; 
			$rows.="
			<tr class='{$class}' id='tr_{$count}'>
				<td><input type='hidden' name='rows[{$count}][id]' value='{$r['id']}' />
					<input type='hidden' name='rows[{$count}][old_name]' value='{$r['service_description']}' />
					<input type='hidden' name='rows[{$count}][config_name]' value='{$r['config_name']}' />
					{$r['config_name']}
				</td>
				<td>
					{$r['service_description']}
				</td>
				<td>
					<input type='text' class='td' name='rows[{$count}][service_description]' value='{$r['service_description']}' />
				</td>
				<td class='td_hostlist'>".get_service_to_host_list($r['id'])."</td>
				<td><a class='remove' href='javascript:remove(\"tr_{$count}\")'> {$img} </a></td>
			</tr>\n"; 	
		}	
	}
	
	//echo "ROWCOUNT: $count <br />"; 
	return $rows; 
}

/**
*	retrieves a full list of id->host_names from CCM DB
*	@param string $search optional search string
*	@return mixed $rs ADODB OBJECT type 
*/
function get_all_ccm_hosts($search) {	
	$query = "SELECT `id`,`host_name` FROM tbl_host";
	if($search!='')
		$query.=" WHERE `host_name` LIKE '%{$search}%'";  
	$query.=" ORDER BY `host_name`"; 
	$rs = exec_sql_query(DB_NAGIOSQL,$query,true); 	
	return $rs; 
}

/**
*	retrieves a full list of id->host_names from CCM DB
*	@param string $search optional search string
*	@return mixed $services array of services with id and host::service 
*/
function get_all_ccm_services($search) {	
	
	$query="SELECT id,config_name,service_description FROM tbl_service";
	if($search!='')
		$query.=" WHERE `config_name` LIKE '%{$search}%' OR `service_description` LIKE '%{$search}%' "; 
	$query.=" ORDER BY `config_name`,`service_description`";

	$rs = exec_sql_query(DB_NAGIOSQL,$query,true); 	
	$services = array(); 
	foreach($rs as $row) {
		$services[] = array(
			'name' => $row['config_name'].' :: '.$row['service_description'],
			'id' => $row['id'],
		);
	}
		
	return $services; 
}


/**
*	manages all subfunctions for renaming a single host, takes in input array 
*	@param mixed $array 
            ["id"] => 86   //NAGIOSQL id, not ndoutils
            ["old_name"] => _LOC_host_1
            ["host_name"] => MASS_host_1
            ["alias"] => MASS
            ["display_name"] => MASS
        
*	$param string $msg REFERENCE variables for output message
*	@return int $error error code for success or failuer ( 0 | 1 )
*/ 
function process_host_rename($array,&$msg) {

	$errors = 0; 
	//rename_host_ndoutils
	$errors += rename_host_ndoutils($array,$msg); 
	//rename_host_nagiosql
	$errors += rename_host_nagiosql($array,$msg);
	//rename_host_perfdata
	$errors += rename_host_perfdata($array,$msg);
	
	if($errors==0)
		$msg.="<strong>".$array['old_name']. '</strong> updated to <strong>'.$array['host_name']."</strong> successfully!<br />"; 
	
	return $errors;
}

/**
*	manages all subfunctions for renaming a single service, takes in input array 
*	@param mixed $array 
            ["id"] => 86   //NAGIOSQL id, not ndoutils
            ["old_name"] => <old service description>
			["config_name"] => <physical config file it's stored on>
            ["service_description"] => <new service desc>        
*	$param string $msg REFERENCE variables for output message
*	@return int $error error code for success or failuer ( 0 | 1 )
*/ 
function process_service_rename($array,&$msg) {

	$errors = 0; 
	//rename_host_ndoutils
	$errors += rename_service_ndoutils($array,$msg,$hosts); 
	$array['hosts'] = $hosts; //push related hosts into array 
	//rename_host_nagiosql
	$errors += rename_service_nagiosql($array,$msg);
	//rename_host_perfdata
	$errors += rename_service_perfdata($array,$msg);
	
	if($errors==0) {
		$msg.="Service <strong>".$array['old_name']."</strong> updated to
		<strong>".$array['service_description']."</strong> for the following hosts: 
		<br />".implode("<br />",$array['hosts'])."<br />"; 	
	}
	
	return $errors;
}


/**
*	updates name fields in ndoutils
*	@param mixed $host_array host information returned from form
*	@param string $msg REFERENCE variable to output string 
*	@return int $errors error count from function
*/ 
function rename_host_ndoutils($host_array,&$msg) {

	$errors=0;
	$host_name = $host_array['host_name'];
	$old_name = $host_array['old_name'];
	//needs to rename name1 for host entry but also all service entries with name1=host_name
	//abstract this a bit more
	$query = "UPDATE nagios_objects SET `name1`='{$host_name}' WHERE `name1`='$old_name'"; 
	$rs = exec_sql_query(DB_NDOUTILS,$query,true); 
	//handle errors 
	if(!$rs) {	
		$msg.="Error updating {$old_name} to {$host_name}.<br />"; 
		$error++;
	}	

	return $errors; 
}


/**
*	updates name2 field in ndoutils
*	@param mixed $array REFERENCE variable to service information returned from form
*	@param string $msg REFERENCE variable to output string 
*	@return int $errors error count from function
*/ 
function rename_service_ndoutils($array,&$msg,&$hosts) {

	$errors=0;
	$hosts=array(); 
	$old_name = $array['old_name'];
	$service = $array['service_description'];
	$id = $array['id'];
	$hoststring = '';
	
	//get related hosts from nagiosql and build hoststring for next query
	$hosts = get_service_to_host_relationships($id,$hoststring);
	
	//abstract this a bit more?
	$query = "UPDATE nagios_objects SET `name2`='{$service}' WHERE `name1` IN({$hoststring}) AND `name2`='{$old_name}'"; 
	//echo $query."<br />"; 
	$rs = exec_sql_query(DB_NDOUTILS,$query,true); 
	//handle errors 
	if(!$rs) {	
		$msg.="Error updating {$old_name} to {$service}.<br />"; 
		$errors++;
	}	

	return $errors; 
}


/**
*	renames a host in the nagiosql table, remove config file it's stored in
*	@param mixed $host_array host information returned from form
*	@param string $msg REFERENCE variable to output string 
*	@return int $errors error count from function
*/ 
function rename_host_nagiosql($host_array,&$msg) {
	$error=0;
	$host_name = $host_array['host_name'];
	$old_name = $host_array['old_name'];
	$id = intval($host_array['id']);
	$alias = grab_array_var($host_array,'alias','');
	$display_name = grab_array_var($host_array,'display_name','');
	//needs to rename name1 for host entry but also all service entries with name1=host_name
	//abstract this a bit more
	$query = "UPDATE tbl_host SET `host_name`='{$host_name}',`alias`='{$alias}',`display_name`='{$display_name}',`last_modified`=NOW() WHERE `id`={$id}"; 
	$rs = exec_sql_query(DB_NAGIOSQL,$query,true); 
	//handle errors 
	if(!$rs) {	
		$msg.="Error updating {$host_array['old_name']} to {$host_name}.<br />"; 
		$error=1;
	}	
	
    $query = "UPDATE tbl_service SET `config_name`='{$host_name}',`last_modified`=NOW() WHERE `config_name`='{$old_name}'"; 
    $rs = exec_sql_query(DB_NAGIOSQL,$query,true); 
	//handle errors 
	if(!$rs) {	
		$msg.="Error updating service config name from {$host_array['old_name']} to {$host_name}.<br />"; 
		$error=1;
	}	
    
	//remove old host config file 
	$hostdir = '/usr/local/nagios/etc/hosts/';
	$servicedir = '/usr/local/nagios/etc/services/'; 
	if(file_exists($hostdir.$old_name.'.cfg'))
		unlink($hostdir.$old_name.'.cfg');
	if(file_exists($servicedir.$old_name.'.cfg'))
		unlink($servicedir.$old_name.'.cfg');
		
	return 0; 
}




/**
*	renames a service in the nagiosql table, remove config file it's stored in 
*	@param mixed $host_array host information returned from form
*	@param string $msg REFERENCE variable to output string 
*	@return int $errors error count from function
*/ 
function rename_service_nagiosql($array,&$msg) {
	$error=0;
	//$host_name = $array['host_name'];
	$old_name = $array['old_name'];
	$config_name = $array['config_name'];
	$id = intval($array['id']);
	$service = $array['service_description'];

	//abstract this a bit more
	$query = "UPDATE tbl_service SET `service_description`='{$service}',`last_modified`=NOW() WHERE `id`={$id}"; 
	$rs = exec_sql_query(DB_NAGIOSQL,$query,true); 
	//handle errors 
	if(!$rs) {	
		$msg.="Error updating {$host_array['old_name']} to {$host_name}.<br />"; 
		$error=1;
	}	
	
	//remove old service config file 
	$servicedir = '/usr/local/nagios/etc/services/'; 
	$file = $servicedir.$config_name.'.cfg';
	if(file_exists($file))
		@unlink($file);
		
	return $error; 
}

/**
*	creates a directory with new host name, moves perfdata files there
*	This function creates a new directory with apache.apache ownership, so the reconfigure_nagios.sh 
*	script has to update permissions to nagios.nagios to PNP can write to it
*	@param mixed $host_array host information returned from form
*	@param string $msg REFERENCE variable to output string 
*	@return int $errors error count from function
*/ 
function rename_host_perfdata($host_array,&$msg) {
	global $cfg; 
	$errors=0; 
	
	//directories 
	$perfdir = grab_array_var($cfg,'perfdata_dir','/usr/local/nagios/share/perfdata'); 
	$hostdir = doClean($host_array['old_name']); //cleaned variable
	$destdir = $perfdir.'/'.doClean($host_array['host_name']); //cleaned variable 
	$xmlfile = $destdir.'/'.'_HOST_.xml'; 
	
	//does this host have performance data??
	if(!file_exists($perfdir.'/'.$hostdir))
		return $errors; //skip if it doesn't
	
	//make new directory
	$cmd = "mkdir -p ".$destdir;
	$output = system($cmd,$code); 
	if($code > 0 ){
		$errors++; 
		$msg.=gettext("Unable to create directory").": $destdir $output<br />";
		return $errors; 
	}
	//echo "<br />CMD: $cmd OUTPUT: $output CODE: $code <br />"; 
	
	//update xml files
	
	$files = scandir($perfdir.'/'.$hostdir);
	foreach($files as $file) {
		if(!strpos($file,'.xml')) continue; //only want xml files
		
		$f = file_get_contents($perfdir.'/'.$hostdir.'/'.$file); 
		if(!$f) {
			$errors++; 
			$msg.=gettext("Unable to update performance data XML file:")." $file<br />";
		}
		//replace old host string with new one
		$newf = str_replace($host_array['old_name'],$host_array['host_name'],$f);
		if(!file_put_contents($perfdir.'/'.$hostdir.'/'.$file,$newf)) {
			$errors++; 
			$msg.=gettext("Unable to update performance data XML file").": $file<br />";
		}
		
	}
		
	//move files
	$origdir = $perfdir.'/'.$hostdir;
	$cmd = "mv -f ".$perfdir.'/'.$hostdir.'/* '.$destdir;
	$output = system($cmd,$code); 
	if($code > 0 ){
		$errors++; 
		$msg.=$output."<br />";
	}
	//echo "<br />CMD: $cmd OUTPUT: $output CODE: $code <br />"; 	
	
	return $errors;
}


/**
*	Update filenames and XML entries for service performance data 
*	This function creates a new xml / rrd file with apache.apache ownership, so the reconfigure_nagios.sh 
*	script has to update permissions to nagios.nagios to PNP can write to it
*	@param mixed $array service information returned from form
*	@param string $msg REFERENCE variable to output string 
*	@return int $errors error count from function
*/ 
function rename_service_perfdata($array,&$msg) {
	global $cfg; 
	$errors=0; 
	
	//array_dump($array); 
	
	//directories 
	$perfdir = grab_array_var($cfg,'perfdata_dir','/usr/local/nagios/share/perfdata'); 
	
	//will need to fetch related host names from ndoutils function
	$hosts =& $array['hosts'];
	
	//each iteration handles a host:service combination
	foreach($hosts as $host) {
		$destdir = $perfdir . '/'. doClean($host) . '/'; //host directory 
		$servicefile = $destdir . doClean($array['service_description']); 
		$oldfile = $destdir . doClean($array['old_name']);
		$newrrd = $servicefile . '.rrd'; //full absolute paths 
		$newxml = $servicefile . '.xml'; 
		$oldxml = $oldfile.'.xml'; 
		$oldrrd = $oldfile.'.rrd'; 
		
		
		//echo "OLD: $oldfile<br />"; 
		//echo "NEWRRD: $newrrd<br />";
		//echo "newxml: $newxml<br />";
				
		//does this service have performance data??
		if(!file_exists($oldxml) && !file_exists($oldrrd))
			return $errors; //skip if it doesn't
			
		//update xml files
		$f = file_get_contents($oldxml); 
		if(!$f) {
			$errors++; 
			$msg.="Unable to update performance data XML file: $newxml<br />";
			return $errors; 
		}
		//replace old host string with new one
		$newf = str_replace($array['old_name'],$array['service_description'],$f);
		if(!file_put_contents($oldxml,$newf)) {
			$errors++; 
			$msg.="Unable to update service description in performance data XML file: $oldxml<br />";
		}	
				
		//mv (rename) files
		//XXX change to mv after DEV is done 
		$cmd1 = 'mv -f '.$oldfile.'.xml '.$newxml; //xmlfile 
		//echo "CMD1: $cmd1<br />"; 
		$output = system($cmd1,$code); 
		if($code > 0 ){
			$errors++; 
			$msg.="Unable to run: $cmd1. $output<br />";
		}	
		$cmd2 = 'mv -f '.$oldfile.'.rrd '.$newrrd; //rrdfile
		//echo "CMD2: $cmd2<br />"; 
		$output = system($cmd2,$code); 
		if($code > 0 ){
			$errors++; 
			$msg.="Unable to run: $cmd2. $output <br />";
		}		
		

	}
	
	return $errors;
}

//function used from PNP 0.4
function doClean($string) {
	$string = preg_replace('/[ :\/\\\\]/', "_", $string);
	//$string = rawurldecode($string);
	return $string;
}


/**
*	Runs multiple SQL queries and gets all related hosts for a particular service.  
*	This function does NOT handle service->hostgroup->hostgroup->host relationships, but should do everything else
*	@param int $id service ID from nagiosql tbl_service
*	@param string $hoststring REFERENCE variable to hoststring that will be used in SQL IN() search
*	@return mixed $hosts array of all related hosts
*/ 
function get_service_to_host_relationships($id,&$hoststring) {

	$hoststring=''; 
	//handle service->host relationships
	$query = "SELECT a.id,a.host_name FROM tbl_lnkServiceToHost b JOIN  tbl_host a ON a.id=b.idSlave WHERE b.idMaster={$id}"; 
	$rs = exec_sql_query(DB_NAGIOSQL,$query,true); 

	foreach($rs as $row) {
		$hoststring.="'".$row['host_name']."',"; 
		$hosts[] = $row['host_name']; //push related hosts into array
	}	
	
	//check for service->hostgroup relationships	
	//check relationships for hostgroup->host
	$query = "SELECT b.host_name FROM tbl_lnkHostgroupToHost a 
			JOIN tbl_host b ON a.idSlave=b.id WHERE idMaster 
			IN (SELECT idSlave FROM tbl_lnkServiceToHostgroup WHERE idMaster={$id})";	
	$rs = exec_sql_query(DB_NAGIOSQL,$query,true);
	if($rs && $rs->recordCount() > 0) { //there are hostgroup relationships
		foreach($rs as $row) {
			$hoststring.="'".$row['host_name']."',"; 
			$hosts[] = $row['host_name']; //push related hosts into array			
		}	
	}
	
	//check relationships host->hostgroup
	$query = "SELECT b.host_name FROM tbl_lnkHostToHostgroup a 
			JOIN tbl_host b ON a.idMaster=b.id WHERE idSlave 
			IN (SELECT idSlave FROM tbl_lnkServiceToHostgroup WHERE idMaster={$id})";
	
	$rs = exec_sql_query(DB_NAGIOSQL,$query,true); 	
	if($rs && $rs->recordCount() > 0) { //there are hostgroup relationships
		foreach($rs as $row) {
			$hoststring.="'".$row['host_name']."',"; 
			$hosts[] = $row['host_name']; //push related hosts into array			
		}
	}	
	
	//remove last comma
	$hoststring = substr($hoststring,0,(strlen($hoststring)-1) );
	//echo $hoststring."<br />"; 
	
	//$hoststring will get returned as a reference variable
	
	return $hosts; 

}

function get_service_to_host_list($id){

	$hosts = get_service_to_host_relationships($id,$hoststring);
	$output = "<ul class='hostlist'>\n"; 
	foreach($hosts as $host)
		$output.="<li>{$host}</li>\n"; 
		
	$output.="</ul>\n"; 
	
	return $output; 	

}

?>