<?php
/*
 * ======================================================================================================================
 * Active Directory Integration Component
 *
 * Copyright:        Copyright (c) 2010 Nagios Enterprises, LLC.
 * Authors:           Tony Yarusso, Mike Guthrie, Scott Wilkerson, Tim Stahl
 * License:          GPL v2
 * Homepage:         http://www.nagios.com/
 * Description:      Use AD as an authentication source for XI
 *                     This component makes it possible to use an Active Directory store as a source of user account
 *                     information for Nagios XI.  Rather than checking the username and password given against the
 *                     built-in PostgreSQL database, they are checked against the AD domain controller specified to log
 *                     the user in.
 *
 * Revision information: $Id: active_directory.inc.php 901 2012-10-26 21:11:02Z mguthrie $
 *
 * ----------------------------------------------------------------------------------------------------------------------
 *
 * TODO notes
 *   * Allow assignment of permissions based on AD group memberships
 *   * Use contact information (e-mail address, cell phone number) from AD
 *
 * ----------------------------------------------------------------------------------------------------------------------
 *
 * Dependencies
 *   * php-ldap
 *
 * Installation instructions
 *   See http://exchange.nagios.org/directory/Addons/Components/Installing-XI-Components/details
 *
 * ======================================================================================================================
 *
 * LICENSE:
 *
 * This work is made available to you under the terms of Version 2 of
 * the GNU General Public License. A copy of that license should have
 * been provided with this software, but in any event can be obtained
 * from http://www.fsf.org.
 *
 * This work is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 or visit their web page on the internet at
 * http://www.fsf.org.
 *
 *
 * CONTRIBUTION POLICY:
 *
 * (The following paragraph is not intended to limit the rights granted
 * to you to modify and distribute this software under the terms of
 * licenses that may apply to the software.)
 *
 * Contributions to this software are subject to your understanding and acceptance of
 * the terms and conditions of the Nagios Contributor Agreement, which can be found
 * online at:
 *
 * http://www.nagios.com/legal/contributoragreement/
 *
 *
 * DISCLAIMER:
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
 * HOLDERS BE LIABLE FOR ANY CLAIM FOR DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
 * OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
 * GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, STRICT LIABILITY, TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) OR OTHER ACTION, ARISING FROM, OUT OF OR IN CONNECTION
 * WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

require_once(dirname(__FILE__).'/../componenthelper.inc.php');

// respect the name
$active_directory_component_name="active_directory";

// run the initialization function
active_directory_component_init();

////////////////////////////////////////////////////////////////////////
// COMPONENT INIT FUNCTIONS
////////////////////////////////////////////////////////////////////////

function active_directory_component_init() {
	global $active_directory_component_name;

	$versionok=active_directory_component_checkversion();

	$desc="<strong>".gettext("Experimental")."</strong>.";
	if(!$versionok)
		$desc="<br><b>".gettext("Error: This component requires Nagios XI 2009R1.3G or later.")."</b>";

	$args=array(

		// need a name
		COMPONENT_NAME => $active_directory_component_name,
		COMPONENT_VERSION => '0.3',

		// informative information
		COMPONENT_AUTHOR => "Nagios Enterprises, LLC",
		COMPONENT_DESCRIPTION => gettext("Uses Active Directory as a user authentication source").". ".$desc,
		COMPONENT_TITLE => "Active Directory Integration",
		// configuration function (optional)
		COMPONENT_CONFIGFUNCTION => "active_directory_component_config_func",
		);

	register_component($active_directory_component_name,$args);

	if($versionok) {
		// configure authentication callback
		register_callback(CALLBACK_PROCESS_AUTH_INFO,'active_directory_component_check_authentication');
		}

	}


///////////////////////////////////////////////////////////////////////////////////////////
// VERSION CHECK FUNCTIONS
///////////////////////////////////////////////////////////////////////////////////////////

function active_directory_component_checkversion() {

	if(!function_exists('get_product_release'))
		return false;
	//requires greater than 2009R1.2
	if(get_product_release()<124)
		return false;

	return true;
	}

////////////////////////////////////////////////////////////////////////
// CONFIG FUNCTIONS
////////////////////////////////////////////////////////////////////////

function has_security($security_level, $level) {
	if ($security_level == $level) {
		return " selected";
	}
}

function active_directory_component_config_func($mode="",$inargs,&$outargs,&$result) {

	// initialize return code and output
	$result=0;
	$output="";

	$component_name="active_directory";

	switch($mode) {
		case COMPONENT_CONFIGMODE_GETSETTINGSHTML:

			$settings_raw=get_option("active_directory_component_options");
			if($settings_raw=="") {
				$settings=array();
				}
			else
				$settings=unserialize($settings_raw);

			// initial values
			$account_suffix=grab_array_var($settings,"account_suffix","@nagios.com");
			$base_dn=grab_array_var($settings,"base_dn","DC=nagios,DC=com");
			$domain_controllers=grab_array_var($settings,"domain_controllers","dc1.nagios.com");
			$enabled=grab_array_var($settings,"enabled","");
			$security_level=grab_array_var($settings,"security_level","none");
			$port=grab_array_var($settings,"port","389");

			// values passed to us
			$account_suffix=grab_array_var($inargs,"account_suffix",$account_suffix);
			$base_dn=grab_array_var($inargs,"base_dn",$base_dn);
			$domain_controllers=grab_array_var($inargs,"domain_controllers",$domain_controllers);
			$enabled=checkbox_binary(grab_array_var($inargs,"enabled",$enabled));
			$security_level=grab_array_var($inargs,"security_level",$security_level);
			//$port=grab_array_var($inargs,"port",$port);
			//$port=''; 

			$component_url=get_component_url_base($component_name);

			$output='

	<div class="sectionTitle">'.gettext('Active Directory Settings').'</div>

	<table>

	<tr>
		<td valign="top">
			<label for="enabled">'.gettext('Enable Active Directory Authentication').':</label>
			<br class="nobr" />
		</td>
		<td>
			<input type="checkbox" class="checkbox" id="enabled" name="enabled" '.is_checked($enabled,1).'>
			<br class="nobr" />
			'.gettext('Enables test authentication for Nagios XI').'.<br><br>
		</td>
	</tr>

	<tr>
		<td valign="top">
			<label>'.gettext('Account Suffix').':</label>
			<br class="nobr" />
		</td>
		<td>
			<input type="text" size="25" name="account_suffix" id="account_suffix" value="'.htmlentities($account_suffix).'" class="textfield" />
			<br class="nobr" />
			'.gettext('The part of the full user identification after the username, such as').' <i>@nagios.com</i>.
			<br><br>
		</td>
	</tr>

	<tr>
		<td valign="top">
			<label>'.gettext('Base DN').':</label>
			<br class="nobr" />
		</td>
		<td valign="top">
			<input type="text" size="40" name="base_dn" id="base_dn" value="'.htmlentities($base_dn).'" class="textfield" />
			<br class="nobr" />
			'.gettext('The LDAP-format starting object (distinguished name) that your users are defined below, such as').' <i>DC=nagios,DC=com</i>.
			<br><br>
		</td>
	</tr>

	<tr>
		<td valign="top">
			<label>'.gettext('Domain Controllers').':</label>
			<br class="nobr" />
		</td>
		<td valign="top">
			<input type="text" size="80" name="domain_controllers" id="domain_controllers" value="'.htmlentities($domain_controllers).'" class="textfield" />
			<br class="nobr" />
			'.gettext('A comma-separated list of domain controllers on your network.').'
			<br><br>
		</td>
	</tr>
	
	<tr>
		<td valign="top">
			<label>'.gettext('Security').':</label>
			<br class="nobr" />
		</td>
		<td valign="top">
			<select name="security_level" id="security_level">
				<option value="none"'.has_security($security_level, "none").'>'.gettext('None').'</option>
				<option value="ssl"'.has_security($security_level, "ssl").'>SSL</option>
				<!-- Following option uncommented by TJS 1 October 2012 -->
				<option value="tls"'.has_security($security_level, "tls").'>TLS</option>-->
			</select>
			<!--
			<input type="text" size="5" name="port" id="port" value="'.htmlentities($port).'" class="textfield" />
			<br class="nobr" />
			The type of security (if any) and port number to use for the connection to the domain controller.
			<br><br> -->
		</td>
	</tr>

	</table>

			';

			break;

		case COMPONENT_CONFIGMODE_SAVESETTINGS:

			// get variables
			$account_suffix=grab_array_var($inargs,"account_suffix","");
			$base_dn=grab_array_var($inargs,"base_dn","");
			$domain_controllers=grab_array_var($inargs,"domain_controllers","");
			$enabled=checkbox_binary(grab_array_var($inargs,"enabled",""));
			$security_level=grab_array_var($inargs,"security_level","");
			//$port=grab_array_var($inargs,"port","");

			// validate variables
			$errors=0;
			$errmsg=array();
			if($enabled==1){
				if(have_value($account_suffix)==false){
					$errmsg[$errors++]=gettext("No account suffix specified.");
					}
				if(have_value($base_dn)==false){
					$errmsg[$errors++]=gettext("No base Distinguished Name specified.");
					}
				if(have_value($domain_controllers)==false){
					$errmsg[$errors++]=gettext("No domain controllers specified.");
					}
				if(!function_exists('ldap_bind')) {
					$errmsg[$errors++]=gettext("LDAP libraries not installed!  To install them, log into the server, and run 'yum install php-ldap'.");
					}
				/*if ((have_value($port)==false) or ($port > 65535)) {
					$errmsg[$errors++]="No valid port number specified.";
					}*/
				}

			// handle errors
			if($errors>0){
				$outargs[COMPONENT_ERROR_MESSAGES]=$errmsg;
				$result=1;
				return '';
				}

			// save settings
			$settings=array(
				"account_suffix" => $account_suffix,
				"base_dn" => $base_dn,
				"domain_controllers" => $domain_controllers,
				"enabled" => $enabled,
				"security_level" => $security_level
				//"port" => $port
				);
			set_option("active_directory_component_options",serialize($settings));

			break;

		default:
			break;

		}

	return $output;
	}

///////////////////////////////////////////////////////////////////////////////////////////
// AUTHENTICATION FUNCTIONS
///////////////////////////////////////////////////////////////////////////////////////////

function active_directory_component_check_authentication($cbtype,&$cbargs){

	// get the credentials the user is passing to us
	$username=grab_array_var($cbargs["credentials"],"username");
	$password=grab_array_var($cbargs["credentials"],"password");

	// get our settings
	$settings_raw=get_option("active_directory_component_options");
	if($settings_raw=="")
		$settings=array();
	else
		$settings=unserialize($settings_raw);

	// initial values
	$account_suffix=grab_array_var($settings,"account_suffix");
	$base_dn=grab_array_var($settings,"base_dn");
	$domain_controllers=grab_array_var($settings,"domain_controllers");
	$enabled=grab_array_var($settings,"enabled");
	$security_level=grab_array_var($settings,"security_level");
	//$port=grab_array_var($settings,"port");

	// bail out if we're not enabled...
	if($enabled!=1){
		//echo "Active Directory NOT ENABLED<BR>";
		return;
		}

	// bail out if missing libraries...
	if(!function_exists('ldap_bind')) {
		//echo "Missing php-ldap libraries!<BR>";
		return;
		}

	require_once(dirname(__FILE__) . '/adLDAP/adLDAP.php');

	$dc_array = explode('|', preg_replace('/[\,\ \;]+/', '|', $domain_controllers));

	if ($security_level=="ssl") {
		$use_ssl=true;
		$use_tls=false; // 1 Oct 2012 TJS
	} else {
		$use_ssl=false;
	}
	
	// Added by TJS 1 Oct 2012 to attempt TLS support
	if ($security_level=="tls") {
		$use_tls=true;
		$use_ssl=false;
	} else {
		$use_tls=false;
	}
		
	$options = array(
		'account_suffix' => $account_suffix,
		'base_dn' => $base_dn,
		'domain_controllers' => $dc_array,
		'use_ssl' => $use_ssl,
		'use_tls' => $use_tls
		);

	//include the class and create a connection
	try {
		$adldap = new adLDAP($options);
	}
	catch (adLDAPException $e) {
		echo $e; exit();
	}

	// otherwise check authentication
	if ($adldap -> authenticate($username,$password)) {

		// credentials were correct...

		// notify caller of authentication success
		$cbargs["login_ok"]=1;

		// pass back some debug information
		$cbargs["debug_messages"][]=gettext("Active Directory authentication okay!");

		}

	// handle bad authentication
	else{
		// pass back some debug information
		$cbargs["debug_messages"][]=gettext("Active Directory authentication failed - bad username or password.");

		}
	}

?>
