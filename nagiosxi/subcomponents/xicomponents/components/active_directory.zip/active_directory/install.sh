#!/bin/sh

if [ -f $INSTALL_PATH/offline ]; then
	exit 0
else
	#install php-ldap
	yum install php-ldap -y
	exit 0
fi
#should have exited successfully previously
exit 1