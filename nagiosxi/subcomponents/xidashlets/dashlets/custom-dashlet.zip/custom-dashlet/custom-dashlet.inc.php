<?php 
// CUSTOM URL DASHLET 
//
// Copyright (c) 2008-2009 Nagios Enterprises, LLC.  All rights reserved.
//  
// Written by Mike Guthrie

include_once(dirname(__FILE__).'/../dashlethelper.inc.php');

// run the initialization function
custom_dashlet_init();

function custom_dashlet_init(){
	
	$name="custom_dashlet";
	
	$args=array(

		// need a name
		DASHLET_NAME => $name,
		
		// informative information
		DASHLET_VERSION => "1.0",
		DASHLET_DATE => "02-02-2011",
		DASHLET_AUTHOR => "Nagios Enterprises, LLC",
		DASHLET_DESCRIPTION => "Custom URL Dashlet.  Define your own embedded URL, frame size, and opacity.",
		DASHLET_COPYRIGHT => "Copyright (c) 2010 Nagios Enterprises",
		DASHLET_LICENSE => "BSD",
		DASHLET_HOMEPAGE => "www.nagios.com",
		DASHLET_REFRESHRATE => 60,
		
		DASHLET_FUNCTION => "custom_dashlet_func",
		
		DASHLET_TITLE => "Custom URL Dashlet",
		
		DASHLET_OUTBOARD_CLASS=> "custom_outboardclass",
		DASHLET_INBOARD_CLASS => "custom_inboardclass",
		DASHLET_PREVIEW_CLASS => "custom_previewclass",
		
		//DASHLET_CSS_FILE => "custom.css",
		//DASHLET_JS_FILE => "custom.js",

		DASHLET_WIDTH => "300",
		DASHLET_HEIGHT => "200",
		DASHLET_OPACITY => "1.0",
		//DASHLET_BACKGROUND => "",
		);
		
	register_dashlet($name,$args);
	}
	

function custom_dashlet_func($mode=DASHLET_MODE_PREVIEW,$id="",$args=null){


	//$baseurl="http://www.custom.com";

	$output="";
	
	//$imgbase=get_dashlet_url_base("custom")."/images/";

	switch($mode){
		case DASHLET_MODE_GETCONFIGHTML:
			//input form for dashlet vars 
			$output='
			<br/>
			<label for="height">Height</label>
			<br class="nobr" />
			<input type="text" name="height" id="height" />
			<br class="nobr" />
			<label for="width">Width</label>
			<br class="nobr" />
			<input type="text" name="width" id="width" />
			<br class="nobr" />
			
			<label for="url">Dashlet URL</label>
			<br class="nobr" />
			<input type="text" name="url" id="url" value="http://">
			<br class="nobr" />
			
			<label for="opacity">Opacity</label>
			<br class="nobr" />
			<select name="opacity" id="opacity">
			<option value="1.0">100%</option>
			<option value=".75" selected>75%</option>
			<option value=".50">50%</option>
			<option value=".25">25%</option>
			</select>
			<br class="nobr" />
			';  
			break;
		case DASHLET_MODE_OUTBOARD:
		case DASHLET_MODE_INBOARD:
			//vars from input form 
			$height=$args["height"];
			$width=$args["width"];
			$opacity=$args["opacity"];
			$url=urldecode($args["url"]);
			//random dashlet id 
			$rand = rand(); 
			$inWidth = $width-10; //dimensions for iframe 
			$inHeight = $height-50;
			//html output  (heredoc string syntax)  			
			$output=<<<OUTPUT
			<div id='customdashlet{$rand}'>
					<iframe id='dashletIframe{$rand}' src='{$url}'></iframe>			
				</div>
			<script type="text/javascript">
			
			//DO NOT MODIFY
			var dashcontainer = $('#customdashlet{$rand}').parent().parent(); 
			var innercontainer = $('#customdashlet{$rand}').parent(); 
			
			//set specified size on page load.  Overrides hardcoded settings.  
			$(document).ready( function() {
			   //do stuff on load 
			   innercontainer.css('height', '{$inHeight}px')
							.css('width', '{$width}px')
							.css('opacity', '{$opacity}'); 
										
			   dashcontainer.css('height', '{$height}px')
							.css('width', '{$width}px'); 
							
				$('#customdashlet{$rand}').width({$width}).height({$inHeight});
				$('#dashletIframe{$rand}').width({$inWidth}).height({$inHeight});
			  
			}); 
			
			//bind resize handlers to div and iframe  

			
			dashcontainer.resize(function() {
				newHeight = $(this).height();				
				newWidth = $(this).width(); 

				//innercontainer.width(newWidth).height(newHeight);
				//$('#customdashlet{$rand}').width(newWidth).height(newHeight);
				$('#dashletIframe{$rand}').width(newWidth-10).height(newHeight-50);
			}); 	
			
			</script>
OUTPUT;


			
			
			break;
		case DASHLET_MODE_PREVIEW:
			$output="<img src='/nagiosxi/includes/dashlets/custom-dashlet/preview.png' alt='No Preview Available' />";
			break;			
		}
		
	return $output;
	}


?>