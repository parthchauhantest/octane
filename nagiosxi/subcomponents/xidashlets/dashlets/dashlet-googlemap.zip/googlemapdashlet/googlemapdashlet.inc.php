<?php
// GOOGLE MAP DASHLET
//
// Copyright (c) 2008-2009 Nagios Enterprises, LLC.  All rights reserved.
//  
// $Id: googlemapdashlet.inc.php 75 2010-04-01 19:40:08Z mguthrie $

include_once(dirname(__FILE__).'/../dashlethelper.inc.php');

// run the initialization function
googlemap_dashlet_init();

function googlemap_dashlet_init(){
	global $googlemap_component_name;
	
	
	// respect the name!
	$name="googlemapdashlet";
	
	$args=array(

		// need a name
		DASHLET_NAME => $name,
		
		// informative information
		DASHLET_VERSION => "1.1",
		DASHLET_DATE => "07-21-2010",
		DASHLET_AUTHOR => "Nagios Enterprises, LLC",
		DASHLET_DESCRIPTION => "A dashlet that displays host status as an overlay on a google map. REQUIRES <a href='http://assets.nagios.com/downloads/nagiosxi/components/googlemap.zip'>XI Google Map component</a> be installed under Manage Components",
		DASHLET_COPYRIGHT => "Copyright (c) 2009 Nagios Enterprises",
		DASHLET_LICENSE => "BSD",
		DASHLET_HOMEPAGE => "http://www.nagios.com",
		
		// the good stuff - only one output method is used.  order of preference is 1) function, 2) url
		//DASHLET_FUNCTION => "testhtml_dashlet_func",
		DASHLET_URL => get_component_url_base($googlemap_component_name).'/map.php',
		//dashlet folder loc: /usr/local/nagiosxi/html/includes/dashlets/googlemap/(this)
		//component folder loc: /usr/local/nagiosxi/html/includes/dashlets/googlemap/map.php
		DASHLET_PREVIEW_IMAGE => get_dashlet_url_base($name)."/thumbnail.jpg",
			
		
		DASHLET_TITLE => "Google Map",
		
		DASHLET_OUTBOARD_CLASS => "googlemap_outboardclass",
		DASHLET_INBOARD_CLASS => "googlemap_inboardclass",
		DASHLET_PREVIEW_CLASS => "googlemap_previewclass",
		
	

		DASHLET_WIDTH => "350px",
		DASHLET_HEIGHT => "350px",
		DASHLET_OPACITY => "0.8",
		DASHLET_BACKGROUND => "",

//		DASHLET_REFRESHRATE => -1,
		);
	register_dashlet($name,$args);
	}
	

?>