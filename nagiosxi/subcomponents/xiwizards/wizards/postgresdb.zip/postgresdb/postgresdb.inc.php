<?php
// POSTGRES DB CONFIG WIZARD
//
// Copyright (c) 2010 Nagios Enterprises, LLC.  All rights reserved.
//  
// $Id: postgresdb.inc.php 1115 2013-08-26 17:47:35Z swilkerson $

include_once(dirname(__FILE__).'/../configwizardhelper.inc.php');

// run the initialization function
postgresdb_configwizard_init();

function postgresdb_configwizard_init(){

	$name="postgresdb";
	
	$args=array(
		CONFIGWIZARD_NAME => $name,
        CONFIGWIZARD_VERSION => "1.3",
		CONFIGWIZARD_TYPE => CONFIGWIZARD_TYPE_MONITORING,
		CONFIGWIZARD_DESCRIPTION => gettext("Monitor a Postgres database."),
		CONFIGWIZARD_DISPLAYTITLE => gettext("Postgres Database"),
		CONFIGWIZARD_FUNCTION => "postgresdb_configwizard_func",
		CONFIGWIZARD_PREVIEWIMAGE => "postgres.png",
		);
		
	register_configwizard($name,$args);
	}



function postgresdb_configwizard_func($mode="",$inargs=null,&$outargs,&$result){

	$wizard_name="postgresdb";
	
	// initialize return code and output
	$result=0;
	$output="";
	
	// initialize output args - pass back the same data we got
	$outargs[CONFIGWIZARD_PASSBACK_DATA]=$inargs;


	switch($mode){
		case CONFIGWIZARD_MODE_GETSTAGE1HTML:
		
			$address=grab_array_var($inargs,"address","");
			$port=grab_array_var($inargs,"port","5432");
			$username=grab_array_var($inargs,"username","postgres");
			$password=grab_array_var($inargs,"password","");
			$database=grab_array_var($inargs,"database","postgres");
			
			$output='

	<div class="sectionTitle">'.gettext('Postgres Database').'</div>
	
	<p>
	'.gettext('Specify the details for connecting to the Postgres database you want to monitor.').'
	</p>
			
	<table>

	<tr>
	<td valign="top">
	<label>'.gettext('Address:').'</label><br class="nobr" />
	</td>
	<td>
<input type="text" size="40" name="address" id="address" value="'.htmlentities($address).'" class="textfield" /><br class="nobr" />
	'.gettext('The IP address or FQDNS name of the Postgres server.').'<br><br>
	</td>
	</tr>
	
	<tr>
	<td valign="top">
	<label>'.gettext('Port:').'</label><br class="nobr" />
	</td>
	<td>
<input type="text" size="5" name="port" id="port" value="'.htmlentities($port).'" class="textfield" /><br class="nobr" />
	'.gettext('The port to use to connect to the Postgres server.').'<br><br>
	</td>
	</tr>

	<tr>
	<td valign="top">
	<label>'.gettext('Username').':</label><br class="nobr" />
	</td>
	<td>
<input type="text" size="20" name="username" id="username" value="'.htmlentities($username).'" class="textfield" /><br class="nobr" />
	'.gettext('The username used to connect to the Postgres server.').'<br><br>
	</td>
	</tr>

	<tr>
	<td valign="top">
	<label>'.gettext('Password').':</label><br class="nobr" />
	</td>
	<td>
<input type="password" size="20" name="password" id="password" value="'.htmlentities($password).'" class="textfield" /><br class="nobr" />
	'.gettext('The password used to connect to the Postgres server.').'<br><br>
	</td>
	</tr>

	<tr>
	<td valign="top">
	<label>'.gettext('Database').':</label><br class="nobr" />
	</td>
	<td>
<input type="text" size="20" name="database" id="database" value="'.htmlentities($database).'" class="textfield" /><br class="nobr" />
	'.gettext('The database to connect to on the Postgres server.').'<br><br>
	</td>
	</tr>


	</table>

			';
			break;
			
		case CONFIGWIZARD_MODE_VALIDATESTAGE1DATA:
		
			// get variables that were passed to us
			$address=grab_array_var($inargs,"address","");
			$port=grab_array_var($inargs,"port","");
			$username=grab_array_var($inargs,"username","");
			$password=grab_array_var($inargs,"password","");
			$database=grab_array_var($inargs,"database","");
			
			// check for errors
			$errors=0;
			$errmsg=array();
			if(have_value($address)==false)
				$errmsg[$errors++]=gettext("No address specified.");
			if(have_value($port)==false)
				$errmsg[$errors++]=gettext("No port number specified.");				
			if(have_value($username)==false)
				$errmsg[$errors++]=gettext("No username specified.");
			//if(have_value($password)==false)
			//	$errmsg[$errors++]="No password specified.";
			if(have_value($database)==false)
				$errmsg[$errors++]=gettext("No database specified.");
				
			if($errors>0){
				$outargs[CONFIGWIZARD_ERROR_MESSAGES]=$errmsg;
				$result=1;
				}
				
			break;
			
		case CONFIGWIZARD_MODE_GETSTAGE2HTML:
		
			// get variables that were passed to us
			$address=grab_array_var($inargs,"address");
			$port=grab_array_var($inargs,"port","");
			$username=grab_array_var($inargs,"username","");
			$password=grab_array_var($inargs,"password","");
			$database=grab_array_var($inargs,"database","");

			$ha=@gethostbyaddr($address);
			if($ha=="")
				$ha=$address;
			$hostname=grab_array_var($inargs,"hostname",$ha);
			
		
			$services="";
			$services_default=array(
				"connection"=>"on",
				"database_size" => "on",
				"table_sizes"=>"on",
				"relation_sizes"=>"on",
				"sequences"=>"on",
				);
		
			$services_serial=grab_array_var($inargs,"services_serial");
			if($services_serial!="")
				$services=unserialize(base64_decode($services_serial));
			if(!is_array($services))
				$services=grab_array_var($inargs,"services",$services_default);
				
			$serviceargs="";
			$serviceargs_default=array(
				"database_size_warning"=>"500MB",
				"database_size_critical"=>"1GB",
				"table_sizes_warning"=>"200MB",
				"table_sizes_critical"=>"400MB",
				"relation_sizes_warning"=>"50MB",
				"relation_sizes_critical"=>"100MB",
				"sequences_warning"=>"30%",
				"sequences_critical"=>"10%",
				);
					
			
			$serviceargs_serial=grab_array_var($inargs,"serviceargs_serial");
			if($serviceargs_serial!=""){
				//echo "ARGSSERIAL: $serviceargs_serial<BR>\n";
				$serviceargs=unserialize(base64_decode($serviceargs_serial));
				}
			if(!is_array($serviceargs))
				$serviceargs=grab_array_var($inargs,"serviceargs",$serviceargs_default);

		
			$output='
			
		<input type="hidden" name="address" value="'.htmlentities($address).'">
		<input type="hidden" name="port" value="'.htmlentities($port).'">
		<input type="hidden" name="username" value="'.htmlentities($username).'">
		<input type="hidden" name="password" value="'.htmlentities($password).'">
		<input type="hidden" name="database" value="'.htmlentities($database).'">

	<div class="sectionTitle">Postgres Server</div>
	
			
	<table>
	
	<tr>
	<td valign="top">
	<label>'.gettext('Address').':</label><br class="nobr" />
	</td>
	<td>
<input type="text" size="20" name="address" id="address" value="'.htmlentities($address).'" class="textfield" disabled/><br class="nobr" />
	</td>
	</tr>

	<tr>
	<td valign="top">
	<label>'.gettext('Host Name:').'</label><br class="nobr" />
	</td>
	<td>
<input type="text" size="20" name="hostname" id="hostname" value="'.htmlentities($hostname).'" class="textfield" /><br class="nobr" />
	'.gettext('The name you\'d like to have associated with this Postgres server.').'
	</td>
	</tr>
	
	<tr>
	<td valign="top">
	<label>'.gettext('Port').':</label><br class="nobr" />
	</td>
	<td>
<input type="text" size="5" name="port" id="port" value="'.htmlentities($port).'" class="textfield" disabled/><br class="nobr" />
	</td>
	</tr>

	<tr>
	<td valign="top">
	<label>'.gettext('Username').':</label><br class="nobr" />
	</td>
	<td>
<input type="text" size="20" name="username" id="username" value="'.htmlentities($username).'" class="textfield" disabled/><br class="nobr" />
	</td>
	</tr>

	<tr>
	<td valign="top">
	<label>'.gettext('Password').':</label><br class="nobr" />
	</td>
	<td>
<input type="password" size="20" name="password" id="password" value="'.htmlentities($password).'" class="textfield" disabled/><br class="nobr" />
	</td>
	</tr>

	<tr>
	<td valign="top">
	<label>'.gettext('Database').':</label><br class="nobr" />
	</td>
	<td>
<input type="text" size="20" name="database" id="database" value="'.htmlentities($database).'" class="textfield" disabled/><br class="nobr" />
	</td>
	</tr>

	</table>


	<div class="sectionTitle">'.gettext('Postgres Database Metrics').'</div>
	
	<p>'.gettext('Specify the metrics you\'d like to monitor for the Postgres database.').'</p>
	
	
	<table>
	
	<tr>
	<td valign="top">
	<input type="checkbox" class="checkbox" name="services[connection]" '.is_checked(grab_array_var($services,"connection"),"on").'>
	</td>
	<td>
	<b>'.gettext('Connection Status').'</b><br> 
	'.gettext('Monitor the ability to connect to the database.').'<br><br>
	</td>
	</tr>

	<tr>
	<td valign="top">
	<input type="checkbox" class="checkbox" name="services[database_size]" '.is_checked(grab_array_var($services,"database_size"),"on").'>
	</td>
	<td>
	<b>'.gettext('Database Size').'</b><br> 
	'.gettext('Monitor the size of the database').'.<br>
	<label>'.gettext('Warning Threshold:').'</label> <input type="text" size="5" name="serviceargs[database_size_warning]" value="'.htmlentities($serviceargs["database_size_warning"]).'">&nbsp;&nbsp;<label>'.gettext('Critical Threshold:').'</label> <input type="text" size="5" name="serviceargs[database_size_critical]" value="'.htmlentities($serviceargs["database_size_critical"]).'"><br><br>
	</td>
	</tr>	

	<tr>
	<td valign="top">
	<input type="checkbox" class="checkbox" name="services[table_sizes]" '.is_checked(grab_array_var($services,"table_sizes"),"on").'>
	</td>
	<td>
	<b>'.gettext('Table Sizes').'</b><br> 
	'.gettext('Monitor the size of the tables in the database.').'<br>
	<label>'.gettext('Warning Threshold:').'</label> <input type="text" size="5" name="serviceargs[table_sizes_warning]" value="'.htmlentities($serviceargs["table_sizes_warning"]).'">&nbsp;&nbsp;<label>'.gettext('Critical Threshold:').'</label> <input type="text" size="5" name="serviceargs[table_sizes_critical]" value="'.htmlentities($serviceargs["table_sizes_critical"]).'"><br><br>
	</td>
	</tr>	


	<tr>
	<td valign="top">
	<input type="checkbox" class="checkbox" name="services[relation_sizes]" '.is_checked(grab_array_var($services,"relation_sizes"),"on").'>
	</td>
	<td>
	<b>'.gettext('Relation Sizes').'</b><br> 
	'.gettext('Monitor the size of the relations in the database.').'<br>
	<label>'.gettext('Warning Threshold:').'</label> <input type="text" size="5" name="serviceargs[relation_sizes_warning]" value="'.htmlentities($serviceargs["relation_sizes_warning"]).'">&nbsp;&nbsp;<label>'.gettext('Critical Threshold:').'</label> <input type="text" size="5" name="serviceargs[relation_sizes_critical]" value="'.htmlentities($serviceargs["relation_sizes_critical"]).'"><br><br>
	</td>
	</tr>	

	<tr>
	<td valign="top">
	<input type="checkbox" class="checkbox" name="services[sequences]" '.is_checked(grab_array_var($services,"sequences"),"on").'>
	</td>
	<td>
	<b>'.gettext('Sequences').'</b><br> 
	'.gettext('Monitor the percent of remaining sequences in the database.').'<br>
	<label>'.gettext('Warning Threshold:').'</label> <input type="text" size="3" name="serviceargs[sequences_warning]" value="'.htmlentities($serviceargs["sequences_warning"]).'">&nbsp;&nbsp;<label>'.gettext('Critical Threshold:').'</label> <input type="text" size="2" name="serviceargs[sequences_critical]" value="'.htmlentities($serviceargs["sequences_critical"]).'"><br><br>
	</td>
	</tr>	

	</table>
	';
			break;
			
		case CONFIGWIZARD_MODE_VALIDATESTAGE2DATA:
		
			// get variables that were passed to us
			$address=grab_array_var($inargs,"address");
			$hostname=grab_array_var($inargs,"hostname");
			$port=grab_array_var($inargs,"port","");
			$username=grab_array_var($inargs,"username","");
			$password=grab_array_var($inargs,"password","");
			$database=grab_array_var($inargs,"database","");
				
			$services=grab_array_var($inargs,"services",array());
			$serviceargs=grab_array_var($inargs,"serviceargs",array());
			
		
			// check for errors
			$errors=0;
			$errmsg=array();
			if(is_valid_host_name($hostname)==false)
				$errmsg[$errors++]=gettext("Invalid host name.");
				
			if($errors>0){
				$outargs[CONFIGWIZARD_ERROR_MESSAGES]=$errmsg;
				$result=1;
				}
				
			break;

			
		case CONFIGWIZARD_MODE_GETSTAGE3HTML:
		
			// get variables that were passed to us
			$address=grab_array_var($inargs,"address");
			$hostname=grab_array_var($inargs,"hostname");
			$port=grab_array_var($inargs,"port","");
			$username=grab_array_var($inargs,"username","");
			$password=grab_array_var($inargs,"password","");
			$database=grab_array_var($inargs,"database","");
			
			$services_serial=grab_array_var($inargs,"services_serial");
			if($services_serial!="")
				$services=unserialize(base64_decode($services_serial));
			else
				$services=grab_array_var($inargs,"services");
			$serviceargs_serial=grab_array_var($inargs,"serviceargs_serial");
			if($serviceargs_serial!="")
				$serviceargs=unserialize(base64_decode($serviceargs_serial));
			else
				$serviceargs=grab_array_var($inargs,"serviceargs");
		
			$output='
			
		<input type="hidden" name="address" value="'.htmlentities($address).'">
		<input type="hidden" name="hostname" value="'.htmlentities($hostname).'">
		<input type="hidden" name="port" value="'.htmlentities($port).'">
		<input type="hidden" name="username" value="'.htmlentities($username).'">
		<input type="hidden" name="password" value="'.htmlentities($password).'">
		<input type="hidden" name="database" value="'.htmlentities($database).'">
		<input type="hidden" name="services_serial" value="'.base64_encode(serialize($services)).'">
		<input type="hidden" name="serviceargs_serial" value="'.base64_encode(serialize($serviceargs)).'">
		
		<!--SERVICES='.serialize($services).'<BR>
		SERVICEARGS='.serialize($serviceargs).'<BR>-->
		
			';
			break;
			
		case CONFIGWIZARD_MODE_VALIDATESTAGE3DATA:
				
			break;
			
		case CONFIGWIZARD_MODE_GETFINALSTAGEHTML:
			
			
			$output='
			';
			break;
			
		case CONFIGWIZARD_MODE_GETOBJECTS:
		
			$hostname=grab_array_var($inargs,"hostname","");
			$address=grab_array_var($inargs,"address","");
			$hostaddress=$address;
			$port=grab_array_var($inargs,"port","");
			$username=grab_array_var($inargs,"username","");
			$password=grab_array_var($inargs,"password","");
			$database=grab_array_var($inargs,"database","");
		
			$services_serial=grab_array_var($inargs,"services_serial","");
			$serviceargs_serial=grab_array_var($inargs,"serviceargs_serial","");
			
			$services=unserialize(base64_decode($services_serial));
			$serviceargs=unserialize(base64_decode($serviceargs_serial));
			
			/*
			echo "SERVICES<BR>";
			print_r($services);
			echo "<BR>";
			echo "SERVICEARGS<BR>";
			print_r($serviceargs);
			echo "<BR>";
			*/
			
			// save data for later use in re-entrance
			$meta_arr=array();
			$meta_arr["hostname"]=$hostname;
			$meta_arr["address"]=$address;
			$meta_arr["port"]=$port;
			$meta_arr["username"]=$username;
			$meta_arr["password"]=$password;
			$meta_arr["database"]=$database;
			$meta_arr["services"]=$services;
			$meta_arr["serivceargs"]=$serviceargs;
			save_configwizard_object_meta($wizard_name,$hostname,"",$meta_arr);			
			
			$objs=array();
			
			if(!host_exists($hostname)){
				$objs[]=array(
					"type" => OBJECTTYPE_HOST,
					"use" => "xiwizard_postgresdb_host",
					"host_name" => $hostname,
					"address" => $hostaddress,
					"icon_image" => "postgres.png",
					"statusmap_image" => "postgres.png",
					"_xiwizard" => $wizard_name,
					);
				}
			
			$commonopts="-H ".$address." --port=".$port." --dbuser=".$username." --dbname=".$database." ";

			foreach($services as $svcvar => $svcval){
			
				$pluginopts="";
				$pluginopts.=$commonopts;
                
                if($password!="")
                    $pluginopts.=" --dbpass=\"".$password."\"";
			
				switch($svcvar){
								
					case "connection":
					
						$pluginopts.="--action=connection";
					
						$objs[]=array(
							"type" => OBJECTTYPE_SERVICE,
							"host_name" => $hostname,
							"service_description" => "Postgres Database Connection - ".$database,
							"use" => "xiwizard_postgresdb_service",
							"check_command" => "check_xi_postgres_db!".$pluginopts,
							"_xiwizard" => $wizard_name,
							);
						break;
								
					case "database_size":
					
						$pluginopts.=" --action=database_size";
						if($serviceargs["database_size_warning"]!="")
							$pluginopts.=" --warning=".$serviceargs["database_size_warning"]."";
						if($serviceargs["database_size_critical"]!="")
							$pluginopts.=" --critical=".$serviceargs["database_size_critical"]."";
					
						$objs[]=array(
							"type" => OBJECTTYPE_SERVICE,
							"host_name" => $hostname,
							"service_description" => "Postgres Database Size - ".$database,
							"use" => "xiwizard_postgresdb_service",
							"check_command" => "check_xi_postgres_db!".$pluginopts,
							"_xiwizard" => $wizard_name,
							);
						break;
								
					case "table_sizes":
					
						$pluginopts.=" --action=table_size";
						if($serviceargs["table_sizes_warning"]!="")
							$pluginopts.=" --warning=".$serviceargs["table_sizes_warning"]."";
						if($serviceargs["table_sizes_critical"]!="")
							$pluginopts.=" --critical=".$serviceargs["table_sizes_critical"]."";
					
						$objs[]=array(
							"type" => OBJECTTYPE_SERVICE,
							"host_name" => $hostname,
							"service_description" => "Postgres Table Sizes - ".$database,
							"use" => "xiwizard_postgresdb_service",
							"check_command" => "check_xi_postgres_db!".$pluginopts,
							"_xiwizard" => $wizard_name,
							);
						break;
								
					case "relation_sizes":
					
						$pluginopts.=" --action=relation_size";
						if($serviceargs["relation_sizes_warning"]!="")
							$pluginopts.=" --warning=".$serviceargs["relation_sizes_warning"]."";
						if($serviceargs["relation_sizes_critical"]!="")
							$pluginopts.=" --critical=".$serviceargs["relation_sizes_critical"]."";
					
						$objs[]=array(
							"type" => OBJECTTYPE_SERVICE,
							"host_name" => $hostname,
							"service_description" => "Postgres Table Sizes - ".$database,
							"use" => "xiwizard_postgresdb_service",
							"check_command" => "check_xi_postgres_db!".$pluginopts,
							"_xiwizard" => $wizard_name,
							);
						break;
								
					case "sequences":
					
						$pluginopts.=" --action=sequence";
						if($serviceargs["sequences_warning"]!="")
							$pluginopts.=" --warning=".$serviceargs["sequences_warning"]."";
						if($serviceargs["sequences_critical"]!="")
							$pluginopts.=" --critical=".$serviceargs["sequences_critical"]."";
					
						$objs[]=array(
							"type" => OBJECTTYPE_SERVICE,
							"host_name" => $hostname,
							"service_description" => "Postgres Database Sequences - ".$database,
							"use" => "xiwizard_postgresdb_service",
							"check_command" => "check_xi_postgres_db!".$pluginopts,
							"_xiwizard" => $wizard_name,
							);
						break;
								

					default:
						break;
					}
				}
				
			//echo "OBJECTS:<BR>";
			//print_r($objs);
			//exit();
					
			// return the object definitions to the wizard
			$outargs[CONFIGWIZARD_NAGIOS_OBJECTS]=$objs;
		
			break;
			
		default:
			break;			
		}
		
	return $output;
	}
	

?>