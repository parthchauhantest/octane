<?php
// WINDOWS WMI CONFIG WIZARD
//
// Copyright (c) 2011 Nagios Enterprises, LLC.  All rights reserved.
//  
// $Id: windowswmi.inc.php 1137 2013-10-22 21:38:50Z swilkerson $

include_once(dirname(__FILE__).'/../configwizardhelper.inc.php');

// run the initialization function
windowswmi_configwizard_init();

function windowswmi_configwizard_init(){
	
	$name="windowswmi";
	
	$args=array(
		CONFIGWIZARD_NAME => $name,
        CONFIGWIZARD_VERSION => "1.5",
		CONFIGWIZARD_TYPE => CONFIGWIZARD_TYPE_MONITORING,
		CONFIGWIZARD_DESCRIPTION => gettext("Monitor a Microsoft&reg; Windows workstation or server using WMI."),
		CONFIGWIZARD_DISPLAYTITLE => gettext("Windows WMI"),
		CONFIGWIZARD_FUNCTION => "windowswmi_configwizard_func",
		CONFIGWIZARD_PREVIEWIMAGE => "win_server.png",
		);
		
	register_configwizard($name,$args);
	}



function windowswmi_configwizard_func($mode="",$inargs=null,&$outargs,&$result){

	$wizard_name="windowswmi";
	

	// initialize return code and output
	$result=0;
	$output="";
	
	// initialize output args - pass back the same data we got
	$outargs[CONFIGWIZARD_PASSBACK_DATA]=$inargs;


	switch($mode){
		case CONFIGWIZARD_MODE_GETSTAGE1HTML:
		
			$address=grab_array_var($inargs,"address","");
			$username=grab_array_var($inargs,"username","");
			$password=grab_array_var($inargs,"password","");
			
			//bail now if wmic is not installed 
			if(!file_exists('/usr/bin/wmic')) {
				$output='<div>
					<span style="color:red;">
						'.gettext('WARNING: wmic binary has not been installed.').'</span> '.gettext('See documentation on').'
						<a href="http://assets.nagios.com/downloads/nagiosxi/docs/Installing_The_WMI_Client_For_XI.pdf" title="WMI Documentation" target="_blank">'.gettext('Installing WMI').'</a></div>';
				break; 		
			}
			
			$output='

	<div class="sectionTitle">'.gettext('Windows Machine Information').'</div>
	
			
	<table>
	<tr>
	<td valign="top">
	<label>'.gettext('IP Address:').'</label><br class="nobr" />
	</td>
	<td>
<input type="text" size="40" name="address" id="address" value="'.htmlentities($address).'" class="textfield" /><br class="nobr" />
	'.gettext('The IP address of the Windows machine you\'d like to monitor.').'
	</td>
	</tr>

	<tr>
	<td valign="top">
	<label>'.gettext('Username:').'</label><br class="nobr" />
	</td>
	<td>
<input type="text" size="25" name="username" id="username" value="'.htmlentities($username).'" class="textfield" /><br class="nobr" />
	'.gettext('The username used to connect to the Windows machine.').'
	</td>
	</tr>

	<tr>
	<td valign="top">
	<label>'.gettext('Password:').'</label><br class="nobr" />
	</td>
	<td>
<input type="password" size="15" name="password" id="password" value="'.htmlentities($password).'" class="textfield" /><br class="nobr" />
	'.gettext('The password used to authenticate to the Windows machine. ').'
	</td>
	</tr>

	</table>
			';
			break;
			
		case CONFIGWIZARD_MODE_VALIDATESTAGE1DATA:
		
			// get variables that were passed to us
			$address=grab_array_var($inargs,"address","");
			$username=grab_array_var($inargs,"username","");
			$password=grab_array_var($inargs,"password","");
			
			
			// check for errors
			$errors=0;
			$errmsg=array();
			//$errmsg[$errors++]="Address: '$address'";
			if(have_value($address)==false)
				$errmsg[$errors++]=gettext("No address specified.");
			else if(!valid_ip($address))
				$errmsg[$errors++]=gettext("Invalid IP address.");
			if(have_value($username)==false)
				$errmsg[$errors++]=gettext("No username specified.");
			if(have_value($password)==false)
				$errmsg[$errors++]=gettext("No password specified.");
				
			if($errors>0){
				$outargs[CONFIGWIZARD_ERROR_MESSAGES]=$errmsg;
				$result=1;
				}
				
			break;
			
		case CONFIGWIZARD_MODE_GETSTAGE2HTML:
		
			// get variables that were passed to us
			$address=grab_array_var($inargs,"address");
			$username=grab_array_var($inargs,"username","");
			$password=grab_array_var($inargs,"password","");

			$services="";			
			$services_serial=grab_array_var($inargs,"services_serial","");
			if($services_serial!="")
				$services=unserialize(base64_decode($services_serial));
			if(!is_array($services)){
				$services_default=array(
					"ping" => 1,
					"cpu" => 1,
					"memory" => 1,
					"pagefile" => 1,
					"disk" => 1,
					);
				$services=grab_array_var($inargs,"services",$services_default);
				}
			
			$serviceargs="";
			$serviceargs_serial=grab_array_var($inargs,"serviceargs_serial","");
			if($serviceargs_serial!="")
				$serviceargs=unserialize(base64_decode($serviceargs_serial));
			if(!is_array($serviceargs)){
				$serviceargs_default=array(
					"cpu_warning" => 80,
					"cpu_critical" => 90,
					"memory_warning" => 80,
					"memory_critical" => 90,
					"pagefile_warning" => 80,
					"pagefile_critical" => 90,
					);
				for($x=0;$x<5;$x++){
					$serviceargs_default["disk_warning"][$x]=80;
					$serviceargs_default["disk_critical"][$x]=95;
					$serviceargs_default["disk"][$x]=($x==0)?"C":"";
					}
				for($x=0;$x<4;$x++){
					if($x==0){
						$serviceargs_default['processstate'][$x]['process']='Explorer.exe';
						$serviceargs_default['processstate'][$x]['name']='Explorer';
                        $services["processstate"][$x]=""; // defaults for checkboxes, enter on to be checked by default
						}
					else{
						$serviceargs_default['processstate'][$x]['process']='';
						$serviceargs_default['processstate'][$x]['name']='';
                        $services["processstate"][$x]=""; // defaults for checkboxes, enter on to be checked by default
		
						}
					}

				for($x=0;$x<4;$x++){
					if($x==0){
						$serviceargs_default['servicestate'][$x]['service']="W3SVC";
						$serviceargs_default['servicestate'][$x]['name']="IIS Web Server";
                        $services["servicestate"][$x]=""; // defaults for checkboxes, enter on to be checked by default
						}
					elseif($x==1){
						$serviceargs_default['servicestate'][$x]['service']="MSSQLSERVER";
						$serviceargs_default['servicestate'][$x]['name']="SQL Server";
                        $services["servicestate"][$x]=""; // defaults for checkboxes, enter on to be checked by default
						}
                    else{
						$serviceargs_default['servicestate'][$x]['service']="";
						$serviceargs_default['servicestate'][$x]['name']="";
                        $services["servicestate"][$x]=""; // defaults for checkboxes, enter on to be checked by default
						}
					}
					
				for($x=0;$x<5;$x++){
					if($x==0){
						$serviceargs_default['eventlog'][$x]['log']='System';
						$serviceargs_default['eventlog'][$x]['name']='System Log Critical Errors';
						$serviceargs_default['eventlog'][$x]['severity']=1;
						$serviceargs_default['eventlog'][$x]['hours']=1;
						$serviceargs_default['eventlog'][$x]['warning']='';
						$serviceargs_default['eventlog'][$x]['critical']='';
                        $services["eventlog"][$x]=""; // defaults for checkboxes, enter on to be checked by default
						}
					else if($x==1){
						$serviceargs_default['eventlog'][$x]['log']='Application';
						$serviceargs_default['eventlog'][$x]['name']='Application Log Warnings';
						$serviceargs_default['eventlog'][$x]['severity']=2;
						$serviceargs_default['eventlog'][$x]['hours']=1;
						$serviceargs_default['eventlog'][$x]['warning']='';
						$serviceargs_default['eventlog'][$x]['critical']='';
                        $services["eventlog"][$x]=""; // defaults for checkboxes, enter on to be checked by default
						}
                    else{
						$serviceargs_default['eventlog'][$x]['log']='';
						$serviceargs_default['eventlog'][$x]['name']='';
						$serviceargs_default['eventlog'][$x]['severity']='';
						$serviceargs_default['eventlog'][$x]['hours']='';
						$serviceargs_default['eventlog'][$x]['warning']='';
						$serviceargs_default['eventlog'][$x]['critical']='';
                        $services["eventlog"][$x]=""; // defaults for checkboxes, enter on to be checked by default
						}
					}

				$serviceargs=grab_array_var($inargs,"serviceargs",$serviceargs_default);
				}

			$hostname=grab_array_var($inargs,"hostname",gethostbyaddr($address));
			

			$output='
			
			
		<input type="hidden" name="address" value="'.htmlentities($address).'">
		<input type="hidden" name="username" value="'.htmlentities($username).'">
		<input type="hidden" name="password" value="'.htmlentities($password).'">

	<div class="sectionTitle">'.gettext('Windows Machine Details').'</div>
	
	<table>

	<tr>
	<td>
	<label>'.gettext('IP Address:').'</label><br class="nobr" />
	</td>
	<td>
<input type="text" size="40" name="address" id="address" value="'.htmlentities($address).'" class="textfield" disabled/><br class="nobr" />
	</td>
	</tr>

	<tr>
	<td>
	<label>'.gettext('Host Name:').'</label><br class="nobr" />
	</td>
	<td>
<input type="text" size="20" name="hostname" id="hostname" value="'.htmlentities($hostname).'" class="textfield" /><br class="nobr" />
	'.gettext('The name you\'d like to have associated with this Windows machine.').'
	</td>
	</tr>

	</table>


	<div class="sectionTitle">'.gettext('Server Metrics').'</div>
	
	<p>'.gettext('Specify which services you\'d like to monitor for the Windows machine.').'</p>
	
	<table>

	<tr>
	<td valign="top">
	<input type="checkbox" class="checkbox" name="services[ping]" '.is_checked($services["ping"],"1").'>
	</td>
	<td>
	<b>'.gettext('Ping').'</b><br>
	'.gettext('Monitors the machine with an ICMP "ping".  Useful for watching network latency and general uptime.').'<br><br>
	</td>
	</tr>

	<tr>
	<td valign="top">
	<input type="checkbox" class="checkbox" name="services[cpu]" '.is_checked($services["cpu"],"1").'>
	</td>
	<td>
	<b>'.gettext('CPU').'</b><br>
	'.gettext('Monitors the CPU (processor usage) on the machine.').'<br>
	<label>'.gettext('Warning Load').':</label> <input type="text" size="2" name="serviceargs[cpu_warning]" value="'.htmlentities($serviceargs["cpu_warning"]).'" class="textfield" />%
	<label>'.gettext('Critical Load').':</label> <input type="text" size="2" name="serviceargs[cpu_critical]" value="'.htmlentities($serviceargs["cpu_critical"]).'" class="textfield" />%<br><br>
	</td>
	</tr>

	<tr>
	<td valign="top">
	<input type="checkbox" class="checkbox" name="services[memory]" '.is_checked($services["memory"],"1").'>
	</td>
	<td>
	<b>'.gettext('Memory Usage').'</b><br>
	'.gettext('Monitors the memory usage on the machine.').'<br>
	<label>'.gettext('Warning Usage').':</label> <input type="text" size="2" name="serviceargs[memory_warning]" value="'.htmlentities($serviceargs["memory_warning"]).'" class="textfield" />%
	<label>'.gettext('Critical Usage').':</label> <input type="text" size="2" name="serviceargs[memory_critical]" value="'.htmlentities($serviceargs["memory_critical"]).'" class="textfield" />%<br><br>
	</td>
	</tr>

	<tr>
	<td valign="top">
	<input type="checkbox" class="checkbox" name="services[pagefile]" '.is_checked($services["pagefile"],"1").'>
	</td>
	<td>
	<b>'.gettext('Page File Usage').'</b><br>
	'.gettext('Monitors the page file usage on the machine.').'<br>
	<label>'.gettext('Warning Usage').':</label> <input type="text" size="2" name="serviceargs[pagefile_warning]" value="'.htmlentities($serviceargs["pagefile_warning"]).'" class="textfield" />%
	<label>'.gettext('Critical Usage').':</label> <input type="text" size="2" name="serviceargs[pagefile_critical]" value="'.htmlentities($serviceargs["pagefile_critical"]).'" class="textfield" />%<br><br>
	</td>
	</tr>

	<tr>
	<td valign="top">
	<input type="checkbox" class="checkbox" name="services[disk]" '.is_checked($services["disk"],"1").'>
	</td>
	<td>
	<b>'.gettext('Disk Usage').'</b><br>
	'.gettext('Monitors disk usage on the machine.').'<br>
	<table class="adddeleterow">
	';
	for($x=0;$x<count($serviceargs["disk"]);$x++){
		$checkedstr="";
		if($x==0)
			$checkedstr="checked";
		$output.='<tr>';
		//$output.='<td><input type="checkbox" class="checkbox" name="services[disk]['.$x.']" '.$checkedstr.'></td>';
		$output.='<td><label>'.gettext('Drive').':</label> <select name="serviceargs[disk]['.$x.']">';
		$output.='<option value=""></option>';
		for($y=0;$y<26;$y++){
			$selected="";
			//if($x==0 && $y==2)
			//				$selected="selected";
			$diskname=chr(ord('A')+$y);
			$selected=is_selected($serviceargs["disk"][$x],$diskname);
			$output.='<option value="'.$diskname.'" '.$selected.'>'.$diskname.':</option>';
			}
		$output.='</select></td>';
		$output.='<td><label>'.gettext('Warning Usage').':</label> <input type="text" size="2" name="serviceargs[disk_warning]['.$x.']" value="'.htmlentities($serviceargs["disk_warning"][$x]).'" class="textfield" />%
	<label>'.gettext('Critical Usage').':</label> <input type="text" size="2" name="serviceargs[disk_critical]['.$x.']" value="'.htmlentities($serviceargs["disk_critical"][$x]).'" class="textfield" />%</td>';
		$output.='</tr>';
		}
	$output.='
	</table>
	</td>
	</tr>

	</table>

	<div class="sectionTitle">'.gettext('Services').'</div>
	
	<p>'.gettext('Specify any services that should be monitored to ensure they\'re in a running state.').'</p>
	
	<table class="adddeleterow">
	
	<tr><th></th><th>'.gettext('Windows Service').'</th><th>'.gettext('Display Name').'</th></tr>
	';
	for($x=0;$x<count($serviceargs['servicestate']);$x++){

		$servicestring=$serviceargs['servicestate'][$x]['service'];
		$servicename=$serviceargs['servicestate'][$x]['name'];
			
		$output.='<tr><td><input type="checkbox" class="checkbox" name="services[servicestate]['.$x.']"  '.is_checked($services["servicestate"][$x]).'></td><td><input type="text" size="15" name="serviceargs[servicestate]['.$x.'][service]" value="'.htmlentities($servicestring).'" class="textfield" /></td><td><input type="text" size="20" name="serviceargs[servicestate]['.$x.'][name]" value="'.htmlentities($servicename).'" class="textfield" /></td></tr>';
		}
	$output.='
	</table>

	<div class="sectionTitle">'.gettext('Processes').'</div>
	
	<p>'.gettext('Specify any processes that should be monitored to ensure they\'re running.').'</p>
	
	<table class="adddeleterow">
	
	<tr><th></th><th>'.gettext('Windows Process').'</th><th>'.gettext('Display Name').'</th></tr>
	';
	for($x=0;$x<count($serviceargs['processstate']);$x++){

		$processstring=$serviceargs['processstate'][$x]['process'];
		$processname=$serviceargs['processstate'][$x]['name'];

		$output.='<tr><td><input type="checkbox" class="checkbox" name="services[processstate]['.$x.']"  '.is_checked($services["processstate"][$x]).'></td><td><input type="text" size="15" name="serviceargs[processstate]['.$x.'][process]" value="'.htmlentities($processstring).'" class="textfield" /></td><td><input type="text" size="20" name="serviceargs[processstate]['.$x.'][name]" value="'.htmlentities($processname).'" class="textfield" /></td></tr>';
		}
	$output.='
	</table>

	<div class="sectionTitle">'.gettext('Event Logs').'</div>
	
	<p>'.gettext('Specify what type(s) of event log data you\'d like to monitor.').'</p>
	
	<table class="adddeleterow">

	<tr><th></th><th>'.gettext('Event Log').'</th><th>'.gettext('Display Name').'</th><th>'.gettext('Severity').'</th><th>'.gettext('Hours').'</th><th>'.gettext('Warning').'<br>'.gettext('Count').'</th><th>'.gettext('Critical').'<br>'.gettext('Count').'</th></tr>
	';
	for($x=0;$x<count($serviceargs['eventlog']);$x++){

		$eventlog=$serviceargs['eventlog'][$x]['log'];
		$eventname=$serviceargs['eventlog'][$x]['name'];
		$severity=$serviceargs['eventlog'][$x]['severity'];
		$hours=$serviceargs['eventlog'][$x]['hours'];
		$warning=$serviceargs['eventlog'][$x]['warning'];
		$critical=$serviceargs['eventlog'][$x]['critical'];

		$output.='<tr><td><input type="checkbox" class="checkbox" name="services[eventlog]['.$x.']"  '.is_checked($services["eventlog"][$x]).'></td><td><input type="text" size="15" name="serviceargs[eventlog]['.$x.'][log]" value="'.htmlentities($eventlog).'" class="textfield" /></td><td><input type="text" size="25" name="serviceargs[eventlog]['.$x.'][name]" value="'.htmlentities($eventname).'" class="textfield" /></td>';
		$output.='<td><select name="serviceargs[eventlog]['.$x.'][severity]"><option value="1">Warnings</option><option value="2" '.is_selected($severity,1).'>Errors</option></select></td>';
		$output.='<td><input type="text" size="2" name="serviceargs[eventlog]['.$x.'][hours]" value="'.htmlentities($hours).'" class="textfield" /></td>';
		$output.='<td><input type="text" size="2" name="serviceargs[eventlog]['.$x.'][warning]" value="'.htmlentities($warning).'" class="textfield" /></td>';
		$output.='<td><input type="text" size="2" name="serviceargs[eventlog]['.$x.'][critical]" value="'.htmlentities($critical).'" class="textfield" /></td>';
		$output.='</tr>';
		}
	$output.='
	</table>


	</table>

			';
			break;
			
		case CONFIGWIZARD_MODE_VALIDATESTAGE2DATA:
		
			// get variables that were passed to us
			$address=grab_array_var($inargs,"address");
			$hostname=grab_array_var($inargs,"hostname");
			$password=grab_array_var($inargs,"password");
			
			// check for errors
			$errors=0;
			$errmsg=array();
			if(is_valid_host_name($hostname)==false)
				$errmsg[$errors++]=gettext("Invalid host name.");
			//if(preg_match('/[^a-zA-Z0-9 .\:_-]/',$password))
				//$errmsg[$errors++]="Password contains invalid characters.";
				
			if($errors>0){
				$outargs[CONFIGWIZARD_ERROR_MESSAGES]=$errmsg;
				$result=1;
				}
				
			break;

			
		case CONFIGWIZARD_MODE_GETSTAGE3HTML:
		
			// get variables that were passed to us
			$address=grab_array_var($inargs,"address");
			$hostname=grab_array_var($inargs,"hostname");
			$username=grab_array_var($inargs,"username");
			$password=grab_array_var($inargs,"password");

			$services_serial=grab_array_var($inargs,"services_serial","");
			if($services_serial=="")
				$services=grab_array_var($inargs,"services");
			else
				$services=unserialize(base64_decode($services_serial));
				
			$serviceargs_serial=grab_array_var($inargs,"serviceargs_serial","");
			if($serviceargs_serial=="")
				$serviceargs=grab_array_var($inargs,"serviceargs");
			else
				$serviceargs=unserialize(base64_decode($serviceargs_serial));
				
			$output='
			
		<input type="hidden" name="address" value="'.htmlentities($address).'">
		<input type="hidden" name="hostname" value="'.htmlentities($hostname).'">
		<input type="hidden" name="username" value="'.htmlentities($username).'">
		<input type="hidden" name="password" value="'.htmlentities($password).'">
		<input type="hidden" name="services_serial" value="'.base64_encode(serialize($services)).'">
		<input type="hidden" name="serviceargs_serial" value="'.base64_encode(serialize($serviceargs)).'">
		
		<!--SERVICES='.serialize($services).'<BR>
		SERVICEARGS='.serialize($serviceargs).'<BR>-->
		
			';
			break;
			
		case CONFIGWIZARD_MODE_VALIDATESTAGE3DATA:
				
			break;
			
		case CONFIGWIZARD_MODE_GETFINALSTAGEHTML:
			
			break;
			
		case CONFIGWIZARD_MODE_GETOBJECTS:
		
			$hostname=grab_array_var($inargs,"hostname","");
			$address=grab_array_var($inargs,"address","");
			$username=grab_array_var($inargs,"username");
			$password=grab_array_var($inargs,"password","");
			$hostaddress=$address;
			
			$services_serial=grab_array_var($inargs,"services_serial","");
			$serviceargs_serial=grab_array_var($inargs,"serviceargs_serial","");
			
			$services=unserialize(base64_decode($services_serial));
			$serviceargs=unserialize(base64_decode($serviceargs_serial));
			
			/*
			echo "SERVICES<BR>";
			print_r($services);
			echo "<BR>";
			echo "SERVICEARGS<BR>";
			print_r($serviceargs);
			echo "<BR>";
			*/
			
			#replace backslash with forward slash from domain\username to domain/username -SW
			$username=str_replace("\\", "/", $username);
			
			// save data for later use in re-entrance
			$meta_arr=array();
			$meta_arr["hostname"]=$hostname;
			$meta_arr["address"]=$address;
			$meta_arr["password"]=$password;
			$meta_arr["services"]=$services;
			$meta_arr["serivceargs"]=$serviceargs;
			save_configwizard_object_meta($wizard_name,$hostname,"",$meta_arr);			
			
			$objs=array();
			
			if(!host_exists($hostname)){
				$objs[]=array(
					"type" => OBJECTTYPE_HOST,
					"use" => "xiwizard_windowswmi_host",
					"host_name" => $hostname,
					"address" => $hostaddress,
					"icon_image" => "win_server.png",
					"statusmap_image" => "win_server.png",
					"_xiwizard" => $wizard_name,
					);
				}
				
			// see which services we should monitor
			foreach($services as $svc => $svcstate){
			
				//echo "PROCESSING: $svc -> $svcstate<BR>\n";
		
				switch($svc){
				
					case "ping":
						$objs[]=array(
							"type" => OBJECTTYPE_SERVICE,
							"host_name" => $hostname,
							"service_description" => "Ping",
							"use" => "xiwizard_windowsserver_ping_service",
							"_xiwizard" => $wizard_name,
							);
						break;
					
					case "cpu":
						$objs[]=array(
							"type" => OBJECTTYPE_SERVICE,
							"host_name" => $hostname,
							"service_description" => "CPU Usage",
							"use" => "xiwizard_windowswmi_service",
							"check_command" => "check_xi_service_wmiplus!".escapeshellarg($username)."!".escapeshellarg($password)."!checkcpu!-w ".escapeshellarg($serviceargs["cpu_warning"])." -c ".escapeshellarg($serviceargs["cpu_critical"]),
							"_xiwizard" => $wizard_name,
							);
						break;
					
					case "memory":
						$objs[]=array(
							"type" => OBJECTTYPE_SERVICE,
							"host_name" => $hostname,
							"service_description" => "Memory Usage",
							"use" => "xiwizard_windowswmi_service",
							"check_command" => "check_xi_service_wmiplus!".escapeshellarg($username)."!".escapeshellarg($password)."!checkmem!-s physical -w ".escapeshellarg($serviceargs["memory_warning"])." -c ".escapeshellarg($serviceargs["memory_critical"]),
							"_xiwizard" => $wizard_name,
							);
						break;
					
					case "pagefile":
						$objs[]=array(
							"type" => OBJECTTYPE_SERVICE,
							"host_name" => $hostname,
							"service_description" => "Page File Usage",
							"use" => "xiwizard_windowswmi_service",
							"check_command" => "check_xi_service_wmiplus!".escapeshellarg($username)."!".escapeshellarg($password)."!checkmem!-s page -w ".escapeshellarg($serviceargs["pagefile_warning"])." -c ".escapeshellarg($serviceargs["pagefile_critical"]),
							"_xiwizard" => $wizard_name,
							);
						break;
					
					case "disk":
						$donedisks=array();
						$diskid=0;
						foreach($serviceargs["disk"] as $diskname){
						
							if($diskname=="")
								continue;
						
							//echo "HANDLING DISK: $diskname<BR>";
							
							// we already configured this disk
							if(in_array($diskname,$donedisks))
								continue;
							$donedisks[]=$diskname;
							
							$objs[]=array(
								"type" => OBJECTTYPE_SERVICE,
								"host_name" => $hostname,
								"service_description" => gettext("Drive ").$diskname.gettext(": Disk Usage"),
								"use" => "xiwizard_windowswmi_service",
								"check_command" => "check_xi_service_wmiplus!".escapeshellarg($username)."!".escapeshellarg($password)."!checkdrivesize!-a ".escapeshellarg($diskname).": -w ".escapeshellarg($serviceargs["disk_warning"][$diskid])." -c ".escapeshellarg($serviceargs["disk_critical"][$diskid]),
								"_xiwizard" => $wizard_name,
								);		

							$diskid++;
							}
						break;
						
					case "servicestate":

						$enabledservices=$svcstate;			
						foreach($enabledservices as $sid => $sstate){
						
							$sname=$serviceargs["servicestate"][$sid]["service"];
							$sdesc=$serviceargs["servicestate"][$sid]["name"];
						
							$objs[]=array(
								"type" => OBJECTTYPE_SERVICE,
								"host_name" => $hostname,
								"service_description" => $sdesc,
								"use" => "xiwizard_windowswmi_service",
								 "check_command" => "check_xi_service_wmiplus!".escapeshellarg($username)."!".escapeshellarg($password)."!checkservice!-a ".escapeshellarg($sname)." ",
								"_xiwizard" => $wizard_name,
								);		
							}
						break;
					
					case "processstate":
						
						$enabledprocs=$svcstate;
						foreach($enabledprocs as $pid => $pstate){
						
							$pname=$serviceargs["processstate"][$pid]["process"];
							$pdesc=$serviceargs["processstate"][$pid]["name"];
						
							$objs[]=array(
								"type" => OBJECTTYPE_SERVICE,
								"host_name" => $hostname,
								"service_description" => $pdesc,
								"use" => "xiwizard_windowswmi_service",
								"check_command" => "check_xi_service_wmiplus!".escapeshellarg($username)."!".escapeshellarg($password)."!checkprocess!-s Commandline -a ".escapeshellarg($pname)." ",
								"_xiwizard" => $wizard_name,
								);		
							}
						break;
						
					case "eventlog":
						
						$enabledlogs=$svcstate;
						foreach($enabledlogs as $lid => $pstate){
						
							$log=$serviceargs["eventlog"][$lid]["log"];
							$lname=$serviceargs["eventlog"][$lid]["name"];
							$lseverity=$serviceargs["eventlog"][$lid]["severity"];
							$lhours=$serviceargs["eventlog"][$lid]["hours"];
							$lwarning=$serviceargs["eventlog"][$lid]["warning"];
							$lcritical=$serviceargs["eventlog"][$lid]["critical"];
							
							$lstr=escapeshellarg($log.",".$lseverity.",".$lhours);
							
							$lextra="";
							if($lwarning!="")
								$lextra.=" -w ".escapeshellarg($lwarning);
							if($lcritical!="")
								$lextra.=" -c ".escapeshellarg($lcritical);
						
							$objs[]=array(
								"type" => OBJECTTYPE_SERVICE,
								"host_name" => $hostname,
								"service_description" => $lname,
								"use" => "xiwizard_windowswmi_service",
								"check_command" => "check_xi_service_wmiplus!".escapeshellarg($username)."!".escapeshellarg($password)."!checkeventlog!-a ".$lstr." ".$lextra,
								"_xiwizard" => $wizard_name,
								);		
							}
						break;
						
						
				
					default:
						break;
					}
				}
				
			//echo "OBJECTS:<BR>";
			//print_r($objs);
			//exit();
					
			// return the object definitions to the wizard
			$outargs[CONFIGWIZARD_NAGIOS_OBJECTS]=$objs;
		
			break;
			
		default:
			break;			
		}
		
	return $output;
	}
	

?>