#!/bin/sh

(
	cd /tmp
	
	if [ ! -f $INSTALL_PATH/offline ]; then
		wget http://assets.nagios.com/downloads/nagiosxi/scripts/wmicinstall.py
	else
		cp $INSTALL_PATH/packages/offline_install/Downloads/wmicinstall.py ./
	fi
	
	chmod +x wmicinstall.py
	./wmicinstall.py
)

