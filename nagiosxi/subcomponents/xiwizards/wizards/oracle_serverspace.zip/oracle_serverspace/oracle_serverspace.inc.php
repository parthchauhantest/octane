<?php
// MYSQL SERVER CONFIG WIZARD
//
// Copyright (c) 2010 Nagios Enterprises, LLC.  All rights reserved.
//  
// $Id: $

include_once(dirname(__FILE__).'/../configwizardhelper.inc.php');

// run the initialization function
oracleserverspace_configwizard_init();

function oracleserverspace_configwizard_init(){

	$name="oracleserverspace";
	
	$args=array(
		CONFIGWIZARD_NAME => $name,
        CONFIGWIZARD_VERSION => "1.4",
		CONFIGWIZARD_TYPE => CONFIGWIZARD_TYPE_MONITORING,
		CONFIGWIZARD_DESCRIPTION => gettext("Monitor an Oracle Server"),
		CONFIGWIZARD_DISPLAYTITLE => gettext("Oracle Serverspace"),
		CONFIGWIZARD_FUNCTION => "oracleserverspace_configwizard_func",
		CONFIGWIZARD_PREVIEWIMAGE => "oracleserverspace.png",
		);
		
	register_configwizard($name,$args);
	}



function oracleserverspace_configwizard_func($mode="",$inargs=null,&$outargs,&$result){

	$wizard_name="oracleserverspace";
	
	// initialize return code and output
	$result=0;
	$output="";
	
	// initialize output args - pass back the same data we got
	$outargs[CONFIGWIZARD_PASSBACK_DATA]=$inargs;


	switch($mode){
		case CONFIGWIZARD_MODE_GETSTAGE1HTML:
		
			$address=grab_array_var($inargs,"address","");
			$port=grab_array_var($inargs,"port","1521");
			$username=grab_array_var($inargs,"username","");
			$password=grab_array_var($inargs,"password","");
            $sid=grab_array_var($inargs,"sid","");
			
			//sanity check for wizard requirements
			$sanity=''; 
			if(!file_exists('/usr/lib/oracle') && !file_exists('/usr/lib64/oracle')) {
				$sanity.="<div style='color:red'><strong>WARNING:</strong> ".gettext('Oracle libraries to not appear to be installed. See the')." 
				<a href='http://assets.nagios.com/downloads/nagiosxi/docs/Oracle_Plugin_Installation.pdf' title='Install Instructions' target='_blank'>
				".gettext('Oracle Plugin Installation')."</a>".gettext('instructions for monitoring Oracle')."</div>\n"; 
			}
			
			$output='

	<div class="sectionTitle">'.gettext('Oracle Serverspace').'</div>
	'.$sanity.'
	<p>
	'.gettext("Specify the details for connecting to the Oracle serverspace you want to monitor.").'
	</p>
			
	<table>

	<tr>
	<td valign="top">
	<label>'.gettext("Address:").'</label><br class="nobr" />
	</td>
	<td>
<input type="text" size="40" name="address" id="address" value="'.htmlentities($address).'" class="textfield" /><br class="nobr" />
	'.gettext("The IP address or FQDNS name of the Oracle server.").'<br><br>
	</td>
	</tr>
	
	<tr>
	<td valign="top">
	<label>'.gettext("Port:").'</label><br class="nobr" />
	</td>
	<td>
<input type="text" size="5" name="port" id="port" value="'.htmlentities($port).'" class="textfield" /><br class="nobr" />
	'.gettext("The port to use to connect to the Oracle server.").'<br><br>
	</td>
	</tr>

	<tr>
	<td valign="top">
    <label>'.gettext("Sid:").'</label><br class="nobr" />
    </td>
    <td>
    <input type="text" size="5" name="sid" id="sid" value="'.htmlentities($sid).'" class="textfield" /><br class="nobr" />
    '.gettext("The servicename (sid) to use to connect to the Oracle server.").'<br><br>
    </td>
    </tr>

    <tr>
    <td valign="top">
	<label>'.gettext("Username:").'</label><br class="nobr" />
	</td>
	<td>
<input type="text" size="20" name="username" id="username" value="'.htmlentities($username).'" class="textfield" /><br class="nobr" />
	'.gettext("The username used to connect to the Oracle server.").'<br><br>
	</td>
	</tr>

	<tr>
	<td valign="top">
	<label>'.gettext("Password:").'</label><br class="nobr" />
	</td>
	<td>
<input type="password" size="20" name="password" id="password" value="'.htmlentities($password).'" class="textfield" /><br class="nobr" />
	'.gettext("The password used to connect to the Oracle server.").'<br><br>
	</td>
	</tr>

	<!-- <tr>
	<td valign="top">
	<label>'.gettext("Database:").'</label><br class="nobr" />
	</td>
	<td>
<input type="text" size="20" name="database" id="database" value="'.htmlentities($database).'" class="textfield" /><br class="nobr" />
	'.gettext("The tablespace to connect to on the Oracle server.").'<br><br>
	</td>
	</tr> -->


	</table>

			';
			break;
			
		case CONFIGWIZARD_MODE_VALIDATESTAGE1DATA:
		
			// get variables that were passed to us
			$address=grab_array_var($inargs,"address","");
			$port=grab_array_var($inargs,"port","");
			$username=grab_array_var($inargs,"username","");
            $sid=grab_array_var($inargs,"sid","");
			$password=grab_array_var($inargs,"password","");
			//$database=grab_array_var($inargs,"database","");
			
			// check for errors
			$errors=0;
			$errmsg=array();
			if(have_value($address)==false)
				$errmsg[$errors++]=gettext("No address specified.");
			if(have_value($port)==false)
				$errmsg[$errors++]=gettext("No port number specified.");				
			if(have_value($username)==false)
				$errmsg[$errors++]=gettext("No username specified.");
			if(have_value($password)==false)
				$errmsg[$errors++]=gettext("No password specified.");
			//if(have_value($database)==false)
			//	$errmsg[$errors++]="No tablespace specified.";
				
			if($errors>0){
				$outargs[CONFIGWIZARD_ERROR_MESSAGES]=$errmsg;
				$result=1;
				}
				
			break;
			
		case CONFIGWIZARD_MODE_GETSTAGE2HTML:
		
			// get variables that were passed to us
			$address=grab_array_var($inargs,"address");
			$port=grab_array_var($inargs,"port","");
            $sid=grab_array_var($inargs,"sid","");
			$username=grab_array_var($inargs,"username","");
			$password=grab_array_var($inargs,"password","");
			//$database=grab_array_var($inargs,"database","");

			$ha=@gethostbyaddr($address);
			if($ha=="")
				$ha=$address;
			$hostname=grab_array_var($inargs,"hostname",$ha);
			
		
			$services=grab_array_var($inargs,"services",array(
				"connection-time"=>"on",
				"connected-users"=>"on",
				"sga-data-buffer-hit-ratio" => "on",
				"sga-library-cache-hit-ratio"=>"on",
				"sga-dictionary-cache-hit-ratio"=>"on",
				"sga-latches-hit-ratio"=>"on",
				"sga-shared-pool-reload-ratio"=>"on",
				"sga-shared-pool-free"=>"on",				
				"pga-in-memory-sort-ratio"=>"on",								
				"soft-parse-ratio"=>"on",				
				"retry-ratio"=>"on",
				"redo-io-traffic"=>"on",
				"roll-header-contention"=>"on",
				"roll-block-contention"=>"on",
				"roll-hit-ratio"=>"on",
				"roll-wraps"=>"on",
				"roll-extends"=>"on",
				"flash-recovery-area-usage"=>"on",
				));
			$serviceargs=grab_array_var($inargs,"serviceargs",array(
				"connection-time_warning"=>"1",
				"connection-time_critical"=>"5",
				"connected-users_warning"=>"50",
				"connected-users_critical"=>"100",
				"sga-data-buffer-hit-ratio_warning"=>"98:",
				"sga-data-buffer-hit-ratio_critical"=>"95:",
				"sga-library-cache-hit-ratio_warning"=>"98:",
				"sga-library-cache-hit-ratio_critical"=>"95:",
				"sga-dictionary-cache-hit-ratio_warning"=>"98:",
				"sga-dictionary-cache-hit-ratio_critical"=>"95:",
				"sga-latches-hit-ratio_warning"=>"98:",
				"sga-latches-hit-ratio_critical"=>"95:",
				"sga-shared-pool-reload-ratio_warning"=>"1",
				"sga-shared-pool-reload-ratio_critical"=>"10",
				"sga-shared-pool-free_warning"=>"10:",
				"sga-shared-pool-free_critical"=>"5:",
				"pga-in-memory-sort-ratio_warning"=>"99:",
				"pga-in-memory-sort-ratio_critical"=>"90:",
				"soft-parse-ratio_warning"=>"98:",
				"soft-parse-ratio_critical"=>"90:",
				"retry-ratio_warning"=>"1",
				"retry-ratio_critical"=>"10",
				"redo-io-traffic_warning"=>"100",
				"redo-io-traffic_critical"=>"200",
				"roll-header-contention_warning"=>"1",
				"roll-header-contention_critical"=>"2",
				"roll-block-contention_warning"=>"1",
				"roll-block-contention_critical"=>"2",
				"roll-hit-ratio_warning"=>"99:",
				"roll-hit-ratio_critical"=>"98:",
				"roll-wraps_warning"=>"1",
				"roll-wraps_critical"=>"100",
				"roll-extends_warning"=>"1",
				"roll-extends_critical"=>"100",
				"flash-recovery-area-usage_warning"=>"90",
				"flash-recovery-area-usage_critical"=>"98",
				));
			
			$services_serial=grab_array_var($inargs,"services_serial");
			if($services_serial!="")
				$services=unserialize(base64_decode($services_serial));
			$serviceargs_serial=grab_array_var($inargs,"serviceargs_serial");
			if($serviceargs_serial!=""){
				//echo "ARGSSERIAL: $serviceargs_serial<BR>\n";
				$serviceargs=unserialize(base64_decode($serviceargs_serial));
				}
		
			$output='
			
		<input type="hidden" name="address" value="'.htmlentities($address).'">
		<input type="hidden" name="port" value="'.htmlentities($port).'">
		<input type="hidden" name="username" value="'.htmlentities($username).'">
        <input type="hidden" name="sid" value="'.htmlentities($sid).'">
		<input type="hidden" name="password" value="'.htmlentities($password).'">
		<!-- <input type="hidden" name="database" value="'.htmlentities($database).'"> -->

	<div class="sectionTitle">'.gettext("Oracle Server").'</div>
	
			
	<table>
	
	<tr>
	<td valign="top">
	<label>'.gettext("Address:").'</label><br class="nobr" />
	</td>
	<td>
<input type="text" size="20" name="address" id="address" value="'.htmlentities($address).'" class="textfield" disabled/><br class="nobr" />
	</td>
	</tr>

	<tr>
	<td valign="top">
	<label>'.gettext("Host Name:").'</label><br class="nobr" />
	</td>
	<td>
<input type="text" size="20" name="hostname" id="hostname" value="'.htmlentities($hostname).'" class="textfield" /><br class="nobr" />
	'.gettext("The name you\'d like to have associated with this Oracle Tablespace.").'
	</td>
	</tr>
	
	<tr>
	<td valign="top">
	<label>'.gettext("Port:").'</label><br class="nobr" />
	</td>
	<td>
<input type="text" size="5" name="port" id="port" value="'.htmlentities($port).'" class="textfield" disabled/><br class="nobr" />
	</td>
	</tr>
    <tr>
    <td valign="top">
    label>'.gettext("Sid:").'</label><br class="nobr" />
    </td>
    <td>
    <input type="text" size="5" name="sid" id="sid" value="'.htmlentities($sid).'" class="textfield" disabled/><br class="nobr" />
    </td>
    </tr>
	<tr>
	<td valign="top">
	<label>'.gettext("Username:").'</label><br class="nobr" />
	</td>
	<td>
<input type="text" size="20" name="username" id="username" value="'.htmlentities($username).'" class="textfield" disabled/><br class="nobr" />
	</td>
	</tr>

	<tr>
	<td valign="top">
	<label>'.gettext("Password:").'</label><br class="nobr" />
	</td>
	<td>
<input type="password" size="20" name="password" id="password" value="'.htmlentities($password).'" class="textfield" disabled/><br class="nobr" />
	</td>
	</tr>

	<tr>
	<!-- <td valign="top">
	<label>'.gettext("Tablespace:").'</label><br class="nobr" />
	</td>
	<td>
<input type="text" size="20" name="database" id="database" value="'.htmlentities($database).'" class="textfield" disabled/><br class="nobr" />
	</td> -->
	</tr>

	</table>


	<div class="sectionTitle">'.gettext("Oracle Serverspace Metrics").'</div>
	
	<p>'.gettext("Specify the metrics you\'d like to monitor on the Oracle Serverspace.").'</p>
	
	
	<table>
	
	<tr>
	<td valign="top">
	<input type="checkbox" class="checkbox" name="services[connection-time]" '.is_checked(grab_array_var($services,"connection-time"),"on").'>
	</td>
	<td>
	<b>'.gettext('Connection Time').'</b><br> 
	'.gettext("Monitor amount time it takes to connect to the Oracle Server.").'<br>
	<label>'.gettext("Warning Threshold:").'</label> <input type="text" size="1" name="serviceargs[connection-time_warning]" value="'.htmlentities($serviceargs["connection-time_warning"]).'">&nbsp;&nbsp;<label>Critical Threshold:</label> <input type="text" size="1" name="serviceargs[connection-time_critical]" value="'.htmlentities($serviceargs["connection-time_critical"]).'"><br><br>
	</td>
	</tr>

	<tr>
	<td valign="top">
	<input type="checkbox" class="checkbox" name="services[connected-users]" '.is_checked(grab_array_var($services,"connected-users"),"on").'>
	</td>
	<td>
	<b>'.gettext("Connected Users").'</b><br> 
	'.gettext("Monitor amount of connected users.").'<br>
	<label>'.gettext("Warning Threshold:").'</label> <input type="text" size="1" name="serviceargs[connected-users_warning]" value="'.htmlentities($serviceargs["connected-users_warning"]).'">&nbsp;&nbsp;<label>'.gettext("Critical Threshold:").'</label> <input type="text" size="1" name="serviceargs[connected-users_critical]" value="'.htmlentities($serviceargs["connected-users_critical"]).'"><br><br>
	</td>
	</tr>

	<tr>
	<td valign="top">
	<input type="checkbox" class="checkbox" name="services[sga-data-buffer-hit-ratio]" '.is_checked(grab_array_var($services,"sga-data-buffer-hit-ratio"),"on").'>
	</td>
	<td>
	<b>'.gettext("SGA Data Buffer Hit Ratio").'</b><br> 
	'.gettext("Monitor the SGA Data Buffer.").'<br>
	<label>'.gettext("Warning Threshold:").'</label> <input type="text" size="1" name="serviceargs[sga-data-buffer-hit-ratio_warning]" value="'.htmlentities($serviceargs["sga-data-buffer-hit-ratio_warning"]).'">&nbsp;&nbsp;<label>'.gettext("Critical Threshold:").'</label> <input type="text" size="1" name="serviceargs[sga-data-buffer-hit-ratio_critical]" value="'.htmlentities($serviceargs["sga-data-buffer-hit-ratio_critical"]).'"><br><br>
	</td>
	</tr>

	<tr>
	<td valign="top">
	<input type="checkbox" class="checkbox" name="services[sga-library-cache-hit-ratio]" '.is_checked(grab_array_var($services,"sga-library-cache-hit-ratio"),"on").'>
	</td>
	<td>
	<b>'.gettext("SGA Library Cache Hit Ratio").'</b><br> 
	'.gettext("Monitor the Library Cache.").'<br>
	<label>'.gettext("Warning Threshold:").'</label> <input type="text" size="1" name="serviceargs[sga-library-cache-hit-ratio_warning]" value="'.htmlentities($serviceargs["sga-library-cache-hit-ratio_warning"]).'">&nbsp;&nbsp;<label>'.gettext("Critical Threshold:").'</label> <input type="text" size="1" name="serviceargs[sga-library-cache-hit-ratio_critical]" value="'.htmlentities($serviceargs["sga-library-cache-hit-ratio_critical"]).'"><br><br>
	</td>
	</tr>
	
	<tr>
	<td valign="top">
	<input type="checkbox" class="checkbox" name="services[sga-dictionary-cache-hit-ratio]" '.is_checked(grab_array_var($services,"sga-dictionary-cache-hit-ratio"),"on").'>
	</td>
	<td>
	<b>'.gettext("SGA Dictionary Cache Hit Ratio").'</b><br> 
	'.gettext("Monitor the SGA Dictionary.").'<br>
	<label>'.gettext("Warning Threshold:").'</label> <input type="text" size="1" name="serviceargs[sga-dictionary-cache-hit-ratio_warning]" value="'.htmlentities($serviceargs["sga-dictionary-cache-hit-ratio_warning"]).'">&nbsp;&nbsp;<label>'.gettext("Critical Threshold:").'</label> <input type="text" size="1" name="serviceargs[sga-dictionary-cache-hit-ratio_critical]" value="'.htmlentities($serviceargs["sga-dictionary-cache-hit-ratio_critical"]).'"><br><br>
	</td>
	</tr>
	
	<tr>
	<td valign="top">
	<input type="checkbox" class="checkbox" name="services[sga-shared-pool-reload-ratio]" '.is_checked(grab_array_var($services,"sga-shared-pool-reload-ratio"),"on").'>
	</td>
	<td>
	<b>'.gettext("SGA Shared Pool Reload Ratio").'</b><br> 
	'.gettext("Monitor the SGA Shared Pool.").'<br>
	<label>'.gettext("Warning Threshold:").'</label> <input type="text" size="1" name="serviceargs[sga-shared-pool-reload-ratio_warning]" value="'.htmlentities($serviceargs["sga-shared-pool-reload-ratio_warning"]).'">&nbsp;&nbsp;<label>'.gettext("Critical Threshold:").'</label> <input type="text" size="1" name="serviceargs[sga-shared-pool-reload-ratio_critical]" value="'.htmlentities($serviceargs["sga-shared-pool-reload-ratio_critical"]).'"><br><br>
	</td>
	</tr>
	
		<tr>
	<td valign="top">
	<input type="checkbox" class="checkbox" name="services[sga-shared-pool-free]" '.is_checked(grab_array_var($services,"sga-shared-pool-free"),"on").'>
	</td>
	<td>
	<b>'.gettext("SGA Shared Pool Free").'</b><br> 
	'.gettext("Monitor the SGA Shared Pool.").'<br>
	<label>'.gettext("Warning Threshold:").'</label> <input type="text" size="1" name="serviceargs[sga-shared-pool-free_warning]" value="'.htmlentities($serviceargs["sga-shared-pool-free_warning"]).'">&nbsp;&nbsp;<label>'.gettext("Critical Threshold:").'</label> <input type="text" size="1" name="serviceargs[sga-shared-pool-free_critical]" value="'.htmlentities($serviceargs["sga-shared-pool-free_critical"]).'"><br><br>
	</td>
	</tr>
	
		<tr>
	<td valign="top">
	<input type="checkbox" class="checkbox" name="services[pga-in-memory-sort-ratio]" '.is_checked(grab_array_var($services,"pga-in-memory-sort-ratio"),"on").'>
	</td>
	<td>
	<b>'.gettext("PGA In Memory Sort Ratio").'</b><br> 
	'.gettext("Monitor the PGA Memory.").'<br>
	<label>'.gettext("Warning Threshold:").'</label> <input type="text" size="1" name="serviceargs[pga-in-memory-sort-ratio_warning]" value="'.htmlentities($serviceargs["pga-in-memory-sort-ratio_warning"]).'">&nbsp;&nbsp;<label>'.gettext("Critical Threshold:").'</label> <input type="text" size="1" name="serviceargs[pga-in-memory-sort-ratio_critical]" value="'.htmlentities($serviceargs["pga-in-memory-sort-ratio_critical"]).'"><br><br>
	</td>
	</tr>
	
		<tr>
	<td valign="top">
	<input type="checkbox" class="checkbox" name="services[soft-parse-ratio]" '.is_checked(grab_array_var($services,"soft-parse-ratio"),"on").'>
	</td>
	<td>
	<b>'.gettext("Soft Parse Ratio").'</b><br> 
	'.gettext("Monitor the amount of soft parses.").'<br>
	<label>'.gettext("Warning Threshold:").'</label> <input type="text" size="1" name="serviceargs[soft-parse-ratio_warning]" value="'.htmlentities($serviceargs["soft-parse-ratio_warning"]).'">&nbsp;&nbsp;<label>'.gettext("Critical Threshold:").'</label> <input type="text" size="1" name="serviceargs[soft-parse-ratio_critical]" value="'.htmlentities($serviceargs["soft-parse-ratio_critical"]).'"><br><br>
	</td>
	</tr>
	
		<tr>
	<td valign="top">
	<input type="checkbox" class="checkbox" name="services[retry-ratio]" '.is_checked(grab_array_var($services,"retry-ratio"),"on").'>
	</td>
	<td>
	<b>'.gettext("Retry Ratio").'</b><br> 
	'.gettext("Monitor redo buffer retries.").'<br>
	<label>'.gettext("Warning Threshold:").'</label> <input type="text" size="1" name="serviceargs[retry-ratio_warning]" value="'.htmlentities($serviceargs["retry-ratio_warning"]).'">&nbsp;&nbsp;<label>Critical Threshold:</label> <input type="text" size="1" name="serviceargs[retry-ratio_critical]" value="'.htmlentities($serviceargs["retry-ratio_critical"]).'"><br><br>
	</td>
	</tr>
	
		<tr>
	<td valign="top">
	<input type="checkbox" class="checkbox" name="services[redo-io-traffic]" '.is_checked(grab_array_var($services,"redo-io-traffic"),"on").'>
	</td>
	<td>
	<b>'.gettext("Redo I/O Traffic").'</b><br> 
	'.gettext("Monitor the amount of I/O traffic from redos.").'<br>
	<label>'.gettext("Warning Threshold:").'</label> <input type="text" size="1" name="serviceargs[redo-io-traffic_warning]" value="'.htmlentities($serviceargs["redo-io-traffic_warning"]).'">&nbsp;&nbsp;<label>'.gettext("Critical Threshold:").'</label> <input type="text" size="1" name="serviceargs[redo-io-traffic_critical]" value="'.htmlentities($serviceargs["redo-io-traffic_critical"]).'"><br><br>
	</td>
	</tr>
	
		<tr>
	<td valign="top">
	<input type="checkbox" class="checkbox" name="services[roll-header-contention]" '.is_checked(grab_array_var($services,"roll-header-contention"),"on").'>
	</td>
	<td>
	<b>'.gettext("Roll Header Contention").'</b><br> 
	'.gettext("Monitor contention for writes for the roll header.").'<br>
	<label>'.gettext("Warning Threshold:").'</label> <input type="text" size="1" name="serviceargs[roll-header-contention_warning]" value="'.htmlentities($serviceargs["roll-header-contention_warning"]).'">&nbsp;&nbsp;<label>'.gettext("Critical Threshold:").'</label> <input type="text" size="1" name="serviceargs[roll-header-contention_critical]" value="'.htmlentities($serviceargs["roll-header-contention_critical"]).'"><br><br>
	</td>
	</tr>
	
		<tr>
	<td valign="top">
	<input type="checkbox" class="checkbox" name="services[roll-block-contention]" '.is_checked(grab_array_var($services,"roll-block-contention"),"on").'>
	</td>
	<td>
	<b>'.gettext("Roll Block Contention").'</b><br> 
	'.gettext("Monitor the roll block contention.").'<br>
	<label>'.gettext("Warning Threshold:").'</label> <input type="text" size="1" name="serviceargs[roll-block-contention_warning]" value="'.htmlentities($serviceargs["roll-block-contention_warning"]).'">&nbsp;&nbsp;<label>'.gettext("Critical Threshold:").'</label> <input type="text" size="1" name="serviceargs[roll-block-contention_critical]" value="'.htmlentities($serviceargs["roll-block-contention_critical"]).'"><br><br>
	</td>
	</tr>
	
	<tr>
	<td valign="top">
	<input type="checkbox" class="checkbox" name="services[roll-hit-ratio]" '.is_checked(grab_array_var($services,"roll-hit-ratio"),"on").'>
	</td>
	<td>
	<b>'.gettext("Roll Hit Ratio").'</b><br> 
	'.gettext("Monitor the roll hit.").'<br>
	<label>'.gettext("Warning Threshold:").'</label> <input type="text" size="1" name="serviceargs[roll-hit-ratio_warning]" value="'.htmlentities($serviceargs["roll-hit-ratio_warning"]).'">&nbsp;&nbsp;<label>'.gettext("Critical Threshold:").'</label> <input type="text" size="1" name="serviceargs[roll-hit-ratio_critical]" value="'.htmlentities($serviceargs["roll-hit-ratio_critical"]).'"><br><br>
	</td>
	</tr>
	
	<tr>
	<td valign="top">
	<input type="checkbox" class="checkbox" name="services[roll-wraps]" '.is_checked(grab_array_var($services,"roll-wraps"),"on").'>
	</td>
	<td>
	<b>'.gettext("Roll Wraps").'</b><br> 
	'.gettext("Monitor the roll wraps.").'<br>
	<label>'.gettext("Warning Threshold:").'</label> <input type="text" size="1" name="serviceargs[roll-wraps_warning]" value="'.htmlentities($serviceargs["roll-wraps_warning"]).'">&nbsp;&nbsp;<label>'.gettext("Critical Threshold:").'</label> <input type="text" size="1" name="serviceargs[roll-wraps_critical]" value="'.htmlentities($serviceargs["roll-wraps_critical"]).'"><br><br>
	</td>
	</tr>
	
	<tr>
	<td valign="top">
	<input type="checkbox" class="checkbox" name="services[roll-extends]" '.is_checked(grab_array_var($services,"roll-extends"),"on").'>
	</td>
	<td>
	<b>'.gettext("Roll Extends").'</b><br> 
	'.gettext("Monitor the roll extends.").'<br>
	<label>'.gettext("Warning Threshold:").'</label> <input type="text" size="1" name="serviceargs[roll-extends_warning]" value="'.htmlentities($serviceargs["roll-extends_warning"]).'">&nbsp;&nbsp;<label>'.gettext("Critical Threshold:").'</label> <input type="text" size="1" name="serviceargs[roll-extends_critical]" value="'.htmlentities($serviceargs["roll-extends_critical"]).'"><br><br>
	</td>
	</tr>
	
			<tr>
	<td valign="top">
	<input type="checkbox" class="checkbox" name="services[flash-recovery-area-usage]" '.is_checked(grab_array_var($services,"flash-recovery-area-usage"),"on").'>
	</td>
	<td>
	<b>'.gettext("Flash Recovery Area Usage").'</b><br> 
	'.gettext("Monitor the flash recovery area.").'<br>
	<label>'.gettext("Warning Threshold:").'</label> <input type="text" size="1" name="serviceargs[flash-recovery-area-usage_warning]" value="'.htmlentities($serviceargs["flash-recovery-area-usage_warning"]).'">&nbsp;&nbsp;<label>'.gettext("Critical Threshold:").'</label> <input type="text" size="1" name="serviceargs[flash-recovery-area-usage_critical]" value="'.htmlentities($serviceargs["flash-recovery-area-usage_critical"]).'"><br><br>
	</td>
	</tr>
	
	<tr>
	<td valign="top">
	<input type="checkbox" class="checkbox" name="services[sga-latches-hit-ratio]" '.is_checked(grab_array_var($services,"sga-latches-hit-ratio"),"on").'>
	</td>
	<td>
	<b>'.gettext("SGA Latches Hit Ratio").'</b><br> 
	'.gettext("Monitor SGA Latches .").'<br>
	<label>'.gettext("Warning Threshold:").'</label> <input type="text" size="1" name="serviceargs[sga-latches-hit-ratio_warning]" value="'.htmlentities($serviceargs["sga-latches-hit-ratio_warning"]).'">&nbsp;&nbsp;<label>'.gettext("Critical Threshold:").'</label> <input type="text" size="1" name="serviceargs[sga-latches-hit-ratio_critical]" value="'.htmlentities($serviceargs["sga-latches-hit-ratio_critical"]).'"><br><br>
	</td>
	</tr>
    </table>
	';
			break;
			
		case CONFIGWIZARD_MODE_VALIDATESTAGE2DATA:
		
			// get variables that were passed to us
			$address=grab_array_var($inargs,"address");
			$hostname=grab_array_var($inargs,"hostname");
			$port=grab_array_var($inargs,"port","");
			$username=grab_array_var($inargs,"username","");
			$password=grab_array_var($inargs,"password","");
			//$database=grab_array_var($inargs,"database","");
				
			$services=grab_array_var($inargs,"services",array());
			$serviceargs=grab_array_var($inargs,"serviceargs",array());
			
            $sid=grab_array_var($inargs,"sid","");
			// check for errors
			$errors=0;
			$errmsg=array();
			if(is_valid_host_name($hostname)==false)
				$errmsg[$errors++]="Invalid host name.";
				
			if($errors>0){
				$outargs[CONFIGWIZARD_ERROR_MESSAGES]=$errmsg;
				$result=1;
				}
				
			break;

			
		case CONFIGWIZARD_MODE_GETSTAGE3HTML:
		
			// get variables that were passed to us
			$address=grab_array_var($inargs,"address");
			$hostname=grab_array_var($inargs,"hostname");
			$port=grab_array_var($inargs,"port","");
			$username=grab_array_var($inargs,"username","");
			$password=grab_array_var($inargs,"password","");
			//$database=grab_array_var($inargs,"database","");
			$sid=grab_array_var($inargs,"sid","");
			$services=grab_array_var($inargs,"services");
			$serviceargs=grab_array_var($inargs,"serviceargs");
		
			$output='
			
		<input type="hidden" name="address" value="'.htmlentities($address).'">
		<input type="hidden" name="hostname" value="'.htmlentities($hostname).'">
		<input type="hidden" name="port" value="'.htmlentities($port).'">
		<input type="hidden" name="username" value="'.htmlentities($username).'">
		<input type="hidden" name="password" value="'.htmlentities($password).'">
		<!-- <input type="hidden" name="database" value="'.htmlentities($database).'"> -->
		<input type="hidden" name="services_serial" value="'.base64_encode(serialize($services)).'">
		<input type="hidden" name="serviceargs_serial" value="'.base64_encode(serialize($serviceargs)).'">
		<input type="hidden" name="sid" value="'.htmlentities($sid).'">
		<!--SERVICES='.serialize($services).'<BR>
		SERVICEARGS='.serialize($serviceargs).'<BR>-->
		
			';
			break;
			
		case CONFIGWIZARD_MODE_VALIDATESTAGE3DATA:
				
			break;
			
		case CONFIGWIZARD_MODE_GETFINALSTAGEHTML:
			
			
			$output='
			';
			break;
			
		case CONFIGWIZARD_MODE_GETOBJECTS:
		
			$hostname=grab_array_var($inargs,"hostname","");
			$address=grab_array_var($inargs,"address","");
			$hostaddress=$address;
			$port=grab_array_var($inargs,"port","");
			$username=grab_array_var($inargs,"username","");
			$password=grab_array_var($inargs,"password","");
			//$database=grab_array_var($inargs,"database","");
		
			$services_serial=grab_array_var($inargs,"services_serial","");
			$serviceargs_serial=grab_array_var($inargs,"serviceargs_serial","");
			$sid=grab_array_var($inargs,"sid","");
			$services=unserialize(base64_decode($services_serial));
			$serviceargs=unserialize(base64_decode($serviceargs_serial));
			
			/*
			echo "SERVICES<BR>";
			print_r($services);
			echo "<BR>";
			echo "SERVICEARGS<BR>";
			print_r($serviceargs);
			echo "<BR>";
			*/
			
			// save data for later use in re-entrance
			$meta_arr=array();
			$meta_arr["hostname"]=$hostname;
			$meta_arr["address"]=$address;
			$meta_arr["port"]=$port;
			$meta_arr["username"]=$username;
			$meta_arr["password"]=$password;
			//$meta_arr["database"]=$database;
			$meta_arr["services"]=$services;
			$meta_arr["serviceargs"]=$serviceargs;
            $meta_arr["sid"]=$sid;
			save_configwizard_object_meta($wizard_name,$hostname,"",$meta_arr);			
			$objs=array();
			
			if(!host_exists($hostname)){
				$objs[]=array(
					"type" => OBJECTTYPE_HOST,
					"use" => "xiwizard_oracleserverspace_host",
					"host_name" => $hostname,
					"address" => $hostaddress,
					"icon_image" => "oracle.png",
					"statusmap_image" => "oracle.png",
					"_xiwizard" => $wizard_name,
					);
				}
			
			// common plugin opts
			if(have_value($sid)==false) {
                $commonopts="--connect '{$address}:{$port}' --username '{$username}' --password '{$password}' ";
                $add_to_description="";
            }
            else {
                $commonopts="--connect '{$address}:{$port}/{$sid}' --username '{$username}' --password '{$password}' ";
                $add_to_description=$sid." ";
            }

			foreach($services as $svcvar => $svcval){
			
				$pluginopts="";
				$pluginopts.=$commonopts;
			
				switch($svcvar){
								
					case "connection-time":
					
						$pluginopts.="--mode connection-time  --warning ".$serviceargs["connection-time_warning"]." --critical ".$serviceargs["connection-time_critical"]."";
					
						$objs[]=array(
							"type" => OBJECTTYPE_SERVICE,
							"host_name" => $hostname,
							"service_description" => $add_to_description."Connection Time",
							"use" => "xiwizard_oracleserverspace_service",
							"check_command" => "check_xi_oracleserverspace!".$pluginopts,
							"_xiwizard" => $wizard_name,
							);
						break;
								
					case "connected-users":
					
						$pluginopts.="--mode connected-users  --warning ".$serviceargs["connected-users_warning"]." --critical ".$serviceargs["connected-users_critical"]."";
					
						$objs[]=array(
							"type" => OBJECTTYPE_SERVICE,
							"host_name" => $hostname,
							"service_description" => $add_to_description."Connected Users",
							"use" => "xiwizard_oracleserverspace_service",
							"check_command" => "check_xi_oracleserverspace!".$pluginopts,
							"_xiwizard" => $wizard_name,
							);
						break;
								
					case "sga-data-buffer-hit-ratio":
					
						$pluginopts.="--mode sga-data-buffer-hit-ratio  --warning ".$serviceargs["sga-data-buffer-hit-ratio_warning"]." --critical ".$serviceargs["sga-data-buffer-hit-ratio_critical"]."";
					
						$objs[]=array(
							"type" => OBJECTTYPE_SERVICE,
							"host_name" => $hostname,
							"service_description" => $add_to_description."SGA Data Buffer Hit Ratio",
							"use" => "xiwizard_oracleserverspace_service",
							"check_command" => "check_xi_oracleserverspace!".$pluginopts,
							"_xiwizard" => $wizard_name,
							);
						break;
						
					case "sga-library-cache-hit-ratio":
					
						$pluginopts.="--mode sga-library-cache-gethit-ratio  --warning ".$serviceargs["sga-library-cache-hit-ratio_warning"]." --critical ".$serviceargs["sga-library-cache-hit-ratio_critical"]."";
					
						$objs[]=array(
							"type" => OBJECTTYPE_SERVICE,
							"host_name" => $hostname,
							"service_description" => $add_to_description."SGA Library Cache Hit Ratio",
							"use" => "xiwizard_oracleserverspace_service",
							"check_command" => "check_xi_oracleserverspace!".$pluginopts,
							"_xiwizard" => $wizard_name,
							);
						break;				
						

					case "sga-dictionary-cache-hit-ratio":
					
						$pluginopts.="--mode sga-dictionary-cache-hit-ratio  --warning ".$serviceargs["sga-dictionary-cache-hit-ratio_warning"]." --critical ".$serviceargs["sga-dictionary-cache-hit-ratio_critical"]."";
					
						$objs[]=array(
							"type" => OBJECTTYPE_SERVICE,
							"host_name" => $hostname,
							"service_description" => $add_to_description."SGA Dictionary Cache Hit Ratio",
							"use" => "xiwizard_oracleserverspace_service",
							"check_command" => "check_xi_oracleserverspace!".$pluginopts,
							"_xiwizard" => $wizard_name,
							);
						break;	
						
					case "sga-latches-hit-ratio":
					
						$pluginopts.="--mode sga-latches-hit-ratio  --warning ".$serviceargs["sga-latches-hit-ratio_warning"]." --critical ".$serviceargs["sga-latches-hit-ratio_critical"]."";
					
						$objs[]=array(
							"type" => OBJECTTYPE_SERVICE,
							"host_name" => $hostname,
							"service_description" => $add_to_description."SGA Latch Hit Ratio",
							"use" => "xiwizard_oracleserverspace_service",
							"check_command" => "check_xi_oracleserverspace!".$pluginopts,
							"_xiwizard" => $wizard_name,
							);
						break;	
						
					case "sga-shared-pool-reload-ratio":
					
						$pluginopts.="--mode sga-shared-pool-reload-ratio  --warning ".$serviceargs["sga-shared-pool-reload-ratio_warning"]." --critical ".$serviceargs["sga-shared-pool-reload-ratio_critical"]."";
					
						$objs[]=array(
							"type" => OBJECTTYPE_SERVICE,
							"host_name" => $hostname,
							"service_description" => $add_to_description."SGA Shared Pool Reload Ratio",
							"use" => "xiwizard_oracleserverspace_service",
							"check_command" => "check_xi_oracleserverspace!".$pluginopts,
							"_xiwizard" => $wizard_name,
							);
						break;	
						
					case "sga-shared-pool-free":
					
						$pluginopts.="--mode sga-shared-pool-free  --warning ".$serviceargs["sga-shared-pool-free_warning"]." --critical ".$serviceargs["sga-shared-pool-free_critical"]."";
					
						$objs[]=array(
							"type" => OBJECTTYPE_SERVICE,
							"host_name" => $hostname,
							"service_description" => $add_to_description."SGA Shared Pool Free",
							"use" => "xiwizard_oracleserverspace_service",
							"check_command" => "check_xi_oracleserverspace!".$pluginopts,
							"_xiwizard" => $wizard_name,
							);
						break;	
						
					case "pga-in-memory-sort-ratio":
					
						$pluginopts.="--mode pga-in-memory-sort-ratio  --warning ".$serviceargs["pga-in-memory-sort-ratio_warning"]." --critical ".$serviceargs["pga-in-memory-sort-ratio_critical"]."";
					
						$objs[]=array(
							"type" => OBJECTTYPE_SERVICE,
							"host_name" => $hostname,
							"service_description" => $add_to_description."PGA In Memory Sort Ratio",
							"use" => "xiwizard_oracleserverspace_service",
							"check_command" => "check_xi_oracleserverspace!".$pluginopts,
							"_xiwizard" => $wizard_name,
							);
						break;	
											
					case "soft-parse-ratio":
					
						$pluginopts.="--mode soft-parse-ratio  --warning ".$serviceargs["soft-parse-ratio_warning"]." --critical ".$serviceargs["soft-parse-ratio_critical"]."";
					
						$objs[]=array(
							"type" => OBJECTTYPE_SERVICE,
							"host_name" => $hostname,
							"service_description" => $add_to_description."Soft Parse Ratio",
							"use" => "xiwizard_oracleserverspace_service",
							"check_command" => "check_xi_oracleserverspace!".$pluginopts,
							"_xiwizard" => $wizard_name,
							);
						break;	
											
					case "retry-ratio":
					
						$pluginopts.="--mode retry-ratio  --warning ".$serviceargs["retry-ratio_warning"]." --critical ".$serviceargs["retry-ratio_critical"]."";
					
						$objs[]=array(
							"type" => OBJECTTYPE_SERVICE,
							"host_name" => $hostname,
							"service_description" => $add_to_description."Retry Ratio",
							"use" => "xiwizard_oracleserverspace_service",
							"check_command" => "check_xi_oracleserverspace!".$pluginopts,
							"_xiwizard" => $wizard_name,
							);
						break;	
											
					case "redo-io-traffic":
					
						$pluginopts.="--mode redo-io-traffic  --warning ".$serviceargs["redo-io-traffic_warning"]." --critical ".$serviceargs["redo-io-traffic_critical"]."";
					
						$objs[]=array(
							"type" => OBJECTTYPE_SERVICE,
							"host_name" => $hostname,
							"service_description" => $add_to_description."Redo I/O Traffic",
							"use" => "xiwizard_oracleserverspace_service",
							"check_command" => "check_xi_oracleserverspace!".$pluginopts,
							"_xiwizard" => $wizard_name,
							);
						break;	
											
					case "roll-header-contention":
					
						$pluginopts.="--mode roll-header-contention  --warning ".$serviceargs["roll-header-contention_warning"]." --critical ".$serviceargs["roll-header-contention_critical"]."";
					
						$objs[]=array(
							"type" => OBJECTTYPE_SERVICE,
							"host_name" => $hostname,
							"service_description" => $add_to_description."Roll Header Contention",
							"use" => "xiwizard_oracleserverspace_service",
							"check_command" => "check_xi_oracleserverspace!".$pluginopts,
							"_xiwizard" => $wizard_name,
							);
						break;	
											
					case "roll-block-contention":
					
						$pluginopts.="--mode roll-block-contention  --warning ".$serviceargs["roll-block-contention_warning"]." --critical ".$serviceargs["roll-block-contention_critical"]."";
					
						$objs[]=array(
							"type" => OBJECTTYPE_SERVICE,
							"host_name" => $hostname,
							"service_description" => $add_to_description."Roll Block Contention",
							"use" => "xiwizard_oracleserverspace_service",
							"check_command" => "check_xi_oracleserverspace!".$pluginopts,
							"_xiwizard" => $wizard_name,
							);
						break;	
											
					case "roll-hit-ratio":
					
						$pluginopts.="--mode roll-hit-ratio  --warning ".$serviceargs["roll-hit-ratio_warning"]." --critical ".$serviceargs["roll-hit-ratio_critical"]."";
					
						$objs[]=array(
							"type" => OBJECTTYPE_SERVICE,
							"host_name" => $hostname,
							"service_description" => $add_to_description."Roll Hit Ratio",
							"use" => "xiwizard_oracleserverspace_service",
							"check_command" => "check_xi_oracleserverspace!".$pluginopts,
							"_xiwizard" => $wizard_name,
							);
						break;	
											
					case "roll-wraps":
					
						$pluginopts.="--mode roll-wraps --warning ".$serviceargs["roll-wraps_warning"]." --critical ".$serviceargs["roll-wraps_critical"]."";
					
						$objs[]=array(
							"type" => OBJECTTYPE_SERVICE,
							"host_name" => $hostname,
							"service_description" => $add_to_description."Roll Wraps",
							"use" => "xiwizard_oracleserverspace_service",
							"check_command" => "check_xi_oracleserverspace!".$pluginopts,
							"_xiwizard" => $wizard_name,
							);
						break;	
											
					case "roll-extends":
					
						$pluginopts.="--mode roll-extends --warning ".$serviceargs["roll-extends_warning"]." --critical ".$serviceargs["roll-extends_critical"]."";
					
						$objs[]=array(
							"type" => OBJECTTYPE_SERVICE,
							"host_name" => $hostname,
							"service_description" => $add_to_description."Roll Extends",
							"use" => "xiwizard_oracleserverspace_service",
							"check_command" => "check_xi_oracleserverspace!".$pluginopts,
							"_xiwizard" => $wizard_name,
							);
						break;	
											
					case "flash-recovery-area-usage":
					
						$pluginopts.="--mode flash-recovery-area-usage  --warning ".$serviceargs["flash-recovery-area-usage_warning"]." --critical ".$serviceargs["flash-recovery-area-usage_critical"]."";
					
						$objs[]=array(
							"type" => OBJECTTYPE_SERVICE,
							"host_name" => $hostname,
							"service_description" => $add_to_description."Flash Recovery Area Usage",
							"use" => "xiwizard_oracleserverspace_service",
							"check_command" => "check_xi_oracleserverspace!".$pluginopts,
							"_xiwizard" => $wizard_name,
							);
						break;
					
					default:
						break;
					}
				}
				
			//echo "OBJECTS:<BR>";
			//print_r($objs);
			//exit();
					
			// return the object definitions to the wizard
			$outargs[CONFIGWIZARD_NAGIOS_OBJECTS]=$objs;
		
			break;
			
		default:
			break;			
		}
		
	return $output;
	}
	

?>