<?php
// BULK HOST IMPORT CONFIG WIZARD
//
// Copyright (c) 2010 Nagios Enterprises, LLC.  All rights reserved.
//  
// $Id: bulkhostimport.inc.php 1079 2013-06-21 15:30:37Z swilkerson $

include_once(dirname(__FILE__).'/../configwizardhelper.inc.php');

// run the initialization function
bulkhostimport_configwizard_init();

function bulkhostimport_configwizard_init(){

	// only show this wizard to advanced users
	//if(is_advanced_user()==false)
	//	return;
	
	$name="bulkhostimport";
	
	$args=array(
		CONFIGWIZARD_NAME => $name,
		CONFIGWIZARD_TYPE => CONFIGWIZARD_TYPE_MONITORING,
		CONFIGWIZARD_DESCRIPTION => gettext("Clones existing hosts quickly and easily.  Supports import from auto-discovery jobs and CSV input."),
		CONFIGWIZARD_DISPLAYTITLE => "Bulk Host Cloning and Import",
		CONFIGWIZARD_FUNCTION => "bulkhostimport_configwizard_func",
		CONFIGWIZARD_PREVIEWIMAGE => "bulkimport.png",
		CONFIGWIZARD_VERSION => 1.8,
		CONFIGWIZARD_DATE => "09/23/2012",
		);

	register_configwizard($name,$args);
	}
	
function bulkhostimport_configwizard_checkversion(){

	if(!function_exists('get_product_release'))
		return false;
	$ver=get_product_release();
	//echo "VER=$ver";
	if($ver<206)
		return false;
	return true;
	}
	

function bulkhostimport_configwizard_func($mode="",$inargs=null,&$outargs,&$result){

	$wizard_name="bulkhostimport";
	
	// initialize return code and output
	$result=0;
	$output="";
	
	// initialize output args - pass back the same data we got
	$outargs[CONFIGWIZARD_PASSBACK_DATA]=$inargs;


	switch($mode){
		case CONFIGWIZARD_MODE_GETSTAGE1HTML:
		
			$host=grab_array_var($inargs,"host","");
			
			if(bulkhostimport_configwizard_checkversion()==false)
				$output='<p><strong>'.gettext('Error').':</strong> '.gettext('This wizard requires Nagios XI 2011R1.6 or later').'.</p>';
			else{
		
			$output='
			
	<p>
	'.gettext('This wizard allows you to clone existing hosts quicky and easily.  It supports import of new hosts in bulk.').'
	</p>
	<p>'.gettext('New host information is specified in CSV format and each newly imported host is given the same services as an existing host that is being monitored.  This is useful if you setup one host as a template and want to setup several other hosts using the same template').'.
	</p>
	
	<br>

	<div class="sectionTitle">'.gettext('Template Host Information').'</div>
	
			
	<table>
	
	<tr>
	<td valign="top">
	<label>'.gettext('Host Name').':</label><br class="nobr" />
	</td>
	<td>
	<select name="host">
	<OPTION VALUE=""></OPTION>
	';
	
	$args=array(
		"is_active" => 1,
		);
	$xmlhosts=get_xml_host_objects($args);
	foreach($xmlhosts->host as $h){
		$hname=strval($h->host_name);
		$hdesc=$hname;
		$halias=strval($h->alias);
		if($halias!=$hname && $halias!="")
			$hdesc.=" (".$halias.")";
		$output.='<OPTION VALUE="'.$hname.'" '.is_selected($host,$hname).'>'.$hdesc.'</OPTION>';
		}
		
	$output.='
	</select>
	<br class="nobr" /><br>
	'.gettext('Select an existing host that should be cloned and used as the template for new hosts').'.<br><br>
	</td>
	</tr>


	</table>
				';
				}
			break;
			
		case CONFIGWIZARD_MODE_VALIDATESTAGE1DATA:
		
			// get variables that were passed to us
			$host=grab_array_var($inargs,"host","");
			
			
			// check for errors
			$errors=0;
			$errmsg=array();
			//$errmsg[$errors++]="Address: '$address'";
			if(bulkhostimport_configwizard_checkversion()==false)
				$errmsg[$errors++]=gettext("Error: This wizard requires Nagios XI 2011R1.6 or later");
			if(have_value($host)==false)
				$errmsg[$errors++]=gettext("No template host specified.");
			else if(host_exists($host)==false)
				$errmsg[$errors++]=gettext("Template host could not be found.");
			//else if(!valid_ip($address))
				//$errmsg[$errors++]="Invalid IP address.";
				
			if($errors>0){
				$outargs[CONFIGWIZARD_ERROR_MESSAGES]=$errmsg;
				$result=1;
				}
				
			break;
			
		case CONFIGWIZARD_MODE_GETSTAGE2HTML:
		
			// get variables that were passed to us
			$host=grab_array_var($inargs,"host");
			$csvdata=grab_array_var($inargs,"csvdata");
			$field1=grab_array_var($inargs,"field1","address");
			$field2=grab_array_var($inargs,"field2");
			$field3=grab_array_var($inargs,"field3");

			$services="";			
			$services_serial=grab_array_var($inargs,"services_serial","");
			if($services_serial!="")
				$services=unserialize(base64_decode($services_serial));
			if(!is_array($services)){
				$services_default=array(
					);
				$services=grab_array_var($inargs,"services",$services_default);
				}
			$serviceargs="";
			$serviceargs_serial=grab_array_var($inargs,"serviceargs_serial","");
			if($serviceargs_serial!="")
				$serviceargs=unserialize(base64_decode($serviceargs_serial));
			if(!is_array($serviceargs)){
				$serviceargs_default=array(			
					);					
				$serviceargs=grab_array_var($inargs,"serviceargs",$serviceargs_default);
				}
			

			
		
			$output='
			<script type="text/javascript">
				//check all ports 
				var allChecked=false;
				function CheckAll()
				{
					$(".checkbox").each(function() { 
					  this.checked = "checked";					  
					});
				}	
				function UncheckAll()
				{
					$(".checkbox").each(function() { 
					  this.checked = "";					  
					});
				}
                
				</script>
			
		<input type="hidden" name="host" value="'.htmlentities($host).'">

		
	<div class="sectionTitle">'.gettext('Template Host').'</div>
	
	<table>

	<tr>
	<td valign="top">
	';
	
	// show host icon
	$img=get_object_icon_image($host);
	$imghtml=get_object_icon_html($img,"");
	$output.=$imghtml;
	
	$output.='
	<br class="nobr" />
	</td>
	<td><a href="'.get_host_status_detail_link($host).'" target="_blank"><b>'.htmlentities($host).'</b></a><br class="nobr" />
	</td>
	</tr>
	
	</table>

	<div class="sectionTitle">'.gettext('Template Services').'</div>
	
	<p>'.gettext('Specify the services from the template host that should cloned').'. 
    <br/>
    <b><a href="javascript:void(0);" onclick="CheckAll()" title="Check All">'.gettext('Check All').'</a> / 
					<a href="javascript:void(0);" onclick="UncheckAll()" title="Uncheck All">'.gettext('Uncheck All').'</a></b></p>
	
	<table>
	
	<!--<tr><th></th><th>'.gettext('Service').'</th></tr>-->
	';
	
	$args=array(
		"host_name" => $host,
		"is_active" => 1,
		);
	$tservices=get_xml_service_objects($args);
	foreach($tservices->service as $ts){
	
		$sname=strval($ts->service_description);
		if(service_exists($host,$sname)) //extra verification 
			$output.='<tr>
			<td><input type="checkbox" class="checkbox" name="services['.htmlentities($sname).']"  '.is_checked(grab_array_var($services,$sname)).'></td>
			<td><a href="'.get_service_status_detail_link($host,$sname).'" target="_blank"><b>'.htmlentities($sname).'</b></a></td>
			</tr>';
	}
	
	
	$output.='
	</table>

	<div class="sectionTitle">'.gettext('Import / Cloning Data').'</div>
	
	<p>
	'.gettext('Enter addresses of new hosts that should be created by cloning the template host and services specified above').'.
	</p>
	
	<table>

	<tr>
	<td>
	<label>Fields:</label><br class="nobr" />
	</td>
	<td>
	<table>
	<tr><th>'.gettext('Field').' 1</th><th>'.gettext('Field').' 2</th><th>'.gettext('Field').' 3</th></tr>
	<tr>
	<td>
	<select name="field1">
	<option value="address" '.is_selected($field1,"address").'>'.gettext('Address').'</option>
	<option value="hostname" '.is_selected($field1,"hostname").'>'.gettext('Name').'</option>
	<option value="hostalias" '.is_selected($field1,"hostalias").'>'.gettext('Description').'</option>
	</select>
	</td>
	<td>
	<select name="field2">
	<option value="ignore" >'.gettext('IGNORE').'</option>
	<option value="address" '.is_selected($field2,"address").'>'.gettext('Address').'</option>
	<option value="hostname" '.is_selected($field2,"hostname").'>'.gettext('Name').'</option>
	<option value="hostalias" '.is_selected($field2,"hostalias").'>'.gettext('Description').'</option>
	</select>
	</td>
	<td>
	<select name="field3">
	<option value="ignore" >'.gettext('IGNORE').'</option>
	<option value="address" '.is_selected($field3,"address").'>'.gettext('Address').'</option>
	<option value="hostname" '.is_selected($field3,"hostname").'>'.gettext('Name').'</option>
	<option value="hostalias" '.is_selected($field3,"hostalias").'>'.gettext('Description').'</option>
	</select>
	</td>
	</tr>
	</table>
	'.gettext('Specify the type of data that is present in the fields of the data below').'.<br><br>
	</td>
	</tr>
	
	<tr>
	<td valign="top">
	<label>Data:</label><br class="nobr" />
	</td>
	<td>
<textarea name="csvdata" rows="6" cols="50">'.$csvdata.'
</textarea><br>
	'.gettext('The addresses of new hosts that should be created by cloning the template host and services specified above.  Multiple fields should be separated by a comma.  One entry per line.').'
	</td>
	</tr>
	
	</table>
	
			';
			break;
			
		case CONFIGWIZARD_MODE_VALIDATESTAGE2DATA:
		
			// get variables that were passed to us
			$host=grab_array_var($inargs,"host");
			$csvdata=grab_array_var($inargs,"csvdata");
			$field1=grab_array_var($inargs,"field1");
			$field2=grab_array_var($inargs,"field2");
			$field3=grab_array_var($inargs,"field3");
			
			$host_template=nagiosql_read_host_config_from_file($host);
			//print_r($host_template);
			//print grab_array_var($host_template,"use");
			
			
			$services="";			
			$services_serial=grab_array_var($inargs,"services_serial","");
			if($services_serial!="")
				$services=unserialize(base64_decode($services_serial));
			if(!is_array($services)){
				$services=grab_array_var($inargs,"services",array());
				}

			// check for errors
			$errors=0;
			$errmsg=array();
			
            // Not sure why we were requiring services to be selected, so I removed them 6/21/2013 -SW
			//if(count($services)==0)
			//	$errmsg[$errors++]=gettext("No template services selected.");
				
			// check fields
			if($field1!="address" && $field2!="address" && $field3!="address")
				$errmsg[$errors++]="Address must be present in CSV fields.";
			if((($field1==$field2 || $field1==$field3)) && $field1!="ignore" || ($field2==$field3 && $field2!="ignore"))
				$errmsg[$errors++]=gettext("Import / cloning data fields must be unique.");

			// check CSV data
			$csva1=explode("\n",$csvdata);
			$csva2=array_unique($csva1);
			$csva3=array_filter($csva2);
			$csvarray=$csva3;
			if(count($csvarray)==0)
				$errmsg[$errors++]=gettext("No import / cloning data provided.");
				
			if($errors>0){
				$outargs[CONFIGWIZARD_ERROR_MESSAGES]=$errmsg;
				$result=1;
				}
				
			break;

			

		case CONFIGWIZARD_MODE_GETSTAGE3OPTS:	
	
			$output.=gettext('Monitoring options will be inherited from the template host and services you selected.  Click Next to continue.');
			$result=CONFIGWIZARD_HIDE_OPTIONS;
			break;

		case CONFIGWIZARD_MODE_GETSTAGE3HTML:
		
			// get variables that were passed to us
			$host=grab_array_var($inargs,"host");
			$csvdata=grab_array_var($inargs,"csvdata");
			$field1=grab_array_var($inargs,"field1");
			$field2=grab_array_var($inargs,"field2");
			$field3=grab_array_var($inargs,"field3");

			$services="";
			$services_serial=grab_array_var($inargs,"services_serial");
			if($services_serial!="")
				$services=unserialize(base64_decode($services_serial));
			else
				$services=grab_array_var($inargs,"services");
				
			$serviceargs="";
			$serviceargs_serial=grab_array_var($inargs,"serviceargs_serial");
			if($serviceargs_serial!="")
				$serviceargs=unserialize(base64_decode($serviceargs_serial));
			else
				$serviceargs=grab_array_var($inargs,"serviceargs");

			$output='
			
		<input type="hidden" name="host" value="'.htmlentities($host).'">
		<input type="hidden" name="csvdata" value="'.htmlentities($csvdata).'">
		<input type="hidden" name="field1" value="'.htmlentities($field1).'">
		<input type="hidden" name="field2" value="'.htmlentities($field2).'">
		<input type="hidden" name="field3" value="'.htmlentities($field3).'">
		<input type="hidden" name="services_serial" value="'.base64_encode(serialize($services)).'">
		<input type="hidden" name="serviceargs_serial" value="'.base64_encode(serialize($serviceargs)).'">
		
		<!-- SERVICES='.serialize($services).'<BR>
		SERVICEARGS='.serialize($serviceargs).'<BR> -->
		
			';
			break;
			
		case CONFIGWIZARD_MODE_VALIDATESTAGE3DATA:
				
			break;
			
		case CONFIGWIZARD_MODE_GETSTAGE4OPTS:	
	
			$output.=gettext('Notification options will be inherited from the template host and services you selected.  Click Next to continue.');
			$result=CONFIGWIZARD_HIDE_OPTIONS;
			$outargs[CONFIGWIZARD_HIDDEN_OPTIONS]=array(
				CONFIGWIZARD_HIDE_NOTIFICATION_OPTIONS,
				CONFIGWIZARD_HIDE_NOTIFICATION_INTERVAL,
				CONFIGWIZARD_HIDE_NOTIFICATION_TARGETS,
				);

			break;

		case CONFIGWIZARD_MODE_GETSTAGE5OPTS:	
	
			$output.=gettext('Group membership will be inherited from the template host and services you selected.  Click Next to continue.');

			$result=CONFIGWIZARD_HIDE_OPTIONS;
			
			$outargs[CONFIGWIZARD_HIDDEN_OPTIONS]=array(
				CONFIGWIZARD_HIDE_HOSTGROUPS,
				CONFIGWIZARD_HIDE_SERVICEGROUPS,
				CONFIGWIZARD_HIDE_PARENT_HOSTS,
				);

			break;

		case CONFIGWIZARD_MODE_GETFINALSTAGEHTML:
			
			break;
			
		case CONFIGWIZARD_MODE_GETOBJECTS:
		
			$host=grab_array_var($inargs,"host","");
			$csvdata=grab_array_var($inargs,"csvdata");
			$field1=grab_array_var($inargs,"field1");
			$field2=grab_array_var($inargs,"field2");
			$field3=grab_array_var($inargs,"field3");
			
			$services_serial=grab_array_var($inargs,"services_serial","");
			$serviceargs_serial=grab_array_var($inargs,"serviceargs_serial","");
			
			$services=unserialize(base64_decode($services_serial));
			$serviceargs=unserialize(base64_decode($serviceargs_serial));
			
			/*
			echo "SERVICES<BR>";
			print_r($services);
			echo "<BR>";
			echo "SERVICEARGS<BR>";
			print_r($serviceargs);
			echo "<BR>";
			*/
			
			// save data for later use in re-entrance
			/*
			$meta_arr=array();
			$meta_arr["hostname"]=$hostname;
			$meta_arr["address"]=$address;
			$meta_arr["osdistro"]=$osdistro;
			$meta_arr["services"]=$services;
			$meta_arr["serviceargs"]=$serviceargs;
			save_configwizard_object_meta($wizard_name,$hostname,"",$meta_arr);			
			*/
			
			$objs=array();
			
			
			// fetch template host settings
			// read existing configuration from config file

			
			// fetch template service settings
			$service_templates=array();
			foreach($services as $svc => $svcstate){
				// read existing configuration from config file
				$service_templates[$svc]=nagiosql_read_service_config_from_file($host,$svc);
				}
		
			$host_template=nagiosql_read_host_config_from_file($host);
			
			$csva1=explode("\n",$csvdata);
			$csva2=array_unique($csva1);
			$csva3=array_filter($csva2);
			$csvarray=$csva3;
			
			/*
			echo "ARRAY:<BR>";
			print_r($csvarray);
			echo "<BR><BR>";
			*/
			
			foreach($csvarray as $c){
			
				$cf=explode(",",$c);
			
				$fv1=grab_array_var($cf,0,"");
				$fv2=grab_array_var($cf,1,"");
				$fv3=grab_array_var($cf,2,"");
				// fix problem where user uses " in CSV - SW
				$fv1=str_replace('"','',$fv1);
				$fv2=str_replace('"','',$fv2);
				$fv3=str_replace('"','',$fv3);
				/*
				echo "CF:<BR>\n";
				print_r($cf);
				echo "<BR>\n";
				echo "FV1=$fv1<BR>\n";
				echo "FV2=$fv2<BR>\n";
				echo "FV3=$fv3<BR>\n";
				*/
				
				$address="";
				$hostname="";
				$hostalias="";
				
				switch($field1){
					case "address":
						$address=$fv1;
						break;
					case "hostname":
						$hostname=$fv1;
						break;
					case "hostalias":
						$hostalias=$fv1;
						break;
					}
				switch($field2){
					case "address":
						$address=$fv2;
						break;
					case "hostname":
						$hostname=$fv2;
						break;
					case "hostalias":
						$hostalias=$fv2;
						break;
					}				
				switch($field3){
					case "address":
						$address=$fv3;
						break;
					case "hostname":
						$hostname=$fv3;
						break;
					case "hostalias":
						$hostalias=$fv3;
						break;
					}
					
				//echo "ADDRESS: $address<BR>";
				//echo "HOSTALIAS: $hostalias<BR>";
				//echo "HOSTNAME1: $hostname<BR>";
				
				$address=trim($address);
				$hostname=trim($hostname);
				$hostalias=trim($hostalias);
				
				if($address=="")
					continue;
					
				if($hostname=="")
					$hostname=$address;

				//echo "HOSTNAME: '$hostname'<BR>";
					
				if(is_valid_host_name($hostname)==false){
					//echo "BAD HOST NAME!<BR><BR>";
					continue;
					}
					
				//echo "OK TO GO!<BR><BR>";

				// add the host
				if(!host_exists($hostname)){
					$newhost=array(
						"type" => OBJECTTYPE_HOST,
						"use" => grab_array_var($host_template,"use","generic-host"),
						"host_name" => $hostname,
						"address" => $address,
                        "alias" => $hostalias,
						//"check_command" => grab_array_var($host_template,"check_command"),
						//"icon_image" => grab_array_var($host_template,"icon_image"),
						//"statusmap_image" => grab_array_var($host_template,"statusmap_image"),
						//"_xiwizard" => grab_array_var($host_template,"_xiwizard"),
						);
						
					// these may or may not be specified in the config file
					$cvars=array(	"check_command",
									"icon_image",
									"statusmap_image",
									"_xiwizard",
									"check_period", // fix 09-23-12 per Ludmil
									"check_interval",
									"retry_interval",
									"max_check_attempts",
									"hostgroups",
									"contacts",
									"contact_groups",
									"notifications_enabled", // fix 09-23-12 per Ludmil
									"notification_period",
									"notification_interval",
									"first_notification_delay",
									"notification_options",
									"use",
									"parents",
					);
					foreach($cvars as $cv){
						$cvv=grab_array_var($host_template, $cv, "null");
						if($cvv != "")
							$newhost[$cv]=$cvv;
						}
					//print_r($newhost);
					$objs[]=$newhost;
					}
					
				// add services to the host
				foreach($services as $svc => $svcstate){
									
					$newsvc=array(
						"type" => OBJECTTYPE_SERVICE,
						"host_name" => $hostname,
						"service_description" => $svc,
						//"check_command" => grab_array_var($service_templates[$svc],"check_command"),
						//"use" => grab_array_var($service_templates[$svc],"use"),
						//"_xiwizard" => grab_array_var($service_templates[$svc],"_xiwizard"),
						);

						
						
					// these may or may not be specified in the config file
					$cvars=array(	"use",
									"check_command",
									"icon_image",
									"_xiwizard",
									"check_period", // fix 09-23-12 per Ludmil
									"check_interval",
									"retry_interval",
									"max_check_attempts",
									"is_volatile",
									"stalking_options",
									"servicegroups",
									"active_checks_enabled",
									"passive_checks_enabled",
									"contacts",
									"contact_groups",
									"notifications_enabled", // fix 09-23-12 per Ludmil
									"notification_period",
									"notification_interval",
									"first_notification_delay",
									"notification_options",
					);
					foreach($cvars as $cv){
						$cvv=grab_array_var($service_templates[$svc],$cv,"null");
						if($cvv!="")
							$newsvc[$cv]=$cvv;
						}

					$objs[]=$newsvc;
					}
				
				}
			
			
			/*
			
			$icon="";
			
			if(!host_exists($hostname)){
				$objs[]=array(
					"type" => OBJECTTYPE_HOST,
					"use" => "xiwizard_linuxserver_host",
					"host_name" => $hostname,
					"address" => $hostaddress,
					"icon_image" => $icon,
					"statusmap_image" => $icon,
					"_xiwizard" => $wizard_name,
					);
				}

			// see which services we should monitor
			foreach($services as $svc => $svcstate){
			
				//echo "PROCESSING: $svc -> $svcstate<BR>\n";
		
				switch($svc){
				
					case "ping":
						$objs[]=array(
							"type" => OBJECTTYPE_SERVICE,
							"host_name" => $hostname,
							"service_description" => "Ping",
							"use" => "xiwizard_linuxserver_ping_service",
							"_xiwizard" => $wizard_name,
							);
						break;
					

					case "commands":
						
						$enabledcmds=$svcstate;
						foreach($enabledcmds as $pid => $pstate){
						
							$pname=$serviceargs["commands"][$pid]["command"];
							$pdesc=$serviceargs["commands"][$pid]["name"];
							
							$checkcommand="check_xi_by_ssh!-C \"".$pname."\"";
						
							$objs[]=array(
								"type" => OBJECTTYPE_SERVICE,
								"host_name" => $hostname,
								"service_description" => $pdesc,
								"use" => "generic-service",
								"check_command" => $checkcommand,
								"_xiwizard" => $wizard_name,
								);		
							}
						break;
					
					default:
						break;
					}
				}
				
			*/
				
//			echo "OBJECTS:<BR>";
//			print "<pre>".print_r($objs,true)."</pre>";
//			exit();
					
			// return the object definitions to the wizard
			$outargs[CONFIGWIZARD_NAGIOS_OBJECTS]=$objs;
			
			break;
			
		default:
			break;			
		}
		
	return $output;
	}

	
function bulkhostimport_configwizard_get_fval(){
	}
?>
