<?php
// MSSQL DATABASE CONFIG WIZARD
//
// Copyright (c) 2010 Nagios Enterprises, LLC.  All rights reserved.
//  
// $Id: $

include_once(dirname(__FILE__).'/../configwizardhelper.inc.php');

// run the initialization function
mssqldatabase_configwizard_init();

function mssqldatabase_configwizard_init(){

	$name="mssqldatabase";
	
	$args=array(
		CONFIGWIZARD_NAME => $name,
        CONFIGWIZARD_VERSION => "1.51",
		CONFIGWIZARD_TYPE => CONFIGWIZARD_TYPE_MONITORING,
		CONFIGWIZARD_DESCRIPTION => gettext("Monitor a MSSQL Database"),
		CONFIGWIZARD_DISPLAYTITLE => gettext("MSSQL Database"),
		CONFIGWIZARD_FUNCTION => "mssqldatabase_configwizard_func",
		CONFIGWIZARD_PREVIEWIMAGE => "mssqldatabase.png",
		);
		
	register_configwizard($name,$args);
	}



function mssqldatabase_configwizard_func($mode="",$inargs=null,&$outargs,&$result){

	$wizard_name="mssqldatabase";
	
	// initialize return code and output
	$result=0;
	$output="";
	
	// initialize output args - pass back the same data we got
	$outargs[CONFIGWIZARD_PASSBACK_DATA]=$inargs;


	switch($mode){
		case CONFIGWIZARD_MODE_GETSTAGE1HTML:
		
			$address=grab_array_var($inargs,"address","");
			$port=grab_array_var($inargs,"port","1433");
            $instance=grab_array_var($inargs,"instance","");
			$username=grab_array_var($inargs,"username","");
			$password=grab_array_var($inargs,"password","");
			$database=grab_array_var($inargs,"database","master");
			
			$output='

	<div class="sectionTitle">'.gettext('MSSQL Database').'</div>
	
	<p>
	'.gettext('Specify the details for connecting to the MSSQL database you want to monitor').'.
	</p>
			
	<table>

	<tr>
	<td valign="top">
	<label>'.gettext('Address').':</label><br class="nobr" />
	</td>
	<td>
<input type="text" size="40" name="address" id="address" value="'.htmlentities($address).'" class="textfield" /><br class="nobr" />
	'.gettext('The IP address or FQDNS name of the MSSQL server').'.<br><br>
	</td>
	</tr>
    
	<tr>
	<td valign="top">
	<label>'.gettext('Instance').':</label><br class="nobr" />
	</td>
	<td>
<input type="text" size="40" name="instance" id="instance" value="'.htmlentities($instance).'" class="textfield" /><br class="nobr" />
	'.gettext('Instance name of the MSSQL server').'.<br><br>
	</td>
	</tr>
	
	<tr>
	<td valign="top">
	<label>'.gettext('Port').':</label><br class="nobr" />
	</td>
	<td>
<input type="text" size="5" name="port" id="port" value="'.htmlentities($port).'" class="textfield" /><br class="nobr" />
	'.gettext('The port to use to connect to the MSSQL server. This defaults to 1433, however, if you are using a named
    instance you should remove this number').'.<br><br>
	</td>
	</tr>

	<tr>
	<td valign="top">
	<label>'.gettext('Username').':</label><br class="nobr" />
	</td>
	<td>
<input type="text" size="20" name="username" id="username" value="'.htmlentities($username).'" class="textfield" /><br class="nobr" />
	'.gettext('The username used to connect to the MSSQL server').'.<br><br>
	</td>
	</tr>

	<tr>
	<td valign="top">
	<label>'.gettext('Password').':</label><br class="nobr" />
	</td>
	<td>
<input type="password" size="20" name="password" id="password" value="'.htmlentities($password).'" class="textfield" /><br class="nobr" />
	'.gettext('The password used to connect to the MSSQL server').'.<br><br>
	</td>
	</tr>

	<tr>
	<td valign="top">
	<label>'.gettext('Database').':</label><br class="nobr" />
	</td>
	<td>
<input type="text" size="20" name="database" id="database" value="'.htmlentities($database).'" class="textfield" /><br class="nobr" />
	'.gettext('The database to connect to on the MSSQL server').'.<br><br>
	</td>
	</tr>


	</table>

			';
			break;
			
		case CONFIGWIZARD_MODE_VALIDATESTAGE1DATA:
		
			// get variables that were passed to us
			$address=grab_array_var($inargs,"address","");
			$port=grab_array_var($inargs,"port","");
            $instance=grab_array_var($inargs,"instance","");
			$username=grab_array_var($inargs,"username","");
			$password=grab_array_var($inargs,"password","");
			$database=grab_array_var($inargs,"database","");
			
			// check for errors
			$errors=0;
			$errmsg=array();
			if(have_value($address)==false)
				$errmsg[$errors++]=gettext("No address specified.");
			if(have_value($port)==false and have_value($instance)==false)
				$errmsg[$errors++]=gettext("No port number or instance name specified.\nOne must be specified.");				
			if(have_value($username)==false)
				$errmsg[$errors++]=gettext("No username specified.");
			if(have_value($password)==false)
				$errmsg[$errors++]=gettext("No password specified.");
			if(have_value($database)==false)
				$errmsg[$errors++]=gettext("No database specified.");
			if($port && $instance)
                $errmsg[$errors++]=gettext("Cannot specify port and instance.");
            
			if($errors>0){
				$outargs[CONFIGWIZARD_ERROR_MESSAGES]=$errmsg;
				$result=1;
				}
				
			break;
			
		case CONFIGWIZARD_MODE_GETSTAGE2HTML:
		
			// get variables that were passed to us
			$address=grab_array_var($inargs,"address");
			$port=grab_array_var($inargs,"port","");
            $instance=grab_array_var($inargs,"instance","");
			$username=grab_array_var($inargs,"username","");
			$password=grab_array_var($inargs,"password","");
			$database=grab_array_var($inargs,"database","");

			$ha=@gethostbyaddr($address);
			if($ha=="")
				$ha=$address;
			$hostname=grab_array_var($inargs,"hostname",$ha);
			
		
			$services=grab_array_var($inargs,"services",array(
				"connection_time"=>"on",
				"logfileusage"=>"on",
				"active_transactions" => "on",
				"transactions_per_second"=>"on",
				"log_cache_hit_rate"=>"on",
				"log_growths"=>"on",
				"log_shrinks"=>"on",
				"log_truncs"=>"on",
				"log_wait"=>"on",
				"log_flushes"=>"on",
				));
			$serviceargs=grab_array_var($inargs,"serviceargs",array(
				"connection_time_warning"=>"1",
				"connection_time_critical"=>"5",
				"logfileusage_warning"=>array("0","80"),
				"logfileusage_critical"=>array("0","90"),
				"active_transactions_warning"=>"10",
				"active_transactions_critical"=>"20",
				"transactions_per_second_warning"=>"10",
				"transactions_per_second_critical"=>"20",
				"log_cache_hit_rate_warning"=>array("0","95"),
				"log_cache_hit_rate_critical"=>array("0","97"),
				"log_truncs_warning"=>"20",
				"log_truncs_critical"=>"30",
				"log_growths_warning"=>"20",
				"log_growths_critical"=>"30",
				"log_shrinks_warning"=>"20",
				"log_shrinks_critical"=>"30",
				"log_wait_warning"=>"100",
				"log_wait_critical"=>"1000",
				"log_flushes_warning"=>"20",
				"log_flushes_critical"=>"30",
				));
			
			$services_serial=grab_array_var($inargs,"services_serial");
			if($services_serial!="")
				$services=unserialize(base64_decode($services_serial));
			$serviceargs_serial=grab_array_var($inargs,"serviceargs_serial");
			if($serviceargs_serial!=""){
				//echo "ARGSSERIAL: $serviceargs_serial<BR>\n";
				$serviceargs=unserialize(base64_decode($serviceargs_serial));
				}
		
			$output='
			
		<input type="hidden" name="address" value="'.htmlentities($address).'" />
		<input type="hidden" name="port" value="'.htmlentities($port).'" />
		<input type="hidden" name="username" value="'.htmlentities($username).'" />
		<input type="hidden" name="password" value="'.htmlentities($password).'" />
		<input type="hidden" name="database" value="'.htmlentities($database).'" />
        <input type="hidden" name="instance" value="'.htmlentities($instance).'" />

	<div class="sectionTitle">'.gettext('MSSQL Server').'</div>
	
			
	<table>
	
	<tr>
	<td valign="top">
	<label>'.gettext('Address').':</label><br class="nobr" />
	</td>
	<td>
<input type="text" size="20" name="address" id="address" value="'.htmlentities($address).'" class="textfield" disabled/><br class="nobr" />
	</td>
	</tr>

	<tr>
	<td valign="top">
	<label>'.gettext('Host Name').':</label><br class="nobr" />
	</td>
	<td>
<input type="text" size="20" name="hostname" id="hostname" value="'.htmlentities($hostname).'" class="textfield" /><br class="nobr" />
	'.gettext('The name you\'d like to have associated with this MSSQL Database').'.
	</td>
	</tr>

	<tr>
	<td valign="top">
	<label>'.gettext('Instance').':</label><br class="nobr" />
	</td>
	<td>
<input type="text" size="20" name="instance" id="instance" value="'.htmlentities($instance).'" class="textfield" disabled/><br class="nobr" />
	'.gettext('Instance name of the MSSQL server').'.<br><br>
	</td>
	</tr>
	
	<tr>
	<td valign="top">
	<label>'.gettext('Port').':</label><br class="nobr" />
	</td>
	<td>
<input type="text" size="5" name="port" id="port" value="'.htmlentities($port).'" class="textfield" disabled/><br class="nobr" />
	</td>
	</tr>

	<tr>
	<td valign="top">
	<label>'.gettext('Username').':</label><br class="nobr" />
	</td>
	<td>
<input type="text" size="20" name="username" id="username" value="'.htmlentities($username).'" class="textfield" disabled/><br class="nobr" />
	</td>
	</tr>

	<tr>
	<td valign="top">
	<label>'.gettext('Password').':</label><br class="nobr" />
	</td>
	<td>
<input type="password" size="20" name="password" id="password" value="'.htmlentities($password).'" class="textfield" disabled/><br class="nobr" />
	</td>
	</tr>

	<tr>
	<td valign="top">
	<label>'.gettext('Database').':</label><br class="nobr" />
	</td>
	<td>
<input type="text" size="20" name="database" id="database" value="'.htmlentities($database).'" class="textfield" disabled/><br class="nobr" />
	</td>
	</tr>

	</table>


	<div class="sectionTitle">'.gettext('MSSQL Database Metrics').'</div>
	
	<p>'.gettext('Specify the metrics you\'d like to monitor on the MSSQL Database').'.</p>
	
	
	<table>
	
	<tr>
	<td valign="top">
	<input type="checkbox" class="checkbox" name="services[connection_time]" '.is_checked(grab_array_var($services,"connection_time"),"on").'>
	</td>
	<td>
	<b>'.gettext('Connection Time').'</b><br> 
	'.gettext('Monitor the time it takes to connect to the database').'.<br>
	<label>'.gettext('Warning Threshold').':</label> <input type="text" size="1" name="serviceargs[connection_time_warning]" value="'.htmlentities($serviceargs["connection_time_warning"]).'">sec&nbsp;&nbsp;<label>'.gettext('Critical Threshold').':</label> <input type="text" size="1" name="serviceargs[connection_time_critical]" value="'.htmlentities($serviceargs["connection_time_critical"]).'">sec<br><br>
	</td>
	</tr>

	<tr>
	<td valign="top">
	<input type="checkbox" class="checkbox" name="services[logfileusage]" '.is_checked(grab_array_var($services,"logfileusage"),"on").'>
	</td>
	<td>
	<b>'.gettext('Log File Usage').'</b><br> 
	'.gettext('Monitor how much of the Log File is in use').'.<br>
	<table border="0">
	<tr>
	<td><label>'.gettext('Warning Thresholds').'</label></td>
	<td><label>'.gettext('Low').':</label></td>
	<td><input type="text" size="1" name="serviceargs[logfileusage_warning][0]" value="'.htmlentities($serviceargs["logfileusage_warning"][0]).'">min</td>
	<td><label>'.gettext('High').':</label></td>
	<td><input type="text" size="1" name="serviceargs[logfileusage_warning][1]" value="'.htmlentities($serviceargs["logfileusage_warning"][1]).'">min</td>
	</tr>
	<tr>
	<td><label>'.gettext('Critical Thresholds').'</label></td>
	<td><label>'.gettext('Low').':</label></td>
	<td><input type="text" size="1" name="serviceargs[logfileusage_critical][0]" value="'.htmlentities($serviceargs["logfileusage_critical"][0]).'">min</td>
	<td><label>'.gettext('High').':</label></td>
	<td><input type="text" size="1" name="serviceargs[logfileusage_critical][1]" value="'.htmlentities($serviceargs["logfileusage_critical"][1]).'">min</td>
	</tr>
	</table>
	<br>
	</td>
	</tr>

	<tr>
	<td valign="top">
	<input type="checkbox" class="checkbox" name="services[active_transactions]" '.is_checked(grab_array_var($services,"active_transactions"),"on").'>
	</td>
	<td>
	<b>'.gettext('Open Connections').'</b><br> 
	'.gettext('Monitor the number of currently open connections').'.<br>
	<label>'.gettext('Warning Threshold').':</label> <input type="text" size="2" name="serviceargs[active_transactions_warning]" value="'.htmlentities($serviceargs["active_transactions_warning"]).'">&nbsp;&nbsp;<label>'.gettext('Critical Threshold').':</label> <input type="text" size="2" name="serviceargs[active_transactions_critical]" value="'.htmlentities($serviceargs["active_transactions_critical"]).'"><br><br>
	</td>
	</tr>

	<tr>
	<td valign="top">
	<input type="checkbox" class="checkbox" name="services[transactions_per_second]" '.is_checked(grab_array_var($services,"transactions_per_second"),"on").'>
	</td>
	<td>
	<b>'.gettext('Transactions Per Second').'</b><br> 
	'.gettext('Monitor the transactions per second').'.<br>
	<label>'.gettext('Warning Threshold').':</label> <input type="text" size="2" name="serviceargs[transactions_per_second_warning]" value="'.htmlentities($serviceargs["transactions_per_second_warning"]).'" />/sec&nbsp;&nbsp;<label>'.gettext('Critical Threshold').':</label> <input type="text" size="2" name="serviceargs[transactions_per_second_critical]" value="'.htmlentities($serviceargs["transactions_per_second_critical"]).'" />/sec<br><br>
	</td>
	</tr>
	
	<tr>
	<td valign="top">
	<input type="checkbox" class="checkbox" name="services[log_cache_hit_rate]" '.is_checked(grab_array_var($services,"log_cache_hit_rate"),"on").'>
	</td>
	<td>
	<b>'.gettext('Log Cache Hitrate').'</b><br> 
	'.gettext('Monitor the log cache hit rate').'.<br>
	<table border="0">
	<tr>
	<td><label>'.gettext('Warning Thresholds').'</label></td>
	<td><label>'.gettext('Low').':</label></td>
	<td><input type="text" size="1" name="serviceargs[log_cache_hit_rate_warning][0]" value="'.htmlentities($serviceargs["log_cache_hit_rate_warning"][0]).'">%</td>
	<td><label>'.gettext('High').':</label></td>
	<td><input type="text" size="1" name="serviceargs[log_cache_hit_rate_warning][1]" value="'.htmlentities($serviceargs["log_cache_hit_rate_warning"][1]).'">%</td>
	</tr>
	<tr>
	<td><label>'.gettext('Critical Thresholds').'</label></td>
	<td><label>'.gettext('Low').':</label></td>
	<td><input type="text" size="1" name="serviceargs[log_cache_hit_rate_critical][0]" value="'.htmlentities($serviceargs["log_cache_hit_rate_critical"][0]).'">%</td>
	<td><label>'.gettext('High').':</label></td>
	<td><input type="text" size="1" name="serviceargs[log_cache_hit_rate_critical][1]" value="'.htmlentities($serviceargs["log_cache_hit_rate_critical"][1]).'">%</td>
	</tr>
	</table>
	<br>
	</td>
	</tr>
	
	<tr>
	<td valign="top">
	<input type="checkbox" class="checkbox" name="services[log_wait]" '.is_checked(grab_array_var($services,"log_wait"),"on").'>
	</td>
	<td>
	<b>'.gettext('Log Waits').'</b><br> 
	'.gettext('Monitor the log waits due to small log buffers').'.<br>
	<label>'.gettext('Warning Threshold').':</label> <input type="text" size="2" name="serviceargs[log_wait_warning]" value="'.htmlentities($serviceargs["log_wait_warning"]).'">/sec&nbsp;&nbsp;<label>'.gettext('Critical Threshold').':</label> <input type="text" size="2" name="serviceargs[log_wait_critical]" value="'.htmlentities($serviceargs["log_wait_critical"]).'">/sec<br><br>
	</td>
	</tr>

	<tr>
	<td valign="top">
	<input type="checkbox" class="checkbox" name="services[log_growths]" '.is_checked(grab_array_var($services,"log_growths"),"on").'>
	</td>
	<td>
	<b>'.gettext('Log Growths').'</b><br> 
	'.gettext('Monitor the log growths due to improperly sized partitions').'.<br>
	<label>'.gettext('Warning Threshold').':</label> <input type="text" size="2" name="serviceargs[log_growths_warning]" value="'.htmlentities($serviceargs["log_growths_warning"]).'">/sec&nbsp;&nbsp;<label>'.gettext('Critical Threshold').':</label> <input type="text" size="2" name="serviceargs[log_growths_critical]" value="'.htmlentities($serviceargs["log_growths_critical"]).'">/sec<br><br>
	</td>
	</tr>
	
	<tr>
	<td valign="top">
	<input type="checkbox" class="checkbox" name="services[log_shrinks]" '.is_checked(grab_array_var($services,"log_shrinks"),"on").'>
	</td>
	<td>
	<b>'.gettext('Log Shrinks').'</b><br> 
	'.gettext('Monitor the log shrinks due to improperly sized partitions').'.<br>
	<label>'.gettext('Warning Threshold').':</label> <input type="text" size="2" name="serviceargs[log_shrinks_warning]" value="'.htmlentities($serviceargs["log_shrinks_warning"]).'">/sec&nbsp;&nbsp;<label>'.gettext('Critical Threshold').':</label> <input type="text" size="2" name="serviceargs[log_shrinks_critical]" value="'.htmlentities($serviceargs["log_shrinks_critical"]).'">/sec<br><br>
	</td>
	</tr>

	<tr>
	<td valign="top">
	<input type="checkbox" class="checkbox" name="services[log_truncs]" '.is_checked(grab_array_var($services,"log_truncs"),"on").'>
	</td>
	<td>
	<b>'.gettext('Log Truncations').'</b><br> 
	'.gettext('Monitor the log truncations due to malformed tables').'.<br>
	<label>'.gettext('Warning Threshold').':</label> <input type="text" size="2" name="serviceargs[log_truncs_warning]" value="'.htmlentities($serviceargs["log_truncs_warning"]).'">/sec&nbsp;&nbsp;<label>'.gettext('Critical Threshold').':</label> <input type="text" size="2" name="serviceargs[log_truncs_critical]" value="'.htmlentities($serviceargs["log_truncs_critical"]).'">/sec<br><br>
	</td>
	</tr>
	
	<tr>
	<td valign="top">
	<input type="checkbox" class="checkbox" name="services[log_wait]" '.is_checked(grab_array_var($services,"log_wait"),"on").'>
	</td>
	<td>
	<b>'.gettext('Log Flush Wait Times').'</b><br> 
	'.gettext('Monitor the log flush wait times to load').'.<br>
	<label>'.gettext('Warning Threshold').':</label> <input type="text" size="2" name="serviceargs[log_truncs_warning]" value="'.htmlentities($serviceargs["log_wait_warning"]).'">ms&nbsp;&nbsp;<label>'.gettext('Critical Threshold').':</label> <input type="text" size="2" name="serviceargs[log_wait_critical]" value="'.htmlentities($serviceargs["log_truncs_critical"]).'">ms<br><br>
	</td>
	</tr>
		
	</table>
	';
			break;
			
		case CONFIGWIZARD_MODE_VALIDATESTAGE2DATA:
		
			// get variables that were passed to us
			$address=grab_array_var($inargs,"address");
			$hostname=grab_array_var($inargs,"hostname");
			$port=grab_array_var($inargs,"port","");
			$username=grab_array_var($inargs,"username","");
			$password=grab_array_var($inargs,"password","");
			$database=grab_array_var($inargs,"database","");
            $instance=grab_array_var($inargs,"instance","");
			$services=grab_array_var($inargs,"services",array());
			$serviceargs=grab_array_var($inargs,"serviceargs",array());
			
		
			// check for errors
			$errors=0;
			$errmsg=array();
			if(is_valid_host_name($hostname)==false)
				$errmsg[$errors++]="Invalid host name.";
				
			if($errors>0){
				$outargs[CONFIGWIZARD_ERROR_MESSAGES]=$errmsg;
				$result=1;
				}
				
			break;

			
		case CONFIGWIZARD_MODE_GETSTAGE3HTML:
		
			// get variables that were passed to us
			$address=grab_array_var($inargs,"address");
			$hostname=grab_array_var($inargs,"hostname");
			$port=grab_array_var($inargs,"port","");
            $instance=grab_array_var($inargs,"instance","");
			$username=grab_array_var($inargs,"username","");
			$password=grab_array_var($inargs,"password","");
			$database=grab_array_var($inargs,"database","");
			
			$services=grab_array_var($inargs,"services");
			$serviceargs=grab_array_var($inargs,"serviceargs");
		
			$output='
			
		<input type="hidden" name="address" value="'.htmlentities($address).'">
        <input type="hidden" name="instance" value="'.htmlentities($instance).'">
		<input type="hidden" name="hostname" value="'.htmlentities($hostname).'">
		<input type="hidden" name="port" value="'.htmlentities($port).'">
		<input type="hidden" name="username" value="'.htmlentities($username).'">
		<input type="hidden" name="password" value="'.htmlentities($password).'">
		<input type="hidden" name="database" value="'.htmlentities($database).'">
		<input type="hidden" name="services_serial" value="'.base64_encode(serialize($services)).'">
		<input type="hidden" name="serviceargs_serial" value="'.base64_encode(serialize($serviceargs)).'">
		
		<!--SERVICES='.serialize($services).'<BR>
		SERVICEARGS='.serialize($serviceargs).'<BR>-->
		
			';
			break;
			
		case CONFIGWIZARD_MODE_VALIDATESTAGE3DATA:
				
			break;
			
		case CONFIGWIZARD_MODE_GETFINALSTAGEHTML:
			
			
			$output='
			';
			break;
			
		case CONFIGWIZARD_MODE_GETOBJECTS:
		
			$hostname=grab_array_var($inargs,"hostname","");
			$address=grab_array_var($inargs,"address","");
			$hostaddress=$address;
			$port=grab_array_var($inargs,"port","");
			$username=grab_array_var($inargs,"username","");
            $instance=grab_array_var($inargs,"instance","");
			$password=grab_array_var($inargs,"password","");
			$database=grab_array_var($inargs,"database","");
		
			$services_serial=grab_array_var($inargs,"services_serial","");
			$serviceargs_serial=grab_array_var($inargs,"serviceargs_serial","");
			
			$services=unserialize(base64_decode($services_serial));
			$serviceargs=unserialize(base64_decode($serviceargs_serial));
			
			/*
			echo "SERVICES<BR>";
			print_r($services);
			echo "<BR>";
			echo "SERVICEARGS<BR>";
			print_r($serviceargs);
			echo "<BR>";
			*/
			
			// save data for later use in re-entrance
			$meta_arr=array();
			$meta_arr["hostname"]=$hostname;
			$meta_arr["address"]=$address;
			$meta_arr["port"]=$port;
			$meta_arr["username"]=$username;
			$meta_arr["password"]=$password;
			$meta_arr["database"]=$database;
			$meta_arr["services"]=$services;
			$meta_arr["serviceargs"]=$serviceargs;
            $meta_arr["instance"]=$serviceargs;
			save_configwizard_object_meta($wizard_name,$hostname,"",$meta_arr);			
			
			$objs=array();
			
			if(!host_exists($hostname)){
				$objs[]=array(
					"type" => OBJECTTYPE_HOST,
					"use" => "xiwizard_mssqldatabase_host",
					"host_name" => $hostname,
					"address" => $hostaddress,
					"icon_image" => "mssql.png",
					"statusmap_image" => "mysql.png",
					"_xiwizard" => $wizard_name,
					);
				}
			
			// common plugin opts
			$commonopts="-U '$username' -P '$password' -T '$database' ";
            if($instance)
                $commonopts .= "-I $instance ";
            if($port)
                $commonopts .= "-p $port ";

			foreach($services as $svcvar => $svcval){
			
				$pluginopts="";
				$pluginopts.=$commonopts;
			
				switch($svcvar){
								
					case "connection_time":
					
						$pluginopts.="--time2connect --warning ".$serviceargs["connection_time_warning"]." --critical ".$serviceargs["connection_time_critical"]."";
					
						$objs[]=array(
							"type" => OBJECTTYPE_SERVICE,
							"host_name" => $hostname,
							"service_description" => "MSSQL Connection Time",
							"use" => "xiwizard_mssqldatabase_service",
							"check_command" => "check_xi_mssql_database!".$pluginopts,
							"_xiwizard" => $wizard_name,
							);
						break;
								
					case "logfileusage":
					
						$pluginopts.="--logfileusage --warning ".$serviceargs["logfileusage_warning"][0].":".$serviceargs["logfileusage_warning"][1]." --critical ".$serviceargs["logfileusage_critical"][0].":".$serviceargs["logfileusage_critical"][1];
					
						$objs[]=array(
							"type" => OBJECTTYPE_SERVICE,
							"host_name" => $hostname,
							"service_description" => "MSSQL Log File Usage",
							"use" => "xiwizard_mssqldatabase_service",
							"check_command" => "check_xi_mssql_database!".$pluginopts,
							"_xiwizard" => $wizard_name,
							);
						break;
								
					case "active_transactions":
					
						$pluginopts.="--activetrans --warning ".$serviceargs["active_transactions_warning"]." --critical ".$serviceargs["active_transactions_critical"]."";
					
						$objs[]=array(
							"type" => OBJECTTYPE_SERVICE,
							"host_name" => $hostname,
							"service_description" => "MSSQL Active Transactions",
							"use" => "xiwizard_mssqldatabase_service",
							"check_command" => "check_xi_mssql_database!".$pluginopts,
							"_xiwizard" => $wizard_name,
							);
						break;
						
					case "log_cache_hit_rate":
					
						$pluginopts.="--logcachehit --warning ".$serviceargs["log_cache_hit_rate_warning"][0].":".$serviceargs["log_cache_hit_rate_warning"][1]." --critical ".$serviceargs["log_cache_hit_rate_critical"][0].":".$serviceargs["log_cache_hit_rate_critical"][1];
					
						$objs[]=array(
							"type" => OBJECTTYPE_SERVICE,
							"host_name" => $hostname,
							"service_description" => "MSSQL Log Cache Hit Rate",
							"use" => "xiwizard_mssqldatabase_service",
							"check_command" => "check_xi_mssql_database!".$pluginopts,
							"_xiwizard" => $wizard_name,
							);
						break;					
						

					case "log_wait":
					
						$pluginopts.="--logwait --warning ".$serviceargs["log_wait_warning"]." --critical ".$serviceargs["log_wait_critical"]."";
					
						$objs[]=array(
							"type" => OBJECTTYPE_SERVICE,
							"host_name" => $hostname,
							"service_description" => "MSSQL Log Flush Wait Time",
							"use" => "xiwizard_mssqldatabase_service",
							"check_command" => "check_xi_mssql_database!".$pluginopts,
							"_xiwizard" => $wizard_name,
							);
						break;
						
					case "log_growths":
					
						$pluginopts.="--loggrowths --warning ".$serviceargs["log_growths_warning"]." --critical ".$serviceargs["log_growths_critical"]."";
					
						$objs[]=array(
							"type" => OBJECTTYPE_SERVICE,
							"host_name" => $hostname,
							"service_description" => "MSSQL Log Growths",
							"use" => "xiwizard_mssqldatabase_service",
							"check_command" => "check_xi_mssql_database!".$pluginopts,
							"_xiwizard" => $wizard_name,
							);
						break;
						
					case "log_shrinks":
					
						$pluginopts.="--logshrinks --warning ".$serviceargs["log_shrinks_warning"]." --critical ".$serviceargs["log_shrinks_critical"]."";
					
						$objs[]=array(
							"type" => OBJECTTYPE_SERVICE,
							"host_name" => $hostname,
							"service_description" => "MSSQL Log Shrinks",
							"use" => "xiwizard_mssqldatabase_service",
							"check_command" => "check_xi_mssql_database!".$pluginopts,
							"_xiwizard" => $wizard_name,
							);
						break;		
						
					case "log_truncs":
					
						$pluginopts.="--logtruncs --warning ".$serviceargs["log_truncs_warning"]." --critical ".$serviceargs["log_truncs_critical"]."";
					
						$objs[]=array(
							"type" => OBJECTTYPE_SERVICE,
							"host_name" => $hostname,
							"service_description" => "MSSQL Log Truncations",
							"use" => "xiwizard_mssqldatabase_service",
							"check_command" => "check_xi_mssql_database!".$pluginopts,
							"_xiwizard" => $wizard_name,
							);
						break;		
						
					case "log_flushes":
					
						$pluginopts.="--logflushes --warning ".$serviceargs["log_flushes_warning"]." --critical ".$serviceargs["log_flushes_critical"]."";
					
						$objs[]=array(
							"type" => OBJECTTYPE_SERVICE,
							"host_name" => $hostname,
							"service_description" => "MSSQL Log Flushes / Sec",
							"use" => "xiwizard_mssqldatabase_service",
							"check_command" => "check_xi_mssql_database!".$pluginopts,
							"_xiwizard" => $wizard_name,
							);
						break;		
						
					case "transactions_per_second":
					
						$pluginopts.="--transpsec --warning ".$serviceargs["transactions_per_second_warning"]." --critical ".$serviceargs["transactions_per_second_critical"]."";
					
						$objs[]=array(
							"type" => OBJECTTYPE_SERVICE,
							"host_name" => $hostname,
							"service_description" => "MSSQL Transactions / Sec",
							"use" => "xiwizard_mssqldatabase_service",
							"check_command" => "check_xi_mssql_database!".$pluginopts,
							"_xiwizard" => $wizard_name,
							);
						break;	
						

					default:
						break;
					}
				}
				
			// echo "OBJECTS:<BR>";
			// print_r($objs);
			// exit();
					
			// return the object definitions to the wizard
			$outargs[CONFIGWIZARD_NAGIOS_OBJECTS]=$objs;
		
			break;
			
		default:
			break;			
		}
		
	return $output;
	}
	

?>
