<?php
// WATCHGUARD WIZARD
//
// Copyright (c) 2011 Nagios Enterprises, LLC.  All rights reserved.
//  
// $Id: watchguard.inc.php 659 2011-06-22 20:56:34Z nscott $
//
// TODOS:
// * Smarter MRTG file update
//     Current implementation is naive in that it only looks for a single existing address/port match
//     Make it smarter by determining missing ports in the MRTG file and only adding those...

include_once(dirname(__FILE__).'/../configwizardhelper.inc.php');

// run the initialization function
watchguard_configwizard_init();

function watchguard_configwizard_init(){
	
	$name="watchguard";
	
	$args=array(
		CONFIGWIZARD_NAME => $name,
        CONFIGWIZARD_VERSION => "1.2",
		CONFIGWIZARD_TYPE => CONFIGWIZARD_TYPE_MONITORING,
		CONFIGWIZARD_DESCRIPTION => gettext("Monitor a WatchGuard device."),
		CONFIGWIZARD_DISPLAYTITLE => "WatchGuard",
		CONFIGWIZARD_FUNCTION => "watchguard_configwizard_func",
		CONFIGWIZARD_PREVIEWIMAGE => "watchguard.png",
		);
		
	register_configwizard($name,$args);
	}

function watchguard_configwizard_func($mode="",$inargs=null,&$outargs,&$result){

	$wizard_name="watchguard";

	// initialize return code and output
	$result=0;
	$output="";
	
	// initialize output args - pass back the same data we got
	$outargs[CONFIGWIZARD_PASSBACK_DATA]=$inargs;


	switch($mode){
		case CONFIGWIZARD_MODE_GETSTAGE1HTML:
		
			$address=grab_array_var($inargs,"address","");
			$snmpcommunity=grab_array_var($inargs,"snmpcommunity","public");
			$snmpversion=grab_array_var($inargs,"snmpversion","1");
			$default_port_speed=grab_array_var($inargs,"default_port_speed",100000000);
			$vendor=grab_array_var($inargs,"vendor","");

			$portnames=grab_array_var($inargs,"portnames","number");
			$warn_speed_in_percent=grab_array_var($inargs,"warn_speed_in_percent",20);
			$warn_speed_out_percent=grab_array_var($inargs,"warn_speed_out_percent",20);
			$crit_speed_in_percent=grab_array_var($inargs,"crit_speed_in_percent",50);
			$crit_speed_out_percent=grab_array_var($inargs,"crit_speed_out_percent",50);
			
			$output='

	<div class="sectionTitle">'.gettext('Switch / Router Information').'</div>
	
	<table>
	
	<tr>
	<td valign="top">
	<label>'.gettext('WatchGuard Address').':</label><br class="nobr" />
	</td>
	<td>
<input type="text" size="20" name="address" id="address" value="'.htmlentities($address).'" class="textfield" /><br class="nobr" />
	'.gettext('The IP address of the WatchGuard device you\'d like to monitor').'.
	<br><br>
	</td>
	</tr>

	<tr>
	<td valign="top">
	<label>'.gettext('SNMP Community').':</label><br class="nobr" />
	</td>
	<td>
<input type="text" size="10" name="snmpcommunity" id="snmpcommunity" value="'.htmlentities($snmpcommunity).'" class="textfield" /><br class="nobr" />
	'.gettext('The SNMP community string used to access the WatchGuard device').'.
	<br><br>
	</td>
	</tr>

	<tr>
	<td valign="top">
	<label>'.gettext('SNMP Version').':</label><br class="nobr" />
	</td>
	<td>
	<select name="snmpversion">
	<option value="2" '.is_selected($snmpversion,"2").'>2</option>
	</select><br class="nobr" />
	<br><br>
	</td>
	</tr>

	<tr>
	<td valign="top">
	<label for="portnames">'.gettext('Port Naming Scheme').':</label>
	</td>
	<td>
	<select name="portnames">
	<option value="number" '.is_selected($portnames,"number").'>Port Number</option>
	<option value="name" '.is_selected($portnames,"name").'>Port Description</option>
	</select>
	<br class="nobr" />
	'.gettext('Select the port naming scheme that should be used').'.
	<br><br>
	</td>
	</tr>
	
	<tr>
	<td valign="top">
	<label for="scaninterfaces">'.gettext('Scan Interfaces').':</label>
	</td>
	<td>
	<input type="checkbox" class="checkbox" id="scaninterfaces" name="scaninterfaces" checked><br>
	'.gettext('Scan the WatchGuard device to auto-detect interfaces that can be monitored for link up/down status and bandwidth usage').'.<br>
	'.gettext('The scanning process may take several seconds to complete').'.
	<br><br>
	
	<table border="0">
	<tr><th colspan="2">'.gettext('Bandwidth Monitoring Defaults').'</th></tr>
	<tr>
	<td><label>'.gettext('Warning Input Rate').':</label></td><td><input type="text" class="textfield" size="2" name="warn_speed_in_percent" value="'.htmlentities($warn_speed_in_percent).'">%</td>
	<td><label>'.gettext('Critical Input Rate').':</label></td><td><input type="text" class="textfield" size="2" name="crit_speed_in_percent" value="'.htmlentities($crit_speed_in_percent).'">%</td>
	</tr>
	<tr>
	<td><label>'.gettext('Warning Output Rate').':</label></td><td><input type="text" class="textfield" size="2" name="warn_speed_out_percent" value="'.htmlentities($warn_speed_out_percent).'">%</td>
	<td><label>'.gettext('Critical Output Rate').':</label></td><td><input type="text" class="textfield" size="2" name="crit_speed_out_percent" value="'.htmlentities($crit_speed_out_percent).'">%</td>
	</tr>
	<tr>
	<td><label>'.gettext('Default Port Speed').':</label></td><td colspan="3"><input type="text" class="textfield" size="10" name="default_port_speed" value="'.htmlentities($default_port_speed).'"> bytes/second</td>	
	</tr>
	</table>
	
	</td>
	</tr>


	</table>
			';
			break;
			
		case CONFIGWIZARD_MODE_VALIDATESTAGE1DATA:
		
			// get variables that were passed to us
			$address=grab_array_var($inargs,"address","");
			$snmpcommunity=grab_array_var($inargs,"snmpcommunity");
			$scaninterfaces=grab_array_var($inargs,"scaninterfaces");
			$snmpversion=grab_array_var($inargs,"snmpversion","2");
			$default_port_speed=grab_array_var($inargs,"default_port_speed",100000000);
			
			// check for errors
			$errors=0;
			$errmsg=array();
			//$errmsg[$errors++]="Address: '$address'";
			if(have_value($address)==false)
				$errmsg[$errors++]=gettext("No address specified.");
			else if(!valid_ip($address))
				$errmsg[$errors++]=gettext("Invalid IP address.");
				
			if($errors>0){
				$outargs[CONFIGWIZARD_ERROR_MESSAGES]=$errmsg;
				$result=1;
				}

				
			// things look good so far...
			// if user wants to scan interfaces, immediately launch the command and start working on it....
			if($scaninterfaces=="on"){

				//echo "SCANNING!";
				
				$tmp_dir=get_tmp_dir();
				$outfile=$tmp_dir."/mrtgscan-".$address;
				$donefile=$outfile.".done";	
				
				// get rid of the old "done" file
				if(file_exists($donefile))
					unlink($donefile);
				
				// run MRTG's cfgmaker command in the background
				// TODO - see if data already exists in mrtg.cfg and skip this step....
				$cfgmaker_cmd=switch_configwizard_get_cfgmaker_cmd($snmpcommunity,$address,$snmpversion,$default_port_speed);
				$cmd=$cfgmaker_cmd." > ".$outfile." ; touch ".$donefile." > /dev/null &";
				
				exec($cmd);
				}
				
			break;
			
		case CONFIGWIZARD_MODE_GETSTAGE2HTML:
		
			// get variables that were passed to us
			$address=grab_array_var($inargs,"address");
			$snmpcommunity=grab_array_var($inargs,"snmpcommunity");
			$vendor=grab_array_var($inargs,"vendor","");
			$portnames=grab_array_var($inargs,"portnames");
			$scaninterfaces=grab_array_var($inargs,"scaninterfaces");
			$snmpversion=grab_array_var($inargs,"snmpversion","1");
			$default_port_speed=grab_array_var($inargs,"default_port_speed",100000000);
			$warn_speed_in_percent=grab_array_var($inargs,"warn_speed_in_percent",50);
			$warn_speed_out_percent=grab_array_var($inargs,"warn_speed_out_percent",50);
			$crit_speed_in_percent=grab_array_var($inargs,"crit_speed_in_percent",80);
			$crit_speed_out_percent=grab_array_var($inargs,"crit_speed_out_percent",80);
	
			$hostname=gethostbyaddr($address);
			
			$services="";
			$services_default=array(
				"cpu_usage"=>"on",
				"ping"=>"on",
				"active_connections"=>"on",
				"total_sent_packets"=>"on",
                "total_received_packets"=>"on",
                "stream_requests_total"=>"on",
                "stream_requests_drop"=>"on",
                "total_sent_bytes"=>"on",
                "total_received_bytes"=>"on",
            );
            /* Check to see if there is any information in the $services_serial array. This is in case someone used
            a back form button. We use this data to populate the displayed forms. */
			$services_serial=grab_array_var($inargs,"services_serial");
			if($services_serial!="")
				$services=unserialize(base64_decode($services_serial));
			if(!is_array($services))
				$services=grab_array_var($inargs,"services",$services_default);
                
            $serviceargs="";
			$serviceargs_default=array(
				"cpu_usage_warning"=>"20",
				"cpu_usage_critical"=>"40",
				"ping_warning"=>"20",
				"ping_critical"=>"40",
				"active_connections_warning"=>"300",
				"active_connections_critical"=>"500",
				"total_sent_bytes_warning"=>"1000",
				"total_sent_bytes_critical"=>"2000",
				"total_received_bytes_warning"=>"1000",
				"total_received_bytes_critical"=>"2000",
				"total_sent_packets_warning"=>"1000",
				"total_sent_packets_critical"=>"2000",
				"total_received_packets_warning"=>"1000",
				"total_received_packets_critical"=>"2000",
				"stream_requests_total_warning"=>"300", 
				"stream_requests_total_critical"=>"500",
				"stream_requests_drop_warning"=>"300", 
				"stream_requests_drop_critical"=>"500",
            );
            
			$serviceargs_serial=grab_array_var($inargs,"serviceargs_serial");
			if($serviceargs_serial!=""){
				//echo "ARGSSERIAL: $serviceargs_serial<BR>\n";
				$serviceargs=unserialize(base64_decode($serviceargs_serial));
				}
			if(!is_array($serviceargs))
				$serviceargs=grab_array_var($inargs,"serviceargs",$serviceargs_default);
                
			$output='
			
			
		<input type="hidden" name="address" value="'.htmlentities($address).'">
		<input type="hidden" name="vendor" value="'.htmlentities($vendor).'">
		<input type="hidden" name="snmpcommunity" value="'.htmlentities($snmpcommunity).'">
		<input type="hidden" name="portnames" value="'.htmlentities($portnames).'"> 
		<input type="hidden" name="scaninterfaces" value="'.htmlentities($scaninterfaces).'">
		<input type="hidden" name="warn_speed_in_percent" value="'.htmlentities($warn_speed_in_percent).'">
		<input type="hidden" name="crit_speed_in_percent" value="'.htmlentities($crit_speed_in_percent).'">
		<input type="hidden" name="warn_speed_out_percent" value="'.htmlentities($warn_speed_out_percent).'">
		<input type="hidden" name="crit_speed_out_percent" value="'.htmlentities($crit_speed_out_percent).'">

	<div class="sectionTitle">'.gettext('Switch Details').'</div>
	
	<table>

	<tr>
	<td>
	<label>'.gettext('Switch/Router Address').':</label><br class="nobr" />
	</td>
	<td>
<input type="text" size="20" name="address" id="address" value="'.htmlentities($address).'" class="textfield" disabled/><br class="nobr" />
	</td>
	</tr>

	<tr>
	<td>
	<label>'.gettext('Host Name').':</label><br class="nobr" />
	</td>
	<td>
<input type="text" size="20" name="hostname" id="hostname" value="'.htmlentities($hostname).'" class="textfield" /><br class="nobr" />
	'.gettext('The name you\'d like to have associated with this WatchGuard device').'.
	</td>
	</tr>

	</table>

	<div class="sectionTitle">'.gettext('Services').'</div>
	
	<p>'.gettext('Specify which services you\'d like to monitor for the WatchGuard device').'.</p>
	
	<table>';
    // Create variable here to avoid typos, which will hold the name of the service we are editing
    // Create Ping service HTML
    $cs = array( 0 => "ping" );
    $output.="
	<tr>
	<td valign='top'>
        <input type='checkbox' class='checkbox' id='{$cs[0]}' name='services[{$cs[0]}]' ".is_checked(grab_array_var($services,$cs[0]),"on")." />
    </td>
    <td>
	<b>".gettext('Ping')."</b><br />
	".gettext('Monitors the WatchGuard device with an ICMP ping.  Useful for watching network latency').".<br /><br />
	</td>
	</tr>";
    // Create CPU Usage service HTML
	$cs = array( 'name' => "cpu_usage",
                 'title'=> "CPU Usage",
                 'desc' => gettext("Monitors the Watchguards CPU usage."), );
    $output.="
	<tr>
	<td valign='top'>
	<input type='checkbox' class='checkbox' id='{$cs['name']}' name='services[{$cs['name']}]' ".is_checked(grab_array_var($services,$cs['name']),"on")." />
	</td>
    <td>
    <b>{$cs['title']}</b><br />
	{$cs['desc']} <br />
	<label>".gettext('Warning Threshold').":</label> <input type='text' size='3' name='serviceargs[{$cs['name']}_warning]' value='".htmlentities($serviceargs["{$cs['name']}_warning"])."' />sec&nbsp;&nbsp;<label>".gettext('Critical Threshold').":</label> <input type='text' size='3' name='serviceargs[{$cs['name']}_critical]' value='".htmlentities($serviceargs["{$cs['name']}_critical"])."' />sec<br /><br />
	</td>
    </tr>";
    // Create Active Connections service HTML
	$cs = array( 'name' => "active_connections",
                 'title'=> "Active Connections",
                 'desc' => gettext("Checks the active connections that the WatchGuard device is servicing."), );
    $output.="
	<tr>
	<td valign='top'>
	<input type='checkbox' class='checkbox' id='{$cs['name']}' name='services[{$cs['name']}]' ".is_checked(grab_array_var($services,$cs['name']),"on")." />
	</td>
	<td>
	<b>{$cs['title']}</b><br />
	{$cs['desc']}<br />
	<label>".gettext('Warning Threshold').":</label> <input type='text' size='3' name='serviceargs[{$cs['name']}_warning]' value='".htmlentities($serviceargs["{$cs['name']}_warning"])."' />".gettext("sec")."&nbsp;&nbsp;<label>".gettext('Critical Threshold').":</label> <input type='text' size='3' name='serviceargs[{$cs['name']}_critical]' value='".htmlentities($serviceargs["{$cs['name']}_critical"])."' />".gettext("sec")."<br /><br />
	</td>
    </tr>";
    // Create Total Sent Packets service HTML
	$cs = array( 'name' => "total_sent_packets",
                 'title'=> "Total Sent Packets",
                 'desc' => gettext("Checks the total number of packets sent by the WatchGuard device."), );
    $output.="
	<tr>
	<td valign='top'>
	<input type='checkbox' class='checkbox' id='{$cs['name']}' name='services[{$cs['name']}]' ".is_checked(grab_array_var($services,$cs['name']),"on")." />
	</td>
	<td>
	<b>{$cs['title']}</b><br />
	{$cs['desc']}<br />
	<label>".gettext('Warning Threshold').":</label> <input type='text' size='3' name='serviceargs[{$cs['name']}_warning]' value='".htmlentities($serviceargs["{$cs['name']}_warning"])."' />".gettext("sec")."&nbsp;&nbsp;<label>".gettext('Critical Threshold').":</label> <input type='text' size='3' name='serviceargs[{$cs['name']}_critical]' value='".htmlentities($serviceargs["{$cs['name']}_critical"])."' />".gettext("sec")."<br /><br />
	</td>
    </tr>";
    // Create Total Received Packets service HTML
	$cs = array( 'name' => "total_received_packets",
                 'title'=> "Total Received Packets",
                 'desc' => gettext("Checks the total number of packets received by the WatchGuard device."), );
    $output.="
	<tr>
	<td valign='top'>
	<input type='checkbox' class='checkbox' id='{$cs['name']}' name='services[{$cs['name']}]' ".is_checked(grab_array_var($services,$cs['name']),"on")." />
	</td>
	<td>
	<b>{$cs['title']}</b><br />
	{$cs['desc']}<br />
	<label>".gettext('Warning Threshold').":</label> <input type='text' size='3' name='serviceargs[{$cs['name']}_warning]' value='".htmlentities($serviceargs["{$cs['name']}_warning"])."' />".gettext("sec")."&nbsp;&nbsp;<label>".gettext('Critical Threshold').":</label> <input type='text' size='3' name='serviceargs[{$cs['name']}_critical]' value='".htmlentities($serviceargs["{$cs['name']}_critical"])."' />".gettext("sec")."<br /><br />
	</td>
    </tr>";
    // Create Stream Requests Total service HTML
	$cs = array( 'name' => "stream_requests_total",
                 'title'=> "Stream Requests",
                 'desc' => gettext("Checks the total number of stream requests received by the WatchGuard device."), );
    $output.="
	<tr>
	<td valign='top'>
	<input type='checkbox' class='checkbox' id='{$cs['name']}' name='services[{$cs['name']}]' ".is_checked(grab_array_var($services,$cs['name']),"on")." />
	</td>
	<td>
	<b>{$cs['title']}</b><br />
	{$cs['desc']}<br />
	<label>".gettext('Warning Threshold').":</label> <input type='text' size='3' name='serviceargs[{$cs['name']}_warning]' value='".htmlentities($serviceargs["{$cs['name']}_warning"])."' />".gettext("sec")."&nbsp;&nbsp;<label>".gettext('Critical Threshold').":</label> <input type='text' size='3' name='serviceargs[{$cs['name']}_critical]' value='".htmlentities($serviceargs["{$cs['name']}_critical"])."' />".gettext("sec")."<br /><br />
	</td>
    </tr>";
    // Create Stream Requests Drop service HTML
	$cs = array( 'name' => "stream_requests_drop",
                 'title'=> "Stream Requests Dropped",
                 'desc' => gettext("Checks the total number of stream requests dropped by the WatchGuard device."), );
    $output.="
	<tr>
	<td valign='top'>
	<input type='checkbox' class='checkbox' id='{$cs['name']}' name='services[{$cs['name']}]' ".is_checked(grab_array_var($services,$cs['name']),"on")." />
	</td>
	<td>
	<b>{$cs['title']}</b><br />
	{$cs['desc']}<br />
	<label>".gettext('Warning Threshold').":</label> <input type='text' size='3' name='serviceargs[{$cs['name']}_warning]' value='".htmlentities($serviceargs["{$cs['name']}_warning"])."' />".gettext("sec")."&nbsp;&nbsp;<label>".gettext('Critical Threshold').":</label> <input type='text' size='3' name='serviceargs[{$cs['name']}_critical]' value='".htmlentities($serviceargs["{$cs['name']}_critical"])."' />".gettext("sec")."<br /><br />
	</td>
    </tr>";
    // Create Total Bytes Sent service HTML
	$cs = array( 'name' => "total_sent_bytes",
                 'title'=> "Total Bytes Sent",
                 'desc' => gettext("Checks the total number of bytes sent by the WatchGuard device."), );
    $output.="
	<tr>
	<td valign='top'>
	<input type='checkbox' class='checkbox' id='{$cs['name']}' name='services[{$cs['name']}]' ".is_checked(grab_array_var($services,$cs['name']),"on")." />
	</td>
	<td>
	<b>{$cs['title']}</b><br />
	{$cs['desc']}<br />
	<label>".gettext('Warning Threshold').":</label> <input type='text' size='3' name='serviceargs[{$cs['name']}_warning]' value='".htmlentities($serviceargs["{$cs['name']}_warning"])."' />".gettext("sec")."&nbsp;&nbsp;<label>".gettext('Critical Threshold').":</label> <input type='text' size='3' name='serviceargs[{$cs['name']}_critical]' value='".htmlentities($serviceargs["{$cs['name']}_critical"])."' />".gettext("sec")."<br /><br />
	</td>
    </tr>";
    // Create Total Received Bytes service HTML
	$cs = array( 'name' => "total_received_bytes",
                 'title'=> "Total Received Bytes",
                 'desc' => gettext("Checks the total number of bytes received by the WatchGuard device."), );
    $output.="
	<tr>
	<td valign='top'>
	<input type='checkbox' class='checkbox' id='{$cs['name']}' name='services[{$cs['name']}]' ".is_checked(grab_array_var($services,$cs['name']),"on")." />
	</td>
	<td>
	<b>{$cs['title']}</b><br />
	{$cs['desc']}<br />
	<label>".gettext('Warning Threshold').":</label> <input type='text' size='3' name='serviceargs[{$cs['name']}_warning]' value='".htmlentities($serviceargs["{$cs['name']}_warning"])."' />".gettext("sec")."&nbsp;&nbsp;<label>".gettext('Critical Threshold').":</label> <input type='text' size='3' name='serviceargs[{$cs['name']}_critical]' value='".htmlentities($serviceargs["{$cs['name']}_critical"])."' />".gettext("sec")."<br /><br />
	</td>
    </tr>";
			
			// TODO - add option to monitor switch environmental sensors
			
			$output.='
	</table>
			';

			if($scaninterfaces=="on"){
			
				// read results of MRTG's scan
				// TODO - if switch is already in mrtg.cfg, read that instead...
				$tmp_dir=get_tmp_dir();
				$outfile=$tmp_dir."/mrtgscan-".$address;
				$ports=switch_configwizard_read_walk_file($outfile,$address);
				
				//print_r($ports);
				
				$output.='
				
				<div class="sectionTitle">'.gettext('Bandwidth and Port Status').'</div>
				
				<script type="text/javascript">
				//check all ports 
				var allChecked=false;
				function switchCheckAll()
				{
					$(".portbox:checkbox").each(function() { 
					  this.checked = "checked";					  
					});
				}	
				function switchUncheckAll()
				{
					$(".portbox:checkbox").each(function() { 
					  this.checked = "";					  
					});
				}
				</script>
				
				';
				
				if(count($ports)>1){
				
					$output.='
					<p>'.gettext('Select the ports for which you\'d like to monitor bandwidth and port status.  You may specify an optional port name to be associated with specific ports.').'</p>
					<p><a href="javascript:void(0);" onclick="switchCheckAll()" title="Check All Ports"> Check All Ports</a> / 
					<a href="javascript:void(0);" onclick="switchUncheckAll()" title="Uncheck All Ports"> Uncheck All Ports</a>  
					</p>
					<table class="standardtable">
					<tr><th>'.gettext('Port').'</th><th>'.gettext('Max Speed').'</th><th>'.gettext('Port Name').'</th><th>'.gettext('Bandwidth').'</th><th>'.gettext('Port Status').'</th></tr>
					';
					
					$x=0;
					foreach($ports as $port_num => $parr){
					
						$port_bytes=grab_array_var($parr,"max_bytes",0);
						// we'll use either description or number as the name later
						$port_description=grab_array_var($parr,"port_description",$port_num);
						$port_number=grab_array_var($parr,"port_number",$port_num);
						$port_long_desc = grab_array_var($parr,"port_long_description",$port_num);
						
						// default to using port number for service name
						$port_name="Port ".$port_number;
						if($portnames=="name")
							$port_name=$port_long_desc; //changed to long description -MG 
							
						$x++;
					 
						$max_speed=switch_configwizard_get_readable_port_line_speed($port_bytes,$speed,$label);
						//$speed="mbps";
						$warn_in_speed=($speed*($warn_speed_in_percent/100));
						$warn_out_speed=($speed*($warn_speed_out_percent/100));
						$crit_in_speed=($speed*($crit_speed_in_percent/100));
						$crit_out_speed=($speed*($crit_speed_out_percent/100));
						
						// possible refomat speed values/labels
						switch_configwizard_recalculate_speeds($warn_in_speed,$warn_out_speed,$crit_in_speed,$crit_out_speed,$label);
						
						$rowclass="";
						if(($x%2)!=0)
							$rowclass.=" odd";
						else
							$rowclass.=" even";
					
						$output.='
						<tr class='.$rowclass.'>
						<td valign="top">
						<input type="checkbox" class="checkbox portbox" id="port_'.$port_num.'" name="services[port]['.$port_num.']" checked> 
						Port '.$port_num.'<br />'.
						$port_description
						.'</td>
						
						<td>
						'.$max_speed.'
						</td>

						<td>
						<input type="text" size="20" name="serviceargs[portname]['.$port_num.']" value="'.$port_name.'">
						</td>

						<td>
						<table>
						<tr>
						<td>
						<input type="checkbox" class="checkbox" id="bandwidth_'.$port_num.'" name="serviceargs[bandwidth]['.$port_num.']" checked> 
						</td>
						<td>'.gettext('Rate In').':</td>
						<td>'.gettext('Rate Out').':</td>
						<td></td>
						<td>'.gettext('Rate In').':</td>
						<td>'.gettext('Rate Out').':</td>
						</tr>

						<tr>
						<td>
						<label>'.gettext('Warning').':</label>
						</td>
						<td>
						<input type="text" size="2" name="serviceargs[bandwidth_warning_input_value]['.$port_num.']" value="'.number_format($warn_in_speed).'">
						</td>
						<td>
						<input type="text" size="2" name="serviceargs[bandwidth_warning_output_value]['.$port_num.']" value="'.number_format($warn_out_speed).'">
						</td>
		
						<td>
						<label>'.gettext('Critical').':</label>
						</td>
						<td>
						<input type="text" size="2" name="serviceargs[bandwidth_critical_input_value]['.$port_num.']" value="'.number_format($crit_in_speed).'">
						</td>
						<td>
						<input type="text" size="2" name="serviceargs[bandwidth_critical_output_value]['.$port_num.']" value="'.number_format($crit_out_speed).'">
						</td>
						<td>
						<select name="serviceargs[bandwidth_speed_label]['.$port_num.']">
						<option value="Gbps" '.is_selected("Gbps",$label).'>Gbps</option>
						<option value="Mbps" '.is_selected("Mbps",$label).'>Mbps</option>
						<option value="Kbps" '.is_selected("Kbps",$label).'>Kbps</option>
						<option value="bps" '.is_selected("bps",$label).'>bps</option>
						</select>
						</td>
						</tr>
						</table>
				
						
						</td>
						<td>
						<input type="checkbox" class="checkbox" id="portstatus_'.$port_num.'" name="serviceargs[portstatus]['.$port_num.']" checked>
						</td>
						</tr>
						';
						}
					
					$output.='
					</table>
					';
					}
				else{
					$output.='
					<img src="'.theme_image("critical_small.png").'">
					<b>'.gettext('No ports were detected on the switch').'.</b>  '.gettext('Possible reasons for this include').':
					<ul>
					<li>'.gettext('The switch is currently down').'</li>
					<li>'.gettext('The switch does not exist at the address you specified').'</li>
					<li>'.gettext('SNMP support on the switch is disabled').'</li>
					</ul>
					';
					
					if(is_admin()==true){
						$cfgmaker_cmd=switch_configwizard_get_cfgmaker_cmd($snmpcommunity,$address);
						$output.='
						<br>
						<img src="'.theme_image("ack.png").'">
						<b>'.gettext('Troubleshooting Tip').':</b>
						<p>
						'.gettext('If you keep experiencing problems with the switch wizard scan, login to the Nagios XI server as the root user and execute the following command').':
						</p>
<pre>
'.$cfgmaker_cmd.'
</pre>
<p>
'.gettext('Send the output of the command and a description of your problem to the Nagios support team by posting to our online').' <a href="http://support.nagios.com/forum/" target="_blank">'.gettext('support forum').'</a>.
</p>
						';
						}
					}

				}
			
			break;
			
		case CONFIGWIZARD_MODE_VALIDATESTAGE2DATA:
		
			// get variables that were passed to us
			$hostname=grab_array_var($inargs,"hostname");
			$address=grab_array_var($inargs,"address");
			$portnames=grab_array_var($inargs,"portnames");
			$snmpcommunity=grab_array_var($inargs,"snmpcommunity");
			$vendor=grab_array_var($inargs,"vendor");
			$scaninterfaces=grab_array_var($inargs,"scaninterfaces");
			$warn_speed_in_percent=grab_array_var($inargs,"warn_speed_in_percent",50);
			$warn_speed_out_percent=grab_array_var($inargs,"warn_speed_out_percent",50);
			$crit_speed_in_percent=grab_array_var($inargs,"crit_speed_in_percent",80);
			$crit_speed_out_percent=grab_array_var($inargs,"crit_speed_out_percent",80);
			
			// check for errors
			$errors=0;
			$errmsg=array();
			if(is_valid_host_name($hostname)==false)
				$errmsg[$errors++]=gettext("Invalid host name.");
				
			// TODO - check rate in/out warning and critical thresholds
				
			if($errors>0){
				$outargs[CONFIGWIZARD_ERROR_MESSAGES]=$errmsg;
				$result=1;
				}
				
			break;

			
		case CONFIGWIZARD_MODE_GETSTAGE3HTML:
		
			// get variables that were passed to us
			$address=grab_array_var($inargs,"address");
			$hostname=grab_array_var($inargs,"hostname");
			$vendor=grab_array_var($inargs,"vendor");
			$portnames=grab_array_var($inargs,"portnames");
			$snmpcommunity=grab_array_var($inargs,"snmpcommunity");
			$scaninterfaces=grab_array_var($inargs,"scaninterfaces");
			$warn_speed_in_percent=grab_array_var($inargs,"warn_speed_in_percent",50);
			$warn_speed_out_percent=grab_array_var($inargs,"warn_speed_out_percent",50);
			$crit_speed_in_percent=grab_array_var($inargs,"crit_speed_in_percent",80);
			$crit_speed_out_percent=grab_array_var($inargs,"crit_speed_out_percent",80);

			$services=grab_array_var($inargs,"services");
			$serviceargs=grab_array_var($inargs,"serviceargs");
		
			$services_serial=grab_array_var($inargs,"services_serial",base64_encode(serialize($services)));
			$serviceargs_serial=grab_array_var($inargs,"serviceargs_serial",base64_encode(serialize($serviceargs)));

			
			//~ echo "REQUEST:<BR>";
			//~ global $request;
			//~ print_r($request);
			//~ 
			//~ echo "SERVICES:<BR>";
			//~ print_r($services);
			//~ echo "SERVICEARGS:<BR>";
			//~ print_r($serviceargs);
			
			

			$output='
			
		<input type="hidden" name="address" value="'.htmlentities($address).'">
		<input type="hidden" name="hostname" value="'.htmlentities($hostname).'">
		<input type="hidden" name="snmpcommunity" value="'.htmlentities($snmpcommunity).'">
		<input type="hidden" name="vendor" value="'.htmlentities($vendor).'">
		<input type="hidden" name="portnames" value="'.htmlentities($portnames).'">
		<input type="hidden" name="scaninterfaces" value="'.htmlentities($scaninterfaces).'">
		<input type="hidden" name="warn_speed_in_percent" value="'.htmlentities($warn_speed_in_percent).'">
		<input type="hidden" name="crit_speed_in_percent" value="'.htmlentities($crit_speed_in_percent).'">
		<input type="hidden" name="warn_speed_out_percent" value="'.htmlentities($warn_speed_out_percent).'">
		<input type="hidden" name="crit_speed_out_percent" value="'.htmlentities($crit_speed_out_percent).'">
		<input type="hidden" name="services_serial" value="'.$services_serial.'">
		<input type="hidden" name="serviceargs_serial" value="'.$serviceargs_serial.'">
		

		
			';
			break;
			
		case CONFIGWIZARD_MODE_VALIDATESTAGE3DATA:
				
			break;
			
		case CONFIGWIZARD_MODE_GETFINALSTAGEHTML:
			
			$output='
			
			';
			break;
			
		case CONFIGWIZARD_MODE_GETOBJECTS:
		
			$hostname=grab_array_var($inargs,"hostname","");
			$address=grab_array_var($inargs,"address","");
			$snmpcommunity=grab_array_var($inargs,"snmpcommunity");
			$portnames=grab_array_var($inargs,"portnames");
			$scaninterfaces=grab_array_var($inargs,"scaninterfaces");
			$vendor=grab_array_var($inargs,"vendor");
			
			$hostaddress=$address;
			
			$services_serial=grab_array_var($inargs,"services_serial","");
			$serviceargs_serial=grab_array_var($inargs,"serviceargs_serial","");
			
			$services=unserialize(base64_decode($services_serial));
			$serviceargs=unserialize(base64_decode($serviceargs_serial));
			
			//echo "SERVICES:<BR>";
			//print_r($services);
			//echo "SERVICEARGS:<BR>";
			//print_r($serviceargs);
			
			// save data for later use in re-entrance
			$meta_arr=array();
			$meta_arr["hostname"]=$hostname;
			$meta_arr["address"]=$address;
			$meta_arr["snmpcommunity"]=$snmpcommunity;
			$meta_arr["portnames"]=$portnames;
			$meta_arr["scaninterfaces"]=$scaninterfaces;
			$meta_arr["vendor"]=$vendor;
			$meta_arr["services"]=$services;
			$meta_arr["serivceargs"]=$serviceargs;
			save_configwizard_object_meta($wizard_name,$hostname,"",$meta_arr);	
            
            // ABSTRACTION FOR OIDS
            $CPU_oid                = "1.3.6.1.4.1.3097.6.3.78.0";
            $AConns_oid             = "1.3.6.1.4.1.3097.6.3.80.0";
			$Sent_Packets_oid       = "1.3.6.1.4.1.3097.6.3.10.0";
            $Recv_Packets_oid       = "1.3.6.1.4.1.3097.6.3.11.0";
            $Strm_Requests_oid      = "1.3.6.1.4.1.3097.6.3.30.0";
            $Strm_Dropped_oid       = "1.3.6.1.4.1.3097.6.3.34.0";
            $Sent_Bytes_oid         = "1.3.6.1.4.1.3097.6.3.8.0";
            $Recv_Bytes_oid         = "1.3.6.1.4.1.3097.6.3.9.0";
            
			
			$objs=array();
			
			if(!host_exists($hostname)){
				$objs[]=array(
					"type" => OBJECTTYPE_HOST,
					"use" => "xiwizard_switch_host",
					"host_name" => $hostname,
					"address" => $hostaddress,
					"icon_image" => "switch.png",
					"statusmap_image" => "switch.png",
					"_xiwizard" => $wizard_name,
					);
				}
				
			$have_bandwidth=false;
				
			// see which services we should monitor
			foreach($services as $svc => $svcstate){
			
				//echo "PROCESSING: $svc -> $svcstate<BR>\n";
                $warn = $serviceargs["{$svc}_warning"];
                $crit = $serviceargs["{$svc}_critical"];
                
                
                
				switch($svc){
				
					case "ping":
						$objs[]=array(
							"type" => OBJECTTYPE_SERVICE,
							"host_name" => $hostname,
							"service_description" => "Ping",
							"use" => "xiwizard_switch_ping_service",
							"_xiwizard" => $wizard_name,
							);
						break;
                        
                    case "cpu_usage":
                        $objs[]=array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => "CPU Usage",
                            "use" => "xiwizard_watchguard_service",
                            "check_command" => "check_xi_service_snmp_watchguard!-N '-c $snmpcommunity -v2c' {$CPU_oid} -l CPU_Usage -u '%' -d 'CPU Usage' -w $warn -c $crit -D 100",
                            "_xiwizard" => $wizard_name,
                            );
						break;                            
                            
                    case "active_connections":
                        $objs[]=array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => "Active Connections",
                            "use" => "xiwizard_watchguard_service",
                            "check_command" => "check_xi_service_snmp_watchguard!-N '-c $snmpcommunity -v2c' {$AConns_oid} -l Active_Connections -d 'Active Connections' -w $warn -c $crit",
                            "_xiwizard" => $wizard_name,
                            );
                        break;

                    case "total_sent_packets":
                        $objs[]=array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => "Sent Packets",
                            "use" => "xiwizard_watchguard_service",
                            "check_command" => "check_xi_service_snmp_watchguard!-N '-c $snmpcommunity -v2c' {$Sent_Packets_oid} -l Total_Sent_Packets -d 'Total Sent Packets/Sec' -w $warn -c $crit -e",
                            "_xiwizard" => $wizard_name,
                            );                             
						break;                            
                    
                    case "total_received_packets":
                        $objs[]=array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => "Received Packets",
                            "use" => "xiwizard_watchguard_service",
                            "check_command" => "check_xi_service_snmp_watchguard!-N '-c $snmpcommunity -v2c' {$Recv_Packets_oid} -l Total_Received_Packets -d 'Total Received Packets/Sec' -w $warn -c $crit -e",
                            "_xiwizard" => $wizard_name,
                            );
                        break;

                    case "stream_requests_total":
                        $objs[]=array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => "Stream Requests",
                            "use" => "xiwizard_watchguard_service",
                            "check_command" => "check_xi_service_snmp_watchguard!-N '-c $snmpcommunity -v2c' {$Strm_Requests_oid} -l Total_Stream_Requests -d 'Total Stream Requests/Sec' -w $warn -c $crit -e",
                            "_xiwizard" => $wizard_name,
                            );                                                 
						break;                            

                    case "stream_requests_drop":
                        $objs[]=array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => "Stream Drops",
                            "use" => "xiwizard_watchguard_service",
                            "check_command" => "check_xi_service_snmp_watchguard!-N '-c $snmpcommunity -v2c' {$Strm_Dropped_oid} -l Total_Stream_Requests_Dropped -d 'Total Stream Requests Dropped/Sec' -w $warn -c $crit -e",
                            "_xiwizard" => $wizard_name,
                            );
						break;                                                                             

                    case "total_sent_bytes":
                        $objs[]=array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => "Total Sent Bytes",
                            "use" => "xiwizard_watchguard_service",
                            "check_command" => "check_xi_service_snmp_watchguard!-N '-c $snmpcommunity -v2c' {$Sent_Bytes_oid} -l Sent_Bytes -u KB -d 'Total Sent Bytes/Sec' -w $warn -c $crit -e -D 1024",
                            "_xiwizard" => $wizard_name,
                            );                                                                

                    case "total_received_bytes":
                        $objs[]=array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => "Total Received Bytes",
                            "use" => "xiwizard_watchguard_service",
                            "check_command" => "check_xi_service_snmp_watchguard!-N '-c $snmpcommunity -v2c' {$Recv_Bytes_oid} -l Received_Bytes -u KB -d 'Total Received Bytes/Sec' -w $warn -c $crit -e -D 1024",
                            "_xiwizard" => $wizard_name,
                            );
						break;                            
                    
					case "port":
					
						foreach($svcstate as $portnum => $portstate){
							//echo "HAVE PORT $portnum<BR>\n";
							
							$portname="Port ".$portnum;
							if(array_key_exists("portname",$serviceargs)){
								if(array_key_exists($portnum,$serviceargs["portname"])){
									$portname=$serviceargs["portname"][$portnum];
									}
								}
								
							// monitor bandwidth
							if(array_key_exists("bandwidth",$serviceargs)){
								if(array_key_exists($portnum,$serviceargs["bandwidth"])){
									//echo "MONITOR BANDWIDTH ON $portnum<BR>\n";
									
									$have_bandwidth=true;
									
									$warn_pair=$serviceargs["bandwidth_warning_input_value"][$portnum].",".$serviceargs["bandwidth_warning_output_value"][$portnum];
									$crit_pair=$serviceargs["bandwidth_critical_input_value"][$portnum].",".$serviceargs["bandwidth_critical_output_value"][$portnum];
									
									switch($serviceargs["bandwidth_speed_label"][$portnum]){
										case "Gbps":
											$label="G";
											break;
										case "Mbps":
											$label="M";
											break;
										case "Kbps":
											$label="K";
											break;
										default:
											$label="B";
											break;
										}
									
									$objs[]=array(
										"type" => OBJECTTYPE_SERVICE,
										"host_name" => $hostname,
										"service_description" => $portname." Bandwidth",
										"use" => "xiwizard_switch_port_bandwidth_service",
										"check_command" => "check_xi_service_mrtgtraf!".$hostaddress."_".$portnum.".rrd!".$warn_pair."!".$crit_pair."!".$label,
										"_xiwizard" => $wizard_name,
										);
									}
								}

							// monitor port status
							if(array_key_exists("portstatus",$serviceargs)){
								if(array_key_exists($portnum,$serviceargs["portstatus"])){
									//echo "MONITOR PORT STATUS ON $portnum<BR>\n";
									$objs[]=array(
										"type" => OBJECTTYPE_SERVICE,
										"host_name" => $hostname,
										"service_description" => $portname." Status",
										"use" => "xiwizard_switch_port_status_service",
										"check_command" => "check_xi_service_ifoperstatus!".$snmpcommunity."!".$portnum,
										"_xiwizard" => $wizard_name,
										);
									}
								}

							}
						break;
					
					default:
						break;
					}
				}
				
			//echo "OBJECTS:<BR>";
			//print_r($objs);
			//exit();
			
			// tell MRTG to start monitoring the switch
			if($have_bandwidth==true){
				$tmp_dir=get_tmp_dir();
				$outfile=$tmp_dir."/mrtgscan-".$address;
				switch_configwizard_add_walk_file_to_mrtg($outfile,$address);
				//echo "ADDED WALK FILE TO MRTG...";
				}
			//else
			//	echo "WE DON'T HAVE BANDWIDTH...";

			// return the object definitions to the wizard
			$outargs[CONFIGWIZARD_NAGIOS_OBJECTS]=$objs;
		
			break;
			
		default:
			break;			
		}
		
	return $output;
	}
?>
