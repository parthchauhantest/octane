#!/bin/sh
yum install lftp -y
exit 0