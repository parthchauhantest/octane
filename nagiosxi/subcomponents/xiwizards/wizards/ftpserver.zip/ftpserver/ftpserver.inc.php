<?php
// FTP SERVER CONFIG WIZARD
//
// Copyright (c) 2010 Nagios Enterprises, LLC.  All rights reserved.
//  
// $Id: $

include_once(dirname(__FILE__).'/../configwizardhelper.inc.php');

// run the initialization function
ftpserver_configwizard_init();

function ftpserver_configwizard_init(){
	
	$name="ftpserver";
	
	$args=array(
		CONFIGWIZARD_NAME => $name,
        CONFIGWIZARD_VERSION => "1.51",
		CONFIGWIZARD_TYPE => CONFIGWIZARD_TYPE_MONITORING,
		CONFIGWIZARD_DESCRIPTION => gettext("Monitor login and file transfer capabilities of an FTP server."),
		CONFIGWIZARD_DISPLAYTITLE => "FTP Server",
		CONFIGWIZARD_FUNCTION => "ftpserver_configwizard_func",
		CONFIGWIZARD_PREVIEWIMAGE => "ftpserver.png",
		);
		
	register_configwizard($name,$args);
	}



function ftpserver_configwizard_func($mode="",$inargs=null,&$outargs,&$result){

	$wizard_name="ftpserver";
	
	// initialize return code and output
	$result=0;
	$output="";
	
	// initialize output args - pass back the same data we got
	$outargs[CONFIGWIZARD_PASSBACK_DATA]=$inargs;


	switch($mode){
		case CONFIGWIZARD_MODE_GETSTAGE1HTML:
		
			$address=grab_array_var($inargs,"address","");
			
			$output='

	<div class="sectionTitle">'.gettext('FTP Server').'</div>
	
			
	<table>

	<tr>
	<td valign="top">
	<label>'.gettext('Address').':</label><br class="nobr" />
	</td>
	<td>
<input type="text" size="40" name="address" id="address" value="'.htmlentities($address).'" class="textfield" /><br class="nobr" />
	'.gettext('The IP address or FQDNS name of the device or server associated with the FTP server').'.<br><br>
	</td>
	</tr>

	</table>

			';
			break;
			
		case CONFIGWIZARD_MODE_VALIDATESTAGE1DATA:
		
			// get variables that were passed to us
			$address=grab_array_var($inargs,"address","");
			
			
			// check for errors
			$errors=0;
			$errmsg=array();
			if(have_value($address)==false)
				$errmsg[$errors++]=gettext("No address specified.");
				
			if($errors>0){
				$outargs[CONFIGWIZARD_ERROR_MESSAGES]=$errmsg;
				$result=1;
				}
				
			break;
			
		case CONFIGWIZARD_MODE_GETSTAGE2HTML:
		
			// get variables that were passed to us
			$address=grab_array_var($inargs,"address");

			$ha=@gethostbyaddr($address);
			if($ha=="")
				$ha=$address;
			$hostname=grab_array_var($inargs,"hostname",$ha);
			
			$services_serial=grab_array_var($inargs,"services_serial");
			$serviceargs_serial=grab_array_var($inargs,"serviceargs_serial");
			if($services_serial!="")
				$services=unserialize(base64_decode($services_serial));
			else
				$services=grab_array_var($inargs,"services",array(
					"server"=>"on",
					"transfer"=>"",
					));
			if($serviceargs_serial!="")
				$serviceargs=unserialize(base64_decode($serviceargs_serial));
			else
				$serviceargs=grab_array_var($inargs,"serviceargs",array(
					"server_port"=>"21",
					"server_ssl"=>"",
					"transfer_username"=>"",
					"transfer_password"=>"",
					"transfer_port"=>"21",
					));
				
			//print_r($services);
			//print_r($services_serial);
			
		
			$output='
			
		<input type="hidden" name="address" value="'.htmlentities($address).'">

	<div class="sectionTitle">'.gettext('FTP Server').'</div>
	
			
	<table>
	
	<tr>
	<td valign="top">
	<label>'.gettext('Address').':</label><br class="nobr" />
	</td>
	<td>
<input type="text" size="20" name="address" id="address" value="'.htmlentities($address).'" class="textfield" disabled/><br class="nobr" />
	</td>
	</tr>

	<tr>
	<td valign="top">
	<label>'.gettext('Host Name').':</label><br class="nobr" />
	</td>
	<td>
<input type="text" size="20" name="hostname" id="hostname" value="'.htmlentities($hostname).'" class="textfield" /><br class="nobr" />
	'.gettext('The name you\'d like to have associated with this FTP server.').'
	</td>
	</tr>
	
	</table>


	<div class="sectionTitle">'.gettext('FTP Server Metrics').'</div>
	
	<p>
	'.gettext('Check the options you would like to monitor on the FTP server.').'
	</p>
			
	<table>
	
	<tr>
	<td valign="top">
	<input type="checkbox" class="checkbox" name="services[server]" '.is_checked(htmlentities($services["server"]),"on").'>
	</td>
	<td>
	<b>'.gettext('FTP Server').'</b><br> 
	'.gettext('Check the FTP server to ensure it can be contacted by clients.').'<br>

	<table>

	<tr>
	<td>
	<label>'.gettext('Port').':</label>
	</td>
	<td>
	<input type="text" size="3" name="serviceargs[server_port]" value="'.htmlentities($serviceargs["server_port"]).'" class="textfield" /><br> 
	</td>
	<td>
	<label>'.gettext('Use SSL').':</label>
	</td>
	<td>
	';
	$server_ssl=grab_array_var("server_ssl",$serviceargs);
	$output.='
	<input type="checkbox" class="checkbox" name="serviceargs[server_ssl]" '.is_checked($server_ssl,"on").'><br> 
	</td>
	</tr>

	</table>
	 <br> 
	</td>
	</tr>

	<tr>
	<td valign="top">
	<input type="checkbox" class="checkbox" name="services[transfer]" '.is_checked($services["transfer"],"on").'>
	</td>
	<td>
	<b>'.gettext('File Transfer').'</b><br> 
	'.gettext('Check the FTP server to ensure a test file can be uploaded to and deleted from the root directory.  Does not support SSL.').'<br>

	<table>

	<tr>
	<td>
	<label>'.gettext('Username').':</label>
	</td>
	<td>
	<input type="text" size="10" name="serviceargs[transfer_username]" value="'.htmlentities($serviceargs["transfer_username"]).'" class="textfield" /><br> 
	</td>
	<td>
	<label>'.gettext('Password').':</label>
	</td>
	<td>
	<input type="text" size="10" name="serviceargs[transfer_password]" value="'.htmlentities($serviceargs["transfer_password"]).'" class="textfield" /><br> 
	</td>
	<td>
	<label>'.gettext('Port').':</label>
	</td>
	<td>
	<input type="text" size="3" name="serviceargs[transfer_port]" value="'.htmlentities($serviceargs["transfer_port"]).'" class="textfield" /><br> 
	</td>
	</tr>

	</table>
	</td>
	</tr>

	</table>

			';
			break;
			
		case CONFIGWIZARD_MODE_VALIDATESTAGE2DATA:
		
			// get variables that were passed to us
			$address=grab_array_var($inargs,"address");
			$hostname=grab_array_var($inargs,"hostname");
			
			$services=grab_array_var($inargs,"services",array());
			$serviceargs=grab_array_var($inargs,"serviceargs",array());
			
		
			// check for errors
			$errors=0;
			$errmsg=array();
			if(is_valid_host_name($hostname)==false)
				$errmsg[$errors++]="Invalid host name.";
			/*
			if(array_key_exists("transfer",$services)){
				if($username=="" || $password=="")
					$errmsg[$errors++]="Username or password is blank.";
				if($port=="")
					$errmsg[$errors++]="Invalid port number.";
				}
			*/
			
			if($errors>0){
				$outargs[CONFIGWIZARD_ERROR_MESSAGES]=$errmsg;
				$result=1;
				}
				
			break;

			
		case CONFIGWIZARD_MODE_GETSTAGE3HTML:
		
			// get variables that were passed to us
			$address=grab_array_var($inargs,"address");
			$hostname=grab_array_var($inargs,"hostname");
			
			$services=grab_array_var($inargs,"services");
			$serviceargs=grab_array_var($inargs,"serviceargs");
		
			$output='
			
		<input type="hidden" name="address" value="'.htmlentities($address).'">
		<input type="hidden" name="hostname" value="'.htmlentities($hostname).'">
		<input type="hidden" name="services_serial" value="'.base64_encode(serialize($services)).'">
		<input type="hidden" name="serviceargs_serial" value="'.base64_encode(serialize($serviceargs)).'">
		
		<!--SERVICES='.serialize($services).'<BR>
		SERVICEARGS='.serialize($serviceargs).'<BR>-->
		
			';
			break;
			
		case CONFIGWIZARD_MODE_VALIDATESTAGE3DATA:
				
			break;
			
		case CONFIGWIZARD_MODE_GETFINALSTAGEHTML:
			
			
			$output='
			';
			break;
			
		case CONFIGWIZARD_MODE_GETOBJECTS:
		
			$hostname=grab_array_var($inargs,"hostname","");
			$address=grab_array_var($inargs,"address","");
			$hostaddress=$address;
			
			$services_serial=grab_array_var($inargs,"services_serial","");
			$serviceargs_serial=grab_array_var($inargs,"serviceargs_serial","");
			
			$services=unserialize(base64_decode($services_serial));
			$serviceargs=unserialize(base64_decode($serviceargs_serial));
			
			/*
			echo "SERVICES<BR>";
			print_r($services);
			echo "<BR>";
			echo "SERVICEARGS<BR>";
			print_r($serviceargs);
			echo "<BR>";
			*/
			
			// save data for later use in re-entrance
			$meta_arr=array();
			$meta_arr["hostname"]=$hostname;
			$meta_arr["address"]=$address;
			$meta_arr["services"]=$services;
			$meta_arr["serivceargs"]=$serviceargs;
			save_configwizard_object_meta($wizard_name,$hostname,"",$meta_arr);			
			
			$objs=array();
			
			if(!host_exists($hostname)){
				$objs[]=array(
					"type" => OBJECTTYPE_HOST,
					"use" => "xiwizard_ftpserver_host",
					"host_name" => $hostname,
					"address" => $hostaddress,
					"icon_image" => "ftpserver.png",
					"statusmap_image" => "ftpserver.png",
					"_xiwizard" => $wizard_name,
					);
				}
				
			if(array_key_exists("server",$services)){
			
				$pluginopts="";
				if(array_key_exists("server_port",$serviceargs))
					$pluginopts.=" -p ".$serviceargs["server_port"];
				if(array_key_exists("server_ssl",$serviceargs))
					$pluginopts.=" -S";
			
				$objs[]=array(
					"type" => OBJECTTYPE_SERVICE,
					"host_name" => $hostname,
					"service_description" => "FTP Server",
					"use" => "xiwizard_ftpserver_server_service",
					"check_command" => "check_xi_service_ftp!".$pluginopts,
					"_xiwizard" => $wizard_name,
					"icon_image" => "ftpserver.png",
					);
				}
			
			if(array_key_exists("transfer",$services)){
			
				$username=grab_array_var($serviceargs,"transfer_username");
				$password=grab_array_var($serviceargs,"transfer_password");
				$port=grab_array_var($serviceargs,"transfer_port");
				
				$objs[]=array(
					"type" => OBJECTTYPE_SERVICE,
					"host_name" => $hostname,
					"service_description" => "FTP Transfer",
					"use" => "xiwizard_ftpserver_transfer_service",
					"check_command" => "check_ftp_fully!".$username."!".$password."!".$port,
					"_xiwizard" => $wizard_name,
					);
				}
				
			//echo "OBJECTS:<BR>";
			//print_r($objs);
			//print_r($serviceargs);
			//exit();
					
			// return the object definitions to the wizard
			$outargs[CONFIGWIZARD_NAGIOS_OBJECTS]=$objs;
		
			break;
			
		default:
			break;			
		}
		
	return $output;
	}
	

?>