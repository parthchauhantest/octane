<?php
// AUTO-DISCOVERY CONFIG WIZARD
//
// Copyright (c) 2010 Nagios Enterprises, LLC.  All rights reserved.
//
// $Id: snmp-trap.inc.php 533 2010-08-16 23:12:27Z egalstad $

include_once(dirname(__FILE__).'/../configwizardhelper.inc.php');

// run the initialization function
autodiscovery_configwizard_init();

function autodiscovery_configwizard_init(){
	$name="autodiscovery";

	$args=array(
		CONFIGWIZARD_NAME => $name,
        CONFIGWIZARD_VERSION => "1.1",
		CONFIGWIZARD_TYPE => CONFIGWIZARD_TYPE_MONITORING,
		CONFIGWIZARD_DESCRIPTION => gettext('Monitor devices and services found by auto-discovery jobs.'),
		CONFIGWIZARD_DISPLAYTITLE => 'Auto-Discovery',
		CONFIGWIZARD_FUNCTION => 'autodiscovery_configwizard_func',
		CONFIGWIZARD_PREVIEWIMAGE => 'autodiscovery.png',
		);

	register_configwizard($name,$args);
	}



function autodiscovery_configwizard_func($mode="",$inargs=null,&$outargs,&$result){
	$wizard_name="autodiscovery";

	// initialize return code and output
	$result=0;
	$output="";

	// initialize output args - pass back the same data we got
	$outargs[CONFIGWIZARD_PASSBACK_DATA]=$inargs;


	switch($mode){
		case CONFIGWIZARD_MODE_GETSTAGE1HTML:

			$job=grab_array_var($inargs,"job","");
			$show=grab_array_var($inargs,"show","");
			$addresstype=grab_array_var($inargs,"addresstype","ip");
			$defaultservices=grab_array_var($inargs,"defaultservices","common");
			
			$output='

				<div class="sectionTitle">'.gettext('Auto-Discovery Job').'</div>
	<table>

	<tr>
	<td valign="top">
	<label>'.gettext('Job').':</label><br class="nobr" />
	</td>
	<td>
		<select name="job" >
	';
	
		// get jobs
		$jobs=autodiscovery_component_getjobs();

		// sort jobs by start time
		foreach($jobs as $jobid => $row){
			$search[$jobid] = $row['start_date'];
			}	
		array_multisort($search,SORT_DESC,$jobs);
		
		$visible_jobs=0;
		foreach($jobs as $jobid => $jobarr){

			$output_file=get_component_dir_base("autodiscovery")."/jobs/".$jobid.".xml";

			// job is still running - skip it
			if(!file_exists($output_file))
				continue;
				
			$visible_jobs++;
				
			$total_hosts=0;
			$new_hosts=0;
			$xml=@simplexml_load_file($output_file);
			if($xml){
				foreach($xml->device as $d){
					$status=strval($d->status);
					if($status=="new")
						$new_hosts++;
					$total_hosts++;
					}
				}
				
			$jobdesc='Scan of '.$jobarr["address"].' @ '.get_datetime_string($jobarr["start_date"])." - ".gettext('Found')." ".$new_hosts.' '.gettext('New').' / '.$total_hosts.' '.gettext('Total Hosts');

			$output.='<option value="'.htmlentities($jobid).'" '.is_selected($job,$jobid).'>'.$jobdesc.'</option>';
			}
			
		if($visible_jobs==0){
			$output.='<option value="">'.gettext('No completed auto-discovery jobs found').'.</option>';
			}
		
	$output.='
		</select><br>
	'.gettext('Select the auto-discovery job you wish to use for choosing new hosts and services to monitor.').'
	<br>
	'.gettext('If you wish, you can also').' <a href="'.get_base_url().'/includes/components/autodiscovery/">'.gettext('launch a new discovery job').'</a>.<br><br>
	</td>
	</tr>
	
	<tr>
	<td valign="top">
	<label>'.gettext('Show').':</label><br class="nobr" />
	</td>
	<td>
		<select name="show" >
		<option value="new" '.is_selected($show,"new").'>'.gettext('New Hosts').'</option>
		<option value="all" '.is_selected($show,"all").'>'.gettext('All Hosts').'</option>
		</select><br>
	'.gettext('Choose whether you\'d like to see results from all hosts that were found during the scan, or only new hosts that aren\'t currently being monitored').'.<br><br>
	</td>
	</tr>

	<tr>
	<td valign="top">
	<label>'.gettext('Default Services').':</label><br class="nobr" />
	</td>
	<td>
		<select name="defaultservices" >
		<option value="common" '.is_selected($defaultservices,"common").'>'.gettext('Common').'</option>
		<option value="none" '.is_selected($defaultservices,"none").'>'.gettext('None').'</option>
		<option value="all" '.is_selected($defaultservices,"all").'>'.gettext('All').'</option>
		</select><br>
	'.gettext('Select the types of services that you would like to be selected for monitoring by default.  You can override individual services on the next page').'.<br><br>
	</td>
	</tr>

	<tr>
	<td valign="top">
	<label>'.gettext('Host Addresses').':</label><br class="nobr" />
	</td>
	<td>
		<select name="addresstype" >
		<option value="ip" '.is_selected($addresstype,"ip").'>'.gettext('IP Addresses').'</option>
		<option value="dns" '.is_selected($addresstype,"dns").'>'.gettext('DNS Names').'</option>
		</select><br>
	'.gettext('Select the type of addresses that you would prefer to use for newly configured hosts').'.
	</td>
	</tr>

	</table>

			';
			break;

		case CONFIGWIZARD_MODE_VALIDATESTAGE1DATA:

			// get variables that were passed to us
			$job=grab_array_var($inargs,"job","");
			$defaultservices=grab_array_var($inargs,"defaultservices","common");
			
			
			// check for errors
			$errors=0;
			$errmsg=array();
			if(have_value($job)==false)
				$errmsg[$errors++]=gettext("No job specified.");

			if($errors>0){
				$outargs[CONFIGWIZARD_ERROR_MESSAGES]=$errmsg;
				$result=1;
				}

			break;

		case CONFIGWIZARD_MODE_GETSTAGE2HTML:
		
			//print_r($inargs);
		
			// get variables that were passed to us
			$job=grab_array_var($inargs,"job");
			$show=grab_array_var($inargs,"show","");
			$addresstype=grab_array_var($inargs,"addresstype","ip");
			$defaultservices=grab_array_var($inargs,"defaultservices","common");
			
			$services_serial=grab_array_var($inargs,"services_serial","");
			$services=unserialize(base64_decode($services_serial));
			if(!is_array($services))
				$services=grab_array_var($inargs,"services",array());
			
		
			$output='
			
		<input type="hidden" name="job" value="'.htmlentities($job).'">
		<input type="hidden" name="show" value="'.htmlentities($show).'">
		<input type="hidden" name="addresstype" value="'.htmlentities($addresstype).'">
		<input type="hidden" name="defaultservices" value="'.htmlentities($defaultservices).'">

	<div class="sectionTitle">'.gettext('Scan Results').'</div>
	
			<p>'.gettext('The hosts and services below were discovered during the auto-discovery scan.  Select the hosts and services you\'d like to monitor').'.</p>

			';
			
			if(count($services)==0){

				$jobid=$job;
				$output_file=get_component_dir_base("autodiscovery")."/jobs/".$jobid.".xml";
					
				$total_hosts=0;
				$new_hosts=0;
				$xml=@simplexml_load_file($output_file);
				if($xml){
				
					foreach($xml->device as $d){

						$status=strval($d->status);
						//if($status!="new")
							//continue;
							
						$address=strval($d->address);
						//$fqdns=strval($d->fqdns);
						$fqdns=gethostbyaddr($address);
						
						$os="";
						$type="";

						
						$services[$address]=array(
							"address" => $address,
							"fqdns" => $fqdns,
							"os" => $os,
							"type" => $type,
							"status" => $status,
							"selected" => 0,
							"ports" => array(),
							
							"addressisdns" => 0,
							"hostname" => $fqdns,
							);
						if($addresstype=="ip")
							$services[$address]["hostaddress"]=$address;
						else{
							$dnsname=gethostbyaddr($address);
							if($dnsname!=$address)
								$services[$address]["addressisdns"]=1;
							$services[$address]["hostaddress"]=$dnsname;
							$services[$address]["hostname"]=$dnsname;
							}
							
						// get ports
						foreach($d->ports->port as $p){
							
							$protocol=strval($p->protocol);
							$port=strval($p->port);
							$state=strval($p->state);
							
							if($state!="open")
								continue;
						
							$service=getservbyport($port,strtolower($protocol));
							$servicename=autodiscovery_configwizard_get_friendly_service_name($service,$port,$protocol);
							
							// should the service be selected/shown?
							$is_selected=0;
							$display_service=1;
							if($defaultservices=="all")
								$is_selected=1;
							else if($defaultservices=="common"){
								if(autodiscovery_configwizard_is_common_service($service,$port,$protocol)==true)
									$is_selected=1;
								else
									$display_service=0;
								}
							//echo "SELECTED: $is_selected<BR>";
						
							if($display_service==1){
								$protocol=strtoupper($protocol);
							
								$services[$address]["ports"][$protocol."".$port]=array(
									"protocol" => $protocol,
									"port" => $port,
									"service" => $service,
									"servicename" => $servicename,
									"selected" => $is_selected,
									);
								}
							}

						// get operating system and device type
						foreach($d->operatingsystems->osinfo as $o){
						
							$ostype=strval($o->ostype);
							$osvendor=strval($o->osvendor);
							$osfamily=strval($o->osfamily);
							$osgen=strval($o->osgen);
							
							$services[$address]["ostype"]=$osvendor;
							$services[$address]["osvendor"]=$osvendor;
							$services[$address]["osfamily"]=$osfamily;
							$services[$address]["osgen"]=$osgen;

							autodiscovery_component_get_device_info($ostype,$osvendor,$osfamily,$osgen,$os,$type);
							
							$services[$address]["os"]=$os;
							$services[$address]["type"]=$type;			
							
							break;
							}

							
						}
					}
				else{
					$output.='<p><b>'.gettext('Error').':</b> '.gettext('No results were found in the selected auto-discovery scan').'.</p>';
					}
				}

			// display the hosts/services to choose from
			//$output.=serialize($services);
			
			$output.='
			<script type="text/javascript">
			$(document).ready(function(){
				$("#cb_selectallhosts").click(function(){
					$(".ad_host_checkbox").attr("checked",this.checked);
				});
				$("#cb_selectallservices").click(function(){
					$(".ad_service_checkbox").attr("checked",this.checked);
				});
			});
			</script>
				';

			$output.='
				<table class="standardtable">
				<thead>
				<tr><th rowspan="2"><input type="checkbox" id="cb_selectallhosts" name="selectallhosts"></th><th rowspan="2">'.gettext('Address').'</th><th rowspan="2">'.gettext('Type').'</th><th rowspan="2">'.gettext('OS').'</th><th rowspan="2">'.gettext('Status').'</th><th rowspan="2">'.gettext('Host Name').'</th><th colspan="5">'.gettext('Services').'</th></tr>
				<tr><th><input type="checkbox" id="cb_selectallservices" name="selectallservices"></th><th>'.gettext('Service Name').'</th><th>'.gettext('Service').'</th><th>Port</th><th>'.gettext('Protocol').'</th></tr>
				</thead>
				<tbody>
				';
				
			//print_r($services);
				
			foreach($services as $address => $arr){
			
				$status="";
				if($arr["status"]=="new"){
					$status="New";
					}
				else{
					// skip old hosts
					if($show=="new")
						continue;
					$status="Old";
					}
			
				$output.='<tr>';
				
				$output.='<input type="hidden" name="services['.htmlentities($address).'][address]" value="'.htmlentities($arr["address"]).'">';
				$output.='<input type="hidden" name="services['.htmlentities($address).'][status]" value="'.htmlentities($arr["status"]).'">';
				
				$output.='<td><input type="checkbox" name="services['.htmlentities($address).'][selected]" class="ad_host_checkbox" '.is_checked($services[$address]["selected"],1).'></td>';
				
				$output.='<td>'.$arr["hostaddress"];
				if($services[$address]["addressisdns"]==1)
					$output.='<br> ('.$services[$address]["address"].')';
				$output.='</td>';

				$output.='<td>'.$arr["type"].'</td>';
				$output.='<td>'.$arr["os"].'</td>';
				
				$output.='<td>'.$status.'</td>';

				$output.='<td colspan="6"><input type="text" name="services['.htmlentities($address).'][fqdns]" value="'.htmlentities($arr["hostname"]).'" size="25"></td>';
				
				$output.='</tr>';
			
				foreach($arr["ports"] as $pid => $parr){
				
					$protocol=strtoupper($parr["protocol"]);
					$port=$parr["port"];
					$service=$parr["service"];
					$servicename=$parr["servicename"];
					
					$output.='<tr>';
					$output.='<td colspan="6"></td>';
					
					$output.='<input type="hidden" name="services['.htmlentities($address).'][ports]['.htmlentities($protocol).''.htmlentities($port).'][service]" value="'.htmlentities($service).'">';
					$output.='<input type="hidden" name="services['.htmlentities($address).'][ports]['.htmlentities($protocol).''.htmlentities($port).'][port]" value="'.htmlentities($port).'">';
					$output.='<input type="hidden" name="services['.htmlentities($address).'][ports]['.htmlentities($protocol).''.htmlentities($port).'][protocol]" value="'.htmlentities($parr["protocol"]).'">';
					
					$output.='<td><input type="checkbox" name="services['.htmlentities($address).'][ports]['.htmlentities($protocol).''.htmlentities($port).'][selected]" class="ad_service_checkbox" '.is_checked($services[$address]["ports"][$protocol."".$port]["selected"],1).'></td>';
					
					$output.='<td><input type="text" name="services['.htmlentities($address).'][ports]['.htmlentities($protocol).''.htmlentities($port).'][servicename]" value="'.htmlentities($servicename).'" size="25"></td>';
					
					$output.='<td>'.htmlentities($service).'</td>';
					$output.='<td>'.htmlentities($port).'</td>';
					$output.='<td>'.htmlentities($protocol).'</td>';
					$output.='</tr>';
					}
				if(count($arr["ports"])==0){
					$output.='<tr><td colspan="6"></td><td colspan="5">'.gettext('No services were detected on this host').'.</td></tr>';
					}
			
				$output.='<tr></tr>';
				}
				
			$output.='
				</tbody>
				</table>
				';
		
			break;

		case CONFIGWIZARD_MODE_VALIDATESTAGE2DATA:

			//print_r($inargs);

			// get variables that were passed to us
			$job=grab_array_var($inargs,"job");
			$show=grab_array_var($inargs,"show","");
			$addresstype=grab_array_var($inargs,"addresstype","ip");
			$defaultservices=grab_array_var($inargs,"defaultservices","common");

			$services_serial=grab_array_var($inargs,"services_serial","");
			$services=unserialize(base64_decode($services_serial));
			if(!is_array($services))
				$services=grab_array_var($inargs,"services");
				
			// check for errors
			$errors=0;
			$errmsg=array();
			/*
			if(is_valid_host_name($hostname)==false)
				$errmsg[$errors++]="Invalid host name.";
			*/
			if(!is_array($services))
				$errmsg[$errors++]=gettext("Service array is empty.");
			else{
				$havesvc=false;
				$hosthost=false;
				
				//print_r($services);
				
				foreach($services as $address => $harr){
				
					$checkthishost=false;
				
					if(array_key_exists("selected",$harr)){
						$havesvc=true;
						$havehost=true;
						$checkthishost=true;
						}
				
					// validate host name
					if($checkthishost==true){
						$hostname=$harr["fqdns"];
						if(is_valid_host_name($hostname)==false)
							$errmsg[$errors++]="Invalid host name '<b>$hostname</b>'";
						}						
						
					// check all of the host's services
					foreach($harr["ports"] as $pid => $parr){
						$checkthissvc=false;
						if(array_key_exists("selected",$parr)){
							$havesvc=true;
							$checkthissvc=true;
							}
						// validate service name
						if($checkthishost==true && $checkthissvc==true){
							$servicename=$parr["servicename"];
							if(is_valid_service_name($servicename)==false)
								$errmsg[$errors++]=gettext("Invalid service name")." '<b>$servicename</b>' ".gettext("on host")." <b>$hostname</b>";
							}
						}
					}
				if($havehost==false)
					$errmsg[$errors++]=gettext("No hosts were selected.");
				//$errmsg[$errors++]="Looks okay.";
				}

			if($errors>0){
				$outargs[CONFIGWIZARD_ERROR_MESSAGES]=$errmsg;
				$result=1;
				}

			break;


		case CONFIGWIZARD_MODE_GETSTAGE3OPTS:	
	
			break;

		case CONFIGWIZARD_MODE_GETSTAGE3HTML:

			//print_r($inargs);

			// get variables that were passed to us
			$job=grab_array_var($inargs,"job");
			$show=grab_array_var($inargs,"show","");
			$addresstype=grab_array_var($inargs,"addresstype","ip");
			$defaultservices=grab_array_var($inargs,"defaultservices","common");

			$services_serial=grab_array_var($inargs,"services_serial","");
			$services=unserialize(base64_decode($services_serial));
			if(!is_array($services))
				$services=grab_array_var($inargs,"services");
				
			$serviceargs=grab_array_var($inargs,"serviceargs");

			$output='

		<input type="hidden" name="job" value="'.htmlentities($job).'">
		<input type="hidden" name="show" value="'.htmlentities($show).'">
		<input type="hidden" name="addresstype" value="'.htmlentities($addresstype).'">
		<input type="hidden" name="defaultservices" value="'.htmlentities($defaultservices).'">

		<input type="hidden" name="services_serial" value="'.
			base64_encode(serialize($services)).'">
		<input type="hidden" name="serviceargs_serial" value="'.
			base64_encode(serialize($serviceargs)).'">

		<!--SERVICES='.serialize($services).'<BR>
		SERVICEARGS='.serialize($serviceargs).'<BR>-->

			';
			break;

		case CONFIGWIZARD_MODE_VALIDATESTAGE3DATA:

			break;

		case CONFIGWIZARD_MODE_GETSTAGE4OPTS:

			break;

		case CONFIGWIZARD_MODE_GETFINALSTAGEHTML:


			$output='
			';
			break;

		case CONFIGWIZARD_MODE_GETOBJECTS:

			$services_serial=grab_array_var($inargs,"services_serial","");
			$serviceargs_serial=grab_array_var($inargs,
				"serviceargs_serial","");

			$services=unserialize(base64_decode($services_serial));
			$serviceargs=unserialize(base64_decode($serviceargs_serial));

			$job=grab_array_var($inargs,"job");
			$show=grab_array_var($inargs,"show","");
			$addresstype=grab_array_var($inargs,"addresstype","ip");
			$defaultservices=grab_array_var($inargs,"defaultservices","common");

			/*
			echo "SERVICES<BR>";
			print_r($services);
			echo "<BR>";
			echo "SERVICEARGS<BR>";
			print_r($serviceargs);
			echo "<BR>";
			*/

			$objs=array();
			
			// make sure hosts are monitored if they have a service that is monitored...
			foreach($services as $address => $arr){			
				foreach($arr["ports"] as $pid => $parr){
					if(array_key_exists("selected",$parr))
						$services[$address]["selected"]="on";
					}
				}
		
			// process each host
			foreach($services as $address => $arr){			

					// the host should be monitored...
					if(array_key_exists("selected",$arr)){
					
						$hostname=$arr["fqdns"];
						$address=$arr["address"];

						// add the host if necessary
						if(!host_exists($hostname)){
						
							$hostaddress=$address;
							if($addresstype=="dns")
								$hostaddress=gethostbyaddr($address);
						
							// add the host
							$objs[]=array(
								"type" => OBJECTTYPE_HOST,
								"use" => "xiwizard_generic_host",
								"host_name" => $hostname,
								"address" => $hostaddress,
								"_xiwizard" => $wizard_name,
								);
							
							// add a "Ping" service
							$objs[]=array(
								"type" => OBJECTTYPE_SERVICE,
								"host_name" => $hostname,
								"service_description" => "Ping",
								"use" => "xiwizard_genericnetdevice_ping_service",
								"_xiwizard" => $wizard_name,
								);							
							}
						}

					// process each port/service
					foreach($arr["ports"] as $pid => $parr){
					
						// skip this service if it wasn't selected
						if(!array_key_exists("selected",$parr))
							continue;
					
						$servicename=$parr["servicename"];
						$port=$parr["port"];
						$protocol=$parr["protocol"];
						
						autodiscovery_configwizard_get_object_vars($port,$protocol,$use,$cmdline);

						$newsvc=array(
							'type' => OBJECTTYPE_SERVICE,
							'host_name' => $hostname,
							'service_description' => $servicename,
							'_xiwizard' => $wizard_name,
							);
						if($use!="")
							$newsvc['use']=$use;
						if($cmdline!="")
							$newsvc['check_command']=$cmdline;

						$objs[]=$newsvc;
						}
				}

			//echo "OBJECTS:<BR>";
			//print_r($objs);
			//exit();

			// return the object definitions to the wizard
			$outargs[CONFIGWIZARD_NAGIOS_OBJECTS]=$objs;

			break;


		// THE FOLLOWING MODES ARE POST-CONFIGURATION CALLBACKS
		// THEY CAN BE USED TO DO CONFIGURATION TASKS, ETC AFTER A NEW
		//		CONFIGURATION HAS BEEN SUBMITTED

		case CONFIGWIZARD_MODE_COMMITERROR:
			break;

		case CONFIGWIZARD_MODE_COMMITCONFIGERROR:
			break;

		case CONFIGWIZARD_MODE_COMMITPERMSERROR:
			break;

		case CONFIGWIZARD_MODE_COMMITOK:

			break;

		default:
			break;
		}

	return $output;
	}
	
function autodiscovery_configwizard_get_object_vars($port,$protocol,&$use,&$cmdline){

	$use="xiwizard_generic_service";
	$cmdline="";

	$arr=array(
		"tcp" => array(
			21 => array ("use"=>"xiwizard_ftp_service"),
			22 => array("use"=>"xiwizard_ssh_service"),
			25 => array("use"=>"xiwizard_smtp_service"),
			80 => array("use"=>"xiwizard_website_http_service"),
			110 => array("use"=>"xiwizard_pop_service"),
			143 => array("use"=>"xiwizard_imap_service"),
			443 => array("use"=>"xiwizard_website_http_service","cmdline"=>"check_xi_service_http!-S"),
			),
		"udp" => array(
			),
		);
		
	if(array_key_exists($port,$arr[$protocol])){
		$match=$arr[$protocol][$port];
		$use=grab_array_var($match,"use");
		$cmdline=grab_array_var($match,"cmdline");
		}
	else{
		// use either xiwizard_tcp_service OR xiwizard_udp_service templates
		$use="xiwizard_".$protocol."_service";
		// check_xi_service_tcp OR check_xi_service_udp
		$cmdline="check_xi_service_".$protocol."!-p ".$port;
		}
	}
	
	
function autodiscovery_configwizard_is_common_service($service,$port,$protocol){
	
	$protoname=strtoupper($protocol);

	$name=$service;
	
	$common_services=array(
		"tcp" => array(
			21 => "FTP",
			22 => "SSH",
			23 => "Telnet",
			25 => "SMTP",
			80 => "HTTP",
			110 => "POP3",
			143 => "IMAP",
			389 => "LDAP",
			443 => "HTTPS",
			139 => "NetBIOS",
			631 => "IPP",
			993 => "IMAP SSL",
			3389 => "RDP",
			5666 => "NRPE",
			5667 => "NSCA",
			),
		"udp" => array(
			),
		);
	
	if(array_key_exists($port,$common_services[$protocol]))
		return true;
	return false;
	}

	
function autodiscovery_configwizard_get_friendly_service_name($service,$port,$protocol){

	$protoname=strtoupper($protocol);

	$name=$service;
	
	$friendly_names=array(
		"tcp" => array(
			21 => "FTP",
			22 => "SSH",
			23 => "Telnet",
			25 => "SMTP",
			80 => "HTTP",
			110 => "POP3",
			143 => "IMAP",
			389 => "LDAP",
			443 => "HTTPS",
			139 => "NetBIOS",
			631 => "IPP",
			993 => "IMAP SSL",
			3389 => "RDP",
			5666 => "NRPE",
			5667 => "NSCA",
			),
		"udp" => array(
			),
		);
	
	if(array_key_exists($port,$friendly_names[$protocol]))
		$name=$friendly_names[$protocol][$port];
	else if($service=="")
		$name=$protoname." Port ".$port;
	else{
		// remome illegal chars in portnames -SW
		// `~!$%^&*|'"<>?,()=/\
		$badchars=explode(" "," ` ~ ! $ % ^ & * | ' \" < > ? , ( ) = / \\ { }");
		str_replace($badchars," ",$service);
		$name=$protoname." Port ".$port." - ".$service."";
		}
	return $name;
	}

?>
