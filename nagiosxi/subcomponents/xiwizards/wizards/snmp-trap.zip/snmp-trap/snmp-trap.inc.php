<?php
// SNMP TRAP CONFIG WIZARD
//
// Copyright (c) 2010 Nagios Enterprises, LLC.  All rights reserved.
//
// $Id: snmp-trap.inc.php 1001 2013-03-19 20:09:49Z swilkerson $

include_once(dirname(__FILE__).'/../configwizardhelper.inc.php');

// run the initialization function
snmp_trap_configwizard_init();

function snmp_trap_configwizard_init(){
	$name="snmp_trap";

	$args=array(
		CONFIGWIZARD_NAME => $name,
        CONFIGWIZARD_VERSION => "1.3",
		CONFIGWIZARD_TYPE => CONFIGWIZARD_TYPE_MONITORING,
		CONFIGWIZARD_DESCRIPTION => gettext('Monitor SNMP Traps.'),
		CONFIGWIZARD_DISPLAYTITLE => gettext('SNMP Trap'),
		CONFIGWIZARD_FUNCTION => 'snmp_trap_configwizard_func',
		CONFIGWIZARD_PREVIEWIMAGE => 'snmptrap.png',
		);

	register_configwizard($name,$args);
	}



function snmp_trap_configwizard_func($mode="",$inargs=null,&$outargs,&$result){
	$wizard_name="snmp_trap";

	// initialize return code and output
	$result=0;
	$output="";

	// initialize output args - pass back the same data we got
	$outargs[CONFIGWIZARD_PASSBACK_DATA]=$inargs;


	switch($mode){
		case CONFIGWIZARD_MODE_GETSTAGE1HTML:

			$address=grab_array_var($inargs,"address","");

			$output='

			<p>
			<br>
			'.gettext('This wizard allows you to enable SNMP Traps for existing hosts that are being monitored.').'
			</p>


			';
			break;

		case CONFIGWIZARD_MODE_VALIDATESTAGE1DATA:

			// get variables that were passed to us
			//$address=grab_array_var($inargs,"address","");


			// check for errors
			$errors=0;
			$errmsg=array();

			if($errors>0){
				$outargs[CONFIGWIZARD_ERROR_MESSAGES]=$errmsg;
				$result=1;
				}

			break;

		case CONFIGWIZARD_MODE_GETSTAGE2HTML:
		
			$hosts_per_page=15;

			// get variables that were passed to us
			//$address=grab_array_var($inargs,"address");

			/*
			$ha=@gethostbyaddr($address);
			if($ha=="")
				$ha=$address;
			$hostname=grab_array_var($inargs,"hostname",$ha);
			*/

			//$ipaddress=@gethostbyname($address);

			$output='


	<div class="sectionTitle">'.gettext('SNMP Trap Details').'</div>

		<script type="text/javascript">
		';

		$output.='
	function checkall(){
		var v=$(\'#allhosts\').attr(\'checked\');
		if(v==true)
			$(\'#configWizardForm\').checkCheckboxes(":not(#allhosts)");
		else
			$(\'#configWizardForm\').unCheckCheckboxes(":not(#allhosts)");
		//$(\'#configWizardForm\').toggleCheckboxes(":not(#allhosts)");
		}
		';

	$output.='
	</script>

	<p>
	'.gettext('Select the hosts you would like to enable SNMP Traps for.').'
	</p>

	<style type="text/css">
	table.standardtable.hide { display: none; }
	</style>
	
	<script type="text/javascript">
    var contentDivs = new Array();
    var contentDivsinit = -1;
	var lasttabid = 0; // By default show the first one.

	function showNextTab() {
	  if (contentDivsinit) {
        contentDivs = document.getElementById("HostPages").childNodes;
		contentDivsinit = 0;
	  }
	  selectedId = lasttabid;
	  selectedId++;
	  if (contentDivs.length < selectedId) { return false; }

      contentDivs[selectedId].className = "standardtable";
      contentDivs[lasttabid].className = "standardtable hide";
	  lasttabid = selectedId;

      // Stop the browser following the link
      return false;
    }

	function showPrevTab() {
	  if (contentDivsinit) {
        contentDivs = document.getElementById("HostPages").childNodes;
		contentDivsinit = 0;
	  }
	  selectedId = lasttabid;
	  selectedId--;
	  if (-1 >= selectedId) { return false; }

      contentDivs[selectedId].className = "standardtable";
      contentDivs[lasttabid].className = "standardtable hide";
	  lasttabid = selectedId;

      // Stop the browser following the link
      return false;
    }
	
	</script>';

	$output.='<div id="HostPages">';

		$tstart='<table class="standardtable">';

		$output.=$tstart;
		$output.='<tr><th><input type="checkbox" class="checkbox" id="allhosts"	name="all_hosts" onclick="checkall()">'.gettext('All Hosts ').'</tr>';
		
		$mtstart='<table class="standardtable hide">';

			$args=array(
				"orderby" => "host_name:a",
				);
			$xml=get_xml_host_objects($args);
			if($xml){
				//print_r($xml);
				$x=0;
				foreach($xml->host as $h){
					$x++;
					//print_r($h);
					//echo "<BR><BR>";

					if(($x%2)!=0)
						$rowclass='"odd"';
					else
						$rowclass='"even"';

					$host_name=htmlentities(strval($h->host_name));

					$output.='
					<tr class='.$rowclass.'>
					<td valign="top">
					<input type="checkbox" class="checkbox" id="host_'.$x.
						'" name="services[host]['.$host_name.']" >
					'.$host_name.'
					</td>
					</tr>';

					if(($x%($hosts_per_page))==0){
						$output.='
			</table>'.$mtstart;
						$output.='<tr><th>&nbsp;</th></tr>';
						}

					}
				}

			$output.='</table>';
			$output.='</div>';
			
			if($x>$hosts_per_page){
				//$output.=$tstart;
				$output.='<table>';
				$output.='
						<tr>
						<td><a href="#"><span onClick="showPrevTab()">&lt; '.gettext('Previous').$hosts_per_page.'</span></a>&nbsp;</td>
						<td>&nbsp;<a href="#"><span onClick="showNextTab()">'.gettext('Next').$hosts_per_page.' &gt;</span></a></td>
						</tr>
						</table>
						';
				}

			break;

		case CONFIGWIZARD_MODE_VALIDATESTAGE2DATA:

			//print_r($inargs);

			// get variables that were passed to us
			//$address=grab_array_var($inargs,"address");
			$services=grab_array_var($inargs,"services");

			// check for errors
			$errors=0;
			$errmsg=array();
			//if(is_valid_host_name($hostname)==false)
				//$errmsg[$errors++]="Invalid host name.";
			if(!is_array($services))
				$errmsg[$errors++]=gettext("No hosts selected.");
			else if(!array_key_exists("host",$services))
				$errmsg[$errors++]=gettext("No hosts selected.");
			else if(count($services["host"])==0)
				$errmsg[$errors++]=gettext("No hosts selected.");

			if($errors>0){
				$outargs[CONFIGWIZARD_ERROR_MESSAGES]=$errmsg;
				$result=1;
				}

			break;


		case CONFIGWIZARD_MODE_GETSTAGE3OPTS:

			// hide normal/retry check interval options
			$output=gettext('There are no monitoring options to configure with SNMP Traps.  Click Next to continue.');
			$result=CONFIGWIZARD_HIDE_OPTIONS;

			break;

		case CONFIGWIZARD_MODE_GETSTAGE3HTML:

			// get variables that were passed to us
			//$address=grab_array_var($inargs,"address");
			$services=grab_array_var($inargs,"services");
			$serviceargs=grab_array_var($inargs,"serviceargs");

			$output='

		<input type="hidden" name="services_serial" value="'.
			base64_encode(serialize($services)).'">
		<input type="hidden" name="serviceargs_serial" value="'.
			base64_encode(serialize($serviceargs)).'">

		<!--SERVICES='.serialize($services).'<BR>
		SERVICEARGS='.serialize($serviceargs).'<BR>-->

			';
			break;

		case CONFIGWIZARD_MODE_VALIDATESTAGE3DATA:

			break;

		case CONFIGWIZARD_MODE_GETSTAGE4OPTS:

			// hide some notification options
			$output='';
			$result=CONFIGWIZARD_HIDE_OPTIONS;
			$outargs[CONFIGWIZARD_HIDDEN_OPTIONS]=array(
				CONFIGWIZARD_HIDE_NOTIFICATION_DELAY,
				CONFIGWIZARD_HIDE_NOTIFICATION_INTERVAL,
				);

			break;

		case CONFIGWIZARD_MODE_GETFINALSTAGEHTML:


			$output='
			';
			break;

		case CONFIGWIZARD_MODE_GETOBJECTS:

			$services_serial=grab_array_var($inargs,"services_serial","");
			$serviceargs_serial=grab_array_var($inargs,
				"serviceargs_serial","");

			$services=unserialize(base64_decode($services_serial));
			$serviceargs=unserialize(base64_decode($serviceargs_serial));

			/*
			echo "SERVICES<BR>";
			print_r($services);
			echo "<BR>";
			echo "SERVICEARGS<BR>";
			print_r($serviceargs);
			echo "<BR>";
			*/

			$objs=array();

			$hosts=$services["host"];
			foreach($hosts as $hostname => $hoststate){

				//echo "PROCESSING: $hostname -> $hoststate<BR>\n";

				$objs[]=array(
					'type' => OBJECTTYPE_SERVICE,
					'host_name' => $hostname,
					'service_description' => 'SNMP Traps',
					'use' => 'xiwizard_snmptrap_service',
					'check_interval' => 1,
					'retry_interval' => 1,
					'max_check_attempts' => 1,
					'notification_interval' => 1,
					'icon_image' => 'snmptrap.png',
					'_xiwizard' => $wizard_name,
					);
				}

			//echo "OBJECTS:<BR>";
			//print_r($objs);
			//exit();

			// return the object definitions to the wizard
			$outargs[CONFIGWIZARD_NAGIOS_OBJECTS]=$objs;

			break;


		// THE FOLLOWING MODES ARE POST-CONFIGURATION CALLBACKS
		// THEY CAN BE USED TO DO CONFIGURATION TASKS, ETC AFTER A NEW
		//		CONFIGURATION HAS BEEN SUBMITTED

		case CONFIGWIZARD_MODE_COMMITERROR:
			echo "COMMITERROR!\n";
			break;

		case CONFIGWIZARD_MODE_COMMITCONFIGERROR:
			echo "COMMITCONFIGERROR!\n";
			break;

		case CONFIGWIZARD_MODE_COMMITPERMSERROR:
			echo "COMMITPERMSERROR!\n";
			break;

		case CONFIGWIZARD_MODE_COMMITOK:

			//echo "COMMITOK!\n";
			//echo "INARGS:\n";
			//print_r($inargs);

			$services_serial=grab_array_var($inargs,"services_serial");
			$services=unserialize(base64_decode($services_serial));

			//echo "SERVICES:\n";
			//print_r($services);

			// initialize each new service with an OK state
			$servicename='SNMP Traps';
			$hosts=grab_array_var($services,"host");
			foreach($hosts as $hostname => $hoststate){
				echo "HOST/SVC => $hostname,SNMP Traps\n";
				$output="";
				$raw_command="PROCESS_SERVICE_CHECK_RESULT;".$hostname.
					";".$servicename.";0;Waiting for trap...\n";
				submit_direct_nagioscore_command($raw_command,$output);
				}

			break;

		default:
			break;
		}

	return $output;
	}


?>
