<?php
// DHCP CONFIG WIZARD
//
// Copyright (c) 2010 Nagios Enterprises, LLC.  All rights reserved.
//  
// $Id: email-delivery.inc.php 1013 2013-04-29 21:22:50Z swilkerson $

include_once(dirname(__FILE__).'/../configwizardhelper.inc.php');

// run the initialization function
email_delivery_configwizard_init();

function email_delivery_configwizard_init(){
	
	$name="email-delivery";
	
	$args=array(
		CONFIGWIZARD_NAME => $name,
        CONFIGWIZARD_VERSION => "2.0",
		CONFIGWIZARD_TYPE => CONFIGWIZARD_TYPE_MONITORING,
		CONFIGWIZARD_DESCRIPTION => gettext("Test mail servers reception and simulated users inspection of email messages."),
		CONFIGWIZARD_DISPLAYTITLE => "Email Delivery",
		CONFIGWIZARD_FUNCTION => "email_delivery_configwizard_func",
		CONFIGWIZARD_PREVIEWIMAGE => "email-delivery.png",
		);
		
	register_configwizard($name,$args);
	}



function email_delivery_configwizard_func($mode="",$inargs=null,&$outargs,&$result){

	$wizard_name="email-delivery";
	
	// initialize return code and output
	$result=0;
	$output="";
	
	// initialize output args - pass back the same data we got
	$outargs[CONFIGWIZARD_PASSBACK_DATA]=$inargs;


	switch($mode){
		case CONFIGWIZARD_MODE_GETSTAGE1HTML:
		
			$address=grab_array_var($inargs,"address","");
			
			$output='

	<div class="sectionTitle">'.gettext('Email Server').'</div>
	
			
	<table>

	<tr>
	<td valign="top">
	<label>'.gettext('Address').':</label><br class="nobr" />
	</td>
	<td>
<input type="text" size="40" name="address" id="address" value="'.htmlentities($address).'" class="textfield" /><br class="nobr" />
	'.gettext('The IP address or FQDNS name of the device or server associated with the Email Delivery check').'.<br><br>
	</td>
	</tr>

	</table>

			';
			break;
			
		case CONFIGWIZARD_MODE_VALIDATESTAGE1DATA:
		
			// get variables that were passed to us
			$address=grab_array_var($inargs,"address","");
			
			
			// check for errors
			$errors=0;
			$errmsg=array();
			if(have_value($address)==false)
				$errmsg[$errors++]=gettext("No address specified.");
				
			if($errors>0){
				$outargs[CONFIGWIZARD_ERROR_MESSAGES]=$errmsg;
				$result=1;
				}
				
			break;
			
		case CONFIGWIZARD_MODE_GETSTAGE2HTML:
		
			// get variables that were passed to us
			$address=grab_array_var($inargs,"address");

			$ha=@gethostbyaddr($address);
			if($ha=="")
				$ha=$address;
			$hostname=grab_array_var($inargs,"hostname",$ha);
		
			$servicedesc=grab_array_var($inargs,"servicedesc", 'Email Delivery');
			$smtpto=grab_array_var($inargs,"smtpto");
            $smtpfrom=grab_array_var($inargs,"smtpfrom");
            $smtp_address=grab_array_var($inargs,"smtp_address");
			$smtp_username=grab_array_var($inargs,"smtp_username");
			$smtp_password=grab_array_var($inargs,"smtp_password");
			$smtp_port=grab_array_var($inargs,"smtp_port", '25');
            $smtp_tls=grab_array_var($inargs,"smtp_tls");
            $imap_address=grab_array_var($inargs,"imap_address");
			$imap_username=grab_array_var($inargs,"imap_username");
			$imap_password=grab_array_var($inargs,"imap_password");
			$imap_port=grab_array_var($inargs,"imap_port", '143');
            $imap_ssl=grab_array_var($inargs,"imap_ssl");
			
		
			$output='
			
		<input type="hidden" name="address" value="'.htmlentities($address).'">
<table>
    <tr>
	<td valign="top">
	<label>Host Name:</label><br class="nobr" />
	</td>
	<td>
        <input type="text" size="20" name="hostname" id="Host Name" value="'.htmlentities($hostname).'" class="textfield"/><br class="nobr" />
	The Host Name in Nagios XI.<br><br>
	</td>

	</tr>	<tr>
	<td valign="top">
	<label>Service Description:</label><br class="nobr" />
	</td>
	<td>
<input type="text" size="20" name="servicedesc" id="Service Description" value="'.htmlentities($servicedesc).'" class="textfield"/><br class="nobr" />
	The Description you would like to have associated with this test case.<br><br>
	</td>

	</tr>

	</table>


	<div class="sectionTitle">Email Details</div>


	<table>

	<tr>
	<td valign="top">
	<label>To Address:</label><br class="nobr" />
	</td>
	<td>
<input type="text" size="20" name="smtpto" id="To Address" value="'.htmlentities($smtpto).'" class="textfield"/><br class="nobr" />
	The email address to send the test message to.  This is used in the envelope headers and must match the IMAP account you wish to check.<br><br>
	</td>

	</tr>	<tr>
	<td valign="top">
	<label>From Address:</label><br class="nobr" />
	</td>
	<td>
<input type="text" size="20" name="smtpfrom" id="From Address" value="'.htmlentities($smtpfrom).'" class="textfield"/><br class="nobr" />
	Address to use as the from/sender address in the envelope headers.<br><br>
	</td>

	</tr>

	</table>


	<div class="sectionTitle">SMTP Details</div>


	<table>

	<tr>
	<td valign="top">
	<label>SMTP Address:</label><br class="nobr" />
	</td>
	<td>
<input type="text" size="30" name="smtp_address" id="SMTP Address" value="'.htmlentities($smtp_address).'" class="textfield"/><br class="nobr" />
	The IP address or FQDNS name of the SMTP server.<br><br>
	</td>

	</tr>	<tr>
	<td valign="top">
	<label>SMTP Username:</label><br class="nobr" />
	</td>
	<td>
<input type="text" size="20" name="smtp_username" id="SMTP Username" value="'.htmlentities($smtp_username).'" class="textfield"/><br class="nobr" />
	The username used to login to the SMTP server.<br><br>
	</td>

	</tr>	<tr>
	<td valign="top">
	<label>SMTP Password:</label><br class="nobr" />
	</td>
	<td>
<input type="password" size="20" name="smtp_password" id="SMTP Password" value="'.htmlentities($smtp_password).'" class="textfield"/><br class="nobr" />
	The password used to login to the SMTP server.<br><br>
	</td>

	</tr>	<tr>
	<td valign="top">
	<label>SMTP Port:</label><br class="nobr" />
	</td>
	<td>
<input type="text" size="6" name="smtp_port" id="SMTP Port" value="'.htmlentities($smtp_port).'" class="textfield"/><br class="nobr" />
	Service port on the SMTP server.<br><br>
	</td>

	</tr>	<tr>
	<td valign="top">
	<label>SMTP TLS:</label><br class="nobr" />
	</td>
	<td>
<input type="checkbox" name="smtp_tls" id="SMTP TLS" class="checkfield" '.is_checked($smtp_tls,"on").'/><br class="nobr" />
	Use this to enable or disable TLS/AUTH for the SMTP plugin.<br><br>
	</td>

	</tr>

	</table>


	<div class="sectionTitle">IMAP Details</div>


	<table>

	<tr>
	<td valign="top">
	<label>IMAP Address:</label><br class="nobr" />
	</td>
	<td>
<input type="text" size="30" name="imap_address" id="IMAP Address" value="'.htmlentities($imap_address).'" class="textfield"/><br class="nobr" />
	The IP address or FQDNS name of the IMAP server.<br><br>
	</td>

	</tr>	<tr>
	<td valign="top">
	<label>IMAP Username:</label><br class="nobr" />
	</td>
	<td>
<input type="text" size="20" name="imap_username" id="IMAP Username" value="'.htmlentities($imap_username).'" class="textfield"/><br class="nobr" />
	The username used to login to the IMAP server.<br><br>
	</td>

	</tr>	<tr>
	<td valign="top">
	<label>IMAP Password:</label><br class="nobr" />
	</td>
	<td>
<input type="password" size="20" name="imap_password" id="IMAP Password" value="'.htmlentities($imap_password).'" class="textfield"/><br class="nobr" />
	The password used to login to the IMAP server.<br><br>
	</td>

	</tr>	<tr>
	<td valign="top">
	<label>IMAP Port:</label><br class="nobr" />
	</td>
	<td>
<input type="text" size="6" name="imap_port" id="IMAP Port" value="'.htmlentities($imap_port).'" class="textfield"/><br class="nobr" />
	Service port on the IMAP server.<br><br>
	</td>

	</tr>	<tr>
	<td valign="top">
	<label>IMAP SSL:</label><br class="nobr" />
	</td>
	<td>
<input type="checkbox" name="imap_ssl" id="IMAP SSL" class="checkfield" '.is_checked($imap_ssl,"on").'/><br class="nobr" />
	Use this to enable or disable SSL for the IMAP plugin.<br><br>
	</td>

	</tr>

	</table>

			';
			break;
			
		case CONFIGWIZARD_MODE_VALIDATESTAGE2DATA:
		
			// get variables that were passed to us
            $address=grab_array_var($inargs,"address");
			$hostname=grab_array_var($inargs,"hostname");
			$servicedesc=grab_array_var($inargs,"servicedesc");
			$smtpto=grab_array_var($inargs,"smtpto");
            $smtpfrom=grab_array_var($inargs,"smtpfrom");
            $smtp_address=grab_array_var($inargs,"smtp_address");
			$smtp_username=grab_array_var($inargs,"smtp_username");
			$smtp_password=grab_array_var($inargs,"smtp_password");
			$smtp_port=grab_array_var($inargs,"smtp_port");
            $smtp_tls=grab_array_var($inargs,"smtp_tls");
            $imap_address=grab_array_var($inargs,"imap_address");
			$imap_username=grab_array_var($inargs,"imap_username");
			$imap_password=grab_array_var($inargs,"imap_password");
			$imap_port=grab_array_var($inargs,"imap_port");
            $imap_ssl=grab_array_var($inargs,"imap_ssl");
			
		
			// check for errors
			$errors=0;
			$errmsg=array();
			if(is_valid_host_name($hostname)==false)
				$errmsg[$errors++]=gettext("Invalid host name.");
			if(is_valid_service_name($servicedesc)==false)
				$errmsg[$errors++]=gettext("Invalid service description.");
            if($smtp_address=="")
				$errmsg[$errors++]=gettext("SMTP address cannot be blank.");
            if($smtp_port=="")
				$errmsg[$errors++]=gettext("SMTP port cannot be blank.");
			if($imap_address=="")
				$errmsg[$errors++]=gettext("IMAP address cannot be blank.");
            if($imap_username=="")
				$errmsg[$errors++]=gettext("IMAP username cannot be blank.");
			if($imap_password=="")
				$errmsg[$errors++]=gettext("IMAP password cannot be blank.");
            if($imap_port=="")
				$errmsg[$errors++]=gettext("IMAP port cannot be blank.");
			
            if($smtpto=="")
				$errmsg[$errors++]=gettext("To address cannot be blank.");
			if($smtpfrom=="")
				$errmsg[$errors++]=gettext("From address cannot be blank.");
                
				
			if($errors>0){
				$outargs[CONFIGWIZARD_ERROR_MESSAGES]=$errmsg;
				$result=1;
				}
				
			break;

			
		case CONFIGWIZARD_MODE_GETSTAGE3HTML:
		
			// get variables that were passed to us
            $address=grab_array_var($inargs,"address");
			$hostname=grab_array_var($inargs,"hostname");
			$servicedesc=grab_array_var($inargs,"servicedesc");
			$smtpto=grab_array_var($inargs,"smtpto");
            $smtpfrom=grab_array_var($inargs,"smtpfrom");
            $smtp_address=grab_array_var($inargs,"smtp_address");
			$smtp_username=grab_array_var($inargs,"smtp_username");
			$smtp_password=grab_array_var($inargs,"smtp_password");
			$smtp_port=grab_array_var($inargs,"smtp_port");
            $smtp_tls=grab_array_var($inargs,"smtp_tls");
            $imap_address=grab_array_var($inargs,"imap_address");
			$imap_username=grab_array_var($inargs,"imap_username");
			$imap_password=grab_array_var($inargs,"imap_password");
			$imap_port=grab_array_var($inargs,"imap_port");
            $imap_ssl=grab_array_var($inargs,"imap_ssl");
		
			$output='
			
		<input type="hidden" name="address" value="'.htmlentities($address).'">
		<input type="hidden" name="hostname" value="'.htmlentities($hostname).'">
		<input type="hidden" name="servicedesc" value="'.htmlentities($servicedesc).'">
		<input type="hidden" name="smtpto" value="'.htmlentities($smtpto).'">
		<input type="hidden" name="smtpfrom" value="'.htmlentities($smtpfrom).'">
		<input type="hidden" name="smtp_address" value="'.htmlentities($smtp_address).'">
		<input type="hidden" name="smtp_username" value="'.htmlentities($smtp_username).'">
        <input type="hidden" name="smtp_password" value="'.htmlentities($smtp_password).'">
        <input type="hidden" name="smtp_port" value="'.htmlentities($smtp_port).'">
        <input type="hidden" name="smtp_tls" value="'.htmlentities($smtp_tls).'">
        <input type="hidden" name="imap_address" value="'.htmlentities($imap_address).'">
        <input type="hidden" name="imap_username" value="'.htmlentities($imap_username).'">
        <input type="hidden" name="imap_password" value="'.htmlentities($imap_password).'">
        <input type="hidden" name="imap_port" value="'.htmlentities($imap_port).'">
        <input type="hidden" name="imap_ssl" value="'.htmlentities($imap_ssl).'">
		
			';
			break;
			
		case CONFIGWIZARD_MODE_VALIDATESTAGE3DATA:
				
			break;
			
		case CONFIGWIZARD_MODE_GETFINALSTAGEHTML:
			
			
			$output='<p></p>';
			break;
			
		case CONFIGWIZARD_MODE_GETOBJECTS:
		
			$address=grab_array_var($inargs,"address");
			$hostname=grab_array_var($inargs,"hostname");
			$servicedesc=grab_array_var($inargs,"servicedesc");
			$smtpto=grab_array_var($inargs,"smtpto");
            $smtpfrom=grab_array_var($inargs,"smtpfrom");
            $smtp_address=grab_array_var($inargs,"smtp_address");
			$smtp_username=grab_array_var($inargs,"smtp_username");
			$smtp_password=grab_array_var($inargs,"smtp_password");
			$smtp_port=grab_array_var($inargs,"smtp_port");
            $smtp_tls=grab_array_var($inargs,"smtp_tls");
            $imap_address=grab_array_var($inargs,"imap_address");
			$imap_username=grab_array_var($inargs,"imap_username");
			$imap_password=grab_array_var($inargs,"imap_password");
			$imap_port=grab_array_var($inargs,"imap_port");
            $imap_ssl=grab_array_var($inargs,"imap_ssl");
			
			// save data for later use in re-entrance
			$meta_arr=array();
			$meta_arr["hostname"]=$hostname;
			$meta_arr["address"]=$address;
			$meta_arr["servicedesc"]=$servicedesc;
			$meta_arr["smtpto"]=$smtpto;
			$meta_arr["smtpfrom"]=$smtpfrom;
			$meta_arr["smtp_address"]=$smtp_address;
			$meta_arr["smtp_username"]=$smtp_username;
			$meta_arr["smtp_password"]=$smtp_password;
			$meta_arr["smtp_port"]=$smtp_port;
            $meta_arr["smtp_tls"]=$smtp_tls;
            $meta_arr["imap_address"]=$imap_address;
            $meta_arr["imap_username"]=$imap_username;
            $meta_arr["imap_password"]=$imap_password;
            $meta_arr["imap_port"]=$imap_port;
            $meta_arr["imap_ssl"]=$imap_ssl;
			save_configwizard_object_meta($wizard_name,$hostname,"",$meta_arr);			
			
			$objs=array();
			
			if(!host_exists($hostname)){
				$objs[]=array(
					"type" => OBJECTTYPE_HOST,
					"use" => "xiwizard_generic_host",
					"host_name" => $hostname,
					"address" => $hostaddress,
					"icon_image" => "email-delivery.png",
					"statusmap_image" => "email-delivery.png",
					"_xiwizard" => $wizard_name,
					);
				}
				
			// email service
			$emailargs="--mailto $smtpto --mailfrom $smtpfrom -H $address ";
            $emailargs.="--smtp-server $smtp_address --smtp-username '$smtp_username' --smtp-password '$smtp_password' --smtp-port $smtp_port ";
            $emailargs.="--imap-server $imap_address --username '$imap_username' --password '$imap_password' --imap-port $imap_port";
			if($smtp_tls)
				$emailargs.=" --smtptls";
			if($imap_ssl)
				$emailargs.=" --imapssl";
	
			
			$objs[]=array(
				"type" => OBJECTTYPE_SERVICE,
				"host_name" => $hostname,
				"service_description" => $servicedesc,
				"use" => "xiwizard_generic_service",
				"check_command" => "check_email_delivery!".$emailargs,
				"_xiwizard" => $wizard_name,
				);
				
			//echo "OBJECTS:<BR>";
			//print_r($objs);
			//exit();
					
			// return the object definitions to the wizard
			$outargs[CONFIGWIZARD_NAGIOS_OBJECTS]=$objs;
		
			break;
			
		default:
			break;			
		}
		
	return $output;
	}
	

?>