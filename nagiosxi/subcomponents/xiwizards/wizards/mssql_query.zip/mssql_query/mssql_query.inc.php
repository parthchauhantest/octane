<?php
// MSSQL QUERY CONFIG WIZARD
//
// Copyright (c) 2010 Nagios Enterprises, LLC.  All rights reserved.
//  
// $Id: mysqlquery.inc.php 688 2011-07-27 11:44:14Z egalstad $

include_once(dirname(__FILE__).'/../configwizardhelper.inc.php');

// run the initialization function
mssqlquery_configwizard_init();

function mssqlquery_configwizard_init(){

	$name="mssqlquery";
	
	$args=array(
		CONFIGWIZARD_NAME => $name,
        CONFIGWIZARD_VERSION => "1.5",
		CONFIGWIZARD_TYPE => CONFIGWIZARD_TYPE_MONITORING,
		CONFIGWIZARD_DESCRIPTION => "Monitor a MSSQL Database Query",
		CONFIGWIZARD_DISPLAYTITLE => "MSSQL Query",
		CONFIGWIZARD_FUNCTION => "mssqlquery_configwizard_func",
		CONFIGWIZARD_PREVIEWIMAGE => "mssqlquery.png",
		);
		
	register_configwizard($name,$args);
	}



function mssqlquery_configwizard_func($mode="",$inargs=null,&$outargs,&$result){

	$wizard_name="mssqlquery";
	
	// initialize return code and output
	$result=0;
	$output="";
	
	// initialize output args - pass back the same data we got
	$outargs[CONFIGWIZARD_PASSBACK_DATA]=$inargs;


	switch($mode){
		case CONFIGWIZARD_MODE_GETSTAGE1HTML:
		
			$address=grab_array_var($inargs,"address","");
			$port=grab_array_var($inargs,"port","");
            $instance=grab_array_var($inargs,"instance","");
			$username=grab_array_var($inargs,"username","");
			$password=grab_array_var($inargs,"password","");
			$database=grab_array_var($inargs,"database","master");
			
			$output='

	<div class="sectionTitle">MSSQL Server</div>
	
	<p>
	Specify the details for connecting to the MSSQL server you want to monitor.
	</p>
			
	<table>

	<tr>
	<td valign="top">
	<label>Address:</label><br class="nobr" />
	</td>
	<td>
<input type="text" size="40" name="address" id="address" value="'.htmlentities($address).'" class="textfield" /><br class="nobr" />
	The IP address or FQDNS name of the MSSQL server.<br><br>
	</td>
	</tr>
	
	<tr>
	<td valign="top">
	<label>Instance:</label><br class="nobr" />
	</td>
	<td>
<input type="text" size="40" name="instance" id="instance" value="'.htmlentities($instance).'" class="textfield" /><br class="nobr" />
	The instance of the MSSQL server to connect to. Do not enter a value for both instance and port.<br><br>
	</td>
	</tr>    
    
	<tr>
	<td valign="top">
	<label>Port:</label><br class="nobr" />
	</td>
	<td>
<input type="text" size="5" name="port" id="port" value="'.htmlentities($port).'" class="textfield" /><br class="nobr" />
	The port to use to connect to the MSSQL server.<br><br>
	</td>
	</tr>

	<tr>
	<td valign="top">
	<label>Username:</label><br class="nobr" />
	</td>
	<td>
<input type="text" size="20" name="username" id="username" value="'.htmlentities($username).'" class="textfield" /><br class="nobr" />
	The username used to connect to the MSSQL server.<br><br>
	</td>
	</tr>

	<tr>
	<td valign="top">
	<label>Password:</label><br class="nobr" />
	</td>
	<td>
<input type="password" size="20" name="password" id="password" value="'.htmlentities($password).'" class="textfield" /><br class="nobr" />
	The password used to connect to the MSSQL server.<br><br>
	</td>
	</tr>

	<tr>
	<td valign="top">
	<label>Database:</label><br class="nobr" />
	</td>
	<td>
<input type="text" size="20" name="database" id="database" value="'.htmlentities($database).'" class="textfield" /><br class="nobr" />
	The database to connect to on the MSSQL server.<br><br>
	</td>
	</tr>


	</table>

			';
			break;
			
		case CONFIGWIZARD_MODE_VALIDATESTAGE1DATA:
		
			// get variables that were passed to us
			$address=grab_array_var($inargs,"address","");
			$port=grab_array_var($inargs,"port","");
            $instance=grab_array_var($inargs,"instance","");
			$username=grab_array_var($inargs,"username","");
			$password=grab_array_var($inargs,"password","");
			$database=grab_array_var($inargs,"database","");
			
			// check for errors
			$errors=0;
			$errmsg=array();
			if(have_value($address)==false)
				$errmsg[$errors++]="No address specified.";	
			if(have_value($username)==false)
				$errmsg[$errors++]="No username specified.";
			if(have_value($password)==false)
				$errmsg[$errors++]="No password specified.";
			if(have_value($database)==false)
				$errmsg[$errors++]="No database specified.";
            if($port && $instance)
                $errmsg[$errors++]="Cannot specify port and instance.";
				
			if($errors>0){
				$outargs[CONFIGWIZARD_ERROR_MESSAGES]=$errmsg;
				$result=1;
				}
				
			break;
			
		case CONFIGWIZARD_MODE_GETSTAGE2HTML:
		
			// get variables that were passed to us
			$address=grab_array_var($inargs,"address");
			$port=grab_array_var($inargs,"port","");
            $instance=grab_array_var($inargs,"instance","");
			$username=grab_array_var($inargs,"username","");
			$password=grab_array_var($inargs,"password","");
			$database=grab_array_var($inargs,"database","");
			
			$query=grab_array_var($inargs,"query","SELECT COUNT(*) FROM sys.sysperfinfo");
			$queryname=grab_array_var($inargs,"queryname","Test Query");
			$result=grab_array_var($inargs,"result","");
			$warning=grab_array_var($inargs,"warning","1");
			$critical=grab_array_var($inargs,"critical","2");
            $querywarning=grab_array_var($inargs,"querywarning","50");
			$querycritical=grab_array_var($inargs,"querycritical","200");

			$ha=@gethostbyaddr($address);
			if($ha=="")
				$ha=$address;
			$hostname=grab_array_var($inargs,"hostname",$ha);
			
			
			$output='
			
		<input type="hidden" name="address" value="'.htmlentities($address).'">
		<input type="hidden" name="port" value="'.htmlentities($port).'">
        <input type="hidden" name="instance" value="'.htmlentities($instance).'">
		<input type="hidden" name="username" value="'.htmlentities($username).'">
		<input type="hidden" name="password" value="'.htmlentities($password).'">
		<input type="hidden" name="database" value="'.htmlentities($database).'">

	<div class="sectionTitle">MSSQL Server</div>
	
			
	<table>
	
	<tr>
	<td valign="top">
	<label>Address:</label><br class="nobr" />
	</td>
	<td>
<input type="text" size="20" name="address" id="address" value="'.htmlentities($address).'" class="textfield" disabled/><br class="nobr" />
	</td>
	</tr>

	<tr>
	<td valign="top">
	<label>Host Name:</label><br class="nobr" />
	</td>
	<td>
<input type="text" size="20" name="hostname" id="hostname" value="'.htmlentities($hostname).'" class="textfield" /><br class="nobr" />
	The name you\'d like to have associated with this MSSQL server.
	</td>
	</tr>
	
	<tr>
	<td valign="top">
	<label>Port:</label><br class="nobr" />
	</td>
	<td>
<input type="text" size="5" name="port" id="port" value="'.htmlentities($port).'" class="textfield" disabled/><br class="nobr" />
	</tr>
	</td>

	<tr>
	<td valign="top">
	<label>Instance:</label><br class="nobr" />
	</td>
	<td>
<input type="text" size="40" name="instance" id="instance" value="'.htmlentities($instance).'" class="textfield" disabled/><br class="nobr" />
	</tr>
	</td>    
    
	<tr>
	<td valign="top">
	<label>Username:</label><br class="nobr" />
	</td>
	<td>
<input type="text" size="20" name="username" id="username" value="'.htmlentities($username).'" class="textfield" disabled/><br class="nobr" />
	</td>
	</tr>

	<tr>
	<td valign="top">
	<label>Password:</label><br class="nobr" />
	</td>
	<td>
<input type="password" size="20" name="password" id="password" value="'.htmlentities($password).'" class="textfield" disabled/><br class="nobr" />
	</td>
	</tr>

	<tr>
	<td valign="top">
	<label>Database:</label><br class="nobr" />
	</td>
	<td>
<input type="text" size="20" name="database" id="database" value="'.htmlentities($database).'" class="textfield" disabled/><br class="nobr" />
	</td>
	</tr>

	</table>


	<div class="sectionTitle">MSSQL Query</div>
	
	<p>Specify the details of the query you\'d like to monitor.</p>
	
	
	<table>
	
	<tr>
	<td valign="top">
	<label>Query Name:</label><br class="nobr" />
	</td>
	<td>
<input type="text" size="40" name="queryname" id="queryname" value="'.htmlentities($queryname).'" class="textfield" ><br class="nobr" />
	A friendly name for the SQL query.<br><br>
	</td>
	</tr>
	
	<tr>
	<td valign="top">
	<label>Query:</label><br class="nobr" />
	</td>
	<td>
<textarea cols="60" rows="5" name="query" id="query" class="textfield">'.htmlentities($query).'</textarea><br class="nobr" />
	The SQL query to run.<br><br>
	</td>
	</tr>
	
	<tr>
	<td valign="top">
	<label>Result:</label><br class="nobr" />
	</td>
	<td>
<input type="text" size="60" name="result" id="result" value="'.htmlentities($result).'" class="textfield" ><br class="nobr" />
	Exact expected result from the SQL query. Will return critical if query does not match this exactly. Literal strings or numbers only. If result is numeric and the below "Query Warning" or "Query Critical" are specified, this entry will be ignored.<br><br>
	</td>
	</tr>
	
	<tr>
	<td valign="top">
	<label>Query Warning:</label><br class="nobr" />
	</td>
	<td>
<input type="text" size="4" name="querywarning" id="querywarning" value="'.htmlentities($querywarning).'" class="textfield" ><br class="nobr" />
	An optional warning threshold to use when checking the result of the SQL query.<br /><b>Please note: The return values must be numeric in order for this to work.</b><br><br>
	</td>
	</tr>
	
	<tr>
	<td valign="top">
	<label>Query Critical:</label><br class="nobr" />
	</td>
	<td>
<input type="text" size="4" name="querycritical" id="querycritical" value="'.htmlentities($querycritical).'" class="textfield" ><br class="nobr" />
	An optional critical threshold to use when checking the result of the SQL connection time.<br /><b>Please note: The return values must be numeric in order for this to work.</b><br><br>
	</td>
	</tr>
    
	<tr>
	<td valign="top">
	<label>Warning:</label><br class="nobr" />
	</td>
	<td>
<input type="text" size="4" name="warning" id="warning" value="'.htmlentities($warning).'" class="textfield" ><br class="nobr" />
	An optional warning threshold to use when checking the result of the SQL connection time.<br><br>
	</td>
	</tr>
	
	<tr>
	<td valign="top">
	<label>Critical:</label><br class="nobr" />
	</td>
	<td>
<input type="text" size="4" name="critical" id="critical" value="'.htmlentities($critical).'" class="textfield" ><br class="nobr" />
	An optional critical threshold to use when checking the result of the SQL connection time.<br><br>
	</td>
	</tr>
	
	</table>
	';
			break;
			
		case CONFIGWIZARD_MODE_VALIDATESTAGE2DATA:
		
			// get variables that were passed to us
			$address=grab_array_var($inargs,"address");
			$hostname=grab_array_var($inargs,"hostname");
			$port=grab_array_var($inargs,"port","");
            $instance=grab_array_var($inargs,"instance","");
			$username=grab_array_var($inargs,"username","");
			$password=grab_array_var($inargs,"password","");
			$database=grab_array_var($inargs,"database","");

			$query=grab_array_var($inargs,"query","");
			$queryname=grab_array_var($inargs,"queryname","");
			$reult=grab_array_var($inargs,"result","");
			$warning=grab_array_var($inargs,"warning","");
			$critical=grab_array_var($inargs,"critical","");
            $querywarning=grab_array_var($inargs,"querywarning","");
			$querycritical=grab_array_var($inargs,"querycritical","");

				
			$services=grab_array_var($inargs,"services",array());
			$serviceargs=grab_array_var($inargs,"serviceargs",array());
			
		
			// check for errors
			$errors=0;
			$errmsg=array();
			if(is_valid_host_name($hostname)==false)
				$errmsg[$errors++]="Invalid host name.";
			if(is_valid_service_name($queryname)==false)
				$errmsg[$errors++]="Invalid query name '".$queryname."'.";
				
			if($errors>0){
				$outargs[CONFIGWIZARD_ERROR_MESSAGES]=$errmsg;
				$result=1;
				}
				
			break;

			
		case CONFIGWIZARD_MODE_GETSTAGE3HTML:
		
			// get variables that were passed to us
			$address=grab_array_var($inargs,"address");
			$hostname=grab_array_var($inargs,"hostname");
			$port=grab_array_var($inargs,"port","");
            $instance=grab_array_var($inargs,"instance","");
			$username=grab_array_var($inargs,"username","");
			$password=grab_array_var($inargs,"password","");
			$database=grab_array_var($inargs,"database","");

			$query=grab_array_var($inargs,"query","");
			$queryname=grab_array_var($inargs,"queryname","");
			$result=grab_array_var($inargs,"result","");
			$warning=grab_array_var($inargs,"warning","");
			$critical=grab_array_var($inargs,"critical","");
            $querywarning=grab_array_var($inargs,"querywarning","");
			$querycritical=grab_array_var($inargs,"querycritical","");
		
			$services_serial=grab_array_var($inargs,"services_serial");
			if($services_serial!="")
				$services=unserialize(base64_decode($services_serial));
			else
				$services=grab_array_var($inargs,"services");
			$serviceargs_serial=grab_array_var($inargs,"serviceargs_serial");
			if($serviceargs_serial!="")
				$serviceargs=unserialize(base64_decode($serviceargs_serial));
			else
				$serviceargs=grab_array_var($inargs,"serviceargs");
		
			$output='
			
		<input type="hidden" name="address" value="'.htmlentities($address).'">
		<input type="hidden" name="hostname" value="'.htmlentities($hostname).'">
		<input type="hidden" name="port" value="'.htmlentities($port).'">
        <input type="hidden" name="instance" value="'.htmlentities($instance).'">
		<input type="hidden" name="username" value="'.htmlentities($username).'">
		<input type="hidden" name="password" value="'.htmlentities($password).'">
		<input type="hidden" name="database" value="'.htmlentities($database).'">
		<input type="hidden" name="query" value="'.htmlentities($query).'">
		<input type="hidden" name="queryname" value="'.htmlentities($queryname).'">
		<input type="hidden" name="result" value="'.htmlentities($result).'">
		<input type="hidden" name="warning" value="'.htmlentities($warning).'">
		<input type="hidden" name="critical" value="'.htmlentities($critical).'">
        <input type="hidden" name="querywarning" value="'.htmlentities($querywarning).'">
		<input type="hidden" name="querycritical" value="'.htmlentities($querycritical).'">
		<input type="hidden" name="services_serial" value="'.base64_encode(serialize($services)).'">
		<input type="hidden" name="serviceargs_serial" value="'.base64_encode(serialize($serviceargs)).'">
		
		<!--SERVICES='.serialize($services).'<BR>
		SERVICEARGS='.serialize($serviceargs).'<BR>-->
		
			';
			break;
			
		case CONFIGWIZARD_MODE_VALIDATESTAGE3DATA:

				
			break;
			
		case CONFIGWIZARD_MODE_GETFINALSTAGEHTML:
			
			
			$output='
			';
			break;
			
		case CONFIGWIZARD_MODE_GETOBJECTS:
		
			$hostname=grab_array_var($inargs,"hostname","");
			$address=grab_array_var($inargs,"address","");
			$hostaddress=$address;
			$port=grab_array_var($inargs,"port","");
            $instance=grab_array_var($inargs,"instance","");
			$username=grab_array_var($inargs,"username","");
			$password=grab_array_var($inargs,"password","");
			$database=grab_array_var($inargs,"database","");

			$query=grab_array_var($inargs,"query","");
			$queryname=grab_array_var($inargs,"queryname","");
			$result=grab_array_var($inargs,"result","");
			$warning=grab_array_var($inargs,"warning","");
			$critical=grab_array_var($inargs,"critical","");
            
            $querywarning=grab_array_var($inargs,"querywarning","");
			$querycritical=grab_array_var($inargs,"querycritical","");
		
			$services_serial=grab_array_var($inargs,"services_serial","");
			$serviceargs_serial=grab_array_var($inargs,"serviceargs_serial","");
			
			$services=unserialize(base64_decode($services_serial));
			$serviceargs=unserialize(base64_decode($serviceargs_serial));
			
			/*
			echo "SERVICES<BR>";
			print_r($services);
			echo "<BR>";
			echo "SERVICEARGS<BR>";
			print_r($serviceargs);
			echo "<BR>";
			*/
			
			// save data for later use in re-entrance
			$meta_arr=array();
			$meta_arr["hostname"]=$hostname;
			$meta_arr["address"]=$address;
            $meta_arr["instance"]=$instance;
			$meta_arr["port"]=$port;
			$meta_arr["username"]=$username;
			$meta_arr["password"]=$password;
			$meta_arr["database"]=$database;
			$meta_arr["query"]=$query;
			$meta_arr["queryname"]=$queryname;
			$meta_arr["result"]=$result;
			$meta_arr["warning"]=$warning;
			$meta_arr["critical"]=$critical;
            $meta_arr["querywarning"]=$querywarning;
			$meta_arr["querycritical"]=$querycritical;
			$meta_arr["services"]=$services;
			$meta_arr["serivceargs"]=$serviceargs;
			save_configwizard_object_meta($wizard_name,$hostname,"",$meta_arr);			
			
			$objs=array();
			
			if(!host_exists($hostname)){
				$objs[]=array(
					"type" => OBJECTTYPE_HOST,
					"use" => "xiwizard_mssqlquery_host",
					"host_name" => $hostname,
					"address" => $hostaddress,
					"icon_image" => "mssql.png",
					"statusmap_image" => "mssql.png",
					"_xiwizard" => $wizard_name,
					);
				}
			
			// common plugin opts
			$commonopts="--username ".$username.' --password "'.$password.'" --database '.$database;
			if($instance)
                $commonopts.=" --instance ".$instance;
            else if($port)
                $commonopts.=" --port ".$port;
            
			$pluginopts=$commonopts.' --query "'.urlencode($query).'" --result "'.html_entity_decode($result).'" --decode';
			if($warning!="")
				$pluginopts.=" --warning ".$warning;
			if($critical!="")
				$pluginopts.=" --critical ".$critical;
            if($querywarning!="")
                $pluginopts.=" --querywarning ".$querywarning;
            if($querycritical!="")
                $pluginopts.=" --querycritical ".$querycritical;
            if($result!="") 
                $pluginopts.=" --result ".$result;

					
			$objs[]=array(
				"type" => OBJECTTYPE_SERVICE,
				"host_name" => $hostname,
				"service_description" => "MSSQL Query - ".$queryname,
				"use" => "xiwizard_mssqlquery_service",
				"check_command" => "check_xi_mssql_query!".$pluginopts,
				"_xiwizard" => $wizard_name,
				);
				
			//echo "OBJECTS:<BR>";
			//print_r($objs);
			//exit();
					
			// return the object definitions to the wizard
			$outargs[CONFIGWIZARD_NAGIOS_OBJECTS]=$objs;
		
			break;
			
		default:
			break;			
		}
		
	return $output;
	}
	

?>
