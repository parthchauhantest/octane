<?php
// LINUX SNMP CONFIG WIZARD
//
// Copyright (c) 2011 Nagios Enterprises, LLC.  All rights reserved.
//  
// $Id: windowssnmp.inc.php 649 2011-06-13 17:02:29Z nscott $

include_once(dirname(__FILE__).'/../configwizardhelper.inc.php');

// run the initialization function
linuxsnmp_configwizard_init();

function linuxsnmp_configwizard_init(){
	
	$name="linuxsnmp";
	
	$args=array(
		CONFIGWIZARD_NAME => $name,
        CONFIGWIZARD_VERSION => "1.4",
		CONFIGWIZARD_TYPE => CONFIGWIZARD_TYPE_MONITORING,
		CONFIGWIZARD_DESCRIPTION => gettext("Monitor a Linux workstation or server using SNMP."),
		CONFIGWIZARD_DISPLAYTITLE => gettext("Linux SNMP"),
		CONFIGWIZARD_FUNCTION => "linuxsnmp_configwizard_func",
		CONFIGWIZARD_PREVIEWIMAGE => "snmppenguin.png",
		);
		
	register_configwizard($name,$args);
	}



function linuxsnmp_configwizard_func($mode="",$inargs=null,&$outargs,&$result){

	$wizard_name="linuxsnmp";
	
	$process_count=10;
	

	// initialize return code and output
	$result=0;
	$output="";
	
	// initialize output args - pass back the same data we got
	$outargs[CONFIGWIZARD_PASSBACK_DATA]=$inargs;


	switch($mode){
		case CONFIGWIZARD_MODE_GETSTAGE1HTML:
		
			$address=grab_array_var($inargs,"address","");
			$snmpcommunity=grab_array_var($inargs,"snmpcommunity","public");
			$snmpversion=grab_array_var($inargs,"snmpversion","2c");

			$snmpopts="";
			$snmpopts_serial=grab_array_var($inargs,"snmpopts_serial","");
			if($snmpopts_serial!="")
				$snmpopts=unserialize(base64_decode($snmpopts_serial));
			if(!is_array($snmpopts)){
				$snmpopts_default=array(
					"v3_security_level" => "",
					"v3_username" => "",
					"v3_auth_password" => "",
					"v3_privacy_password" => "",
					"v3_auth_proto" => "",
                    "v3_priv_proto" => "",
					);
				$snmpopts=grab_array_var($inargs,"snmpopts",$snmpopts_default);
				}
			
			
			$output='

	<div class="sectionTitle">'.gettext('Linux Machine Information').'</div>
	
			
	<table>
	<tr>
	<td valign="top">
	<label>'.gettext('IP Address').':</label><br class="nobr" />
	</td>
	<td>
<input type="text" size="40" name="address" id="address" value="'.htmlentities($address).'" class="textfield" /><br class="nobr" />
	'.gettext('The IP address of the Linux machine you\'d like to monitor').'.<br class="nobr" />
	</td>
	</tr>

	</table>

	<div class="sectionTitle">'.gettext('SNMP Settings').'</div>
	
	<p>'.gettext('Specify the settings used to monitor the Linux machine via SNMP').'.</p>
	
	<table>

	<tr>
	<td valign="top">
	<label>'.gettext('SNMP Community').':</label><br class="nobr" />
	</td>
	<td>
<input type="text" size="20" name="snmpcommunity" id="snmpcommunity" value="'.htmlentities($snmpcommunity).'" class="textfield" /><br class="nobr" />
	'.gettext('The SNMP community string required used to to query the Windows machine').'.
	</td>
	</tr>

	<tr>
	<td valign="top">
	<label>'.gettext('SNMP Version').':</label><br class="nobr" />
	</td>
	<td>
	<select name="snmpversion" id="snmpversion">
	<!--<option value="1" '.is_selected($snmpversion,"1").'>1</option>-->
	<option value="2c" '.is_selected($snmpversion,"2c").'>2c</option>
	<option value="3" '.is_selected($snmpversion,"3").'>3</option>
	</select>
	<br class="nobr" />
	'.gettext('The SNMP protocol version used to commicate with the machine').'.
	</td>
	</tr>

	</table>

	<div class="sectionTitle">SNMP Authentication</div>
	
	<p>'.gettext('When using SNMP v3 you must specify authentication information').'.</p>
	
	<table>

	<tr>
	<td valign="top">
	<label>'.gettext('Security Level').':</label><br class="nobr" />
	</td>
	<td>
	<select name="snmpopts[v3_security_level]">
	<option value="noAuthNoPriv" '.is_selected($snmpopts["v3_security_level"],"noAuthNoPriv").'>noAuthNoPriv</option>
	<option value="authNoPriv" '.is_selected($snmpopts["v3_security_level"],"authNoPriv").'>authNoPriv</option>
	<option value="authPriv" '.is_selected($snmpopts["v3_security_level"],"authPriv").'>authPriv</option>
	</select>
	<br class="nobr" />
	</td>
	</tr>

	<tr>
	<td valign="top">
	<label>'.gettext('Username').':</label><br class="nobr" />
	</td>
	<td>
<input type="text" size="20" name="snmpopts[v3_username]" value="'.htmlentities($snmpopts["v3_username"]).'" class="textfield" /><br class="nobr" />
	</td>
	</tr>

	<tr>
	<td valign="top">
	<label>'.gettext('Authentication Password').':</label><br class="nobr" />
	</td>
	<td>
<input type="texs" size="20" name="snmpopts[v3_auth_password]" value="'.htmlentities($snmpopts["v3_auth_password"]).'" class="textfield" /><br class="nobr" />
	</td>
	</tr>

	<tr>
	<td valign="top">
	<label>'.gettext('Privileged Password').':</label><br class="nobr" />
	</td>
	<td>
<input type="text" size="20" name="snmpopts[v3_privacy_password]" value="'.htmlentities($snmpopts["v3_privacy_password"]).'" class="textfield" /><br class="nobr" />
	</td>
	</tr>

	
	<tr>
	<td valign="top">
	<label>'.gettext('Authentication Protocol').':</label><br class="nobr" />
	</td>
	<td>
	<select name="snmpopts[v3_auth_proto]">
	<option value="md5" '.is_selected($snmpopts["v3_auth_proto"],"md5").'>md5</option>
	<option value="sha" '.is_selected($snmpopts["v3_auth_proto"],"sha").'>sha</option>
	</select>
	<br class="nobr" />
	</td>
	</tr>
	
    <tr>
	<td valign="top">
	<label>'.gettext('Privileged Protocol').':</label><br class="nobr" />
	</td>
	<td>
	<select name="snmpopts[v3_priv_proto]">
	<option value="des" '.is_selected($snmpopts["v3_priv_proto"],"des").'>des</option>
	<option value="aes" '.is_selected($snmpopts["v3_priv_proto"],"aes").'>aes</option>
	</select>
	<br class="nobr" />
	</td>
	</tr>

	</table>	
	

	';
			break;
			
		case CONFIGWIZARD_MODE_VALIDATESTAGE1DATA:
		
			// get variables that were passed to us
			$address=grab_array_var($inargs,"address","");
			$snmpcommunity=grab_array_var($inargs,"snmpcommunity","");
			$snmpversion=grab_array_var($inargs,"snmpversion","");
			
			
			// check for errors
			$errors=0;
			$errmsg=array();
			//$errmsg[$errors++]="Address: '$address'";
			if(have_value($address)==false)
				$errmsg[$errors++]="No address specified.";
			else if(!valid_ip($address))
				$errmsg[$errors++]="Invalid IP address.";;
			if(have_value($snmpcommunity)==false && $snmpversion != "3")
				$errmsg[$errors++]="No SNMP community specified.";
				
			if($errors>0){
				$outargs[CONFIGWIZARD_ERROR_MESSAGES]=$errmsg;
				$result=1;
				}
				
			break;
			
		case CONFIGWIZARD_MODE_GETSTAGE2HTML:
		
			// get variables that were passed to us
			$address=grab_array_var($inargs,"address");
			$hostname=grab_array_var($inargs,"hostname",gethostbyaddr($address));

			$snmpcommunity=grab_array_var($inargs,"snmpcommunity","");
			$snmpversion=grab_array_var($inargs,"snmpversion","");
			
			$snmpopts_serial=grab_array_var($inargs,"snmpopts_serial","");
			if($snmpopts_serial=="")
				$snmpopts=grab_array_var($inargs,"snmpopts");
			else
				$snmpopts=unserialize(base64_decode($snmpopts_serial));
			
			$services="";
			$services_serial=grab_array_var($inargs,"services_serial","");
			if($services_serial!="")
				$services=unserialize(base64_decode($services_serial));
			if(!is_array($services)){
				$services_default=array(
					"ping" => 1,
					"cpu" => 1,
					"memory" => 1,
					"pagefile" => 1,
					"disk" => 1,
					);
				$services=grab_array_var($inargs,"services",$services_default);
				}
			
			$serviceargs="";
			$serviceargs_serial=grab_array_var($inargs,"serviceargs_serial","");
			if($serviceargs_serial!="")
				$serviceargs=unserialize(base64_decode($serviceargs_serial));
			if(!is_array($serviceargs)){
				$serviceargs_default=array(
					"cpu_warning" => 80,
					"cpu_critical" => 90,
					"memory_warning" => 80,
					"memory_critical" => 90,
					"pagefile_warning" => 80,
					"pagefile_critical" => 90,
					"disk_warning" => array(),
					"disk_critical" => array(),
					"disk" => array(),
					"processstate" => array(),
					);
				for($x=0;$x<5;$x++){
					$serviceargs_default["disk_warning"][$x]=80;
					$serviceargs_default["disk_critical"][$x]=95;
					$serviceargs_default["disk"][$x]=($x==0)?"/":"";
					}
				for($x=0;$x<5;$x++){
					if($x==0){
						$serviceargs_default['processstate'][$x]['process']='httpd';
						$serviceargs_default['processstate'][$x]['name']='Apache';
						}
					else if($x==1){
						$serviceargs_default['processstate'][$x]['process']='mysqld';
						$serviceargs_default['processstate'][$x]['name']='MySQL';
						}
					else if($x==2){
						$serviceargs_default['processstate'][$x]['process']='sshd';
						$serviceargs_default['processstate'][$x]['name']='SSH';
						}
					else{
						$serviceargs_default['processstate'][$x]['process']='';
						$serviceargs_default['processstate'][$x]['name']='';
						}
					$serviceargs_default['processstate'][$x]['warn']='';
                    $serviceargs_default['processstate'][$x]['crit']='';
                    $services['processstate'][$x]='';
                    }
					

				$serviceargs=grab_array_var($inargs,"serviceargs",$serviceargs_default);
				}

			

			$output='
			
			
		<input type="hidden" name="address" value="'.htmlentities($address).'">
		<input type="hidden" name="snmpcommunity" value="'.htmlentities($snmpcommunity).'">
		<input type="hidden" name="snmpversion" value="'.htmlentities($snmpversion).'">
		<input type="hidden" name="snmpopts_serial" value="'.base64_encode(serialize($snmpopts)).'">

	<div class="sectionTitle">'.gettext('Linux Machine Details').'</div>
	
	<table>

	<tr>
	<td>
	<label>'.gettext('IP Address').':</label><br class="nobr" />
	</td>
	<td>
<input type="text" size="40" name="address" id="address" value="'.htmlentities($address).'" class="textfield" disabled/><br class="nobr" />
	</td>
	</tr>

	<tr>
	<td>
	<label>'.gettext('Host Name').':</label><br class="nobr" />
	</td>
	<td>
<input type="text" size="20" name="hostname" id="hostname" value="'.htmlentities($hostname).'" class="textfield" /><br class="nobr" />
	'.gettext('The name you\'d like to have associated with this Linux machine').'.
	</td>
	</tr>

	</table>


	<div class="sectionTitle">'.gettext('Server Metrics').'</div>
	
	<p>'.gettext('Specify which services you\'d like to monitor for the Linux machine').'.</p>
	
	<table>

	<tr>
	<td valign="top">
	<input type="checkbox" class="checkbox" name="services[ping]" '.is_checked($services["ping"],"1").'>
	</td>
	<td>
	<b>'.gettext('Ping').'</b><br>
	'.gettext('Monitors the machine with an ICMP ping.  Useful for watching network latency and general uptime').'.<br><br>
	</td>
	</tr>

	<tr>
	<td valign="top">
	<input type="checkbox" class="checkbox" name="services[cpu]" '.is_checked($services["cpu"],"1").'>
	</td>
	<td>
	<b>'.gettext('CPU').'</b><br>
	'.gettext('Monitors the CPU (processor usage) on the machine').'.<br>
	<label>Warning Load:</label> <input type="text" size="2" name="serviceargs[cpu_warning]" value="'.htmlentities($serviceargs["cpu_warning"]).'" class="textfield" />%
	<label>'.gettext('Critical Load').':</label> <input type="text" size="2" name="serviceargs[cpu_critical]" value="'.htmlentities($serviceargs["cpu_critical"]).'" class="textfield" />%<br><br>
	</td>
	</tr>

	<tr>
	<td valign="top">
	<input type="checkbox" class="checkbox" name="services[memory]" '.is_checked($services["memory"],"1").'>
	</td>
	<td>
	<b>'.gettext('Physical Memory Usage').'</b><br>
	'.gettext('Monitors the physical (real) memory usage on the machine').'.<br>
	<label>'.gettext('Warning Usage').':</label> <input type="text" size="2" name="serviceargs[memory_warning]" value="'.htmlentities($serviceargs["memory_warning"]).'" class="textfield" />%
	<label>'.gettext('Critical Usage').':</label> <input type="text" size="2" name="serviceargs[memory_critical]" value="'.htmlentities($serviceargs["memory_critical"]).'" class="textfield" />%<br><br>
	</td>
	</tr>

	<tr>
	<td valign="top">
	<input type="checkbox" class="checkbox" name="services[pagefile]" '.is_checked($services["pagefile"],"1").'>
	</td>
	<td>
	<b>'.gettext('Swap Usage').'</b><br>
	'.gettext('Monitors the swap usage on the machine').'.<br>
	<label>'.gettext('Warning Usage').':</label> <input type="text" size="2" name="serviceargs[pagefile_warning]" value="'.htmlentities($serviceargs["pagefile_warning"]).'" class="textfield" />%
	<label>'.gettext('Critical Usage').':</label> <input type="text" size="2" name="serviceargs[pagefile_critical]" value="'.htmlentities($serviceargs["pagefile_critical"]).'" class="textfield" />%<br><br>
	</td>
	</tr>

	<tr>
	<td valign="top">
	<input type="checkbox" class="checkbox" name="services[disk]" '.is_checked($services["disk"],"1").'>
	</td>
	<td>
	<b>'.gettext('Disk Usage').'</b><br>
	'.gettext('Monitors disk usage on the machine').'.<br>
	<table class="adddeleterow">
	';
	for($x=0;$x<count($serviceargs["disk"]);$x++){
		$checkedstr="";
		if($x==0)
			$checkedstr="checked";
		$output.='<tr>';
		$output.='<td><label>Drive:</label>'; 
		$output.='<td><input type="text" size="15" name="serviceargs[disk]['.$x.']" value="'.htmlentities($serviceargs["disk"][$x]).'" class="textfield" /></td>';
		$output.='<td><label>Warning Usage:</label> <input type="text" size="2" name="serviceargs[disk_warning]['.$x.']" value="'.htmlentities($serviceargs["disk_warning"][$x]).'" class="textfield" />%
	<label>'.gettext('Critical Usage').':</label> <input type="text" size="2" name="serviceargs[disk_critical]['.$x.']" value="'.htmlentities($serviceargs["disk_critical"][$x]).'" class="textfield" />%</td>';
		$output.='</tr>';
		}
	$output.='
	</table>
	</td>
	</tr>

	</table>

	<div class="sectionTitle">'.gettext('Processes').'</div>
	
	<p>'.gettext('Specify any processes that should be monitored to ensure they\'re running').'.  <strong>Note:</strong> '.gettext('Process names are case-sensitive').'.</p>
	<p><b>'.gettext('Tip').':</b> '.gettext('The').' <i>'.gettext('Warning').'</i> '.gettext('and').' <i>'.gettext('Critical').'</i> '.gettext('fields can contain two numbers separated by a comma that represent thresholds for the number of processes that should be running. A field value of').' <i>5,10</i> '.gettext('would generate a warning or critical alert if there were less than 5 or more than 10 processes found').'.</p>
	
	<table class="adddeleterow">
	
	<tr><th></th><th>'.gettext('Linux Process').'</th><th>'.gettext('Display Name').'</th><th>'.gettext('Warning').'</th><th>'.gettext('Critical').'</th></tr>
	';
	for($x=0;$x<count($serviceargs['processstate']);$x++){

		$processstring=$serviceargs['processstate'][$x]['process'];
		$processname=$serviceargs['processstate'][$x]['name'];
		$processwarn=$serviceargs['processstate'][$x]['warn'];
		$processcrit=$serviceargs['processstate'][$x]['crit'];

		$output.='<tr><td><input type="checkbox" class="checkbox" name="services[processstate]['.$x.']"  '.is_checked($services["processstate"][$x]).'></td><td><input type="text" size="15" name="serviceargs[processstate]['.$x.'][process]" value="'.htmlentities($processstring).'" class="textfield" /></td><td><input type="text" size="20" name="serviceargs[processstate]['.$x.'][name]" value="'.htmlentities($processname).'" class="textfield" /></td><td><input type="text" size="5" name="serviceargs[processstate]['.$x.'][warn] value="'.htmlentities($processwarn).'" class="textfield" /></td><td><input type="text" size="5" name="serviceargs[processstate]['.$x.'][crit] value="'.htmlentities($processcrit).'" class="textfield" /></td></tr>';
		}
	$output.='
	</table>


			';
			break;
			
		case CONFIGWIZARD_MODE_VALIDATESTAGE2DATA:
		
			// get variables that were passed to us
			$address=grab_array_var($inargs,"address");
			$hostname=grab_array_var($inargs,"hostname");
			$snmpcommunity=grab_array_var($inargs,"snmpcommunity","");
			$snmpversion=grab_array_var($inargs,"snmpversion","");
			
			// check for errors
			$errors=0;
			$errmsg=array();
			if(is_valid_host_name($hostname)==false)
				$errmsg[$errors++]="Invalid host name.";
				
			if($errors>0){
				$outargs[CONFIGWIZARD_ERROR_MESSAGES]=$errmsg;
				$result=1;
				}
				
			break;

			
		case CONFIGWIZARD_MODE_GETSTAGE3HTML:
		
			// get variables that were passed to us
			$address=grab_array_var($inargs,"address");
			$hostname=grab_array_var($inargs,"hostname");
			$snmpcommunity=grab_array_var($inargs,"snmpcommunity","");
			$snmpversion=grab_array_var($inargs,"snmpversion","");
			$services=grab_array_var($inargs,"services");
			$serviceargs=grab_array_var($inargs,"serviceargs");

			$snmpopts_serial=grab_array_var($inargs,"snmpopts_serial","");
			if($snmpopts_serial=="")
				$snmpopts=grab_array_var($inargs,"snmpopts");
			else
				$snmpopts=unserialize(base64_decode($snmpopts_serial));
			
			$output='
			
		<input type="hidden" name="address" value="'.htmlentities($address).'">
		<input type="hidden" name="hostname" value="'.htmlentities($hostname).'">
		<input type="hidden" name="snmpcommunity" value="'.htmlentities($snmpcommunity).'">
		<input type="hidden" name="snmpversion" value="'.htmlentities($snmpversion).'">
		<input type="hidden" name="snmpopts_serial" value="'.base64_encode(serialize($snmpopts)).'">
		<input type="hidden" name="services_serial" value="'.base64_encode(serialize($services)).'">
		<input type="hidden" name="serviceargs_serial" value="'.base64_encode(serialize($serviceargs)).'">
		
		<!--SERVICES='.serialize($services).'<BR>
		SERVICEARGS='.serialize($serviceargs).'<BR>-->
		
			';
			break;
			
		case CONFIGWIZARD_MODE_VALIDATESTAGE3DATA:
				
			break;
			
		case CONFIGWIZARD_MODE_GETFINALSTAGEHTML:
			
			break;
			
		case CONFIGWIZARD_MODE_GETOBJECTS:
		
			$hostname=grab_array_var($inargs,"hostname","");
			$address=grab_array_var($inargs,"address","");
			$snmpcommunity=grab_array_var($inargs,"snmpcommunity","");
			$snmpversion=grab_array_var($inargs,"snmpversion","");
			$hostaddress=$address;
			
			$snmpopts_serial=grab_array_var($inargs,"snmpopts_serial","");
			$snmpopts=unserialize(base64_decode($snmpopts_serial));
			
			$services_serial=grab_array_var($inargs,"services_serial","");
			$serviceargs_serial=grab_array_var($inargs,"serviceargs_serial","");
			
			$services=unserialize(base64_decode($services_serial));
			$serviceargs=unserialize(base64_decode($serviceargs_serial));
			
			/*
			echo "SERVICES<BR>";
			print_r($services);
			echo "<BR>";
			echo "SERVICEARGS<BR>";
			print_r($serviceargs);
			echo "<BR>";
			*/
			
			// save data for later use in re-entrance
			$meta_arr=array();
			$meta_arr["hostname"]=$hostname;
			$meta_arr["address"]=$address;
			$meta_arr["snmpcommunity"]=$snmpcommunity;
			$meta_arr["snmpversion"]=$snmpversion;
			$meta_arr["services"]=$services;
			$meta_arr["serivceargs"]=$serviceargs;
			save_configwizard_object_meta($wizard_name,$hostname,"",$meta_arr);			
			
			$objs=array();
			
			if(!host_exists($hostname)){
				$objs[]=array(
					"type" => OBJECTTYPE_HOST,
					"use" => "xiwizard_linuxsnmp_host",
					"host_name" => $hostname,
					"address" => $hostaddress,
					"icon_image" => "snmppenguin.png",
					"statusmap_image" => "snmppenguin.png",
					"_xiwizard" => $wizard_name,
					);
				}
				
			// determine SNMP args
			$snmpargs="";
			if($snmpcommunity!="" && $snmpversion != "3")
				$snmpargs.=" -C ".$snmpcommunity;
			if($snmpversion=="2c")
				$snmpargs.=" --v2c";
			// snmpv3 stuff
			else if($snmpversion=="3"){
							
				$securitylevel=grab_array_var($snmpopts,"v3_security_level");
				$username=grab_array_var($snmpopts,"v3_username");
				$authproto=grab_array_var($snmpopts,"v3_auth_proto");
                $privproto=grab_array_var($snmpopts,"v3_priv_proto");
				$authpassword=grab_array_var($snmpopts,"v3_auth_password");
				$privacypassword=grab_array_var($snmpopts,"v3_privacy_password");
				
				if($username!="")
					$snmpargs.=" --login=".$username;
				if($authpassword!="")
					$snmpargs.=" --passwd=".$authpassword;
				if($privacypassword!="")
					$snmpargs.=" --privpass=".$privacypassword;
                if($authproto!="")
                    $snmpargs.=" --protocols=".$authproto.",".$privproto;
				}
				
			// see which services we should monitor
			foreach($services as $svc => $svcstate){
			
				//echo "PROCESSING: $svc -> $svcstate<BR>\n";
		
				switch($svc){
				
					case "ping":
						$objs[]=array(
							"type" => OBJECTTYPE_SERVICE,
							"host_name" => $hostname,
							"service_description" => "Ping",
							"check_command" => "check-host-alive",
							"_xiwizard" => $wizard_name,
							);
						break;
					
					case "cpu":
						$objs[]=array(
							"type" => OBJECTTYPE_SERVICE,
							"host_name" => $hostname,
							"service_description" => "CPU Usage",
							"use" => "xiwizard_linuxsnmp_load",
							"check_command" => "check_xi_service_snmp_linux_load!".$snmpargs." -w ".$serviceargs["cpu_warning"]." -c ".$serviceargs["cpu_critical"]." -f",
							"_xiwizard" => $wizard_name,
							);
						break;
					
					case "memory":
						$objs[]=array(
							"type" => OBJECTTYPE_SERVICE,
							"host_name" => $hostname,
							"service_description" => "Memory Usage",
							"use" => "xiwizard_linuxsnmp_storage",
							"check_command" => "check_xi_service_snmp_linux_storage!".$snmpargs." -m 'Memory' -w ".$serviceargs["memory_warning"]." -c ".$serviceargs["memory_critical"]." -f",
							"_xiwizard" => $wizard_name,
							);
						break;
					
					case "pagefile":
						$objs[]=array(
							"type" => OBJECTTYPE_SERVICE,
							"host_name" => $hostname,
							"service_description" => "Swap Usage",
							"use" => "xiwizard_linuxsnmp_storage",
							"check_command" => "check_xi_service_snmp_linux_storage!".$snmpargs." -m 'Swap' -w ".$serviceargs["pagefile_warning"]." -c ".$serviceargs["pagefile_critical"]." -f",
							"_xiwizard" => $wizard_name,
							);
						break;
					
					case "disk":
						$donedisks=array();
						$diskid=0;
						foreach($serviceargs["disk"] as $diskname){
						
							if($diskname=="")
								continue;
						
							//echo "HANDLING DISK: $diskname<BR>";
							
							// we already configured this disk
							if(in_array($diskname,$donedisks))
								continue;
							$donedisks[]=$diskname;
							
							$objs[]=array(
								"type" => OBJECTTYPE_SERVICE,
								"host_name" => $hostname,
								"service_description" => $diskname." Disk Usage",
								"use" => "xiwizard_linuxsnmp_storage",
								"check_command" => "check_xi_service_snmp_linux_storage!".$snmpargs." -m \"^".$diskname."$\" -w ".$serviceargs["disk_warning"][$diskid]." -c ".$serviceargs["disk_critical"][$diskid]." -f",
								"_xiwizard" => $wizard_name,
								);		

							$diskid++;
							}
						break;
						
					
					case "processstate":
						
						$enabledprocs=$svcstate;
						foreach($enabledprocs as $pid => $pstate){
						
							$pname=$serviceargs["processstate"][$pid]["process"];
							$pdesc=$serviceargs["processstate"][$pid]["name"];
							$pwarn=$serviceargs["processstate"][$pid]["warn"];
							$pcrit=$serviceargs["processstate"][$pid]["crit"];
							
							$objs[]=array(
								"type" => OBJECTTYPE_SERVICE,
								"host_name" => $hostname,
								"service_description" => $pdesc,
								"use" => "xiwizard_linuxsnmp_process",
								"check_command" => "check_xi_service_snmp_linux_process!".$snmpargs." -n '".$pname."' -w '".$pwarn."' -c '".$pcrit."'",
								"_xiwizard" => $wizard_name,
								);		
							}
						break;
												
						
				
					default:
						break;
					}
				}
				
			//echo "OBJECTS:<BR>";
			//print_r($objs);
			//exit();
					
			// return the object definitions to the wizard
			$outargs[CONFIGWIZARD_NAGIOS_OBJECTS]=$objs;
		
			break;
			
		default:
			break;			
		}
		
	return $output;
	}
	

?>