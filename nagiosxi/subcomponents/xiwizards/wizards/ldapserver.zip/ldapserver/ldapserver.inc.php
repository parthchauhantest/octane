<?php
// LDAP SERVER CONFIG WIZARD
//
// Copyright (c) 2010 Nagios Enterprises, LLC.  All rights reserved.
//  
// $Id: $

include_once(dirname(__FILE__).'/../configwizardhelper.inc.php');

// run the initialization function
ldapserver_configwizard_init();

function ldapserver_configwizard_init(){
	
	$name="ldapserver";
	
	$args=array(
		CONFIGWIZARD_NAME => $name,
        CONFIGWIZARD_VERSION => "1.2",
		CONFIGWIZARD_TYPE => CONFIGWIZARD_TYPE_MONITORING,
		CONFIGWIZARD_DESCRIPTION => gettext("Monitor an LDAP server."),
		CONFIGWIZARD_DISPLAYTITLE => gettext("LDAP Server"),
		CONFIGWIZARD_FUNCTION => "ldapserver_configwizard_func",
		CONFIGWIZARD_PREVIEWIMAGE => "directory_services3.png",
		);
		
	register_configwizard($name,$args);
	}



function ldapserver_configwizard_func($mode="",$inargs=null,&$outargs,&$result){

	$wizard_name="ldapserver";
	
	// initialize return code and output
	$result=0;
	$output="";
	
	// initialize output args - pass back the same data we got
	$outargs[CONFIGWIZARD_PASSBACK_DATA]=$inargs;


	switch($mode){
		case CONFIGWIZARD_MODE_GETSTAGE1HTML:
		
			$address=grab_array_var($inargs,"address","");
			
			$output='

	<div class="sectionTitle">'.gettext('LDAP Server').'</div>
	
			
	<table>

	<tr>
	<td valign="top">
	<label>Address:</label><br class="nobr" />
	</td>
	<td>
<input type="text" size="40" name="address" id="address" value="'.htmlentities($address).'" class="textfield" /><br class="nobr" />
	'.gettext('The IP address or FQDNS name of the device or server associated with the LDAP server').'.<br><br>
	</td>
	</tr>

	</table>

			';
			break;
			
		case CONFIGWIZARD_MODE_VALIDATESTAGE1DATA:
		
			// get variables that were passed to us
			$address=grab_array_var($inargs,"address","");
			
			
			// check for errors
			$errors=0;
			$errmsg=array();
			if(have_value($address)==false)
				$errmsg[$errors++]="No address specified.";
				
			if($errors>0){
				$outargs[CONFIGWIZARD_ERROR_MESSAGES]=$errmsg;
				$result=1;
				}
				
			break;
			
		case CONFIGWIZARD_MODE_GETSTAGE2HTML:
		
			// get variables that were passed to us
			$address=grab_array_var($inargs,"address");

			$ha=@gethostbyaddr($address);
			if($ha=="")
				$ha=$address;
			$hostname=grab_array_var($inargs,"hostname",$ha);
		
			$port=grab_array_var($inargs,"port");
			$base=grab_array_var($inargs,"base","ou=my unit,o=my org,c=at");
			$bind_dn=grab_array_var($inargs,"bind_dn");
			$password=grab_array_var($inargs,"password");
			$security=grab_array_var($inargs,"security");
			$version=grab_array_var($inargs,"version");
			$search=grab_array_var($inargs,"search");

			$services=grab_array_var($inargs,"services",array("server"=>"on","transfer"=>""));
			
		
			$output='
			
		<input type="hidden" name="address" value="'.htmlentities($address).'">

	<div class="sectionTitle">'.gettext('LDAP Server').'</div>
	
			
	<table>
	
	<tr>
	<td valign="top">
	<label>'.gettext('Address').':</label><br class="nobr" />
	</td>
	<td>
<input type="text" size="20" name="address" id="address" value="'.htmlentities($address).'" class="textfield" disabled/><br class="nobr" />
	</td>
	</tr>

	<tr>
	<td valign="top">
	<label>'.gettext('Host Name').':</label><br class="nobr" />
	</td>
	<td>
<input type="text" size="20" name="hostname" id="hostname" value="'.htmlentities($hostname).'" class="textfield" /><br class="nobr" />
	'.gettext('The name you\'d like to have associated with this LDAP server').'.
	</td>
	</tr>
	
	</table>


	<div class="sectionTitle">'.gettext('LDAP Settings').'</div>
	
	
	<table>
	
	<tr>
	<td valign="top">
	<label>'.gettext('LDAP Base').':</label><br class="nobr" />
	</td>
	<td>
	<input type="text" size="32" name="base" value="'.htmlentities($base).'" class="textfield" /><br> 
	'.gettext('LDAP base to use').'.<br><br>
	</td>
	</tr>

	<tr>
	<td valign="top">
	<label>'.gettext('Bind DN').':</label><br class="nobr" />
	</td>
	<td>
	<input type="text" size="32" name="bind_dn" value="'.htmlentities($bind_dn).'" class="textfield" /><br> 
	'.gettext('LDAP bind DN (if required)').'.<br><br>
	</td>
	</tr>

	<tr>
	<td valign="top">
	<label>'.gettext('Password').':</label><br class="nobr" />
	</td>
	<td>
	<input type="password" size="16" name="password" value="'.htmlentities($password).'" class="textfield" /><br> 
	'.gettext('The password used to login to the LDAP server (if required)').'.<br><br>
	</td>
	</tr>

	<tr>
	<td valign="top">
	<label>'.gettext('Version').':</label><br class="nobr" />
	</td>
	<td>
		<select name="version" >
		<option value="2" '.is_selected($version,'2').'>2</option>
		<option value="3" '.is_selected($version,'3').'>3</option>
		</select><br>
	'.gettext('Version of LDAP protocol to use').'.<br><br>
	</td>
	</tr>

	<tr>
	<td valign="top">
	<label>Security:</label><br class="nobr" />
	</td>
	<td>
		<select name="security" >
		<option value="" '.is_selected($security,'').'>'.gettext('None').'</option>
		<option value="ssl" '.is_selected($security,'ssl').'>'.gettext('SSL').'</option>
		<option value="starttls" '.is_selected($security,'starttls').'>STARTTLS</option>
		</select><br>
	'.gettext('Security to use for LDAP connection (optional)').'.<br><br>
	</td>
	</tr>

	<tr>
	<td valign="top">
	<label>'.gettext('Port Override').':</label><br class="nobr" />
	</td>
	<td>
	<input type="text" size="3" name="port" value="'.htmlentities($port).'" class="textfield" /><br> 
	'.gettext('The port number the LDAP server runs on.  Defaults to port 389 (non-SSL) or 636 (SSL)').'. <br><br>
	</td>
	</tr>

	</table>

			';
			break;
			
		case CONFIGWIZARD_MODE_VALIDATESTAGE2DATA:
		
			// get variables that were passed to us
			$address=grab_array_var($inargs,"address");
			$hostname=grab_array_var($inargs,"hostname");
			
			$port=grab_array_var($inargs,"port");
			$base=grab_array_var($inargs,"base");
			$bind_dn=grab_array_var($inargs,"bind_dn");
			$password=grab_array_var($inargs,"password");
			$security=grab_array_var($inargs,"security");
			$version=grab_array_var($inargs,"version");
			$search=grab_array_var($inargs,"search");
			
			$services=grab_array_var($inargs,"services",array());
			
		
			// check for errors
			$errors=0;
			$errmsg=array();
			if(is_valid_host_name($hostname)==false)
				$errmsg[$errors++]="Invalid host name.";
			if($base=="")
				$errmsg[$errors++]="LDAP base is blank.";
			//if($port=="")
				//$errmsg[$errors++]="Invalid port number.";
				
			if($errors>0){
				$outargs[CONFIGWIZARD_ERROR_MESSAGES]=$errmsg;
				$result=1;
				}
				
			break;

			
		case CONFIGWIZARD_MODE_GETSTAGE3HTML:
		
			// get variables that were passed to us
			$address=grab_array_var($inargs,"address");
			$hostname=grab_array_var($inargs,"hostname");
			
			$port=grab_array_var($inargs,"port");
			$base=grab_array_var($inargs,"base");
			$bind_dn=grab_array_var($inargs,"bind_dn");
			$password=grab_array_var($inargs,"password");
			$security=grab_array_var($inargs,"security");
			$version=grab_array_var($inargs,"version");
			$search=grab_array_var($inargs,"search");
			
			$services=grab_array_var($inargs,"services");
			$serviceargs=grab_array_var($inargs,"serviceargs");
		
			$output='
			
		<input type="hidden" name="address" value="'.htmlentities($address).'">
		<input type="hidden" name="hostname" value="'.htmlentities($hostname).'">
		<input type="hidden" name="port" value="'.htmlentities($port).'">
		<input type="hidden" name="base" value="'.htmlentities($base).'">
		<input type="hidden" name="bind_dn" value="'.htmlentities($bind_dn).'">
		<input type="hidden" name="password" value="'.htmlentities($password).'">
		<input type="hidden" name="security" value="'.htmlentities($security).'">
		<input type="hidden" name="version" value="'.htmlentities($version).'">
		<input type="hidden" name="search" value="'.htmlentities($search).'">
		<input type="hidden" name="services_serial" value="'.base64_encode(serialize($services)).'">
		<input type="hidden" name="serviceargs_serial" value="'.base64_encode(serialize($serviceargs)).'">
		
		<!--SERVICES='.serialize($services).'<BR>
		SERVICEARGS='.serialize($serviceargs).'<BR>-->
		
			';
			break;
			
		case CONFIGWIZARD_MODE_VALIDATESTAGE3DATA:
				
			break;
			
		case CONFIGWIZARD_MODE_GETFINALSTAGEHTML:
			
			
			$output='
			';
			break;
			
		case CONFIGWIZARD_MODE_GETOBJECTS:
		
			$hostname=grab_array_var($inargs,"hostname","");
			$address=grab_array_var($inargs,"address","");
			$hostaddress=$address;
			
			$port=grab_array_var($inargs,"port");
			$base=grab_array_var($inargs,"base");
			$bind_dn=grab_array_var($inargs,"bind_dn");
			$password=grab_array_var($inargs,"password");
			$security=grab_array_var($inargs,"security");
			$version=grab_array_var($inargs,"version");
			$search=grab_array_var($inargs,"search");
			
			$services_serial=grab_array_var($inargs,"services_serial","");
			$serviceargs_serial=grab_array_var($inargs,"serviceargs_serial","");
			
			$services=unserialize(base64_decode($services_serial));
			$serviceargs=unserialize(base64_decode($serviceargs_serial));
			
			/*
			echo "SERVICES<BR>";
			print_r($services);
			echo "<BR>";
			echo "SERVICEARGS<BR>";
			print_r($serviceargs);
			echo "<BR>";
			*/
			
			// save data for later use in re-entrance
			$meta_arr=array();
			$meta_arr["hostname"]=$hostname;
			$meta_arr["address"]=$address;
			$meta_arr["port"]=$port;
			$meta_arr["base"]=$base;
			$meta_arr["bind_dn"]=$bind_dn;
			$meta_arr["password"]=$password;
			$meta_arr["security"]=$security;
			$meta_arr["version"]=$version;
			$meta_arr["search"]=$search;
			$meta_arr["services"]=$services;
			$meta_arr["serivceargs"]=$serviceargs;
			save_configwizard_object_meta($wizard_name,$hostname,"",$meta_arr);			
			
			$objs=array();
			
			if(!host_exists($hostname)){
				$objs[]=array(
					"type" => OBJECTTYPE_HOST,
					"use" => "xiwizard_ldapserver_host",
					"host_name" => $hostname,
					"address" => $hostaddress,
					"icon_image" => "directory_services3.png",
					"statusmap_image" => "directory_services3.png",
					"_xiwizard" => $wizard_name,
					);
				}
				
			$pluginopts="";
			$pluginopts.="-b \"".$base."\"";
			if($bind_dn!="")
				$pluginopts.=" -D \"".$bind_dn."\""; 
			if($password!="")
				$pluginopts.=" -P \"".$password."\""; 
			if($port!="")
				$pluginopts.=" -p ".$port;
			if($version=="2")
				$pluginopts.=" -2";
			else if($version=="3")
				$pluginopts.=" -3";
			if($security=="ssl")
				$pluginopts.=" -S";
			else if($security=="starttls")
				$pluginopts.=" -T";
				
			$objs[]=array(
				"type" => OBJECTTYPE_SERVICE,
				"host_name" => $hostname,
				"service_description" => "LDAP Server",
				"use" => "xiwizard_ldapserver_ldap_service",
				"check_command" => "check_xi_service_ldap!".$pluginopts,
				"_xiwizard" => $wizard_name,
				"icon_image" => "directory_services.png",
				);
				
			//echo "OBJECTS:<BR>";
			//print_r($objs);
			//exit();
					
			// return the object definitions to the wizard
			$outargs[CONFIGWIZARD_NAGIOS_OBJECTS]=$objs;
		
			break;
			
		default:
			break;			
		}
		
	return $output;
	}
	

?>