<?php
// VMWARE CONFIG WIZARD
//
// Copyright (c) 2008-2010 Nagios Enterprises, LLC.  All rights reserved.
//
// $Id: vmware.inc.php 1099 2013-07-23 16:10:30Z swilkerson $


include_once(dirname(__FILE__).'/../configwizardhelper.inc.php');

// run the initialization function
vmware_configwizard_init();

define	(	'VMWARE_SERVICENAMES', 
			serialize	(array	(
									array('CPU',TRUE,'CPU Usage',0,1,2,3,0,1,2,3),
									array('MEM',TRUE,'Memory',0,1,2,3,0,1,2,3),
									array('NET',TRUE,'Networking',0,1,2,3,0,1,2,3),
									array('IO',TRUE,'Input / Output',0,1,2,3,0,1,2,3),
									array('VMFS',FALSE,'Datastore usage',0,1,2,3,0,1,2,3),
									array('RUNTIME',TRUE,'VM Status',0,1,2,3,0,1,2,3),
									array('SERVICE',FALSE,'Services',0,1,2,3,0,1,2,3),
								)
					)
		);

define(	'VMWARE_BASICDATA', 
		serialize( array(
					array(
						array("wng","warning","Warning"),
						array("crt","critical","Critical"),
						 ),
					array(
						array("low","low","%s Below:"),
						array("hi","high","Above:"),
						 )
						)
				 )
);

define('VMWARE_HOSTINPUTF','');

function vmware_configwizard_init()
{
	$name='vmware';

	$args=array(
		CONFIGWIZARD_NAME => $name,
        CONFIGWIZARD_VERSION => "1.6",
		CONFIGWIZARD_TYPE => CONFIGWIZARD_TYPE_MONITORING,
		CONFIGWIZARD_DESCRIPTION => gettext('Monitor a VMware host or guest VM.'),
		CONFIGWIZARD_DISPLAYTITLE => gettext('VMware'),
		CONFIGWIZARD_FUNCTION => 'vmware_configwizard_func',
		CONFIGWIZARD_PREVIEWIMAGE => 'vmware.png',
	);

	register_configwizard($name,$args);
}
	
function vmware_configwizard_check_prereqs()
{
	// plugin doesn't exist
	if(!file_exists("/usr/local/nagios/libexec/check_esx3.pl")){
		return false;
		}
		
	// run the plugin to see if the SDK is installed
	$retval=0;
	$cmdline="/usr/local/nagios/libexec/check_esx3.pl | head --lines=1";
	$output=exec($cmdline);
    
	if(strstr($output,"Missing perl module") )
		return false;

	return true;
}

function vmware_configwizard_parseinargs($inargs=null) 
{
	// get variables that were passed to us
	$address=grab_array_var($inargs,'address','');
	$hostname=grab_array_var($inargs,'hostname','');
	$ha='';
	if ($hostname=='') 
	{
		$ha = $address == '' ? '' : @gethostbyaddr($address);
		if($ha=='')
			$ha=$address;
	}
	$hostname=grab_array_var($inargs,'hostname',$ha);
	$type=grab_array_var($inargs,'type','host');
	$username=grab_array_var($inargs,'username','');
	$password=grab_array_var($inargs,'password','');

	$services_serial=grab_array_var($inargs,'services_serial','');
	$serviceargs_serial=grab_array_var($inargs,'serviceargs_serial','');
	$guests_serial=grab_array_var($inargs,'guests_serial','');

	$services=unserialize(base64_decode($services_serial));
	$serviceargs=unserialize(base64_decode($serviceargs_serial));
	$guests=unserialize(base64_decode($guests_serial));
	if (!is_array($services)) 
		$services = array();
	if (!is_array($serviceargs)) 
		$serviceargs = array();
	if (!is_array($guests)) 
		$guests = array();
	$srvlock = 0;
	$guestlock = 0;

	foreach ( array_keys ($inargs) as $argu ) 
	{
		if ($type=='guest' && preg_match('/^activate_(.*)$/', $argu, $matches)) 
		{
			if (!$guestlock) 
			{
				$guests = array();
				$guestlock = -1;
			}
			$argt=base64_decode($matches[1]);
			$guests[$argt] = grab_array_var($inargs,"alias_${matches[1]}",$argt);
		}
		if (preg_match('/^service_(.*)$/', $argu, $matches)) 
		{
			if (!$srvlock) 
			{
				$services = array();
				$srvlock = -1;
			}
			$services[$matches[1]]=TRUE;
		}
		if (preg_match('/^serviceargs_([^-]*)-(.*)$/', $argu, $matches)) 
		{
			$argt=$matches[1].'_'.$matches[2];
			if (array_search($argt,$serviceargs)===FALSE)
				$serviceargs[$argt] = grab_array_var($inargs,$argu,'');
		}
	}
	
	unset ($argu);

	return array($hostname, $address, $type, $username, $password,$services, $serviceargs, $guests);
}

function vmware_configwizard_pushcheckboxandargs(&$output,$s,$services,$serviceargs,$mode) 
{
	$sl=strtolower($s[0]);
	$output.='&nbsp;&nbsp;&nbsp;&nbsp;<input type="checkbox" id="ckhbx_'.htmlentities($sl).'" name="service_'.htmlentities($sl).'"'.(array_key_exists($sl, $services)?' checked="yes"':'').'></input><label for="ckhbx_'.htmlentities($sl).'">'.htmlentities($s[2]).'</label><br>';
}

function vmware_configwizard_getrangeargs($serviceargs, $svcl)
{
	$ret='';
	$dab=array();
	foreach (array_shift(unserialize(VMWARE_BASICDATA)) as $da) 
	{
		foreach (array_pop(unserialize(VMWARE_BASICDATA)) as $db) 
		{
			$key='-'.$da[1].'_'.$db[1];
			array_push($dab,
				grab_array_var($serviceargs,
					$svcl.$key));
		}
	}
	list($wl,$wh,$cl,$ch) = $dab; unset($dab, $da, $db);
	if(!($wh=='' && $wl==''))
		$ret.=' -w '.$wl.':'.$wh;
	if(!($ch=='' && $cl==''))
		$ret.=' -c '.$cl.':'.$ch;

	return $ret;
}

function vmware_configwizard_makehost(&$objs, $type, $hostname, $address)
{
	return array(
		'type' => OBJECTTYPE_HOST,
		'use' => 'xiwizard_generic_host',
		'host_name' => $hostname,
		'address' => $address,
		'icon_image' => 'vmware.png',
		'statusmap_image' => 'vmware.png',
		'_xiwizard' => 'vmware',
	);
}

function vmware_configwizard_makeservices(&$objs, $hostname, $address, $type, $services, $serviceargs, $guests)
{
	$fil=get_root_dir().'/etc/components/vmware/'.preg_replace("/[ '.\:_-]/",'_',$hostname).'_auth.txt';
	if(!host_exists($hostname))
		$objs[]=vmware_configwizard_makehost($objs, $type, $hostname, $address);
	switch($type) 
	{
		case 'guest':
			foreach($guests as $guestaddress => $guestname)
			{
			
				// see which services we should monitor
				foreach (unserialize(VMWARE_SERVICENAMES) as $s) 
				{
					$sl=strtolower($s[0]);
					if (array_key_exists($sl, $services) ) 
					{
						$warn=vmware_configwizard_getrangeargs($serviceargs,$sl);
						$objs[]=array( 	'type' => OBJECTTYPE_SERVICE,
										'host_name' => $hostname,
										'service_description' => "${guestname} ${s[2]}",
										'use' => 'xiwizard_generic_service',
										'check_command' => "check_esx3_guest!$fil!$guestaddress!${s[0]}!$warn!",
										'_xiwizard' => 'vmware',
						);
					}
				}
			}
			break;
			
		case 'host':

			// see which services we should monitor
			foreach (unserialize(VMWARE_SERVICENAMES) as $s) 
			{
				$sl=strtolower($s[0]);
				if (array_key_exists($sl, $services) ) 
				{
					$warn=vmware_configwizard_getrangeargs($serviceargs, $sl);

					$objs[]=array( 	'type' => OBJECTTYPE_SERVICE,
									'host_name' => $hostname,
									'service_description' => "${s[2]} for VMHost",
									'use' => 'xiwizard_generic_service',
									'check_command' => 'check_esx3_host!'.$fil.'!'.$s[0].'!'.$warn,
									'_xiwizard' => 'vmware',
					);
				}
			}
			break;
			
		default:
			break;
	}
}

function vmware_configwizard_func($mode='',$inargs=null,&$outargs,&$result)
{
	// initialize return code and output
	$result=0;
	$output='';

	// initialize output args - pass back the same data we got
	$outargs[CONFIGWIZARD_PASSBACK_DATA]=$inargs;


	switch($mode)
	{
	
		case CONFIGWIZARD_MODE_GETSTAGE1HTML:

			$output='';
		
			if(vmware_configwizard_check_prereqs()==false)
			{
		
				$output.='<p><b>'.gettext('Error').':</b> '.gettext('It appears as though you have not installed the VMware SDK or ESX plugins on your Nagios XI server.  You must have these components properly installed on your system before using this wizard.').'</p>
                '.gettext('To complete the installation of the required components please follow the').' <strong><a href="http://library.nagios.com/library/products/nagiosxi/documentation/272-monitoring-vmware-with-nagios-xi" target="_blank">'.gettext('Monitoring VMware with Nagios XI').'</a></strong> documentation.';
			}
			
			else
			{
				list($hostname, $address, $type, $username, $password, $services, $serviceargs, $guests) = vmware_configwizard_parseinargs($inargs);

				$output.='<input type="hidden" name="services_serial" value="'.htmlentities(base64_encode(serialize($services))).'">
				<input type="hidden" name="serviceargs_serial" value="'.htmlentities(base64_encode(serialize($serviceargs))).'">
				<input type="hidden" name="guests_serial" value="'.htmlentities(base64_encode(serialize($guests))).'">
				<div class="sectionTitle">'.gettext('VMware Information').'</div>
					<table>
						
						<tr>
							<td valign="top">
								<label>'.gettext('Address').':</label><br class="nobr" />
							</td>
							<td>
								<input type="text" size="30" name="address" id="address" value="'.htmlentities($address).'" class="textfield"></input>
								<br class="nobr" />'.gettext('The IP address or FQDNS name of the VMware (server) host you would like to monitor.').'<br />
							</td>
						</tr>
						
						<tr>
							<td valign="top">
								<label>'.gettext('Username:').'</label><br class="nobr" />
							</td>
							<td>
								<input type="text" size="20" name="username" id="username" value="'.htmlentities($username).'" class="textfield"></input><br />'.gettext('The password used to authenticated to the VMware server.').'<br />
							</td>
						</tr>
						
						<tr>
							<td valign="top">
								<label>'.gettext('Password').':</label><br class="nobr" />
							</td>
							<td>
								<input type="password" size="20" name="password" id="password" value="'.htmlentities($password).'" class="textfield"></input><br />'.gettext('The password used to authenticated to the VMware server.').'<br />
							</td>
						</tr>
						
						<tr>
							<td valign="top">
								<label>'.gettext('Monitoring Mode').':</label><br class="nobr" />
							</td>
							<td>	
								<br class="nobr" />
								'.gettext('Would you like to monitor the VMware host (server) or a guest VM?').'<br />
								<input type="radio" name="type" value="host" '.($type ==="host" ? ' checked="yes"' : '').'>'.gettext('Monitor the VMware host').'<br>
								<input type="radio" name="type" value="guest" '.($type === "guest" ? ' checked="yes"' : '').'>'.gettext('Monitor a guest VM on the VMWare host').'
							</td>
						</tr>
					
					</table>';

			}
			break;

		case CONFIGWIZARD_MODE_VALIDATESTAGE1DATA:

			list($hostname, $address, $type, $username, $password, $services, $serviceargs, $guests) = vmware_configwizard_parseinargs($inargs);

			// check for errors
			$errors=0;
			$errmsg=array();
			if(vmware_configwizard_check_prereqs()==false)
				$errmsg[$errors++]=gettext('Required software components are missing.');
			else
			{
				if(have_value($address)==false)
					$errmsg[$errors++]=gettext('No address specified.');
				if(have_value($username)==false)
					$errmsg[$errors++]=gettext('Username not specified.');
				if(have_value($password)==false)
					$errmsg[$errors++]=gettext('Password not specified.');
			}

			if($errors>0)
			{
				$outargs[CONFIGWIZARD_ERROR_MESSAGES]=$errmsg;
				$result=1;
			}

			break;

		case CONFIGWIZARD_MODE_GETSTAGE2HTML:

			list($hostname, $address, $type, $username, $password, $services, $serviceargs, $guests) = vmware_configwizard_parseinargs($inargs);

			$output='

				<input type="hidden" name="address" value="'.htmlentities($address).'">
				<input type="hidden" name="type" value="'.htmlentities($type).'">
				<input type="hidden" name="username" value="'.htmlentities($username).'">
				<input type="hidden" name="password" value="'.htmlentities($password).'">

				<div class="sectionTitle">'.gettext('VMware Details').'</div>
					<table>
						<tr>
							<td>
								<label>'.gettext('VMware Mode').':</label><br class="nobr" />
							</td>
							<td>'.htmlentities($type).'<br class="nobr" />
							</td>
						</tr>
						
						<tr>
							<td>
								<label>'.gettext('Address').':</label><br class="nobr" />
							</td>
							<td>
								<input type="text" size="20" name="address" id="address" value="'.htmlentities($address).'" class="textfield" disabled/><br class="nobr" />
							</td>
						</tr>
						
						<tr>
							<td>
								<label>'.gettext('Host Name').':</label><br class="nobr" />
							</td>
							<td>
								<input type="text" size="20" name="hostname" id="hostname" value="'.htmlentities($hostname).'" class="textfield" /><br class="nobr" />
								'.gettext('The name you\'d like to have associated with this host.').'
							</td>
						</tr>
						
					</table>';

			switch($type) 
			{
				case 'guest':

					$output.='	<script type="text/javascript">
								$(function() 
								{
									$("#vmware_settings").tabs();
								});
								</script>

								<div id="vmware_settings">
									<ul>
										<li><a href="#vmware_settings-1">'.gettext('Monitored Metrics').'</a></li>
										<li><a href="#vmware_settings-2">'.gettext('Guest Selection').'</a></li>
									</ul>
									<div id="vmware_settings-1">
										<div class="sectionTitle">'.gettext('VMware Monitored Metrics').'</div>
										<p>'.gettext('Select the metrics you\'d like to monitor on each of the guests you select.').'</p>';
				foreach (unserialize(VMWARE_SERVICENAMES) as $s) 
				{
					if ($s[1])
						vmware_configwizard_pushcheckboxandargs($output,$s,$services,$serviceargs,$mode);
				}; 
				$output.='	</div>
							<div id="vmware_settings-2">';
				$data=array();
				exec(get_root_dir().'/html/includes/configwizards/vmware/scripts/getguests.pl -H '.$address.' -u '.$username.' -p '.escapeshellarg($password), $data);
				if ( strstr(implode("\n",$data),"\x00")===FALSE ) 
				{
					$output.='			<div class="sectionTitle">'.gettext('Error').'</div>
										<p>'.gettext('It appears as though the VMware SDK has not yet been installed on your Nagios XI server.  You must install the SDK before you are able to use this wizard.').'</p><pre>'.implode('<br>',$data).'</pre>
									</div>
								</div>';
					return $output;
				}
				
				$output.='	<div class="sectionTitle">'.gettext('VMware Guest Selection').'</div>
							<p>'.gettext('Specify which guests you\'d like to monitor on the VMware host (server).').'</p>
							<table>
							<table class="standardtable" >
								<thead>
									<tr>
										<td> </td>
										<td>'.gettext('VM Name').'</td>
										<td>'.gettext('IP Address').'</td>
										<td>'.gettext('Current Status').'</td>
									</tr>
								</thead>
								<tbody>';
					$rownumber = 2; //Used for determing row color 
					$rowstyles = 'vertical-align:middle;horizontal-align:middle;';
					foreach ($data as &$element) 
					{
						($rownumber++ % 2) ? $tclass = 'odd' : $tclass = 'even';
						$element = explode("\x00",$element);
						$nam=base64_encode($element[0]);
						$idnt=$element[0];
						$nametextfield=sprintf('<input type="text" size="35" name="alias_%s" id="alias_%s" value="%s" class="textfield" /><br class="nobr" />',htmlentities($nam),htmlentities($nam),htmlentities(array_key_exists($idnt,$guests) ? $guests[$idnt] : $idnt));
						
						/* Now we will draw the tables.
							$element[0] is the VM Name (Text Field) set to $nametextfield for readability.
							$element[2] is the IP Address and is used to set $ipaddress variable.
							$element[3] is the VM status and is used to set $powerstatus variable.*/
						// Setting nice looking powerestatus variable.
						( $element[3] == 'poweredOff' ) ? $powerstatus = '<font color="gray">'.gettext('Powered Off').'</font>' : $powerstatus = '<font color="Green"><b>'.gettext('Powered On').'<b></font>'; 
						// Setting nice looking ipaddress variable.
						( $element[2] == '' ) ? $ipaddress = '<font color="gray">'.gettext('None Defined').'</font>' : $ipaddress = '<b>'.$element[2].'</b>';
						if (count($guests) === 0) 
						{
							//print_r($element);
							$output.='	<tr class="'.$tclass.'">
											<td style="'.$rowstyles.'">
												<input type="checkbox" name="activate_'.htmlentities($nam).'"'.($element[3] === 'poweredOn' ? ' checked="yes"' : '').' />';
						} 
						else 
						{
							$output.='	<tr>
											<td style="'.$rowstyles.'">
												<input type="checkbox" name="activate_'.htmlentities($nam).'"'.(array_key_exists($idnt,$guests) ? ' checked="yes"' : '').' />';
						}
						
						$output.='		</td>
										<td style="'.$rowstyles.'">'.$nametextfield.'</td>
										<td style="'.$rowstyles.'">'.$ipaddress.'</td>
										<td style="'.$rowstyles.'">'.$powerstatus.'</td>
									</tr>';						
					}
					
					unset($element, $tmp, $data);

					$output.='		</tbody>
									</table>
									</div>
								</div>';
					break;
				
				case "host":

					$output.='	<div class="sectionTitle">'.gettext('VMware Host Metrics').'</div>
								<p>'.gettext('Specify which metrics you\'d like to monitor on the VMware host (server).').'</p>';
					foreach (unserialize(VMWARE_SERVICENAMES) as $s) 
					{
						vmware_configwizard_pushcheckboxandargs($output,$s,$services,$serviceargs,$mode);
					}
					break;
				default:
					break;
			}

			break;

		case CONFIGWIZARD_MODE_VALIDATESTAGE2DATA:

			list($hostname, $address, $type, $username,$password, $services, $serviceargs,$guests) = vmware_configwizard_parseinargs($inargs);

			// check for errors
			$errors=0;
			$errmsg=array();
			if(is_valid_host_name($hostname)===false)
				$errmsg[$errors++]=gettext('Invalid host name.');

			foreach ( $services as $s )
				if(is_valid_service_name($s)===false)
					$errmsg[$errors++]=sprintf(gettext('Invalid service name')." %s",$s);

			if($errors>0)
			{
				$outargs[CONFIGWIZARD_ERROR_MESSAGES] = $errmsg;
				$result=1;
			}

			break;


		case CONFIGWIZARD_MODE_GETSTAGE3HTML:

			list($hostname, $address, $type, $username,$password, $services, $serviceargs,$guests) =vmware_configwizard_parseinargs($inargs);

			$output='	<input type="hidden" name="address" value="'.htmlentities($address).'">
						<input type="hidden" name="hostname" value="'.htmlentities($hostname).'">
						<input type="hidden" name="type" value="'.htmlentities($type).'">
						<input type="hidden" name="username" value="'.htmlentities($username).'">
						<input type="hidden" name="password" value="'.htmlentities($password).'">
						<input type="hidden" name="services_serial" value="'.htmlentities(base64_encode(serialize($services))).'">
						<input type="hidden" name="serviceargs_serial" value="'.htmlentities(base64_encode(serialize(
						$serviceargs))).'">
						<input type="hidden" name="guests_serial" value="'.htmlentities(base64_encode(serialize($guests))).'">';
			break;

		case CONFIGWIZARD_MODE_VALIDATESTAGE3DATA:

			break;

		case CONFIGWIZARD_MODE_GETFINALSTAGEHTML:

			break;

		case CONFIGWIZARD_MODE_GETOBJECTS:

			list($hostname, $address, $type, $username,$password, $services, $serviceargs,$guests) = vmware_configwizard_parseinargs($inargs);

			// save data for later use in re-entrance
			$meta_arr=array();
			$meta_arr['hostname']=$hostname;
			$meta_arr['address']=$address;
			$meta_arr['username']=$username;
			$meta_arr['password']=$password;
			$meta_arr['type']=$type;
			$meta_arr['services']=$services;
			$meta_arr['serviceargs']=$serviceargs;
			$meta_arr['guests']=$guests;
			save_configwizard_object_meta('vmware',$hostname,'',$meta_arr);

			$objs=array();

			// write auth data file
			$fil=get_root_dir().'/etc/components/vmware';
			if(!file_exists($fil))
				mkdir($fil, 0770);
			$fil.='/'.preg_replace('/[ .\:_-]/','_',$hostname).'_auth.txt';

			$fh=fopen($fil,'w+');
			if($fh)
			{
				fputs($fh,'username='.$username."\npassword=".$password.''); 
				fclose($fh);
			}

			vmware_configwizard_makeservices($objs, $hostname,$address, $type, $services,$serviceargs, $guests);

			// return the object definitions to the wizard
			$outargs[CONFIGWIZARD_NAGIOS_OBJECTS]=$objs;

			break;

		default:
		
			break;
	}

	return $output;
}


?>

