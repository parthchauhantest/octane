<?php
// WINDOWS SNMP CONFIG WIZARD
//
// Copyright (c) 2011 Nagios Enterprises, LLC.  All rights reserved.
//  
// $Id: windowssnmp.inc.php 1106 2013-07-23 17:52:23Z nscott $

include_once(dirname(__FILE__).'/../configwizardhelper.inc.php');

// run the initialization function
windowssnmp_configwizard_init();

function windowssnmp_configwizard_init(){
	
	$name="windowssnmp";
	
	$args=array(
		CONFIGWIZARD_NAME => $name,
        CONFIGWIZARD_VERSION => "1.4",
		CONFIGWIZARD_TYPE => CONFIGWIZARD_TYPE_MONITORING,
		CONFIGWIZARD_DESCRIPTION => gettext("Monitor a Microsoft&reg; Windows workstation or server using SNMP."),
		CONFIGWIZARD_DISPLAYTITLE => gettext("Windows SNMP"),
		CONFIGWIZARD_FUNCTION => "windowssnmp_configwizard_func",
		CONFIGWIZARD_PREVIEWIMAGE => "win_server.png",
		);
		
	register_configwizard($name,$args);
	}



function windowssnmp_configwizard_func($mode="",$inargs=null,&$outargs,&$result){


	$wizard_name="windowssnmp";
	

	// initialize return code and output
	$result=0;
	$output="";
	
	// initialize output args - pass back the same data we got
	$outargs[CONFIGWIZARD_PASSBACK_DATA]=$inargs;


	switch($mode){
		case CONFIGWIZARD_MODE_GETSTAGE1HTML:
		
			$address=grab_array_var($inargs,"address","");
			$osversion=grab_array_var($inargs,"osversion","");
			$snmpcommunity=grab_array_var($inargs,"snmpcommunity","public");
			$snmpversion=grab_array_var($inargs,"snmpversion","2c");

			$snmpopts="";
			$snmpopts_serial=grab_array_var($inargs,"snmpopts_serial","");
			if($snmpopts_serial!="")
				$snmpopts=unserialize(base64_decode($snmpopts_serial));
			if(!is_array($snmpopts)){
				$snmpopts_default=array(
					"v3_security_level" => "",
					"v3_username" => "",
					"v3_auth_password" => "",
					"v3_privacy_password" => "",
					"v3_auth_proto" => "",
					);
				$snmpopts=grab_array_var($inargs,"snmpopts",$snmpopts_default);
				}
			
			
			$output='

	<div class="sectionTitle">'.gettext('Windows Machine Information').'</div>
	
			
	<table>
	<tr>
	<td valign="top">
	<label>IP Address:</label><br class="nobr" />
	</td>
	<td>
<input type="text" size="40" name="address" id="address" value="'.htmlentities($address).'" class="textfield" /><br class="nobr" />
	'.gettext('The IP address of the Windows machine you\'d like to monitor.').'<br class="nobr" />
	</td>
	</tr>

	<tr>
	<td valign="top">
	<label>'.gettext('Operating System:').'</label><br class="nobr" />
	</td>
	<td>
	<select name="osversion">
	<option value="winxp" '.is_selected($osversion,"winxp").'>'.gettext('Windows XP').'</option>
	<option value="winvista" '.is_selected($osversion,"winvista").'>'.gettext('Windows Vista').'</option>
	<option value="win7" '.is_selected($osversion,"win7").'>'.gettext('Windows 7').'</option>
	<option value="win2k" '.is_selected($osversion,"win2k").'>'.gettext('Windows 2000').'</option>
	<option value="win2k3" '.is_selected($osversion,"win2k3").'>'.gettext('Windows 2003').'</option>
	<option value="win2k8" '.is_selected($osversion,"win2k8").'>'.gettext('Windows 2008').'</option>
	<option value="other" '.is_selected($osversion,"other").'>'.gettext('Other').'</option>
	</select>
	</td>
	</tr>

	</table>

	<div class="sectionTitle">'.gettext('SNMP Settings').'</div>
	
	<p>'.gettext('Specify the settings used to monitor the Windows machine via SNMP.').'</p>
	
	<table>

	<tr>
	<td valign="top">
	<label>'.gettext('SNMP Community:').'</label><br class="nobr" />
	</td>
	<td>
<input type="text" size="20" name="snmpcommunity" id="snmpcommunity" value="'.htmlentities($snmpcommunity).'" class="textfield" /><br class="nobr" />
	'.gettext('The SNMP community string required used to to query the Windows machine.').'
	</td>
	</tr>

	<tr>
	<td valign="top">
	<label>'.gettext('SNMP Version:').'</label><br class="nobr" />
	</td>
	<td>
	<select name="snmpversion" id="snmpversion">
	<!--<option value="1" '.is_selected($snmpversion,"1").'>1</option>-->
	<option value="2c" '.is_selected($snmpversion,"2c").'>2c</option>
	<option value="3" '.is_selected($snmpversion,"3").'>3</option>
	</select>
	<br class="nobr" />
	'.gettext('The SNMP protocol version used to commicate with the machine.').'
	</td>
	</tr>

	</table>

	<div class="sectionTitle">'.gettext('SNMP Authentication').'</div>
	
	<p>'.gettext('When using SNMP v3 you must specify authentication information.').'</p>
	
	<table>

	<tr>
	<td valign="top">
	<label>'.gettext('Security Level:').'</label><br class="nobr" />
	</td>
	<td>
	<select name="snmpopts[v3_security_level]">
	<option value="noAuthNoPriv" '.is_selected($snmpopts["v3_security_level"],"noAuthNoPriv").'>noAuthNoPriv</option>
	<option value="authNoPriv" '.is_selected($snmpopts["v3_security_level"],"authNoPriv").'>authNoPriv</option>
	<option value="authPriv" '.is_selected($snmpopts["v3_security_level"],"authPriv").'>authPriv</option>
	</select>
	<br class="nobr" />
	</td>
	</tr>

	<tr>
	<td valign="top">
	<label>'.gettext('Username:').'</label><br class="nobr" />
	</td>
	<td>
<input type="text" size="20" name="snmpopts[v3_username]" value="'.htmlentities($snmpopts["v3_username"]).'" class="textfield" /><br class="nobr" />
	</td>
	</tr>

	<tr>
	<td valign="top">
	<label>'.gettext('Authentication Password').':</label><br class="nobr" />
	</td>
	<td>
<input type="texs" size="20" name="snmpopts[v3_auth_password]" value="'.htmlentities($snmpopts["v3_auth_password"]).'" class="textfield" /><br class="nobr" />
	</td>
	</tr>

	<tr>
	<td valign="top">
	<label>'.gettext('Privileged Password:').'</label><br class="nobr" />
	</td>
	<td>
<input type="text" size="20" name="snmpopts[v3_privacy_password]" value="'.htmlentities($snmpopts["v3_privacy_password"]).'" class="textfield" /><br class="nobr" />
	</td>
	</tr>

	<tr>
	<td valign="top">
	<label>'.gettext('Authentication Protocol:').'</label><br class="nobr" />
	</td>
	<td>
	<select name="snmpopts[v3_auth_proto]">
	<option value="MD5" '.is_selected($snmpopts["v3_auth_proto"],"MD5").'>MD5</option>
	<option value="SHA" '.is_selected($snmpopts["v3_auth_proto"],"SHA").'>SHA</option>
	</select>
	<br class="nobr" />
	</td>
	</tr>

	</table>	
	

	';
			break;
			
		case CONFIGWIZARD_MODE_VALIDATESTAGE1DATA:
		
			// get variables that were passed to us
			$address=grab_array_var($inargs,"address","");
			$osversion=grab_array_var($inargs,"osversion","");
			$snmpcommunity=grab_array_var($inargs,"snmpcommunity","");
			$snmpversion=grab_array_var($inargs,"snmpversion","");
			
			
			// check for errors
			$errors=0;
			$errmsg=array();
			//$errmsg[$errors++]="Address: '$address'";
			if(have_value($address)==false)
				$errmsg[$errors++]=gettext("No address specified.");
			else if(!valid_ip($address))
				$errmsg[$errors++]=gettext("Invalid IP address.");
			if(have_value($osversion)==false)
				$errmsg[$errors++]=gettext("No operating system specified.");
			if(have_value($snmpcommunity)==false && $snmpversion != "3")
				$errmsg[$errors++]=gettext("No SNMP community specified.");
				
			if($errors>0){
				$outargs[CONFIGWIZARD_ERROR_MESSAGES]=$errmsg;
				$result=1;
				}
				
			break;
			
		case CONFIGWIZARD_MODE_GETSTAGE2HTML:
		
			// get variables that were passed to us
			$address=grab_array_var($inargs,"address");
			$hostname=grab_array_var($inargs,"hostname",gethostbyaddr($address));
			$osversion=grab_array_var($inargs,"osversion","");
			$snmpcommunity=grab_array_var($inargs,"snmpcommunity","");
			$snmpversion=grab_array_var($inargs,"snmpversion","");
			
			$snmpopts_serial=grab_array_var($inargs,"snmpopts_serial","");
			if($snmpopts_serial=="")
				$snmpopts=grab_array_var($inargs,"snmpopts");
			else
				$snmpopts=unserialize(base64_decode($snmpopts_serial));
			
			$services="";
			$services_serial=grab_array_var($inargs,"services_serial","");
			if($services_serial!="")
				$services=unserialize(base64_decode($services_serial));
			if(!is_array($services)){
				$services_default=array(
					"ping" => 1,
					"cpu" => 1,
					"memory" => 1,
					"pagefile" => 1,
					"disk" => 1,
					);
				$services=grab_array_var($inargs,"services",$services_default);
				}
			
			$serviceargs="";
			$serviceargs_serial=grab_array_var($inargs,"serviceargs_serial","");
			if($serviceargs_serial!="")
				$serviceargs=unserialize(base64_decode($serviceargs_serial));
			if(!is_array($serviceargs)){
				$serviceargs_default=array(
					"cpu_warning" => 80,
					"cpu_critical" => 90,
					"memory_warning" => 80,
					"memory_critical" => 90,
					"pagefile_warning" => 80,
					"pagefile_critical" => 90,
					);
				for($x=0;$x<5;$x++){
					$serviceargs_default["disk_warning"][$x]=80;
					$serviceargs_default["disk_critical"][$x]=95;
					$serviceargs_default["disk"][$x]=($x==0)?"C":"";
					}
				for($x=0;$x<4;$x++){
					if($x==0){
						$serviceargs_default['processstate'][$x]['process']='explorer.exe';
						$serviceargs_default['processstate'][$x]['name']='Explorer';
                        $services["processstate"][$x]=""; // defaults for checkboxes, enter on to be checked by default
						}
					else{
						$serviceargs_default['processstate'][$x]['process']='';
						$serviceargs_default['processstate'][$x]['name']='';
                        $services["processstate"][$x]=""; // defaults for checkboxes, enter on to be checked by default
						}
					}

				for($x=0;$x<4;$x++){
					if($x==0){
						$serviceargs_default['servicestate'][$x]['service']="World Wide Web Publishing";
						$serviceargs_default['servicestate'][$x]['name']="IIS Web Server";
                        $services["servicestate"][$x]=""; // defaults for checkboxes, enter on to be checked by default
						}
					elseif($x==1){
						$serviceargs_default['servicestate'][$x]['service']="Task Scheduler";
						$serviceargs_default['servicestate'][$x]['name']="Task Scheduler";
                        $services["servicestate"][$x]=""; // defaults for checkboxes, enter on to be checked by default
						}
					elseif($x==2){
						$serviceargs_default['servicestate'][$x]['service']="Terminal Services";
						$serviceargs_default['servicestate'][$x]['name']="Terminal Services";
                        $services["servicestate"][$x]=""; // defaults for checkboxes, enter on to be checked by default
						}
                    else{
						$serviceargs_default['servicestate'][$x]['service']="";
						$serviceargs_default['servicestate'][$x]['name']="";
                        $services["servicestate"][$x]=""; // defaults for checkboxes, enter on to be checked by default
						}
					}
					

				$serviceargs=grab_array_var($inargs,"serviceargs",$serviceargs_default);
				}

			

			$output='
			
			
		<input type="hidden" name="address" value="'.htmlentities($address).'">
		<input type="hidden" name="osversion" value="'.htmlentities($osversion).'">
		<input type="hidden" name="snmpcommunity" value="'.htmlentities($snmpcommunity).'">
		<input type="hidden" name="snmpversion" value="'.htmlentities($snmpversion).'">
		<input type="hidden" name="snmpopts_serial" value="'.base64_encode(serialize($snmpopts)).'">

	<div class="sectionTitle">'.gettext('Windows Machine Details').'</div>
	
	<table>

	<tr>
	<td>
	<label>'.gettext('IP Address:').'</label><br class="nobr" />
	</td>
	<td>
<input type="text" size="40" name="address" id="address" value="'.htmlentities($address).'" class="textfield" disabled/><br class="nobr" />
	</td>
	</tr>

	<tr>
	<td>
	<label>'.gettext('Host Name:').'</label><br class="nobr" />
	</td>
	<td>
<input type="text" size="20" name="hostname" id="hostname" value="'.htmlentities($hostname).'" class="textfield" /><br class="nobr" />
	'.gettext('The name you\'d like to have associated with this Windows machine.').'
	</td>
	</tr>

	</table>


	<div class="sectionTitle">'.gettext('Server Metrics').'</div>
	
	<p>'.gettext('Specify which services you\'d like to monitor for the Windows machine.').'</p>
	
	<table>

	<tr>
	<td valign="top">
	<input type="checkbox" class="checkbox" name="services[ping]" '.is_checked($services["ping"],"1").'>
	</td>
	<td>
	<b>Ping</b><br>
	'.gettext('Monitors the machine with an ICMP "ping".  Useful for watching network latency and general uptime.').'<br><br>
	</td>
	</tr>

	<tr>
	<td valign="top">
	<input type="checkbox" class="checkbox" name="services[cpu]" '.is_checked($services["cpu"],"1").'>
	</td>
	<td>
	<b>CPU</b><br>
	'.gettext('Monitors the CPU (processor usage) on the machine.').'<br>
	<label>'.gettext('Warning Load:').'</label> <input type="text" size="2" name="serviceargs[cpu_warning]" value="'.htmlentities($serviceargs["cpu_warning"]).'" class="textfield" />%
	<label>'.gettext('Critical Load:').'</label> <input type="text" size="2" name="serviceargs[cpu_critical]" value="'.htmlentities($serviceargs["cpu_critical"]).'" class="textfield" />%<br><br>
	</td>
	</tr>

	<tr>
	<td valign="top">
	<input type="checkbox" class="checkbox" name="services[memory]" '.is_checked($services["memory"],"1").'>
	</td>
	<td>
	<b>'.gettext('Physical Memory Usage').'</b><br>
	'.gettext('Monitors the physical (real) memory usage on the machine.').'<br>
	<label>'.gettext('Warning Usage:').'</label> <input type="text" size="2" name="serviceargs[memory_warning]" value="'.htmlentities($serviceargs["memory_warning"]).'" class="textfield" />%
	<label>'.gettext('Critical Usage:').'</label> <input type="text" size="2" name="serviceargs[memory_critical]" value="'.htmlentities($serviceargs["memory_critical"]).'" class="textfield" />%<br><br>
	</td>
	</tr>

	<tr>
	<td valign="top">
	<input type="checkbox" class="checkbox" name="services[pagefile]" '.is_checked($services["pagefile"],"1").'>
	</td>
	<td>
	<b>'.gettext('Virtual Memory Usage').'</b><br>
	'.gettext('Monitors the virtual memory usage on the machine.').'<br>
	<label>'.gettext('Warning Usage:').'</label> <input type="text" size="2" name="serviceargs[pagefile_warning]" value="'.htmlentities($serviceargs["pagefile_warning"]).'" class="textfield" />%
	<label>'.gettext('Critical Usage:').'</label> <input type="text" size="2" name="serviceargs[pagefile_critical]" value="'.htmlentities($serviceargs["pagefile_critical"]).'" class="textfield" />%<br><br>
	</td>
	</tr>

	<tr>
	<td valign="top">
	<input type="checkbox" class="checkbox" name="services[disk]" '.is_checked($services["disk"],"1").'>
	</td>
	<td>
	<b>Disk Usage</b><br>
	'.gettext('Monitors disk usage on the machine.').'<br>
	<table class="adddeleterow">
	';
	for($x=0;$x<count($serviceargs["disk"]);$x++){
		$checkedstr="";
		if($x==0)
			$checkedstr="checked";
		$output.='<tr>';
		//$output.='<td><input type="checkbox" class="checkbox" name="services[disk]['.$x.']" '.$checkedstr.'></td>';
		$output.='<td><label>Drive:</label> <select name="serviceargs[disk]['.$x.']">';
		$output.='<option value=""></option>';
		for($y=0;$y<26;$y++){
			$selected="";
			//if($x==0 && $y==2)
			//				$selected="selected";
			$diskname=chr(ord('A')+$y);
			$selected=is_selected($serviceargs["disk"][$x],$diskname);
			$output.='<option value="'.$diskname.'" '.$selected.'>'.$diskname.':</option>';
			}
		$output.='</select></td>';
		$output.='<td><label>'.gettext('Warning Usage:').'</label> <input type="text" size="2" name="serviceargs[disk_warning]['.$x.']" value="'.htmlentities($serviceargs["disk_warning"][$x]).'" class="textfield" />%
	<label>'.gettext('Critical Usage:').'</label> <input type="text" size="2" name="serviceargs[disk_critical]['.$x.']" value="'.htmlentities($serviceargs["disk_critical"][$x]).'" class="textfield" />%</td>';
		$output.='</tr>';
		}
	$output.='
	</table>
	</td>
	</tr>

	</table>

	<div class="sectionTitle">'.gettext('Services').'</div>
	
	<p>'.gettext('Specify any services that should be monitored to ensure they\'re in a running state.').'<br><strong>Note:</strong> '.gettext('The Windows Service name must match the full name of the service you want to monitor.').'</p>
	
	<table class="adddeleterow">
	
	<tr><th></th><th>'.gettext('Windows Service').'</th><th>'.gettext('Display Name').'</th></tr>
	';
	for($x=0;$x<count($serviceargs['servicestate']);$x++){

		$servicestring=$serviceargs['servicestate'][$x]['service'];
		$servicename=$serviceargs['servicestate'][$x]['name'];
			
		$output.='<tr><td><input type="checkbox" class="checkbox" name="services[servicestate]['.$x.']"  '.is_checked($services["servicestate"][$x]).'></td><td><input type="text" size="35" name="serviceargs[servicestate]['.$x.'][service]" value="'.htmlentities($servicestring).'" class="textfield" /></td><td><input type="text" size="20" name="serviceargs[servicestate]['.$x.'][name]" value="'.htmlentities($servicename).'" class="textfield" /></td></tr>';
		}
	$output.='
	</table>

	<div class="sectionTitle">'.gettext('Processes').'</div>
	
	<p>'.gettext('Specify any processes that should be monitored to ensure they\'re running.').'<br><strong>Note:</strong> '.gettext('Process names are case-sensitive.').'</p>
	
	<table class="adddeleterow">
	
	<tr><th></th><th>'.gettext('Windows Process').'</th><th>'.gettext('Display Name').'</th></tr>
	';
	for($x=0;$x<count($serviceargs['processstate']);$x++){

		$processstring=$serviceargs['processstate'][$x]['process'];
		$processname=$serviceargs['processstate'][$x]['name'];

		$output.='<tr><td><input type="checkbox" class="checkbox" name="services[processstate]['.$x.']"  '.is_checked($services["processstate"][$x]).'></td><td><input type="text" size="15" name="serviceargs[processstate]['.$x.'][process]" value="'.htmlentities($processstring).'" class="textfield" /></td><td><input type="text" size="20" name="serviceargs[processstate]['.$x.'][name]" value="'.htmlentities($processname).'" class="textfield" /></td></tr>';
		}
	$output.='
	</table>


			';
			break;
			
		case CONFIGWIZARD_MODE_VALIDATESTAGE2DATA:
		
			// get variables that were passed to us
			$address=grab_array_var($inargs,"address");
			$hostname=grab_array_var($inargs,"hostname");
			$osversion=grab_array_var($inargs,"osversion","");
			$snmpcommunity=grab_array_var($inargs,"snmpcommunity","");
			$snmpversion=grab_array_var($inargs,"snmpversion","");
			
			// check for errors
			$errors=0;
			$errmsg=array();
			if(is_valid_host_name($hostname)==false)
				$errmsg[$errors++]="Invalid host name.";
				
			if($errors>0){
				$outargs[CONFIGWIZARD_ERROR_MESSAGES]=$errmsg;
				$result=1;
				}
				
			break;

			
		case CONFIGWIZARD_MODE_GETSTAGE3HTML:
		
			// get variables that were passed to us
			$address=grab_array_var($inargs,"address");
			$hostname=grab_array_var($inargs,"hostname");
			$osversion=grab_array_var($inargs,"osversion","");
			$snmpcommunity=grab_array_var($inargs,"snmpcommunity","");
			$snmpversion=grab_array_var($inargs,"snmpversion","");
			$services=grab_array_var($inargs,"services");
			$serviceargs=grab_array_var($inargs,"serviceargs");

			$snmpopts_serial=grab_array_var($inargs,"snmpopts_serial","");
			if($snmpopts_serial=="")
				$snmpopts=grab_array_var($inargs,"snmpopts");
			else
				$snmpopts=unserialize(base64_decode($snmpopts_serial));
				
			$services_serial=grab_array_var($inargs,"services_serial","");
			if($services_serial=="")
				$services=grab_array_var($inargs,"services");
			else
				$services=unserialize(base64_decode($services_serial));
				
			$serviceargs_serial=grab_array_var($inargs,"serviceargs_serial","");
			if($serviceargs_serial=="")
				$serviceargs=grab_array_var($inargs,"serviceargs");
			else
				$serviceargs=unserialize(base64_decode($serviceargs_serial));
				

			
			$output='
			
		<input type="hidden" name="address" value="'.htmlentities($address).'">
		<input type="hidden" name="hostname" value="'.htmlentities($hostname).'">
		<input type="hidden" name="osversion" value="'.htmlentities($osversion).'">
		<input type="hidden" name="snmpcommunity" value="'.htmlentities($snmpcommunity).'">
		<input type="hidden" name="snmpversion" value="'.htmlentities($snmpversion).'">
		<input type="hidden" name="snmpopts_serial" value="'.base64_encode(serialize($snmpopts)).'">
		<input type="hidden" name="services_serial" value="'.base64_encode(serialize($services)).'">
		<input type="hidden" name="serviceargs_serial" value="'.base64_encode(serialize($serviceargs)).'">
		
		<!--SERVICES='.serialize($services).'<BR>
		SERVICEARGS='.serialize($serviceargs).'<BR>-->
		
			';
			break;
			
		case CONFIGWIZARD_MODE_VALIDATESTAGE3DATA:
				
			break;
			
		case CONFIGWIZARD_MODE_GETFINALSTAGEHTML:
			
			break;
			
		case CONFIGWIZARD_MODE_GETOBJECTS:
		
			$hostname=grab_array_var($inargs,"hostname","");
			$address=grab_array_var($inargs,"address","");
			$osversion=grab_array_var($inargs,"osversion","");
			$snmpcommunity=grab_array_var($inargs,"snmpcommunity","");
			$snmpversion=grab_array_var($inargs,"snmpversion","");
			$hostaddress=$address;
			
			$snmpopts_serial=grab_array_var($inargs,"snmpopts_serial","");
			$snmpopts=unserialize(base64_decode($snmpopts_serial));
			
			$services_serial=grab_array_var($inargs,"services_serial","");
			$serviceargs_serial=grab_array_var($inargs,"serviceargs_serial","");
			
			$services=unserialize(base64_decode($services_serial));
			$serviceargs=unserialize(base64_decode($serviceargs_serial));
			
			/*
			echo "SERVICES<BR>";
			print_r($services);
			echo "<BR>";
			echo "SERVICEARGS<BR>";
			print_r($serviceargs);
			echo "<BR>";
			*/
			
			// save data for later use in re-entrance
			$meta_arr=array();
			$meta_arr["hostname"]=$hostname;
			$meta_arr["address"]=$address;
			$meta_arr["osversion"]=$osversion;
			$meta_arr["snmpcommunity"]=$snmpcommunity;
			$meta_arr["snmpversion"]=$snmpversion;
			$meta_arr["services"]=$services;
			$meta_arr["serivceargs"]=$serviceargs;
			save_configwizard_object_meta($wizard_name,$hostname,"",$meta_arr);			
			
			$objs=array();
			
			if(!host_exists($hostname)){
				$objs[]=array(
					"type" => OBJECTTYPE_HOST,
					"use" => "xiwizard_windowssnmp_host",
					"host_name" => $hostname,
					"address" => $hostaddress,
					"icon_image" => "win_server.png",
					"statusmap_image" => "win_server.png",
					"_xiwizard" => $wizard_name,
					);
				}
				
			// determine SNMP args
			$snmpargs="";
			if($snmpcommunity!="" && $snmpversion != "3")
				$snmpargs.=" -C ".$snmpcommunity;
			if($snmpversion=="2c")
				$snmpargs.=" --v2c";
			// snmpv3 stuff
			else if($snmpversion=="3"){
							
				$securitylevel=grab_array_var($snmpopts,"v3_security_level");
				$username=grab_array_var($snmpopts,"v3_username");
				$authproto=grab_array_var($snmpopts,"v3_auth_proto");
				$authpassword=grab_array_var($snmpopts,"v3_auth_password");
				$privacypassword=grab_array_var($snmpopts,"v3_privacy_password");
				
				if($username!="")
					$snmpargs.=" --login=".$username;
				if($authpassword!="")
					$snmpargs.=" --passwd=".$authpassword;
				if($privacypassword!="")
					$snmpargs.=" --privpass=".$privacypassword;
				if($authproto!="")
                    $snmpargs.=" --authproto=".$authproto;
                }
				
			// see which services we should monitor
			foreach($services as $svc => $svcstate){
			
				//echo "PROCESSING: $svc -> $svcstate<BR>\n";
		
				switch($svc){
				
					case "ping":
						$objs[]=array(
							"type" => OBJECTTYPE_SERVICE,
							"host_name" => $hostname,
							"service_description" => "Ping",
							"use" => "xiwizard_windowsserver_ping_service",
							"_xiwizard" => $wizard_name,
							);
						break;
					
					case "cpu":
						$objs[]=array(
							"type" => OBJECTTYPE_SERVICE,
							"host_name" => $hostname,
							"service_description" => "CPU Usage",
							"use" => "xiwizard_windowssnmp_load",
							"check_command" => "check_xi_service_snmp_win_load!".$snmpargs." -w ".$serviceargs["cpu_warning"]." -c ".$serviceargs["cpu_critical"]." -f",
							"_xiwizard" => $wizard_name,
							);
						break;
					
					case "memory":
						$objs[]=array(
							"type" => OBJECTTYPE_SERVICE,
							"host_name" => $hostname,
							"service_description" => "Physical Memory Usage",
							"use" => "xiwizard_windowssnmp_storage",
							"check_command" => "check_xi_service_snmp_win_storage!".$snmpargs." -m 'Physical Memory' -w ".$serviceargs["memory_warning"]." -c ".$serviceargs["memory_critical"]." -f",
							"_xiwizard" => $wizard_name,
							);
						break;
					
					case "pagefile":
						$objs[]=array(
							"type" => OBJECTTYPE_SERVICE,
							"host_name" => $hostname,
							"service_description" => "Virtual Memory Usage",
							"use" => "xiwizard_windowssnmp_storage",
							"check_command" => "check_xi_service_snmp_win_storage!".$snmpargs." -m 'Virtual Memory' -w ".$serviceargs["pagefile_warning"]." -c ".$serviceargs["pagefile_critical"]." -f",
							"_xiwizard" => $wizard_name,
							);
						break;
					
					case "disk":
						$donedisks=array();
						$diskid=0;
						foreach($serviceargs["disk"] as $diskname){
						
							if($diskname=="")
								continue;
						
							//echo "HANDLING DISK: $diskname<BR>";
							
							// we already configured this disk
							if(in_array($diskname,$donedisks))
								continue;
							$donedisks[]=$diskname;
							
							$objs[]=array(
								"type" => OBJECTTYPE_SERVICE,
								"host_name" => $hostname,
								"service_description" => "Drive ".$diskname.": Disk Usage",
								"use" => "xiwizard_windowssnmp_storage",
								"check_command" => "check_xi_service_snmp_win_storage!".$snmpargs." -m ^".$diskname.": -w ".$serviceargs["disk_warning"][$diskid]." -c ".$serviceargs["disk_critical"][$diskid]." -f",
								"_xiwizard" => $wizard_name,
								);		

							$diskid++;
							}
						break;
						
					case "servicestate":

						$enabledservices=$svcstate;			
						foreach($enabledservices as $sid => $sstate){
						
							$sname=$serviceargs["servicestate"][$sid]["service"];
							$sdesc=$serviceargs["servicestate"][$sid]["name"];
						
							$objs[]=array(
								"type" => OBJECTTYPE_SERVICE,
								"host_name" => $hostname,
								"service_description" => $sdesc,
								"use" => "xiwizard_windowssnmp_service",
								 "check_command" => "check_xi_service_snmp_win_service!".$snmpargs." -n '".$sname."'",
								"_xiwizard" => $wizard_name,
								);		
							}
						break;
					
					case "processstate":
						
						$enabledprocs=$svcstate;
						foreach($enabledprocs as $pid => $pstate){
						
							$pname=$serviceargs["processstate"][$pid]["process"];
							$pdesc=$serviceargs["processstate"][$pid]["name"];
						
							$objs[]=array(
								"type" => OBJECTTYPE_SERVICE,
								"host_name" => $hostname,
								"service_description" => $pdesc,
								"use" => "xiwizard_windowssnmp_process",
								"check_command" => "check_xi_service_snmp_win_process!".$snmpargs." -n '".$pname."'",
								"_xiwizard" => $wizard_name,
								);		
							}
						break;
												
						
				
					default:
						break;
					}
				}
				
			//echo "OBJECTS:<BR>";
			//print_r($objs);
			//exit();
					
			// return the object definitions to the wizard
			$outargs[CONFIGWIZARD_NAGIOS_OBJECTS]=$objs;
		
			break;
			
		default:
			break;			
		}
		
	return $output;
	}
	

?>