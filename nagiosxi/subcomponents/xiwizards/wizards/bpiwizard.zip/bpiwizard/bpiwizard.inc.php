<?php
// BPI CONFIG WIZARD
//
// Copyright (c) 2008-2009 Nagios Enterprises, LLC.  All rights reserved.
//  
// $Id: bpi.inc.php 531 2010-08-16 21:35:38Z egalstad $

include_once(dirname(__FILE__).'/../configwizardhelper.inc.php');

// run the initialization function
bpiwizard_configwizard_init();

function bpiwizard_configwizard_init(){
	
	$name="bpiwizard";
	
	$args=array(
		CONFIGWIZARD_NAME => $name,
		CONFIGWIZARD_TYPE => CONFIGWIZARD_TYPE_MONITORING,
		CONFIGWIZARD_DESCRIPTION => gettext("Create service checks for your Nagios BPI groups."),
		CONFIGWIZARD_DISPLAYTITLE => "BPI Wizard",
		CONFIGWIZARD_FUNCTION => "bpiwizard_configwizard_func",
		CONFIGWIZARD_PREVIEWIMAGE => "bpiwizard.png",
		CONFIGWIZARD_VERSION => "1.1",
		CONFIGWIZARD_DATE => "2011-12-01",
		CONFIGWIZARD_COPYRIGHT => "Copyright &copy; 2008-2010 Nagios Enterprises, LLC.",
		CONFIGWIZARD_AUTHOR => "Mike Guthrie, Nagios Enterprises, LLC",
		);
		
	register_configwizard($name,$args);
	}


//error suppressing function for printing session variables -> used for repopulating the form when going "back" 
function bpiVal($value)
{
	if(!isset($_SESSION['bpiwizard'])) return; 
	//checkboxs
	if(isset($_SESSION['bpiwizard']['groups'][$value]) && $_SESSION['bpiwizard']['groups'][$value] !='') return 'checked="checked"'; 
}	
	
	
	

function bpiwizard_configwizard_func($mode="",$inargs=null,&$outargs,&$result){

	global $cfg; 
	$wizard_name="bpiwizard";

	//$_SESSION['bpiwizard'] = array(); 
	// initialize return code and output
	$result=0;
	$output="";
 
	// initialize output args - pass back the same data we got
	$outargs[CONFIGWIZARD_PASSBACK_DATA]=$inargs;


	switch($mode){
		case CONFIGWIZARD_MODE_GETSTAGE1HTML:
				//clear any previous wizard data
			if(!isset($_POST["backButton"]) ) 
			{
				unset($_SESSION['bpiwizard']); 
				$base = grab_array_var($cfg,'root_dir','/usr/local/nagiosxi'); 
				//if we're using the new version of BPI
				if(file_exists($base.'/html/includes/components/nagiosbpi/bpi_display.php')) {
					//echo "NEWVERSION<br />";
					define('CLI',false);
					$includefile = $cfg['root_dir'].'/html/includes/components/nagiosbpi/inc.inc.php';
					require($includefile);
					$groupsArray = parse_bpi_conf();
				}
				else {//old version of BPI
					//echo "OLD VERSION!<br />";
					define('CONFIGFILE','/usr/local/nagiosxi/html/includes/components/nagiosbpi/bpi.conf');
                    $configfile = '/usr/local/nagiosxi/html/includes/components/nagiosbpi/bpi.conf';
					$includefile = '/usr/local/nagiosxi/html/includes/components/nagiosbpi/functions/read_conf.php';
					require($includefile);
					$groupsArray = get_info($configfile);
				}
				
				//make sure we have the necessary include
				if(file_exists($includefile)){
					$_SESSION['bpiwizard']['data'] = $groupsArray;
				}
				else {
					$outargs[CONFIGWIZARD_ERROR_MESSAGES]=gettext('Nagios BPI is not installed as a component').'
					<a href="http://exchange.nagios.org/directory/Addons/Components/Nagios-Business-Process-Intelligence-%28BPI%29/details" title="Download BPI" target="_blank">'.gettext('Download Nagios BPI').'</a>';		
				}
			}
			//else echo "Back has been set<nr />"; 
			$hostname=isset($_SESSION['bpiwizard']['hostname']) ? $_SESSION['bpiwizard']['hostname'] : grab_array_var($inargs,"hostname","");; 
			
			$output='

	<div class="sectionTitle">'.gettext('Create A BPI Dummy Host').'</div>
	
	<table>
	<tr>
	<td valign="top">
	<label>'.gettext('BPI Host Name').':</label><br class="nobr" />
	</td>
	<td>
		<input type="text" size="40" name="hostname" id="hostname" value="'.htmlentities($hostname).'" class="textfield" /><br class="nobr" />
	'.gettext('The dummy host for your BPI services').'.
	</td>
	</tr>

	</table>
			';
			break;
			
		case CONFIGWIZARD_MODE_VALIDATESTAGE1DATA:
		
			// get variables that were passed to us
			$hostname=grab_array_var($inargs,"hostname","");
			
			if(!isset($_POST['backButton'])) //skip validation if back button pressed 
			{
				// check for errors
				$errors=0;
				$errmsg=array();
				//$errmsg[$errors++]="Address: '$address'";
				if(!isset($hostname) || $hostname == '')
					$errmsg[$errors++]="No name specified.";
				
				//check if BPI is installed
				if(!file_exists('/usr/local/nagiosxi/html/includes/components/nagiosbpi/') )
					$errmsg[$errors++]=gettext('Nagios BPI is not installed as a component').'.  
					<a href="http://exchange.nagios.org/directory/Addons/Components/Nagios-Business-Process-Intelligence/details" title="Download BPI" target="_blank">'.gettext('Download Nagios BPI').'</a>'; 
				
				if($errors>0){
					$outargs[CONFIGWIZARD_ERROR_MESSAGES]=$errmsg;
					$result=1;
					}
			}	
			break;
			
		case CONFIGWIZARD_MODE_GETSTAGE2HTML:
		
			// get variables that were passed to us
			$hostname=grab_array_var($inargs,"hostname");
			//save name 
			$_SESSION['bpiwizard']['hostname'] = $hostname; 
			$groupsArray = $_SESSION['bpiwizard']['data']; 
			//begin html form 
			
			//TODO - add jquery select/deselect all 
			$output .='
			<label for="prepend">'.gettext('Prepend for Service Descriptions (optional)').'</label><br />
			<input type="text" name="prepend" id="prepend" value="BPI Process:" /><br />
			<a href="javascript:void(0)" id="selectAll">'.gettext('Select/Deselect All').'</a><br />			
			<table id="bpiGroupsTable"><tr><th>'.gettext('Group ID').'</th><th>'.gettext('Display Name').'</th><th>'.gettext('Selected').'</th><tr>';

			foreach($groupsArray as $id =>$array)
			{
				//create checkboxes based on list of items 
				$output .="<tr><td>{$id}</td><td>{$array['title']}</td><td>".grab_array_var('desc',$array,'')."</td><td><input type='checkbox' name='groups[{$id}]' id='{$id}' ".@bpiVal($id)." /></td></tr>";  			
			}
			$output .= '
			</table>
<script type="text/javascript">
	$(document).ready(function() {
		$("tr:odd").css("background-color","#DEDEDE");
		$("#bpiGroupsTable").css("border", "1px solid #AAA")
							.css("text-align","center"); 
		
		var allChecked = false; 
		//bind click event to select/deselect all 
		$("#selectAll").click(function () {
			if(allChecked==false) {
				$("input:checkbox").each(function (){
					this.checked = "checked";
				});
				allChecked=true; 
			}
			else {
				$("input:checkbox").each(function () {
					this.checked = "";
				});
				allChecked = false; 
			}	
		}); //end 
	}); //end document ready handler 		
</script>
			'; 
							
			break;
			
		case CONFIGWIZARD_MODE_VALIDATESTAGE2DATA:
		
			if(!isset($_POST['backButton']))
			{
				//if nothing was checked, return an error message 
				$groups = grab_array_var($inargs,"groups", array());
				// check for errors
				
				$errors=0;
				$errmsg=array();
				if(count($groups) == 0 && count($_SESSION['bpiwizard']['groups'] ==0))
					$errmsg[$errors++]=gettext("You must select at least one group.");
					
				if($errors>0){
					$outargs[CONFIGWIZARD_ERROR_MESSAGES]=$errmsg;
					$result=1;
					}		
			}
			break;

			
		case CONFIGWIZARD_MODE_GETSTAGE3HTML:
		
			// get variables that were passed to us	
			$groups = grab_array_var($inargs,"groups", array());
			$prepend = grab_array_var($inargs,"prepend",""); 
			$_SESSION['bpiwizard']['prepend'] = $prepend; 
			//process and pass bpi groups to session data 			
			$_SESSION['bpiwizard']['groups'] = $groups; 
			//echo "Groups<br />";
			//print_r($groups); 
			//echo "Hostname: ".$_SESSION['bpiwizard']['hostname']; 
			//save array 
			 
						
			break;
			
		case CONFIGWIZARD_MODE_VALIDATESTAGE3DATA:
			break;
			
		case CONFIGWIZARD_MODE_GETFINALSTAGEHTML:
			break;
			
		case CONFIGWIZARD_MODE_GETOBJECTS:
			//dummy host name
			$hostname=$_SESSION['bpiwizard']['hostname'];
			//group ID's for all selected BPI groups 
			$groups = $_SESSION['bpiwizard']['groups'];
			//full data array for all BPI groups 
			$data = $_SESSION['bpiwizard']['data']; 
			$prepend = $_SESSION['bpiwizard']['prepend']; 
			//debugging
			//echo "Groups<br />"; 
			//print_r($groups);
			//echo "DATA<br />"; 
			//print_r($data); 
						
			$objs=array();
						
			//TODO add a host template for the dummy host 
			if(!host_exists($hostname)){
				$objs[]=array(
					"type" => OBJECTTYPE_HOST,
					"use" => "xiwizard_bpi_host",
					"host_name" => $hostname,
					"address" => '127.0.0.1',
					"_xiwizard" => $wizard_name,
					);
				}
				
			// see which services we should monitor
			foreach($groups as $group => $value){
				
				$objs[]=array(
					"type" => OBJECTTYPE_SERVICE,
					"host_name" => $hostname,
					"service_description" => $prepend.$data[$group]['title'],
					"use" => "xiwizard_bpi_service",
					"check_command" => "check_bpi!{$group}", 
					"_xiwizard" => $wizard_name,
					);
				}
				
			//echo "OBJECTS:<BR>";
			//print_r($objs);
					
			// return the object definitions to the wizard
			$outargs[CONFIGWIZARD_NAGIOS_OBJECTS]=$objs;
			unset($_SESSION['bpiwizard']);  
			break;
			
		default:
			break;			
		}
		
	return $output;
	}
	

?>