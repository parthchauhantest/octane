<?php
// MICROSOFT EXCHANGE CONFIG WIZARD
//
// Copyright (c) 2011 Nagios Enterprises, LLC.  All rights reserved.
//  
// $Id: exchange.inc.php 663 2011-06-22 23:20:48Z egalstad $

include_once(dirname(__FILE__).'/../configwizardhelper.inc.php');

// run the initialization function
exchange_configwizard_init();

function exchange_configwizard_init(){
	
	$name="exchange";
	
	$args=array(
		CONFIGWIZARD_NAME => $name,
        CONFIGWIZARD_VERSION => "1.1",
		CONFIGWIZARD_TYPE => CONFIGWIZARD_TYPE_MONITORING,
		CONFIGWIZARD_DESCRIPTION => "Monitor a Microsoft&reg; Exchange server.",
		CONFIGWIZARD_DISPLAYTITLE => "Exchange Server",
		CONFIGWIZARD_FUNCTION => "exchange_configwizard_func",
		CONFIGWIZARD_PREVIEWIMAGE => "exchange2010.png",
		);
		
	register_configwizard($name,$args);
	}



function exchange_configwizard_func($mode="",$inargs=null,&$outargs,&$result){

	$wizard_name="exchange";
	
	//$agent_url=get_base_url()."downloads/clients/windows/NSClient++.msi";
	$agent_url="http://www.nsclient.org/nscp/downloads";

	// initialize return code and output
	$result=0;
	$output="";
	
	// initialize output args - pass back the same data we got
	$outargs[CONFIGWIZARD_PASSBACK_DATA]=$inargs;


	switch($mode){
		case CONFIGWIZARD_MODE_GETSTAGE1HTML:
		
			$address=grab_array_var($inargs,"address","");
			$version=grab_array_var($inargs,"version","2010");
			
			$output='

	<div class="sectionTitle">Exchange Server Information</div>
	
			
	<table>
	
	<tr>
	<td valign="top">
	<label>IP Address:</label><br class="nobr" />
	</td>
	<td>
<input type="text" size="40" name="address" id="address" value="'.htmlentities($address).'" class="textfield" /><br class="nobr" />
	The IP address of the Exchange server you\'d like to monitor.<br><br>
	</td>
	</tr>

		
	<tr>
	<td>
	<label>Server Version:</label><br class="nobr" />
	</td>
	<td>
	<select name="version">
	<option value="5.5" '.is_selected($version,"5.5").'>Exchange 5.5</option>
	<option value="2000" '.is_selected($version,"2000").'>Exchange 2000</option>
	<option value="2003" '.is_selected($version,"2003").'>Exchange 2003</option>
	<option value="2007" '.is_selected($version,"2007").'>Exchange 2007</option>
	<option value="2010" '.is_selected($version,"2010").'>Exchange 2010</option>
	</select>
	</td>
	</tr>
	
	</table>
			';
			break;
			
		case CONFIGWIZARD_MODE_VALIDATESTAGE1DATA:
		
			// get variables that were passed to us
			$address=grab_array_var($inargs,"address","");
			$version=grab_array_var($inargs,"version","");
			
			
			// check for errors
			$errors=0;
			$errmsg=array();
			//$errmsg[$errors++]="Address: '$address'";
			if(have_value($address)==false)
				$errmsg[$errors++]="No address specified.";
			else if(!valid_ip($address))
				$errmsg[$errors++]="Invalid IP address.";
			if(have_value($version)==false)
				$errmsg[$errors++]="No server version specified.";
				
			if($errors>0){
				$outargs[CONFIGWIZARD_ERROR_MESSAGES]=$errmsg;
				$result=1;
				}
				
			break;
			
		case CONFIGWIZARD_MODE_GETSTAGE2HTML:
		
			// get variables that were passed to us
			$address=grab_array_var($inargs,"address");
			$version=grab_array_var($inargs,"version","");

			$hn=gethostbyaddr($address);
			if($hn=="")
				$hn=$address;
			$hostname=grab_array_var($inargs,"hostname",$hn);

			$password=grab_array_var($inargs,"password","");		
			$url=grab_array_var($inargs,"url","http://".$hostname."/exchange/");
			
			$services="";			
			$services_serial=grab_array_var($inargs,"services_serial","");
			if($services_serial!="")
				$services=unserialize(base64_decode($services_serial));
			if(!is_array($services)){
				$services_default=array(
					"ping" => 1,
					"smtp" => 1,
					"imap" => 1,
					"pop" => 1,
					"rbl" => 1,
					"owa_http"=>1,
					"owa_https"=>0,
					"core_services"=>1,
					"web_services"=>1,
					"pending_routing"=>1,
					"remote_queue_length"=>1,
					);
				$services=grab_array_var($inargs,"services",$services_default);
				}

			$serviceargs="";
			$serviceargs_serial=grab_array_var($inargs,"serviceargs_serial","");
			if($serviceargs_serial!="")
				$serviceargs=unserialize(base64_decode($serviceargs_serial));
			if(!is_array($serviceargs)){
				$serviceargs_default=array(
//					"memory_warning" => 80,
					"rbl_servers"=>"zen.spamhaus.org bl.spamcop.net dnsbl.ahbl.org dnsbl.njabl.org dnsbl.sorbs.net virbl.dnsbl.bit.nl rbl.efnet.org phishing.rbl.msrbl.net 0spam.fusionzero.com list.dsbl.org multihop.dsbl.org unconfirmed.dsbl.org will-spam-for-food.eu.org blacklist.spambag.org blackholes.brainerd.net blackholes.uceb.org spamsources.dnsbl.info map.spam-rbl.com ns1.unsubscore.com psbl.surriel.com l2.spews.dnsbl.sorbs.net bl.csma.biz sbl.csma.biz dynablock.njabl.org no-more-funn.moensted.dk  ubl.unsubscore.com dnsbl-1.uceprotect.net dnsbl-2.uceprotect.net dnsbl-3.uceprotect.net spamguard.leadmon.net opm.blitzed.org bl.spamcannibal.org rbl.schulte.org dnsbl.ahbl.org virbl.dnsbl.bit.nl combined.rbl.msrbl.net",
					"core_service_names"=>"",
					"web_service_names"=>"W3SVC",
					"pending_routing_warning"=>25,
					"pending_routing_critical"=>100,
					"remote_queue_length_warning"=>25,
					"remote_queue_length_critical"=>50,
					);
				switch($version){
					case "2010":
						// assumed for 2010 - nagioswiki.com
						$serviceargs_default["core_service_names"]="MSExchangeADTopology,MSExchangeAntispamUpdate,MSExchangeEdgeSync,MSExchangeFDS,MSExchangeImap4,MSExchangeIS,MSExchangeMailboxAssistants,MSExchangeMailSubmission,MSExchangeMonangePop3,MSExchangeRepl,MSExchangeSA,MSExchangeSearch,MSExchangeServiceHost,MSExchangeTransport,MSExchangeTransportLogSearch,msftesql-Exchange";
						break;
					case "2007":
						// known for 2007 - nagioswiki.com
						$serviceargs_default["core_service_names"]="MSExchangeADTopology,MSExchangeAntispamUpdate,MSExchangeEdgeSync,MSExchangeFDS,MSExchangeImap4,MSExchangeIS,MSExchangeMailboxAssistants,MSExchangeMailSubmission,MSExchangeMonangePop3,MSExchangeRepl,MSExchangeSA,MSExchangeSearch,MSExchangeServiceHost,MSExchangeTransport,MSExchangeTransportLogSearch,msftesql-Exchange";
						break;
					case "2003":
						// assumed for 2003 - nagioswiki.com
						$serviceargs_default["core_service_names"]="MSExchangeIS,MSExchangeMTA,SMTPSVC,RESvc";
					case "2000":
						// known for 2000 - nagioswiki.com
						$serviceargs_default["core_service_names"]="MSExchangeIS,MSExchangeMTA,SMTPSVC,RESvc";
						break;
					case "5.5":
					default:
						// known for 5.5 - Nagios Exchange (http://exchange.nagios.org/directory/Plugins/Email-and-Groupware/Microsoft-Exchange/Check-MS-Exchange-Server-Health/details)
						$serviceargs_default["core_service_names"]="MSExchangeDS,MSExchangeES,MSExchangeIMC,MSExchangeIS,MSExchangeMTA,MSExchangeSA ";
						break;
					}
					
				$serviceargs=grab_array_var($inargs,"serviceargs",$serviceargs_default);
				}

	
		
			$output='
			
			
		<input type="hidden" name="address" value="'.htmlentities($address).'">
		<input type="hidden" name="version" value="'.htmlentities($version).'">

	<div class="sectionTitle">Exchange Server Details</div>
	
	<table>

	<tr>
	<td>
	<label>IP Address:</label><br class="nobr" />
	</td>
	<td>
<input type="text" size="40" name="address" id="address" value="'.htmlentities($address).'" class="textfield" disabled/><br class="nobr" />
	</td>
	</tr>

	<tr>
	<td valign="top">
	<label>Server Version:</label><br class="nobr" />
	</td>
	<td><b>Exchange '.htmlentities($version).'</b><br class="nobr" /><br>
	</td>
	</tr>
	
	<tr>
	<td valign="top">
	<label>Host Name:</label><br class="nobr" />
	</td>
	<td>
<input type="text" size="20" name="hostname" id="hostname" value="'.htmlentities($hostname).'" class="textfield" /><br class="nobr" />
	The name you\'d like to have associated with this Exchange server.<br><br>
	</td>
	</tr>
		
	<tr>
	<td valign="top">
	<label>URL:</label><br class="nobr" />
	</td>
	<td>
<input type="text" size="40" name="url" id="url" value="'.htmlentities($url).'" class="textfield" /><br class="nobr" />
	The URL used to access OWA on the Exchange server.<br><br>
	</td>
	</tr>
	
	</table>

	<div class="sectionTitle">Windows Agent</div>
	
	<p>You\'ll need to install the Nagios Windows agent on the Exchange server in order to monitor anything other than basic services.  For security purposes, it is recommended to use a password with the agent.</p>

	<table>

	<tr>
	<td>
	<label>Instructions:</label><br class="nobr" />
	</td>
	<td>
	<a href="http://assets.nagios.com/downloads/nagiosxi/docs/Installing_The_XI_Windows_Agent.pdf" target="_blank"><b>Agent Installation Instructions</b></a>
	</td>
	</tr>
	
	<tr>
	<td>
	<label>Downloads:</label><br class="nobr" />
	</td>
	<td>
	<a href="'.$agent_url.'"></a> <a href="'.$agent_url.'" target="_blank"><b>Agent Downloads Site<b></a>
	</td>
	</tr>
	
	<tr>
	<td valign="top">
	<label>Agent Password:</label><br class="nobr" />
	</td>
	<td>
<input type="text" size="10" name="password" id="password" value="'.htmlentities($password).'" class="textfield" /><br class="nobr" />
	Valid characters include: <b>a-zA-Z0-9 .\:_-</b><br><br>
	</td>
	</tr>

	</table>

	<div class="sectionTitle">Basic Services</div>
	
	<p>Specify which services you\'d like to monitor for the Exchange server.</p>
	
	<table>

	<tr>
	<td valign="top">
	<input type="checkbox" class="checkbox" name="services[ping]"  '.is_checked(checkbox_binary($services["ping"]),"1").'>
	</td>
	<td>
	<b>Ping</b><br>
	Monitors the server with an ICMP "ping".  Useful for watching network latency and general uptime.<br><br>
	</td>
	</tr>

	<tr>
	<td valign="top">
	<input type="checkbox" class="checkbox" name="services[smtp]"  '.is_checked(checkbox_binary($services["smtp"]),"1").'>
	</td>
	<td>
	<b>SMTP</b><br>
	Monitors SMTP service availability.<br><br>
	</td>
	</tr>
	
	<tr>
	<td valign="top">
	<input type="checkbox" class="checkbox" name="services[imap]"  '.is_checked(checkbox_binary($services["imap"]),"1").'>
	</td>
	<td>
	<b>IMAP</b><br>
	Monitors IMAP service availability.<br><br>
	</td>
	</tr>
	
	<tr>
	<td valign="top">
	<input type="checkbox" class="checkbox" name="services[pop]"  '.is_checked(checkbox_binary($services["pop"]),"1").'>
	</td>
	<td>
	<b>POP</b><br>
	Monitors POP service availability.<br><br>
	</td>
	</tr>
	
	<tr>
	<td valign="top">
	<input type="checkbox" class="checkbox" name="services[rbl]"  '.is_checked(checkbox_binary($services["rbl"]),"1").'><br>
	</td>
	<td>
	<b>RBL Blacklist Check</b><br>
	Checks to see if your mail server is listed on any public RBLs (real time blackhole lists).<br>
	<label>Blacklist Servers:</label>
	<input type="text" size="60" name="serviceargs[rbl_servers]" value="'.htmlentities($serviceargs["rbl_servers"]).'" class="textfield" /><br class="nobr" />	
	</td>
	</tr>
	
	
	<tr>
	<td valign="top">
	<input type="checkbox" class="checkbox" name="services[owa_http]"  '.is_checked(checkbox_binary($services["owa_http"]),"1").'>
	</td>
	<td>
	<b>OWA HTTP</b><br>
	Monitors the availability of Outlook Web Access over HTTP.<br><br>
	</td>
	</tr>
	
	<tr>
	<td valign="top">
	<input type="checkbox" class="checkbox" name="services[owa_https]"  '.is_checked(checkbox_binary($services["owa_https"]),"1").'>
	</td>
	<td>
	<b>OWA HTTPS</b><br>
	Monitors the availability of Outlook Web Access over HTTPS (secured with SSL).<br><br>
	</td>
	</tr>
	
	</table>

	<div class="sectionTitle">Exchange Services</div>
	
	<p>
	Specify which Exchange services you\'d like to monitor (these require installation of the Windows agent).
	</p>
	
	<table>
	
	<tr>
	<td valign="top">
	<input type="checkbox" class="checkbox" name="services[core_services]"  '.is_checked(checkbox_binary($services["core_services"]),"1").'><br>
	</td>
	<td>
	<b>Core Services</b><br>
	Checks to make sure core services (specified below) that are essential to Exchange are running.<br>
	<label>Services:</label>
	<input type="text" size="40" name="serviceargs[core_service_names]" value="'.htmlentities($serviceargs["core_service_names"]).'" class="textfield" /><br class="nobr" />
	</td>
	</tr>
	
	<tr>
	<td valign="top">
	<input type="checkbox" class="checkbox" name="services[web_services]"  '.is_checked(checkbox_binary($services["web_services"]),"1").'><br>
	</td>
	<td>
	<b>Web Services</b><br>
	Checks to make sure web services (specified below) that are essential to Exchange are running.<br>
	<label>Services:</label>
	<input type="text" size="10" name="serviceargs[web_service_names]" value="'.htmlentities($serviceargs["web_service_names"]).'" class="textfield" /><br class="nobr" />
	</td>
	</tr>
	
	</table>
	
	<div class="sectionTitle">Exchange Metrics</div>
	
	<p>Specify which metrics you\'d like to monitor on the Exchange server (these require installation of the Windows agent).</p>
	
	<table>
	
	
	<tr>
	<td valign="top">
	<input type="checkbox" class="checkbox" name="services[pending_routing]"  '.is_checked(checkbox_binary($services["pending_routing"]),"1").'><br>
	</td>
	<td>
	<b>Messages Pending Routing</b><br>
		<label>Warning:</label>	<input type="text" size="3" name="serviceargs[pending_routing_warning]" value="'.htmlentities($serviceargs["pending_routing_warning"]).'" class="textfield" />
	<label>Warning:</label>	<input type="text" size="3" name="serviceargs[pending_routing_critical]" value="'.htmlentities($serviceargs["pending_routing_critical"]).'" class="textfield" />

	
	<tr>
	<td valign="top">
	<input type="checkbox" class="checkbox" name="services[remote_queue_length]"  '.is_checked(checkbox_binary($services["remote_queue_length"]),"1").'><br>
	</td>
	<td>
	<b>Remote Queue Length</b><br>
	<label>Warning:</label>	<input type="text" size="3" name="serviceargs[remote_queue_length_warning]" value="'.htmlentities($serviceargs["remote_queue_length_warning"]).'" class="textfield" />
	<label>Warning:</label>	<input type="text" size="3" name="serviceargs[remote_queue_length_critical]" value="'.htmlentities($serviceargs["remote_queue_length_critical"]).'" class="textfield" />
	
	<br class="nobr" />
	</td>
	</tr>

	</table>
	
			';
			break;
			
		case CONFIGWIZARD_MODE_VALIDATESTAGE2DATA:
		
			// get variables that were passed to us
			$address=grab_array_var($inargs,"address");
			$version=grab_array_var($inargs,"version","");
			$hostname=grab_array_var($inargs,"hostname");
			$password=grab_array_var($inargs,"password");
			$url=grab_array_var($inargs,"url","");
			
			// check for errors
			$errors=0;
			$errmsg=array();
			if(is_valid_host_name($hostname)==false)
				$errmsg[$errors++]="Invalid host name.";
			if(preg_match('/[^a-zA-Z0-9 .\:_-]/',$password))
				$errmsg[$errors++]="Password contains invalid characters.";
			if(valid_url($url)==false)
				$errmsg[$errors++]="Invalid URL.";
				
			if($errors>0){
				$outargs[CONFIGWIZARD_ERROR_MESSAGES]=$errmsg;
				$result=1;
				}
				
			break;

			
		case CONFIGWIZARD_MODE_GETSTAGE3HTML:
		
			// get variables that were passed to us
			$address=grab_array_var($inargs,"address");
			$version=grab_array_var($inargs,"version","");
			$hostname=grab_array_var($inargs,"hostname");
			$password=grab_array_var($inargs,"password");
			$url=grab_array_var($inargs,"url","");
			
			$services="";
			$services_serial=grab_array_var($inargs,"services_serial");
			if($services_serial!="")
				$services=unserialize(base64_decode($services_serial));
			else
				$services=grab_array_var($inargs,"services");
				
			$serviceargs="";
			$serviceargs_serial=grab_array_var($inargs,"serviceargs_serial");
			if($serviceargs_serial!="")
				$serviceargs=unserialize(base64_decode($serviceargs_serial));
			else
				$serviceargs=grab_array_var($inargs,"serviceargs");
		
			$output='
			
		<input type="hidden" name="address" value="'.htmlentities($address).'">
		<input type="hidden" name="version" value="'.htmlentities($version).'">
		<input type="hidden" name="url" value="'.htmlentities($url).'">
		<input type="hidden" name="hostname" value="'.htmlentities($hostname).'">
		<input type="hidden" name="password" value="'.htmlentities($password).'">
		<input type="hidden" name="services_serial" value="'.base64_encode(serialize($services)).'">
		<input type="hidden" name="serviceargs_serial" value="'.base64_encode(serialize($serviceargs)).'">
		
		<!--SERVICES='.serialize($services).'<BR>
		SERVICEARGS='.serialize($serviceargs).'<BR>-->
		
			';
			break;
			
		case CONFIGWIZARD_MODE_VALIDATESTAGE3DATA:
				
			break;
			
		case CONFIGWIZARD_MODE_GETFINALSTAGEHTML:
			
			break;
			
		case CONFIGWIZARD_MODE_GETOBJECTS:
		
			$hostname=grab_array_var($inargs,"hostname","");
			$version=grab_array_var($inargs,"version","");
			$address=grab_array_var($inargs,"address","");
			$password=grab_array_var($inargs,"password","");
			$hostaddress=$address;
			$url=grab_array_var($inargs,"url","");
			
			$services_serial=grab_array_var($inargs,"services_serial","");
			$serviceargs_serial=grab_array_var($inargs,"serviceargs_serial","");
			
			$services=unserialize(base64_decode($services_serial));
			$serviceargs=unserialize(base64_decode($serviceargs_serial));
			
			/*
			echo "SERVICES<BR>";
			print_r($services);
			echo "<BR>";
			echo "SERVICEARGS<BR>";
			print_r($serviceargs);
			echo "<BR>";
			*/
			
			// save data for later use in re-entrance
			$meta_arr=array();
			$meta_arr["hostname"]=$hostname;
			$meta_arr["address"]=$address;
			$meta_arr["password"]=$password;
			$meta_arr["services"]=$services;
			$meta_arr["serivceargs"]=$serviceargs;
			save_configwizard_object_meta($wizard_name,$hostname,"",$meta_arr);			
			
			$objs=array();
			
			if(!host_exists($hostname)){
				$objs[]=array(
					"type" => OBJECTTYPE_HOST,
					"use" => "xiwizard_exchange_host",
					"host_name" => $hostname,
					"address" => $hostaddress,
					"icon_image" => "exchange2010.png",
					"statusmap_image" => "exchange2010.png",
					"_xiwizard" => $wizard_name,
					);
				}
				
			// see which services we should monitor
			foreach($services as $svc => $svcstate){
			
				//echo "PROCESSING: $svc -> $svcstate<BR>\n";
		
				switch($svc){
				
					case "ping":
						$objs[]=array(
							"type" => OBJECTTYPE_SERVICE,
							"host_name" => $hostname,
							"service_description" => "Ping",
							"use" => "xiwizard_exchange_ping_service",
							"_xiwizard" => $wizard_name,
							);
						break;
					
					case "imap":
						$objs[]=array(
							"type" => OBJECTTYPE_SERVICE,
							"host_name" => $hostname,
							"service_description" => "IMAP",
							"use" => "xiwizard_imap_service",
							"check_command" => "check_xi_service_imap!-j",
							"_xiwizard" => $wizard_name,
							);
						break;
					
					case "pop":
						$objs[]=array(
							"type" => OBJECTTYPE_SERVICE,
							"host_name" => $hostname,
							"service_description" => "POP",
							"use" => "xiwizard_pop_service",
							"check_command" => "check_xi_service_pop!-j",
							"_xiwizard" => $wizard_name,
							);
						break;
					
					case "smtp":
						$objs[]=array(
							"type" => OBJECTTYPE_SERVICE,
							"host_name" => $hostname,
							"service_description" => "SMTP",
							"use" => "xiwizard_smtp_service",
							"_xiwizard" => $wizard_name,
							);
						break;
					
					case "rbl":
						$objs[]=array(
							"type" => OBJECTTYPE_SERVICE,
							"host_name" => $hostname,
							"service_description" => "Blacklist Status",
							"use" => "xiwizard_exchange_service",
							"check_command" => "check_exchange_rbl!-B ".$serviceargs["rbl_servers"],
							"_xiwizard" => $wizard_name,
							);
						break;
					
					case "owa_http":
					case "owa_https":
					
						$pluginopts="";

						$urlparts=parse_url($url);
						$vhost=$urlparts["host"];
						if($vhost=="")
							$vhost=$address;			
						$pluginopts.=" -H ".$vhost; // virtual host name
						
						$pluginopts.=" -f ok"; // on redirect, follow (OK status)
						$pluginopts.=" -I ".$address; // ip address

						$urlpath=$urlparts["path"];
						if($urlpath=="")
							$urlpath="/";
						$pluginopts.=" -u \"".$urlpath."\"";

						if($svc=="owa_https")
							$pluginopts.=" -S";
						if($port!="")
							$pluginopts.=" -p ".$port;
						if($username!="")
							$pluginopts.=" -a \"".$username.":".$password."\"";

						$sname="OWA HTTP";
						if($svc=="owa_https")
							$sname.="S";
				
						$objs[]=array(
							"type" => OBJECTTYPE_SERVICE,
							"host_name" => $hostname,
							"service_description" => $sname,
							"use" => "xiwizard_exchange_service",
							"check_command" => "check_xi_service_http!".$pluginopts,
							"_xiwizard" => $wizard_name,
							);
						break;
						
					case "core_services":

						$objs[]=array(
							"type" => OBJECTTYPE_SERVICE,
							"host_name" => $hostname,
							"service_description" => "Exchange Core Services",
							"use" => "xiwizard_exchange_service",
							"check_command" => "check_xi_service_nsclient!".$password."!SERVICESTATE!-l ".$serviceargs["core_service_names"]." -d SHOWALL",
							"_xiwizard" => $wizard_name,
							);		
						break;

					case "web_services":

						$objs[]=array(
							"type" => OBJECTTYPE_SERVICE,
							"host_name" => $hostname,
							"service_description" => "Exchange Web Services",
							"use" => "xiwizard_exchange_service",
							"check_command" => "check_xi_service_nsclient!".$password."!SERVICESTATE!-l ".$serviceargs["web_service_names"]." -d SHOWALL",
							"_xiwizard" => $wizard_name,
							);		
						break;
						
					case "pending_routing":

						$checkcommand="check_xi_service_nsclient!".$password."!COUNTER!-l \"\\\\SMTP Server(_Total)\\\\Messages Pending Routing\"";
						if($serviceargs["pending_routing_warning"]!="")
							$checkcommand.=" -w ".$serviceargs["pending_routing_warning"];
						if($serviceargs["pending_routing_critical"]!="")
							$checkcommand.=" -c ".$serviceargs["pending_routing_critical"];
					
						$objs[]=array(
							"type" => OBJECTTYPE_SERVICE,
							"host_name" => $hostname,
							"service_description" => "Messages Pending Routing",
							"use" => "xiwizard_windowsserver_nsclient_service",
							"check_command" => $checkcommand,
							"_xiwizard" => $wizard_name,
							);
							
						break;
						
					case "remote_queue_length":

						$checkcommand="check_xi_service_nsclient!".$password."!COUNTER!-l \"\\\\SMTP Server(_Total)\\\\Remote Queue Length\"";
						if($serviceargs["remote_queue_length_warning"]!="")
							$checkcommand.=" -w ".$serviceargs["remote_queue_length_warning"];
						if($serviceargs["remote_queue_length_critical"]!="")
							$checkcommand.=" -c ".$serviceargs["remote_queue_length_critical"];
					
						$objs[]=array(
							"type" => OBJECTTYPE_SERVICE,
							"host_name" => $hostname,
							"service_description" => "Remote Queue Length",
							"use" => "xiwizard_windowsserver_nsclient_service",
							"check_command" => $checkcommand,
							"_xiwizard" => $wizard_name,
							);
						break;
					
					default:
						break;
					}
				}
				
			//echo "OBJECTS:<BR>";
			//print_r($objs);
			//exit();
					
			// return the object definitions to the wizard
			$outargs[CONFIGWIZARD_NAGIOS_OBJECTS]=$objs;
		
			break;
			
		default:
			break;			
		}
		
	return $output;
	}
	

?>