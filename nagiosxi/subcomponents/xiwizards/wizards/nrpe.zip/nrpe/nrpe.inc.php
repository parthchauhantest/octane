<?php
// NRPE CONFIG WIZARD
//
// Copyright (c) 2010 Nagios Enterprises, LLC.  All rights reserved.
//  
// $Id: nrpe.inc.php 958 2012-12-27 15:52:49Z mguthrie $

include_once(dirname(__FILE__).'/../configwizardhelper.inc.php');

// run the initialization function
nrpe_configwizard_init();

function nrpe_configwizard_init(){
	
	$name="nrpe";
	
	$args=array(
		CONFIGWIZARD_NAME => $name,
        CONFIGWIZARD_VERSION => "1.3",
		CONFIGWIZARD_TYPE => CONFIGWIZARD_TYPE_MONITORING,
		CONFIGWIZARD_DESCRIPTION => gettext("Monitor a remote Linux/Unix server using NRPE."),
		CONFIGWIZARD_DISPLAYTITLE => "NRPE",
		CONFIGWIZARD_FUNCTION => "nrpe_configwizard_func",
		CONFIGWIZARD_PREVIEWIMAGE => "remote.png",
		);

	register_configwizard($name,$args);
	}
	

function nrpe_configwizard_func($mode="",$inargs=null,&$outargs,&$result){

	$wizard_name="nrpe";
	
	// initialize return code and output
	$result=0;
	$output="";
	
	// initialize output args - pass back the same data we got
	$outargs[CONFIGWIZARD_PASSBACK_DATA]=$inargs;


	switch($mode){
		case CONFIGWIZARD_MODE_GETSTAGE1HTML:
		
			$address=grab_array_var($inargs,"address","");
			$osdistro=grab_array_var($inargs,"osdistro","");
		
			$output='

	<div class="sectionTitle">'.gettext('Server Information').'</div>
	
			
	<table>
	
	<tr>
	<td valign="top">
	<label>'.gettext('IP Address').':</label><br class="nobr" />
	</td>
	<td>
<input type="text" size="40" name="address" id="address" value="'.htmlentities($address).'" class="textfield" /><br class="nobr" />
	'.gettext("The IP address or FQDNS name of the server you'd like to monitor").'.<br><br>
	</td>
	</tr>

	<tr>
	<td valign="top">
	<label>'.gettext('Operating System').':</label><br class="nobr" />
	</td>
	<td>
	<select name="osdistro" id="osdistro">

	<option value="AIX" '.is_selected($osdistro,"AIX").'>AIX</option>
	<option value="FreeBSD" '.is_selected($osdistro,"FreeBSD").'>FreeBSD</option>
	<option value="HP-UX" '.is_selected($osdistro,"HP-UX").'>HP-UX</option>


	<option value="CentOS" '.is_selected($osdistro,"CentOS").'>Linux - CentOS</option>
	<option value="Debian" '.is_selected($osdistro,"Debian").'>Linux - Debian</option>
	<option value="Fedora" '.is_selected($osdistro,"Fedora").'>Linux - Fedora Core</option>
	<option value="RHEL" '.is_selected($osdistro,"RHEL").'>Linux - RedHat Enterprise Linux</option>
	<option value="Ubuntu" '.is_selected($osdistro,"Ubuntu").'>Linux - Ubuntu</option>
	<option value="Linux" '.is_selected($osdistro,"Linux").'>Linux - Other</option>

	<option value="NetBSD" '.is_selected($osdistro,"NetBSD").'>NetBSD</option>
	<option value="OpenBSD" '.is_selected($osdistro,"OpenBSD").'>OpenBSD</option>
	<option value="Solaris" '.is_selected($osdistro,"Solaris").'>Solaris</option>

	<option value="Windows" '.is_selected($osdistro,"Windows").'>Windows</option>

	</select>
	<br class="nobr" />
	'.gettext("The operating system running on the server you'd like to monitor").'.
	</td>
	</tr>

	</table>
			';
			break;
			
		case CONFIGWIZARD_MODE_VALIDATESTAGE1DATA:
		
			// get variables that were passed to us
			$address=grab_array_var($inargs,"address","");
			$osdistro=grab_array_var($inargs,"osdistro","");
			
			
			// check for errors
			$errors=0;
			$errmsg=array();
			//$errmsg[$errors++]="Address: '$address'";
			if(have_value($address)==false)
				$errmsg[$errors++]=gettext("No address specified.");
			//else if(!valid_ip($address))
				//$errmsg[$errors++]="Invalid IP address.";
				
			if($errors>0){
				$outargs[CONFIGWIZARD_ERROR_MESSAGES]=$errmsg;
				$result=1;
				}
				
			break;
			
		case CONFIGWIZARD_MODE_GETSTAGE2HTML:
		
			// get variables that were passed to us
			$address=grab_array_var($inargs,"address");
			$osdistro=grab_array_var($inargs,"osdistro","");
            $ssl=grab_array_var($inargs,"ssl","");

			$ha=@gethostbyaddr($address);
			if($ha=="")
				$ha=$address;
			$hostname=grab_array_var($inargs,"hostname",$ha);
			
			//$ipaddress=@gethostbyname($address);
			
			$password="";


			$services="";			
			$services_serial=grab_array_var($inargs,"services_serial","");
			if($services_serial!="")
				$services=unserialize(base64_decode($services_serial));
			if(!is_array($services)){
				$services_default=array(
					"ping" => 1,
					"commands" => array(),
					);
				$services_default["commands"][0]="on";
				$services_default["commands"][1]="on";
				$services_default["commands"][2]="on";
				$services=grab_array_var($inargs,"services",$services_default);
				}
			$serviceargs="";
			$serviceargs_serial=grab_array_var($inargs,"serviceargs_serial","");
			if($serviceargs_serial!="")
				$serviceargs=unserialize(base64_decode($serviceargs_serial));
			if(!is_array($serviceargs)){
				$serviceargs_default=array(			
					"commands" => array(),
					);
				for($x=0;$x<5;$x++){
					if($x==0){
						$serviceargs_default['commands'][$x]['command']='check_users';
						$serviceargs_default['commands'][$x]['args']='';
						$serviceargs_default['commands'][$x]['name']='Current Users';
						}
					else if($x==1){
						$serviceargs_default['commands'][$x]['command']='check_load';
						$serviceargs_default['commands'][$x]['args']='';
						$serviceargs_default['commands'][$x]['name']='Current Load';
						}
					else if($x==2){
						$serviceargs_default['commands'][$x]['command']='check_total_procs';
						$serviceargs_default['commands'][$x]['args']='';
						$serviceargs_default['commands'][$x]['name']='Total Processes';
						}
					else{
						$serviceargs_default['commands'][$x]['command']='';
						$serviceargs_default['commands'][$x]['args']='';
						$serviceargs_default['commands'][$x]['name']='';
                        $services['commands'][$x]='';
						}
					}
					
				$serviceargs=grab_array_var($inargs,"serviceargs",$serviceargs_default);
				}
			

			
		
			$output='
			
			
		<input type="hidden" name="address" value="'.htmlentities($address).'">
		<input type="hidden" name="osdistro" value="'.htmlentities($osdistro).'">

		
	<div class="sectionTitle">'.gettext('Server Details').'</div>
	
	<table>

	<tr>
	<td valign="top">
	<label>'.gettext('IP Address').':</label><br class="nobr" />
	</td>
	<td>
<input type="text" size="40" name="address" id="address" value="'.htmlentities($address).'" class="textfield" disabled/><br class="nobr" />
	</td>
	</tr>
	';

	$icon=nagioscore_get_ui_url()."images/logos/".nrpe_configwizard_get_distro_icon($osdistro);
	
	$output.='
	<tr>
	<td valign="top">
	<label>'.gettext('Operating System').':</label><br class="nobr" />
	</td>
	<td><img src="'.$icon.'" style=""><br>'.$osdistro.'<br class="nobr" />
	</td>
	</tr>

	<tr>
	<td valign="top">
	<label>'.gettext('Host Name').':</label><br class="nobr" />
	</td>
	<td>
<input type="text" size="20" name="hostname" id="hostname" value="'.htmlentities($hostname).'" class="textfield" /><br class="nobr" />
	'.gettext("The name you'd like to have associated with this server").'.
	</td>
	</tr>

	</table>

	<div class="sectionTitle">'.gettext('NRPE Agent').'</div>
	
	<p>'.gettext('Specify options that should be used to communicate with the remote NRPE agent').'.</p>
	
	<table>
	
	<tr>
	<td valign="top">
	<b>'.gettext('SSL Encryption').':</b><br class="nobr" />
	</td>
	<td>
	<select name="ssl" id="ssl">
	<option value="on" '.is_selected($ssl,"on").'>'.gettext('Enabled (Default)').'</option>
	<option value="off" '.is_selected($ssl,"off").'>'.gettext('Disabled').'</option>
	</select>
	<br class="nobr" />
	'.gettext('Determines whether or not data between the Nagios XI server and NRPE agent is encrypted').'.<br>
	<b>'.gettext('Note').'</b>: '.gettext('Legacy NRPE installations may require that SSL support be disabled').'. 
	</td>
	</tr>
	
	</table>


	<div class="sectionTitle">'.gettext('Server Metrics').'</div>
	
	<p>'.gettext("Specify which services you'd like to monitor for the server").'.</p>
	
	<table>

	<tr>
	<td valign="top">
	<input type="checkbox" class="checkbox" name="services[ping]"  '.is_checked(checkbox_binary($services["ping"]),"1").'>
	</td>
	<td>
	<b>'.gettext('Ping').'</b><br>
	'.gettext('Monitors the server with an ICMP Ping.  Useful for watching network latency and general uptime').'.<br><br>
	</td>
	</tr>
	
	</table>
	';


	$output.='
	<div class="sectionTitle">'.gettext('NRPE Commands').'</div>
	
	<p>'.gettext('Specify any remote NRPE commands that should be monitored on the server. Multiple command arguments should be separated with a space').'.</p>
	
	<table class="adddeleterow">
	
	<tr><th></th><th>'.gettext('Remote NRPE Command').'</th><th>'.gettext('Command Args').'</th><th>'.gettext('Display Name').'</th></tr>
	';
	for($x=0;$x<count($services['commands']);$x++){
	
		$commandstring=$serviceargs['commands'][$x]['command'];
		$commandargs=$serviceargs['commands'][$x]['args'];
		$commandname=$serviceargs['commands'][$x]['name'];
		
		$output.='<tr>
		<td><input type="checkbox" class="checkbox" name="services[commands]['.$x.']"  '.is_checked($services["commands"][$x]).'></td>
		<td><input type="text" size="35" name="serviceargs[commands]['.$x.'][command]" value="'.htmlentities($commandstring).'" class="textfield" /></td>
		<td><input type="text" size="15" name="serviceargs[commands]['.$x.'][args]" value="'.htmlentities($commandargs).'" class="textfield" /></td>
		<td><input type="text" size="25" name="serviceargs[commands]['.$x.'][name]" value="'.htmlentities($commandname).'" class="textfield" /></td>
		</tr>';
		}	
	
	$output.='
	</table>

			';
			break;
			
		case CONFIGWIZARD_MODE_VALIDATESTAGE2DATA:
		
			// get variables that were passed to us
			$address=grab_array_var($inargs,"address");
			$hostname=grab_array_var($inargs,"hostname");
			$osdistro=grab_array_var($inargs,"osdistro","");
			
			// check for errors
			$errors=0;
			$errmsg=array();
			if(is_valid_host_name($hostname)==false)
				$errmsg[$errors++]="Invalid host name.";
				
			if($errors>0){
				$outargs[CONFIGWIZARD_ERROR_MESSAGES]=$errmsg;
				$result=1;
				}
				
			break;

			
		case CONFIGWIZARD_MODE_GETSTAGE3HTML:
		
			// get variables that were passed to us
			$address=grab_array_var($inargs,"address");
			$hostname=grab_array_var($inargs,"hostname");
			$osdistro=grab_array_var($inargs,"osdistro","");
			$ssl=grab_array_var($inargs,"ssl","on");
		
			$services="";
			$services_serial=grab_array_var($inargs,"services_serial");
			if($services_serial!="")
				$services=unserialize(base64_decode($services_serial));
			else
				$services=grab_array_var($inargs,"services");
				
			$serviceargs="";
			$serviceargs_serial=grab_array_var($inargs,"serviceargs_serial");
			if($serviceargs_serial!="")
				$serviceargs=unserialize(base64_decode($serviceargs_serial));
			else
				$serviceargs=grab_array_var($inargs,"serviceargs");

			$output='
			
		<input type="hidden" name="address" value="'.$address.'">
		<input type="hidden" name="hostname" value="'.$hostname.'">
		<input type="hidden" name="osdistro" value="'.$osdistro.'">
		<input type="hidden" name="ssl" value="'.$ssl.'">
		<input type="hidden" name="services_serial" value="'.base64_encode(serialize($services)).'">
		<input type="hidden" name="serviceargs_serial" value="'.base64_encode(serialize($serviceargs)).'">
		
		<!--SERVICES='.serialize($services).'<BR>
		SERVICEARGS='.serialize($serviceargs).'<BR>-->
		
			';
			break;
			
		case CONFIGWIZARD_MODE_VALIDATESTAGE3DATA:
				
			break;
			
		case CONFIGWIZARD_MODE_GETFINALSTAGEHTML:
			
			break;
			
		case CONFIGWIZARD_MODE_GETOBJECTS:
		
			$hostname=grab_array_var($inargs,"hostname","");
			$address=grab_array_var($inargs,"address","");
			$osdistro=grab_array_var($inargs,"osdistro","");
			$ssl=grab_array_var($inargs,"ssl","on");
			$hostaddress=$address;
			
			$services_serial=grab_array_var($inargs,"services_serial","");
			$serviceargs_serial=grab_array_var($inargs,"serviceargs_serial","");
			
			$services=unserialize(base64_decode($services_serial));
			$serviceargs=unserialize(base64_decode($serviceargs_serial));
			
			/*
			echo "SERVICES<BR>";
			print_r($services);
			echo "<BR>";
			echo "SERVICEARGS<BR>";
			print_r($serviceargs);
			echo "<BR>";
			*/
			
			// save data for later use in re-entrance
			$meta_arr=array();
			$meta_arr["hostname"]=$hostname;
			$meta_arr["address"]=$address;
			$meta_arr["osdistro"]=$osdistro;
			$meta_arr["services"]=$services;
			$meta_arr["serviceargs"]=$serviceargs;
			save_configwizard_object_meta($wizard_name,$hostname,"",$meta_arr);			
			
			$objs=array();
			
			$icon=nrpe_configwizard_get_distro_icon($osdistro);
			
			if(!host_exists($hostname)){
				$objs[]=array(
					"type" => OBJECTTYPE_HOST,
					"use" => "xiwizard_linuxserver_host",
					"host_name" => $hostname,
					"address" => $hostaddress,
					"icon_image" => $icon,
					"statusmap_image" => $icon,
					"_xiwizard" => $wizard_name,
					);
				}

			// optional non-SSL args to add
			$sslargs="";
			if($ssl=="off")
				$sslargs.=" -n";

			// see which services we should monitor
			foreach($services as $svc => $svcstate){
			
				//echo "PROCESSING: $svc -> $svcstate<BR>\n";
		
				switch($svc){
				
					case "ping":
						$objs[]=array(
							"type" => OBJECTTYPE_SERVICE,
							"host_name" => $hostname,
							"service_description" => "Ping",
							"use" => "xiwizard_linuxserver_ping_service",
							"_xiwizard" => $wizard_name,
							);
						break;
					

					case "commands":
						
						$enabledcmds=$svcstate;
						foreach($enabledcmds as $pid => $pstate){
						
							$pname=$serviceargs["commands"][$pid]["command"];
							$pargs=$serviceargs["commands"][$pid]["args"];
							$pdesc=$serviceargs["commands"][$pid]["name"];
							
							$checkcommand="check_nrpe!".$pname."!".$sslargs;
							if($pargs!="")
								$checkcommand.=" -a ".$pargs."";
						
							$objs[]=array(
								"type" => OBJECTTYPE_SERVICE,
								"host_name" => $hostname,
								"service_description" => $pdesc,
								"use" => "generic-service",
								"check_command" => $checkcommand,
								"_xiwizard" => $wizard_name,
								);		
							}
						break;
					
					default:
						break;
					}
				}
				
			//echo "OBJECTS:<BR>";
			//print_r($objs);
			//exit();
					
			// return the object definitions to the wizard
			$outargs[CONFIGWIZARD_NAGIOS_OBJECTS]=$objs;
		
			break;
			
		default:
			break;			
		}
		
	return $output;
	}
	
	
function nrpe_configwizard_get_distro_icon($osdistro){

	$icon="linux.png";
	
	switch($osdistro){
		case "Solaris":
			$icon="solaris.png";
			break;
		case "AIX":
			$icon="aix.png";
			break;
		case "HP-UX":
			$icon="hp-ux.png";
			break;

		case "FreeBSD":
			$icon="freebsd2.png";
			break;
		case "NetBSD":
			$icon="netbsd.png";
			break;
		case "OpenBSD":
			$icon="openbsd.png";
			break;
			
		case "Windows":
			$icon="windowsxp.png";
			break;

		case "RHEL":
			$icon="redhat.png";
			break;
		case "Fedora":
			$icon="fedora.png";
			break;
		case "CentOS":
			$icon="centos.png";
			break;
		case "Ubuntu":
			$icon="ubuntu.png";
			break;
		case "Debian":
			$icon="debian.png";
			break;
		default:
			break;
		}
		
	return $icon;
	}




?>
