<?php
// MSSQL SERVER CONFIG WIZARD
//
// Copyright (c) 2010 Nagios Enterprises, LLC.  All rights reserved.
//  
// $Id: $

include_once(dirname(__FILE__).'/../configwizardhelper.inc.php');

// run the initialization function
ncpa_configwizard_init();

function ncpa_configwizard_init(){

    $name="ncpa";
    
    $args=array(
        CONFIGWIZARD_NAME => $name,
        CONFIGWIZARD_VERSION => "1.1",
        CONFIGWIZARD_TYPE => CONFIGWIZARD_TYPE_MONITORING,
        CONFIGWIZARD_DESCRIPTION => gettext("Monitor an NCPA Agent"),
        CONFIGWIZARD_DISPLAYTITLE => gettext("NCPA Agent"),
        CONFIGWIZARD_FUNCTION => "ncpa_configwizard_func",
        CONFIGWIZARD_PREVIEWIMAGE => "ncpawithlogo.png",
        );
        
    register_configwizard($name,$args);
    }



function ncpa_configwizard_func($mode="",$inargs=null,&$outargs,&$result){

    $wizard_name="ncpa";
    
    // initialize return code and output
    $result=0;
    $output="";
    
    // initialize output args - pass back the same data we got
    $outargs[CONFIGWIZARD_PASSBACK_DATA]=$inargs;


    switch($mode){
        case CONFIGWIZARD_MODE_GETSTAGE1HTML:
        
            $address=grab_array_var($inargs,"address","");
            $port=grab_array_var($inargs,"port","5693");
            $token=grab_array_var($inargs,"token","");
            $authmode=grab_array_var($inargs, "authmode", "http");
            
            $output='

    <div class="sectionTitle">'.gettext('NCPA Agent').'</div>
    
    <p>
    '.gettext('Specify the connection details of the NCPA agent.').'.
    </p>
            
    <table>

    <tr>
    <td valign="top">
    <label>'.gettext('Address').':</label><br class="nobr" />
    </td>
    <td>
<input type="text" size="40" name="address" id="address" value="'.htmlentities($address).'" class="textfield" /><br class="nobr" />
    '.gettext('The IP address or FQDNS name of the NCPA Agent.').'.<br><br>
    </td>
    </tr>
    
    <tr>
    <td valign="top">
    <label>'.gettext('Port').':</label><br class="nobr" />
    </td>
    <td>
<input type="text" size="5" name="port" id="port" value="'.htmlentities($port).'" class="textfield" /><br class="nobr" />
    '.gettext('Defaults to port 5693.').'.<br /><br />
    </td>
    </tr>

    <tr>
    <td valign="top">
    <label>'.gettext('Token').':</label><br class="nobr" />
    </td>
    <td>
<input type="text" size="20" name="token" id="token" value="'.htmlentities($token).'" class="textfield" /><br class="nobr" />
    '.gettext('Authentication token used to connect to the NCPA Agent.').'.<br><br>
    </td>
    </tr>

    </table>';
            break;
        
        case CONFIGWIZARD_MODE_VALIDATESTAGE1DATA:
        
            // get variables that were passed to us
            $address=grab_array_var($inargs, "address", "");
            $port=grab_array_var($inargs, "port", "");
            $token=grab_array_var($inargs, "token","");
            
            // check for errors
            $errors=0;
            $errmsg=array();
            
            if(have_value($address)==false) {
                $errmsg[$errors++]="No address specified.";
            }
            if(have_value($port)==false) {
                $errmsg[$errors++]="No port number specified.";
            }
            if(have_value($token)==false) {
                $errmsg[$errors++]="No token specified.";
            }
            /* The URL we will use to query the NCPA agent, and do a walk
             * of all monitorable items. */
            $query_url = "https://{$address}:{$port}/testconnect?token={$token}";
            /* All we want to do is test if we can hit this URL. */
            $raw_json = file_get_contents($query_url, 0, null, null);
            if(empty($raw_json)) {
                $errmsg[$errors++]="Unable to contact server at {$query_url}.";
            }
            else {
                $json = json_decode($raw_json, true);
                if(!array_key_exists('value', $json)) {
                    $errmsg[$errors++]="Bad token for connection.";
                }
            }
            if($errors>0){
                $outargs[CONFIGWIZARD_ERROR_MESSAGES]=$errmsg;
                $result=1;
            }
            break;
        
        case CONFIGWIZARD_MODE_GETSTAGE2HTML:
        
            // get variables that were passed to us
            $address=grab_array_var($inargs,"address");
            $port=grab_array_var($inargs,"port","");
            $token=grab_array_var($inargs,"token","");
            $authmode=grab_array_var($inargs,"authmode","http");
            $hostname=grab_array_var($inargs,"hostname",$address);
            $services_serial=grab_array_var($inargs, "services_serial", "");
            if($services_serial) {
                $services = unserialize(base64_decode($services_serial));
            }
            /* The URL we will use to query the NCPA agent, and do a walk
             * of all monitorable items. */
            $query_url = "https://{$address}:{$port}/api?token={$token}";
            $raw_json = file_get_contents($query_url, 0, null, null);
            $agent_data = json_decode($raw_json, true);
            
            $categories = array();
            $root = $agent_data['value']['root'];
            
            
            
            $output = "
            <input type='hidden' name='address' value='".htmlentities($address)."' />
            <input type='hidden' name='port' value='".htmlentities($port)."' />
            <input type='hidden' name='instance' value='".htmlentities($token)."' />
            <input type='hidden' name='authmode' value='".htmlentities($authmode)."' />
            <input type='hidden' name='token' value='".htmlentities($token)."' />";
        
    $output .= '
    
    <div class="sectionTitle">'.gettext('NCPA Agent').'</div>
    
    <table>
    
    <tr>
    <td valign="top">
    <label>Address:</label><br class="nobr" />
    </td>
    <td>
<input type="text" size="20" name="address" id="address" value="'.htmlentities($address).'" class="textfield" disabled/><br class="nobr" />
    </td>
    </tr>

    <tr>
    <td valign="top">
    <label>'.gettext('Host Name').':</label><br class="nobr" />
    </td>
    <td>
<input type="text" size="20" name="hostname" id="hostname" value="'.htmlentities($hostname).'" class="textfield" /><br class="nobr" />
    '.gettext('The name you\'d like to have associated with this NCPA Agent').'.
    </td>
    </tr>
    
    
    <tr>
    <td valign="top">
    <label>'.gettext('Port').':</label><br class="nobr" />
    </td>
    <td>
<input type="text" size="5" name="port" id="port" value="'.htmlentities($port).'" class="textfield" disabled/><br class="nobr" />
    </td>
    </tr>

    <tr>
    <td valign="top">
    <label>'.gettext('Token').':</label><br class="nobr" />
    </td>
    <td>
<input type="text" size="20" name="token" id="token" value="'.htmlentities($token).'" class="textfield" disabled/><br class="nobr" />
    </td>
    </tr>

    </table>';
    
    
    $default_services['cpu_usage']['monitor'] = 'on';
    $default_services['cpu_usage']['warning'] = 20;
    $default_services['cpu_usage']['critical'] = 40;
    
    $default_services['memory_usage']['monitor'] = 'on';
    $default_services['memory_usage']['warning'] = 50;
    $default_services['memory_usage']['critical'] = 80;
    
    $default_services['swap_usage']['monitor'] = 'on';
    $default_services['swap_usage']['warning'] = 50;
    $default_services['swap_usage']['critical'] = 80;
    
    foreach($root['disk']['logical'] as $title => $value) {
        $default_services['disk'][$title]['monitor'] = 'on';
        $default_services['disk'][$title]['warning'] = 70;
        $default_services['disk'][$title]['critical'] = 90;
        $default_services['disk'][$title]['name'] = str_replace("|", "/", $title);
    }
    
    foreach($root['interface'] as $title => $value) {
        $default_services['interface'][$title]['monitor'] = 'on';
        $default_services['interface'][$title]['warning'] = 10;
        $default_services['interface'][$title]['critical'] = 100;
        $default_services['interface'][$title]['name'] = $title;
    }
    
    for($i=0;$i<5;$i++) {
        $default_services['process'][$i]['monitor'] = 'off';
        $default_services['process'][$i]['name'] = '';
        $default_services['process'][$i]['display_name'] = '';
        $default_services['process'][$i]['count']['warning'] = 60;
        $default_services['process'][$i]['count']['critical'] = 100;
    }
    
    if(!isset($services)) {
        $services = $default_services;
    }
    
    $output .= '

    <div class="sectionTitle">'.gettext('CPU Metrics').'</div>
    
    <p>'.gettext('Specify the metrics you\'d like to monitor on the NCPA Agent').'.</p>
    
    
    <table>
    
    <tr>
    <td valign="top">
    <input type="checkbox" class="checkbox" name="services[cpu_usage][monitor]" '.is_checked(grab_array_var($services['cpu_usage'],"monitor"),"on").' />
    </td>
    <td>
    <b>'.gettext('CPU Usage').'</b><br> 
    '.gettext('Check the CPU Usage of the system.').'.<br>
    <label>'.gettext('Warning Threshold').':</label> 
    <input type="text" size="1" name="services[cpu_usage][warning]" value="'.htmlentities($services['cpu_usage']['warning']).'" />%&nbsp;&nbsp;
    <label>'.gettext('Critical Threshold').':</label>
    <input type="text" size="1" name="services[cpu_usage][critical]" value="'.htmlentities($services['cpu_usage']['critical']).'" />%
    <br /><br />
    </td>
    </tr>
    
    </table>
    
    <div class="sectionTitle">'.gettext('Memory Metrics').'</div>
    
    <table>
    
    <tr>
    <td valign="top">
    <input type="checkbox" class="checkbox" name="services[memory_usage][monitor]" '.is_checked(grab_array_var($services['memory_usage'],'monitor'),'monitor').' />
    </td>
    <td>
    <b>'.gettext('Main Memory Usage').'</b><br /> 
    '.gettext('Monitor the main memory of the system. This metric is the percentage of main memory used.').'.<br />
    <label>'.gettext('Warning Threshold').':</label>
    <input type="text" size="2" name="services[memory_usage][warning]" value="'.htmlentities($services['memory_usage']['warning']).'" />%&nbsp;&nbsp;
    <label>'.gettext('Critical Threshold').':</label>
    <input type="text" size="2" name="services[memory_usage][critical]" value="'.htmlentities($services['memory_usage']['critical']).'" />%
    <br /><br />
    </td>
    </tr>
    
    <tr>
    <td valign="top">
    <input type="checkbox" class="checkbox" name="services[swap_usage][monitor]" '.is_checked(grab_array_var($services['swap_usage'],'monitor'), 'on').' />
    </td>
    <td>
    <b>'.gettext('Swap Usage').'</b><br> 
    '.gettext('Monitor the percentage of allocated swap used by the system.').'.<br>
    <label>'.gettext('Warning Threshold').':</label> 
    <input type="text" size="2" name="services[swap_usage][warning]" value="'.htmlentities($services['swap_usage']['warning']).'" />%&nbsp;&nbsp;
    <label>'.gettext('Critical Threshold').':</label>
    <input type="text" size="2" name="services[swap_usage][critical]" value="'.htmlentities($services['swap_usage']['critical']).'" />%
    <br /><br />
    </td>
    </tr>
    
    </table>
    
    <div class="sectionTitle">'.gettext('Disk Metrics').'</div>
    Specify the disks the the warning and critical percentages for disk capacity.<br />
    
    <table>';
    
    
    foreach($services['disk'] as $title => $metrics) {
        $output .= '
        <tr>
        <td valign="top">
        <input type="checkbox" class="checkbox" name="services[disk]['.$title.'][monitor]" '.is_checked(grab_array_var($services['disk'][$title],'monitor'), 'on').' />
        </td>
        <td>
        <input type="text" name="services[disk]['.$title.'][name]" value="'.htmlentities(str_replace("|", "/", $title)).'" disabled/>
        <label>'.gettext('Warning Threshold').':</label> 
        <input type="text" size="2" name="services[disk]['.$title.'][warning]" value="'.htmlentities($services['disk'][$title]['warning']).'">%&nbsp;&nbsp;
        <label>'.gettext('Critical Threshold').':</label> 
        <input type="text" size="2" name="services[disk]['.$title.'][critical]" value="'.htmlentities($services['disk'][$title]['critical']).'" />%
        <br /><br />
        </td>
        </tr>
    ';
    }
    
    $output .= '</table>
    
    <div class="sectionTitle">'.gettext('Network Interface Metrics').'</div>
    Specify reasonable bandwidths for your network interfaces. Note that these measurements are in megabits.<br />
    
    <table>';
    
    
    foreach($services['interface'] as $title => $metrics) {
        $output .= '
        <tr>
        <td valign="top">
        <input type="checkbox" class="checkbox" name="services[interface]['.$title.'][monitor]" '.is_checked(grab_array_var($services['interface'][$title],'monitor'), 'on').' />
        </td>
        <td>
        <input type="text" name="services[interface]['.$title.'][name]" value="'.htmlentities(str_replace("|", "/", $title)).'" disabled/>
        <label>'.gettext('Warning Threshold').':</label> 
        <input type="text" size="2" name="services[interface]['.$title.'][warning]" value="'.htmlentities($services['interface'][$title]['warning']).'">Mb&nbsp;&nbsp;
        <label>'.gettext('Critical Threshold').':</label> 
        <input type="text" size="2" name="services[interface]['.$title.'][critical]" value="'.htmlentities($services['interface'][$title]['critical']).'" />Mb
        <br /><br />
        </td>
        </tr>
    ';
    }
    
    $output .= '</table>
    
    <div class="sectionTitle">'.gettext('Running Processes').'</div>
    Specify which processes should be running, and how many should be.<br />
    
    <table>
    
    <tr>
    <td></td>
    <td><label>Process Name</label></td>
    <td><label>Display Name</label></td>
    <td><label>Warning<br />Count</label></td>
    <td><label>Critical<br />Count</label></td>
    </tr>
    ';
    
    foreach($services['process'] as $i => $metrics) {
        $output .= '
        <tr>
        <td valign="top">
        <input type="checkbox" class="checkbox deselect" name="services[process]['.$i.'][monitor]" '.is_checked(grab_array_var($services['process'][$i],'monitor'), 'on').' />
        </td>
        <td>
        <input type="text" class="destext" name="services[process]['.$i.'][name]" value="'.htmlentities($metrics['name']).'" />
        </td>
        <td>
        <input type="text" class="destext" name="services[process]['.$i.'][display_name]" value="'.htmlentities($metrics['display_name']).'" />
        </td>
        <td>
        <input type="text" class="destext" size="2" name="services[process]['.$i.'][count][warning]" value="'.htmlentities($metrics['count']['warning']).'" />
        </td>
        <td>
        <input type="text" class="destext" size="2" name="services[process]['.$i.'][count][critical]" value="'.htmlentities($metrics['count']['critical']).'" />
        </td>
        </tr>
    ';
    }
    
    $output .= '</table>';
    
            break;
            
        case CONFIGWIZARD_MODE_VALIDATESTAGE2DATA:
        
            // get variables that were passed to us
            $address=grab_array_var($inargs, 'address');
            $hostname=grab_array_var($inargs, 'hostname');
            $port=grab_array_var($inargs, 'port');
            $token=grab_array_var($inargs, 'token');
        
            // check for errors
            $errors=0;
            $errmsg=array();
            if(is_valid_host_name($hostname)==false)
                $errmsg[$errors++]="Invalid host name.";
                
            if($errors>0){
                $outargs[CONFIGWIZARD_ERROR_MESSAGES]=$errmsg;
                $result=1;
                }
                
            break;

            
        case CONFIGWIZARD_MODE_GETSTAGE3HTML:
        
            // get variables that were passed to us
            $address=grab_array_var($inargs, 'address');
            $hostname=grab_array_var($inargs, 'hostname');
            $port=grab_array_var($inargs, 'port');
            $token=grab_array_var($inargs, 'token');
            
            $services=grab_array_var($inargs, 'services', array());
            
        
            $output='
            
        <input type="hidden" name="address" value="'.htmlentities($address).'" />
        <input type="hidden" name="hostname" value="'.htmlentities($hostname).'" />
        <input type="hidden" name="port" value="'.htmlentities($port).'" />
        <input type="hidden" name="token" value="'.htmlentities($token).'" />
        <input type="hidden" name="services_serial" value="'.base64_encode(serialize($services)).'" />
        
        ';
            // print_r($services);
            break;
            
        case CONFIGWIZARD_MODE_VALIDATESTAGE3DATA:
                
            break;
            
        case CONFIGWIZARD_MODE_GETFINALSTAGEHTML:
            
            
            $output='
            ';
            break;
            
        case CONFIGWIZARD_MODE_GETOBJECTS:
        
            $hostname=grab_array_var($inargs,"hostname","");
            $address=grab_array_var($inargs,"address","");
            $hostaddress=$address;
            $port=grab_array_var($inargs,"port","");
            $token=grab_array_var($inargs,"token","");
        
            $services_serial=grab_array_var($inargs,"services_serial","");
            
            $services=unserialize(base64_decode($services_serial));
            
            
            // echo "SERVICES<br />";
            // print_r($services);
            // echo "<br />";
            
            // save data for later use in re-entrance
            $meta_arr=array();
            $meta_arr["hostname"]=$hostname;
            $meta_arr["address"]=$address;
            $meta_arr["port"]=$port;
            $meta_arr["token"]=$token;
            $meta_arr["services"]=$services;
            save_configwizard_object_meta($wizard_name, $hostname, "",$meta_arr);         
            
            $objs=array();
            
            if(!host_exists($hostname)){
                $objs[]=array(
                    "type" => OBJECTTYPE_HOST,
                    "use" => "xiwizard_ncpa_host",
                    "host_name" => $hostname,
                    "address" => $hostaddress,
                    "icon_image" => "ncpa.png",
                    "statusmap_image" => "ncpa.png",
                    "_xiwizard" => $wizard_name,
                    );
                }
            
            // common plugin opts
            $commonopts="-t '$token' ";
            if($port)
                $commonopts .= "-P $port ";

            foreach($services as $type => $args){
                
                $pluginopts="";
                $pluginopts.=$commonopts;
                
                switch($type){
                                
                    case "cpu_usage":
                        
                        if(!array_key_exists('monitor', $args))  {
                            break;
                        }
                        
                        $pluginopts.="-M cpu/percent -w ".$args["warning"]." -c ".$args["critical"] ;
                    
                        $objs[]=array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => "CPU Usage",
                            "use" => "xiwizard_ncpa_service",
                            "check_command" => "check_xi_ncpa_agent!".$pluginopts,
                            "_xiwizard" => $wizard_name,
                            );
                        break;
                                
                    case "memory_usage":
                        
                        if(!array_key_exists('monitor', $args))  {
                            break;
                        }
                        
                        $pluginopts.="-M memory/virtual/percent -w ".$args["warning"]." -c ".$args["critical"] ;
                    
                        $objs[]=array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => "Main Memory Usage",
                            "use" => "xiwizard_ncpa_service",
                            "check_command" => "check_xi_ncpa_agent!".$pluginopts,
                            "_xiwizard" => $wizard_name,
                            );
                        break;
                                
                    case "swap_usage":
                        
                        if(!array_key_exists('monitor', $args))  {
                            break;
                        }
                        
                        $pluginopts.="-M memory/swap/percent -w ".$args["warning"]." -c ".$args["critical"] ;
                    
                        $objs[]=array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => "Swap Usage",
                            "use" => "xiwizard_ncpa_service",
                            "check_command" => "check_xi_ncpa_agent!".$pluginopts,
                            "_xiwizard" => $wizard_name,
                            );
                        break;          
                        

                    case "disk":
                        
                        foreach($args as $title => $metrics) {
                            
                            if(!array_key_exists('monitor', $metrics))  {
                                continue;
                            }
                            
                            $theseopts="{$pluginopts} -M 'disk/logical/{$title}/used_percent' -w ".$metrics["warning"]." -c ".$metrics["critical"] ;
                        
                            $objs[]=array(
                                "type" => OBJECTTYPE_SERVICE,
                                "host_name" => $hostname,
                                "service_description" => "Disk Usage on ".str_replace('/', '|', $title),
                                "use" => "xiwizard_ncpa_service",
                                "check_command" => "check_xi_ncpa_agent!".$theseopts,
                                "_xiwizard" => $wizard_name,
                                );
                        }
                        break;
                    
                    case "interface":
                        
                        foreach($args as $title => $metrics) {
                            
                            if(!array_key_exists('monitor', $metrics))  {
                                continue;
                            }
                            
                            $theseopts="{$pluginopts} -M 'interface/{$title}/bytes_sent' -d -u M -w ".$metrics["warning"]." -c ".$metrics["critical"] ;
                        
                            $objs[]=array(
                                "type" => OBJECTTYPE_SERVICE,
                                "host_name" => $hostname,
                                "service_description" => "Outbound Bandwidth on {$title}",
                                "use" => "xiwizard_ncpa_service",
                                "check_command" => "check_xi_ncpa_agent!".$theseopts,
                                "_xiwizard" => $wizard_name,
                                );
                            
                            $theseopts="{$pluginopts} -M 'interface/{$title}/bytes_recv' -d -u M -w ".$metrics["warning"]." -c ".$metrics["critical"] ;
                        
                            $objs[]=array(
                                "type" => OBJECTTYPE_SERVICE,
                                "host_name" => $hostname,
                                "service_description" => "Inbound Bandwidth on {$title}",
                                "use" => "xiwizard_ncpa_service",
                                "check_command" => "check_xi_ncpa_agent!".$theseopts,
                                "_xiwizard" => $wizard_name,
                                );
                            
                        }
                        break;
                    
                    case "process":
                        
                        foreach($args as $i => $metrics) {
                            
                            if(!array_key_exists('monitor', $metrics))  {
                                continue;
                            }
                            
                            $proc_name = $metrics['name'];
                            $display = $metrics['display_name'];
                            
                            $theseopts="{$pluginopts} -M 'process/{$proc_name}/count' -w ".$metrics["count"]["warning"]." -c ".$metrics["count"]["critical"] ;
                        
                            $objs[]=array(
                                "type" => OBJECTTYPE_SERVICE,
                                "host_name" => $hostname,
                                "service_description" => "Instances of {$display}",
                                "use" => "xiwizard_ncpa_service",
                                "check_command" => "check_xi_ncpa_agent!".$theseopts,
                                "_xiwizard" => $wizard_name,
                                );
                            
                        }
                        break;
                        
                                        

                    default:
                        break;
                    }
                }
                
            //~ echo "OBJECTS:<BR>";
            //~ print_r($objs);
            //~ exit();
                    
            // return the object definitions to the wizard
            $outargs[CONFIGWIZARD_NAGIOS_OBJECTS]=$objs;
        
            break;
            
        default:
            break;          
        }
        
    return $output;
    }
    

?>
